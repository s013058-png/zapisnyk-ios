package com.my.zapisnyk


import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor


// ==========================================
// 11. РАЗДЕЛ ВЛОЖЕНИЯ (ФОТО И ВИДЕОЗАПИСИ)
// ==========================================

enum class AttachmentFilterType(val label: String) { ALL("Все"), PHOTOS("Фотографии"), VIDEOS("Видеозаписи") }

data class MediaAttachmentItem(
    val path: String,
    val date: Long,
    val isVideo: Boolean,
    val noteTitle: String? = null,
    val noteContent: String? = null
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AttachmentsScreen(
    dao: DiaryDao,
    notes: List<DiaryNote>,
    nav: NavController,
    onOpenDateNote: (Long) -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var filterType by remember { mutableStateOf(AttachmentFilterType.ALL) }
    var fullScreenItem by remember { mutableStateOf<MediaAttachmentItem?>(null) }
    var itemToDelete by remember { mutableStateOf<MediaAttachmentItem?>(null) }
    var targetDateForNewMedia by remember { mutableLongStateOf(System.currentTimeMillis().toMidnight()) }

    var showUrlDialog by remember { mutableStateOf(false) }
    var inputUrl by remember { mutableStateOf("") }
    var customTitle by remember { mutableStateOf("") }
    var isDownloading by remember { mutableStateOf(false) }
    var downloadStatus by remember { mutableStateOf("") }
    var downloadErrorDetails by remember { mutableStateOf<String?>(null) }

    suspend fun attachPathToDate(targetDate: Long, path: String, title: String? = null) {
        try {
            val existing = dao.getNoteByDateSync(targetDate)
            val curPaths = parseMediaPaths(existing?.mediaPaths)
            val newPaths = (curPaths + path).distinct()
            val note = if (existing != null) {
                existing.copy(
                    title = if (!title.isNullOrBlank() && (existing.title ?: "").isBlank()) title else (existing.title ?: ""),
                    content = existing.content ?: "",
                    mediaPaths = Gson().toJson(newPaths),
                    mainMediaPath = existing.mainMediaPath ?: "",
                    mood = existing.mood ?: "",
                    tags = existing.tags ?: "",
                    location = existing.location ?: ""
                )
            } else {
                DiaryNote(
                    date = targetDate,
                    title = title ?: "",
                    content = "",
                    mediaPaths = Gson().toJson(newPaths),
                    mainMediaPath = "",
                    mood = "",
                    tags = "",
                    location = ""
                )
            }
            dao.insertNote(note)
        } catch (e: Throwable) {
            Log.e("Zapisnyk", "attachPathToDate error: ${e.message}", e)
        }
    }

    // Все вложения последовательно, начиная с последней даты
    val allMediaItems = remember(notes) {
        val list = mutableListOf<MediaAttachmentItem>()
        notes.forEach { note ->
            val paths = parseMediaPaths(note.mediaPaths)
            val main = note.mainMediaPath ?: ""
            val combined = if (main.isNotBlank() && !paths.contains(main)) {
                listOf(main) + paths
            } else {
                paths
            }
            combined.distinct().forEach { p ->
                val isYt = isYouTubeUrl(p)
                val isWeb = p.startsWith("http://") || p.startsWith("https://") || p.startsWith("content://") || isYt || p.startsWith("yt:")
                val exists = if (!isWeb) {
                    try { File(p).exists() } catch (_: Throwable) { false }
                } else true
                if (isWeb || exists) {
                    list.add(
                        MediaAttachmentItem(
                            path = p,
                            date = note.date,
                            isVideo = isVideoPath(p),
                            noteTitle = note.title,
                            noteContent = note.content
                        )
                    )
                }
            }
        }
        // Сортировка: все фотографии/видео идут последовательно с последней даты (от новых к старым)
        list.sortedByDescending { it.date }
    }

    val photosCount = remember(allMediaItems) { allMediaItems.count { !it.isVideo } }
    val videosCount = remember(allMediaItems) { allMediaItems.count { it.isVideo } }

    val filteredItems = remember(allMediaItems, filterType) {
        when (filterType) {
            AttachmentFilterType.ALL -> allMediaItems
            AttachmentFilterType.PHOTOS -> allMediaItems.filter { !it.isVideo }
            AttachmentFilterType.VIDEOS -> allMediaItems.filter { it.isVideo }
        }
    }

    fun handlePickedUris(uris: List<Uri>) {
        if (uris.isEmpty()) return
        scope.launch(Dispatchers.Default) {
            val copied = uris.mapNotNull { uri ->
                try {
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(context.contentResolver.getType(uri)) ?: "jpg"
                    val file = File(context.filesDir, "media_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.$ext")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        file.outputStream().use { output -> input.copyTo(output) }
                    }
                    file.absolutePath
                } catch (_: Exception) {
                    null
                }
            }
            if (copied.isNotEmpty()) {
                if (copied.any { isVideoPath(it) }) {
                    VideoLimitManager.recordVideoLoaded(context)
                }
                val existing = dao.getNoteByDateSync(targetDateForNewMedia)
                val curPaths = parseMediaPaths(existing?.mediaPaths)
                val newPaths = curPaths + copied
                val note = if (existing != null) {
                    existing.copy(mediaPaths = Gson().toJson(newPaths))
                } else {
                    DiaryNote(date = targetDateForNewMedia, mediaPaths = Gson().toJson(newPaths))
                }
                dao.insertNote(note)
                withContext(Dispatchers.Main) {
                    val df = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(targetDateForNewMedia))
                    Toast.makeText(context, "Добавлено ${copied.size} медиа к дате $df", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris -> handlePickedUris(uris) }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris -> handlePickedUris(uris) }

    fun deleteItem(item: MediaAttachmentItem) {
        scope.launch(Dispatchers.Default) {
            try {
                val note = dao.getNoteByDateSync(item.date)
                if (note != null) {
                    val curPaths = parseMediaPaths(note.mediaPaths)
                    val updated = curPaths.filter { it != item.path }
                    val newMain = if (note.mainMediaPath == item.path) "" else (note.mainMediaPath ?: "")
                    dao.insertNote(note.copy(mediaPaths = Gson().toJson(updated), mainMediaPath = newMain))
                    if (!item.path.startsWith("http://") && !item.path.startsWith("https://") && !item.path.startsWith("content://")) {
                        try {
                            val f = File(item.path)
                            if (f.exists()) f.delete()
                        } catch (_: Exception) {}
                    }
                }
                withContext(Dispatchers.Main) {
                    if (fullScreenItem?.path == item.path) fullScreenItem = null
                    itemToDelete = null
                    Toast.makeText(context, "Вложение удалено", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) {
                    itemToDelete = null
                    Toast.makeText(context, "Ошибка при удалении: ${e.message}", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        // Верхняя информационная плашка
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "Галерея вложений",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "Всего: ${allMediaItems.size} (Фото: $photosCount, Видео: $videosCount)",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                Text(
                    "От новых к старым",
                    fontSize = 10.sp,
                    color = MaterialTheme.colorScheme.primary,
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        // Основная сетка фотографий и видеозаписей
        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            if (filteredItems.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) {
                    Icon(
                        if (filterType == AttachmentFilterType.VIDEOS) Icons.Default.Videocam else Icons.Default.PhotoLibrary,
                        contentDescription = null,
                        modifier = Modifier.size(56.dp),
                        tint = Color.Gray.copy(alpha = 0.5f)
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        when (filterType) {
                            AttachmentFilterType.PHOTOS -> "Нет фотографий"
                            AttachmentFilterType.VIDEOS -> "Нет видеозаписей"
                            AttachmentFilterType.ALL -> "Нет прикреплённых вложений"
                        },
                        fontWeight = FontWeight.SemiBold,
                        color = Color.Gray
                    )
                    Text(
                        "Используйте кнопки снизу для выбора фото или видео",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    contentPadding = PaddingValues(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 12.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    itemsIndexed(filteredItems, key = { index, item -> "${item.date}_${item.path}_$index" }) { _, item ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    if (item.isVideo) {
                                        openVideo(context, item.path)
                                    } else {
                                        fullScreenItem = item
                                    }
                                }
                        ) {
                            Column(Modifier.fillMaxWidth()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .aspectRatio(1f)
                                        .background(Color.Black.copy(alpha = 0.05f))
                                ) {
                                    SafeMediaThumbnail(
                                        path = item.path,
                                        isVideo = item.isVideo,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                }

                                // СНИЗУ МАЛЕНЬКИМИ ЦИФРАМИ ДАТА ГОД МЕСЯЦ
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 4.dp, vertical = 3.dp),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(item.date)),
                                            fontSize = 9.5.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                                            maxLines = 1
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ПАНЕЛЬ СНИЗУ: ВЫБОР ФИЛЬТРА (ФОТО/ВИДЕО) И ВЫБОР/ДОБАВЛЕНИЕ НОВЫХ ФАЙЛОВ
        Surface(
            tonalElevation = 6.dp,
            shadowElevation = 8.dp,
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                // Фильтр выбора медиа: Все / Фотографии / Видеозаписи
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = filterType == AttachmentFilterType.ALL,
                        onClick = { filterType = AttachmentFilterType.ALL },
                        label = {
                            Text(
                                "Все (${allMediaItems.size})",
                                fontSize = 11.sp,
                                fontWeight = if (filterType == AttachmentFilterType.ALL) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = filterType == AttachmentFilterType.PHOTOS,
                        onClick = { filterType = AttachmentFilterType.PHOTOS },
                        leadingIcon = { Icon(Icons.Default.Photo, null, modifier = Modifier.size(13.dp)) },
                        label = {
                            Text(
                                "Фото ($photosCount)",
                                fontSize = 11.sp,
                                fontWeight = if (filterType == AttachmentFilterType.PHOTOS) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )
                    FilterChip(
                        selected = filterType == AttachmentFilterType.VIDEOS,
                        onClick = { filterType = AttachmentFilterType.VIDEOS },
                        leadingIcon = { Icon(Icons.Default.Videocam, null, modifier = Modifier.size(13.dp)) },
                        label = {
                            Text(
                                "Видео ($videosCount)",
                                fontSize = 11.sp,
                                fontWeight = if (filterType == AttachmentFilterType.VIDEOS) FontWeight.Bold else FontWeight.Normal
                            )
                        },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(Modifier.height(6.dp))

                // Кнопки выбора медиа: Фотографии, Видеозаписи, По ссылке
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = {
                            photoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("Фото", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = {
                            if (!VideoLimitManager.checkAndWarn(context)) {
                                return@OutlinedButton
                            }
                            videoPickerLauncher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Videocam, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("Видео", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }

                    OutlinedButton(
                        onClick = {
                            inputUrl = ""
                            customTitle = ""
                            showUrlDialog = true
                        },
                        modifier = Modifier.weight(1f),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 8.dp),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(15.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("По ссылке", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                    }
                }

                // Дата привязки для новых медиафайлов
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dateFormatted = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(targetDateForNewMedia))
                    val isToday = targetDateForNewMedia == System.currentTimeMillis().toMidnight()
                    Text(
                        text = "Привязка к дате: ${if (isToday) "Сегодня ($dateFormatted)" else dateFormatted}",
                        fontSize = 10.5.sp,
                        color = Color.Gray
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = "Сменить дату",
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable {
                            val c = Calendar.getInstance().apply { timeInMillis = targetDateForNewMedia }
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val sel = Calendar.getInstance().apply {
                                        set(y, m, d, 0, 0, 0)
                                        set(Calendar.MILLISECOND, 0)
                                    }
                                    targetDateForNewMedia = sel.timeInMillis
                                },
                                c.get(Calendar.YEAR),
                                c.get(Calendar.MONTH),
                                c.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }
                    )
                }
            }
        }
    }

    // ПОЛНОЭКРАННЫЙ ПРОСМОТР
    if (fullScreenItem != null) {
        val cur = fullScreenItem!!
        Dialog(
            onDismissRequest = { fullScreenItem = null },
            properties = DialogProperties(usePlatformDefaultWidth = false)
        ) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black)
            ) {
                SafeMediaThumbnail(
                    path = cur.path,
                    isVideo = cur.isVideo,
                    contentScale = ContentScale.Fit,
                    modifier = Modifier
                        .fillMaxSize()
                        .clickable {
                            if (cur.isVideo) {
                                openVideo(context, cur.path)
                            } else {
                                fullScreenItem = null
                            }
                        }
                )

                // Верхняя плашка действий
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.TopCenter)
                        .background(Brush.verticalGradient(listOf(Color.Black.copy(0.75f), Color.Transparent)))
                        .padding(horizontal = 8.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { fullScreenItem = null }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад", tint = Color.White)
                    }
                    Column(modifier = Modifier.weight(1f).padding(horizontal = 8.dp)) {
                        val fullDateStr = SimpleDateFormat("d MMMM yyyy (EE)", Locale("ru")).format(Date(cur.date))
                        Text(
                            text = fullDateStr,
                            color = Color.White,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        if (!cur.noteTitle.isNullOrEmpty()) {
                            Text(
                                text = cur.noteTitle,
                                color = Color.LightGray,
                                fontSize = 11.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                    IconButton(
                        onClick = {
                            if (cur.path.startsWith("http://") || cur.path.startsWith("https://")) {
                                val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                    type = "text/plain"
                                    putExtra(Intent.EXTRA_TEXT, cur.path)
                                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                try {
                                    context.startActivity(Intent.createChooser(shareIntent, "Поделиться ссылкой"))
                                } catch (_: Exception) {
                                    Toast.makeText(context, "Не удалось отправить ссылку", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                val f = File(cur.path)
                                if (f.exists()) {
                                    try {
                                        val uri = FileProvider.getUriForFile(context, "${context.packageName}.provider", f)
                                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                            type = if (cur.isVideo) "video/*" else "image/*"
                                            putExtra(Intent.EXTRA_STREAM, uri)
                                            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                        }
                                        context.startActivity(Intent.createChooser(shareIntent, "Поделиться файлом"))
                                    } catch (_: Exception) {
                                        Toast.makeText(context, "Не удалось открыть диалог отправки", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        }
                    ) {
                        Icon(Icons.Default.Share, contentDescription = "Поделиться", tint = Color.White)
                    }
                    IconButton(onClick = { itemToDelete = cur }) {
                        Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = Color.White)
                    }
                }

                // Нижняя плашка действий
                Surface(
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (cur.isVideo) "🎥 Видеозапись" else "📷 Фотография",
                            color = Color.White,
                            fontSize = 12.sp
                        )
                        Button(
                            onClick = {
                                val targetDate = cur.date
                                fullScreenItem = null
                                onOpenDateNote(targetDate)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                        ) {
                            Text("Перейти к заметке", fontSize = 11.5.sp)
                        }
                    }
                }
            }
        }
    }

    // ДИАЛОГ ПОДТВЕРЖДЕНИЯ УДАЛЕНИЯ
    if (itemToDelete != null) {
        val target = itemToDelete!!
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = { Text("Удалить вложение?") },
            text = { Text("Вы действительно хотите удалить это вложение из записей?") },
            confirmButton = {
                TextButton(
                    onClick = { deleteItem(target) },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Text("Удалить", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) {
                    Text("Отмена")
                }
            }
        )
    }

    // ДИАЛОГ ДОБАВЛЕНИЯ ВИДЕО ПО ССЫЛКЕ
    if (showUrlDialog) {
        val ytId = remember(inputUrl) { extractYouTubeId(inputUrl.trim()) }
        val rtId = remember(inputUrl) { extractRutubeId(inputUrl.trim()) }
        val isRt = remember(inputUrl) { isRutubeUrl(inputUrl.trim()) }
        val isVk = remember(inputUrl) { isVkVideoUrl(inputUrl.trim()) }
        val vkId = remember(inputUrl) { extractVkVideoId(inputUrl.trim()) }
        val hasClipboardText = remember(showUrlDialog) {
            try {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                cm != null && cm.hasPrimaryClip() && (cm.primaryClip?.itemCount ?: 0) > 0
            } catch (_: Throwable) {
                false
            }
        }

        AlertDialog(
            onDismissRequest = { if (!isDownloading) showUrlDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Видео по ссылке", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!VideoLimitManager.canLoadVideo(context)) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "Нужно получить PRO версию для последующей загрузки видео",
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Text(
                        "Вставьте ссылку на YouTube, RUTUBE или видеофайл (.mp4):",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = inputUrl,
                        onValueChange = { inputUrl = it },
                        label = { Text("Ссылка на видео") },
                        placeholder = { Text("https://rutube.ru/... или https://youtu.be/...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = false,
                        maxLines = 3,
                        trailingIcon = {
                            if (inputUrl.isEmpty() && hasClipboardText) {
                                TextButton(onClick = {
                                    try {
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                        val clip = if (cm != null && cm.hasPrimaryClip() && (cm.primaryClip?.itemCount ?: 0) > 0) {
                                            cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
                                        } else null
                                        if (!clip.isNullOrBlank()) {
                                            inputUrl = clip.trim()
                                        }
                                    } catch (e: Throwable) {
                                        Log.w("Zapisnyk", "Clipboard read error: ${e.message}")
                                    }
                                }) {
                                    Text("Вставить", fontSize = 10.sp)
                                }
                            } else if (inputUrl.isNotEmpty()) {
                                IconButton(onClick = { inputUrl = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = null, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    )

                    OutlinedTextField(
                        value = customTitle,
                        onValueChange = { customTitle = it },
                        label = { Text("Подпись к видео (необязательно)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // YouTube Card Preview if detected
                    if (ytId != null) {
                        Surface(
                            color = Color(0xFFCC0000).copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFFCC0000).copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(width = 64.dp, height = 40.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color.Black),
                                    contentAlignment = Alignment.Center
                                ) {
                                    SafeMediaThumbnail(
                                        path = "https://www.youtube.com/watch?v=$ytId",
                                        isVideo = true,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop,
                                        showVideoBadge = false
                                    )
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "YouTube видео обнаружено",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color(0xFFCC0000)
                                    )
                                    Text(
                                        "ID: $ytId",
                                        fontSize = 10.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }

                    // Rutube Card Preview if detected
                    if (isRt) {
                        Surface(
                            color = Color(0xFF00A0E3).copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFF00A0E3).copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(width = 64.dp, height = 40.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF001F3F)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("RUTUBE", color = Color(0xFF00A0E3), fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "Rutube видео обнаружено",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color(0xFF00A0E3)
                                    )
                                    Text(
                                        rtId?.let { "ID: $it" } ?: "Ссылка на Rutube видео",
                                        fontSize = 10.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }

                    // VK Video Card Preview if detected
                    if (isVk) {
                        Surface(
                            color = Color(0xFF0077FF).copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, Color(0xFF0077FF).copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(width = 64.dp, height = 40.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color(0xFF001F44)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("VK ВИДЕО", color = Color(0xFF0077FF), fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        "VK Видео обнаружено",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 11.sp,
                                        color = Color(0xFF0077FF)
                                    )
                                    Text(
                                        vkId?.let { "ID: $it • Доступно скачивание и онлайн" } ?: "VK Видео / Клип",
                                        fontSize = 10.sp,
                                        color = Color.Gray
                                    )
                                }
                            }
                        }
                    }

                    if (isDownloading) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier.padding(12.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                                    Text(
                                        downloadStatus.ifBlank { "Загрузка видео..." },
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Medium
                                    )
                                }
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(4.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    // Вариант 1: Добавить онлайн (мгновенно, без скачивания сотен МБ)
                    Button(
                        onClick = {
                            if (!VideoLimitManager.checkAndWarn(context)) {
                                return@Button
                            }
                            val clean = inputUrl.trim()
                            if (clean.isBlank()) return@Button
                            val yt = extractYouTubeId(clean)
                            val rt = extractRutubeId(clean)
                            val standardUrl = if (yt != null) {
                                "https://www.youtube.com/watch?v=$yt"
                            } else if (rt != null && !clean.contains("?")) {
                                "https://rutube.ru/video/$rt/"
                            } else {
                                clean
                            }
                            val defaultTitle = when {
                                yt != null -> "YouTube ($yt)"
                                rt != null -> "Rutube ($rt)"
                                isRutubeUrl(clean) -> "Rutube видео"
                                isVkVideoUrl(clean) -> "VK Видео"
                                else -> "Видео по ссылке"
                            }
                            val title = customTitle.trim().ifBlank { defaultTitle }
                            val targetDate = targetDateForNewMedia
                            val appContext = context.applicationContext
                            showUrlDialog = false
                            inputUrl = ""
                            customTitle = ""
                            scope.launch(Dispatchers.Default) {
                                try {
                                    var finalTitle = title
                                    // Fetch YouTube title automatically if not entered
                                    if (yt != null && title == defaultTitle) {
                                        try {
                                            val oembedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$yt&format=json"
                                            val conn = (URL(oembedUrl).openConnection() as HttpURLConnection).apply {
                                                connectTimeout = 3000
                                                readTimeout = 3000
                                                setRequestProperty("Accept", "application/json")
                                            }
                                            if (conn.responseCode in 200..299) {
                                                val resp = conn.inputStream.bufferedReader().use { it.readText() }
                                                val json = JSONObject(resp)
                                                val fetched = json.optString("title")
                                                if (fetched.isNotBlank()) {
                                                    finalTitle = fetched
                                                }
                                            }
                                        } catch (_: Throwable) {}
                                    } else if (rt != null && title == defaultTitle) {
                                        try {
                                            val conn = (URL("https://rutube.ru/api/video/$rt/").openConnection() as HttpURLConnection).apply {
                                                connectTimeout = 3000
                                                readTimeout = 3000
                                                setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) Mobile")
                                                setRequestProperty("Accept", "application/json")
                                            }
                                            if (conn.responseCode in 200..299) {
                                                val resp = conn.inputStream.bufferedReader().use { it.readText() }
                                                val map = Gson().fromJson<Map<String, Any?>>(resp, Map::class) ?: emptyMap()
                                                (map["title"] as? String)?.takeIf { it.isNotBlank() }?.let {
                                                    finalTitle = it
                                                }
                                                (map["thumbnail_url"] as? String)?.takeIf { it.isNotBlank() }?.let {
                                                    RutubeThumbnailCache.resolve(rt)
                                                }
                                            }
                                        } catch (_: Throwable) {}
                                    }
                                    attachPathToDate(targetDate, standardUrl, finalTitle)
                                    VideoLimitManager.recordVideoLoaded(appContext)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(appContext, "Видео добавлено во вложения!", Toast.LENGTH_SHORT).show()
                                    }
                                } catch (e: Throwable) {
                                    Log.e("Zapisnyk", "Error adding video: ${e.message}", e)
                                    withContext(Dispatchers.Main) {
                                        Toast.makeText(appContext, "Ошибка добавления: ${e.message}", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        enabled = !isDownloading && inputUrl.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (ytId != null) Color(0xFFCC0000)
                                             else if (rtId != null || isRt) Color(0xFF00A0E3)
                                             else if (isVk) Color(0xFF0077FF)
                                             else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text(
                            if (ytId != null) "Добавить YouTube (Мгновенно)"
                            else if (rtId != null || isRt) "Добавить RUTUBE (Мгновенно)"
                            else if (isVk) "Добавить VK Видео (Мгновенно)"
                            else "Добавить по ссылке (Онлайн)",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Вариант 2: Скачать файл на устройство
                    OutlinedButton(
                        onClick = {
                            if (!VideoLimitManager.checkAndWarn(context)) {
                                downloadErrorDetails = "${VideoLimitManager.PRO_REQUIRED_MESSAGE}. В обычном режиме доступна только 1 загрузка видео."
                                return@OutlinedButton
                            }
                            val clean = inputUrl.trim()
                            if (clean.isBlank()) return@OutlinedButton
                            val yt = extractYouTubeId(clean)
                            val rt = extractRutubeId(clean)
                            val targetDate = targetDateForNewMedia
                            val userTitle = customTitle.trim()
                            val appContext = context.applicationContext
                            isDownloading = true
                            downloadStatus = "Подключение к источнику..."
                            scope.launch(Dispatchers.Default) {
                                try {
                                    if (isVk || isVkVideoUrl(clean) || vkId != null) {
                                        withContext(Dispatchers.Main) { downloadStatus = "Получение VK Видео..." }
                                        var vkDownloadError: String? = null
                                        val result = downloadVkVideo(
                                            context = appContext,
                                            vkUrl = clean,
                                            onProgress = { status ->
                                                scope.launch(Dispatchers.Main) { downloadStatus = status }
                                            },
                                            onError = { err ->
                                                vkDownloadError = err
                                            }
                                        )
                                        val downloadedFile = result.file
                                        if (downloadedFile != null && downloadedFile.exists()) {
                                            val finalTitle = userTitle.ifBlank { result.title ?: "VK Видео" }
                                            VideoLimitManager.recordVideoLoaded(appContext)
                                            attachPathToDate(targetDate, downloadedFile.absolutePath, finalTitle)
                                            withContext(Dispatchers.Main) {
                                                isDownloading = false
                                                showUrlDialog = false
                                                inputUrl = ""
                                                customTitle = ""
                                                Toast.makeText(appContext, "VK Видео успешно скачано и сохранено на устройство!", Toast.LENGTH_SHORT).show()
                                            }
                                            return@launch
                                        } else {
                                            withContext(Dispatchers.Main) {
                                                isDownloading = false
                                                downloadErrorDetails = vkDownloadError ?: "Не удалось скачать VK Видео. Проверьте ссылку или нажмите «Прикрепить онлайн»."
                                            }
                                            return@launch
                                        }
                                    }

                                    if (rt != null || isRutubeUrl(clean)) {
                                        val activeRtId = rt ?: extractRutubeId(clean)
                                        if (activeRtId != null) {
                                            withContext(Dispatchers.Main) { downloadStatus = "Получение данных Rutube..." }
                                            var rtTitle: String? = null
                                            try {
                                                val metaConn = (URL("https://rutube.ru/api/video/$activeRtId/").openConnection() as HttpURLConnection).apply {
                                                    connectTimeout = 3000
                                                    readTimeout = 3000
                                                    setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) Mobile")
                                                    setRequestProperty("Accept", "application/json")
                                                }
                                                if (metaConn.responseCode in 200..299) {
                                                    val metaResp = metaConn.inputStream.bufferedReader().use { it.readText() }
                                                    val metaMap = Gson().fromJson<Map<String, Any?>>(metaResp, Map::class) ?: emptyMap()
                                                    (metaMap["title"] as? String)?.takeIf { it.isNotBlank() }?.let { rtTitle = it }
                                                }
                                            } catch (_: Throwable) {}

                                            var rutubeDownloadError: String? = null
                                            val downloadedFile = downloadRutubeVideo(
                                                context = appContext,
                                                rtId = activeRtId,
                                                onProgress = { status ->
                                                    scope.launch(Dispatchers.Main) { downloadStatus = status }
                                                },
                                                onError = { err ->
                                                    rutubeDownloadError = err
                                                }
                                            )

                                            if (downloadedFile != null && downloadedFile.exists()) {
                                                val finalTitle = userTitle.ifBlank { rtTitle ?: "Rutube ($activeRtId)" }
                                                VideoLimitManager.recordVideoLoaded(appContext)
                                                attachPathToDate(targetDate, downloadedFile.absolutePath, finalTitle)
                                                withContext(Dispatchers.Main) {
                                                    isDownloading = false
                                                    showUrlDialog = false
                                                    inputUrl = ""
                                                    customTitle = ""
                                                    Toast.makeText(appContext, "Видео Rutube (480p) успешно скачано!", Toast.LENGTH_SHORT).show()
                                                }
                                                return@launch
                                            } else {
                                                withContext(Dispatchers.Main) {
                                                    isDownloading = false
                                                    val reason = rutubeDownloadError?.takeIf { it.isNotBlank() }
                                                        ?: "Сервер Rutube ограничил доступ к видеопотоку (защита QRATOR WAF / блокировка прямого скачивания по IP)."
                                                    downloadErrorDetails = reason
                                                }
                                                return@launch
                                            }
                                        }
                                    }

                                    if (yt != null) {
                                        withContext(Dispatchers.Main) { downloadStatus = "Получение данных YouTube..." }
                                        var ytTitle: String? = null
                                        try {
                                            val oembedUrl = "https://www.youtube.com/oembed?url=https://www.youtube.com/watch?v=$yt&format=json"
                                            val conn = (URL(oembedUrl).openConnection() as HttpURLConnection).apply {
                                                connectTimeout = 3000
                                                readTimeout = 3000
                                                setRequestProperty("Accept", "application/json")
                                            }
                                            if (conn.responseCode in 200..299) {
                                                val resp = conn.inputStream.bufferedReader().use { it.readText() }
                                                val json = JSONObject(resp)
                                                val fetched = json.optString("title")
                                                if (fetched.isNotBlank()) ytTitle = fetched
                                            }
                                        } catch (_: Throwable) {}

                                        var ytDownloadError: String? = null
                                        val downloadedFile = downloadYouTubeVideo(
                                            context = appContext,
                                            ytId = yt,
                                            onProgress = { status ->
                                                scope.launch(Dispatchers.Main) { downloadStatus = status }
                                            },
                                            onError = { err ->
                                                ytDownloadError = err
                                            }
                                        )

                                        if (downloadedFile != null && downloadedFile.exists()) {
                                            val finalTitle = userTitle.ifBlank { ytTitle ?: "YouTube ($yt)" }
                                            VideoLimitManager.recordVideoLoaded(appContext)
                                            attachPathToDate(targetDate, downloadedFile.absolutePath, finalTitle)
                                            withContext(Dispatchers.Main) {
                                                isDownloading = false
                                                showUrlDialog = false
                                                inputUrl = ""
                                                customTitle = ""
                                                Toast.makeText(appContext, "Видео YouTube успешно скачано!", Toast.LENGTH_SHORT).show()
                                            }
                                            return@launch
                                        } else {
                                            withContext(Dispatchers.Main) {
                                                isDownloading = false
                                                val reason = ytDownloadError?.takeIf { it.isNotBlank() }
                                                    ?: "YouTube заблокировал прямое скачивание потока (защита SignatureCipher / bot-check)."
                                                downloadErrorDetails = reason
                                            }
                                            return@launch
                                        }
                                    }

                                    // Direct URL download (non-YouTube)
                                    withContext(Dispatchers.Main) { downloadStatus = "Скачивание файла..." }
                                    val ext = if (clean.lowercase().contains(".webm")) "webm" else "mp4"
                                    val file = File(appContext.filesDir, "media_${System.currentTimeMillis()}.$ext")
                                    var downloaded = false
                                    try {
                                        val conn = (URL(clean).openConnection() as HttpURLConnection).apply {
                                            connectTimeout = 15000
                                            readTimeout = 30000
                                            setRequestProperty("User-Agent", "Mozilla/5.0")
                                        }
                                        val cType = conn.contentType?.lowercase() ?: ""
                                        if (cType.contains("text/html") || cType.contains("text/plain")) {
                                            // Webpage, not a media file
                                            downloaded = false
                                        } else {
                                            conn.inputStream.use { input ->
                                                file.outputStream().use { output -> input.copyTo(output) }
                                            }
                                            downloaded = file.exists() && file.length() > 1024
                                        }
                                    } catch (e: Throwable) {
                                        Log.w("Zapisnyk", "Direct download error: ${e.message}")
                                        if (file.exists()) file.delete()
                                    }

                                    if (downloaded) {
                                        VideoLimitManager.recordVideoLoaded(appContext)
                                        attachPathToDate(targetDate, file.absolutePath, userTitle.ifBlank { "Видео" })
                                        withContext(Dispatchers.Main) {
                                            isDownloading = false
                                            showUrlDialog = false
                                            inputUrl = ""
                                            customTitle = ""
                                            Toast.makeText(appContext, "Видео успешно скачано!", Toast.LENGTH_SHORT).show()
                                        }
                                    } else {
                                        // Fallback to saving as online URL
                                        attachPathToDate(targetDate, clean, userTitle.ifBlank { "Онлайн видео" })
                                        withContext(Dispatchers.Main) {
                                            isDownloading = false
                                            showUrlDialog = false
                                            inputUrl = ""
                                            customTitle = ""
                                            Toast.makeText(appContext, "Видео сохранено по ссылке", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } catch (e: Throwable) {
                                    Log.e("Zapisnyk", "Download general error: ${e.message}", e)
                                    try {
                                        attachPathToDate(targetDate, clean, userTitle.ifBlank { "Онлайн видео" })
                                    } catch (_: Throwable) {}
                                    withContext(Dispatchers.Main) {
                                        isDownloading = false
                                        showUrlDialog = false
                                        inputUrl = ""
                                        customTitle = ""
                                        Toast.makeText(appContext, "Видео сохранено по ссылке", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        enabled = !isDownloading && inputUrl.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (isDownloading) "Загрузка..." else "Скачать файл на устройство", fontSize = 11.5.sp)
                    }

                    TextButton(
                        onClick = { showUrlDialog = false },
                        enabled = !isDownloading,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("Отмена", color = Color.Gray, fontSize = 11.5.sp)
                    }
                }
            },
            dismissButton = null
        )
    }

    // ДИАЛОГ С ПОЛНЫМ ТЕКСТОМ ОШИБКИ И ВОЗМОЖНОСТЬЮ ПРИКРЕПИТЬ ОНЛАЙН / СКОПИРОВАТЬ
    if (downloadErrorDetails != null) {
        AlertDialog(
            onDismissRequest = { downloadErrorDetails = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = Color(0xFFE53935))
                    Spacer(Modifier.width(8.dp))
                    Text("Не удалось скачать видео", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = downloadErrorDetails ?: "",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        val isVkError = isVkVideoUrl(inputUrl)
                        val isYtError = inputUrl.contains("youtu")
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Text(
                                if (isVkError) "💡 Почему VK Видео рекомендуется прикреплять онлайн?"
                                else if (isYtError) "💡 Почему видеохостинги защищают скачивание?"
                                else "💡 Почему Rutube блокирует скачивание?",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                if (isVkError)
                                    "1. VK Видео отдаёт стрим через адаптивные HLS-потоки под скорость вашего интернета.\n\n" +
                                    "2. Ссылка ведет на веб-страницу с защищенным плеером, а не на отдельный MP4-файл.\n\n" +
                                    "3. Прикрепив VK Видео онлайн, вы сможете смотреть ролик прямо внутри приложения или через приложение VK в 1 клик — без траты памяти устройства!"
                                else if (isYtError)
                                    "1. YouTube и Rutube защищают видеопотоки от скачивания шифрованием (SignatureCipher / n-sig, QRATOR WAF) и проверками на роботов (bot-check).\n\n" +
                                    "2. Видеохостинги постоянно обновляют защиту и алгоритмы токенов в реальном времени.\n\n" +
                                    "3. Прикрепив видео онлайн, вы сможете смотреть его прямо внутри заметки — без скачивания сотен мегабайт и траты памяти телефона!"
                                else
                                    "1. Rutube защищает видеопотоки системой QRATOR WAF, которая отслеживает и блокирует прямое скачивание через сторонние приложения, автоматические скрипты или IP мобильных сетей/VPN.\n\n" +
                                    "2. Видео не хранится единым MP4-файлом, а отдаётся нарезкой из сотен фрагментов HLS (.m3u8), ссылки на которые динамически шифруются.\n\n" +
                                    "3. Прикрепив видео онлайн, вы сможете смотреть его прямо внутри заметки — без скачивания сотен мегабайт и траты памяти телефона!",
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clean = inputUrl.trim()
                        val yt = extractYouTubeId(clean)
                        val rt = extractRutubeId(clean)
                        val defaultTitle = when {
                            yt != null -> "YouTube ($yt)"
                            rt != null -> "Rutube ($rt)"
                            isVkVideoUrl(clean) -> "VK Видео"
                            else -> "Онлайн видео"
                        }
                        val title = customTitle.trim().ifBlank { defaultTitle }
                        val targetDate = targetDateForNewMedia
                        val appContext = context.applicationContext
                        downloadErrorDetails = null
                        showUrlDialog = false
                        inputUrl = ""
                        customTitle = ""

                        scope.launch(Dispatchers.Default) {
                            try {
                                attachPathToDate(targetDate, clean, title)
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(appContext, "Видео успешно прикреплено онлайн!", Toast.LENGTH_SHORT).show()
                                }
                            } catch (e: Throwable) {
                                withContext(Dispatchers.Main) {
                                    Toast.makeText(appContext, "Ошибка прикрепления: ${e.message}", Toast.LENGTH_SHORT).show()
                                }
                            }
                        }
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (extractYouTubeId(inputUrl) != null) Color(0xFFCC0000)
                                         else if (isVkVideoUrl(inputUrl)) Color(0xFF0077FF)
                                         else Color(0xFF00A0E3)
                    )
                ) {
                    Icon(Icons.Default.CloudQueue, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Прикрепить онлайн", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    TextButton(
                        onClick = {
                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                            val clip = ClipData.newPlainText("Video Download Error", downloadErrorDetails ?: "")
                            clipboard?.setPrimaryClip(clip)
                            Toast.makeText(context, "Текст скопирован в буфер", Toast.LENGTH_SHORT).show()
                        }
                    ) {
                        Text("Скопировать", fontSize = 12.sp)
                    }
                    TextButton(onClick = { downloadErrorDetails = null }) {
                        Text("Закрыть", fontSize = 12.sp)
                    }
                }
            }
        )
    }
}

@Composable
fun DebtDialog(exD: DiaryDebt?, onD: () -> Unit, onC: (String, Double, Long, Long) -> Unit) {
    var cr by remember(exD) { mutableStateOf(exD?.creditor ?: "") }
    var am by remember(exD) { mutableStateOf(exD?.amount?.let { if (it % 1.0 == 0.0) it.toLong().toString() else it.toString() } ?: "") }
    var createdAt by remember(exD) { mutableLongStateOf(exD?.createdAt?.takeIf { it > 0 } ?: System.currentTimeMillis()) }
    var dt by remember(exD) { mutableLongStateOf(exD?.dueDate?.takeIf { it > 0 } ?: (System.currentTimeMillis() + 86400000L * 30)) }
    val ctx = LocalContext.current
    AlertDialog(
        onDismissRequest = onD,
        title = { Text(if(exD == null) "Новый долг" else "Редактирование долга") },
        text = {
            Column {
                OutlinedTextField(value = cr, onValueChange = { cr = it }, label = { Text("Кредитор / Кому должен") }, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(value = am, onValueChange = { am = it }, label = { Text("Сумма") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                Row(Modifier.padding(top = 8.dp).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { DatePickerDialog(ctx, { _, y, m, d -> val c = Calendar.getInstance().apply { set(y, m, d, 0, 0, 0) }; createdAt = c.timeInMillis }, Calendar.getInstance().apply { timeInMillis = createdAt }.get(Calendar.YEAR), Calendar.getInstance().apply { timeInMillis = createdAt }.get(Calendar.MONTH), Calendar.getInstance().apply { timeInMillis = createdAt }.get(Calendar.DAY_OF_MONTH)).show() }, Modifier.weight(1f)) {
                        Text("Оформлен: ${SimpleDateFormat("dd.MM.yy", Locale.getDefault()).format(Date(createdAt))}", fontSize = 11.sp)
                    }
                    Button(onClick = { DatePickerDialog(ctx, { _, y, m, d -> val c = Calendar.getInstance().apply { set(y, m, d, 23, 59, 59) }; dt = c.timeInMillis }, Calendar.getInstance().apply { timeInMillis = dt }.get(Calendar.YEAR), Calendar.getInstance().apply { timeInMillis = dt }.get(Calendar.MONTH), Calendar.getInstance().apply { timeInMillis = dt }.get(Calendar.DAY_OF_MONTH)).show() }, Modifier.weight(1f)) {
                        Text("Срок: ${SimpleDateFormat("dd.MM.yy", Locale.getDefault()).format(Date(dt))}", fontSize = 11.sp)
                    }
                }
            }
        },
        confirmButton = { Button(onClick = { val a = am.toDoubleOrNull() ?: 0.0; if (cr.isNotEmpty() && a > 0) onC(cr, a, dt, createdAt) }) { Text(if(exD == null) "Добавить" else "Сохранить") } },
        dismissButton = { TextButton(onClick = onD) { Text("Отмена") } }
    )
}

// ВОССТАНОВЛЕННЫЙ ДИАЛОГ ПЛАНА ПЛАТЕЖЕЙ (Чек-лист v.2.13.7)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExpectedFinanceDialog(
    items: List<ExpectedFinance>,
    todayDay: Int,
    onDismiss: () -> Unit,
    onSave: (ExpectedFinance) -> Unit,
    onDelete: (ExpectedFinance) -> Unit
) {
    var editingItem by remember { mutableStateOf<ExpectedFinance?>(null) }
    var title by remember { mutableStateOf("") }; var amount by remember { mutableStateOf("") }
    var day by remember { mutableStateOf("1") }; var isInc by remember { mutableStateOf(false) }

    LaunchedEffect(editingItem) {
        editingItem?.let { title = it.title; amount = it.amount.toString(); day = it.dayOfMonth.toString(); isInc = it.isIncome }
            ?: run { title = ""; amount = ""; day = "1"; isInc = false }
    }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(if(editingItem == null) "План платежей" else "Редактирование") },
                    navigationIcon = { IconButton(onClick = onDismiss) { Icon(Icons.Default.Close, null) } }
                )
            }
        ) { p ->
            Column(Modifier.padding(p).padding(16.dp)) {
                Card(Modifier.fillMaxWidth().padding(bottom = 16.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Row {
                            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Название") }, modifier = Modifier.weight(1f))
                            Spacer(Modifier.width(8.dp))
                            OutlinedTextField(
                                value = day,
                                onValueChange = { input ->
                                    val digits = input.filter { it.isDigit() }
                                    if (digits.isEmpty()) {
                                        day = ""
                                    } else {
                                        val num = digits.toIntOrNull() ?: 1
                                        day = num.coerceIn(1, 31).toString()
                                    }
                                },
                                label = { Text("День (1-31)") },
                                modifier = Modifier.width(90.dp),
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true
                            )
                        }
                        OutlinedTextField(value = amount, onValueChange = { amount = it }, label = { Text("Сумма") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                            Checkbox(isInc, { isInc = it }); Text("Доход"); Spacer(Modifier.weight(1f))
                            Button(onClick = {
                                val dVal = day.toIntOrNull() ?: 1
                                val aVal = amount.toDoubleOrNull() ?: 0.0
                                if(title.isNotEmpty() && aVal > 0) {
                                    val safeDay = dVal.coerceIn(1, 31)
                                    onSave(ExpectedFinance(editingItem?.id ?: 0, title, aVal, safeDay, isInc))
                                    editingItem = null
                                }
                            }) { Text(if(editingItem == null) "Добавить" else "Обновить") }
                        }
                    }
                }
                Text("Список регулярных платежей", fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(bottom = 8.dp))
                LazyColumn(Modifier.weight(1f)) {
                    items(items) { f ->
                        val isPast = f.dayOfMonth < todayDay
                        Row(
                            Modifier.fillMaxWidth().clickable { editingItem = f }.padding(8.dp).alpha(if(isPast) 0.4f else 1f),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(if(f.isIncome) Icons.Default.AddCircle else Icons.Default.RemoveCircle, null, tint = if(f.isIncome) Color(0xFF4CAF50) else Color(0xFFF44336))
                            Column(Modifier.padding(start = 8.dp).weight(1f)) {
                                Text(f.title, fontWeight = FontWeight.Bold)
                                Text("${f.dayOfMonth}-е число | ${f.amount}", fontSize = 11.sp, color = Color.Gray)
                            }
                            IconButton(onClick = { onDelete(f) }) { Icon(Icons.Default.Delete, null, tint = Color.Gray) }
                        }
                    }
                }
            }
        }
    }
}

// ДИАЛОГ СОЗДАНИЯ / РЕДАКТИРОВАНИЯ ЦЕЛИ НАКОПЛЕНИЯ
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SavingsGoalDialog(
    goal: SavingsGoal?,
    balanceCategories: List<FinanceSectionInfo>,
    currentMonthKey: String,
    currentMonthName: String,
    onDismiss: () -> Unit,
    onSave: (SavingsGoal) -> Unit,
    onDelete: ((String) -> Unit)? = null
) {
    if (balanceCategories.isEmpty()) {
        AlertDialog(
            onDismissRequest = onDismiss,
            title = { Text("Цели накопления", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
            text = {
                Text(
                    "Нет доступных категорий с типом «Баланс». Создайте новую категорию типа «Баланс» или восстановите «Депозит» в разделе «Финансы», чтобы ставить цели по накоплениям.",
                    fontSize = 13.sp
                )
            },
            confirmButton = {
                Button(onClick = onDismiss) { Text("Понятно") }
            }
        )
        return
    }

    var selectedCategoryId by remember(goal) {
        mutableStateOf(
            if (goal != null && balanceCategories.any { it.id == goal.categoryId }) goal.categoryId
            else balanceCategories.first().id
        )
    }
    var title by remember(goal) { mutableStateOf(goal?.title ?: "") }
    var amountStr by remember(goal) {
        mutableStateOf(if (goal != null && goal.targetAmount > 0) String.format(Locale.US, "%.0f", goal.targetAmount) else "")
    }
    var trackMode by remember(goal) { mutableStateOf(goal?.trackMode ?: "MONTH_ADDITIONS") }
    var isRecurring by remember(goal) { mutableStateOf(goal?.monthKey?.isEmpty() ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (goal == null) "Новая цель на месяц" else "Редактирование цели",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text(
                    "Категория накопления (тип: Баланс):",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 6.dp)
                )

                // Выбор категории типа 'Баланс'
                FlowRow(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    balanceCategories.forEach { sec ->
                        val isSelected = sec.id == selectedCategoryId
                        Surface(
                            onClick = { selectedCategoryId = sec.id },
                            shape = RoundedCornerShape(8.dp),
                            color = if (isSelected) sec.color.copy(alpha = 0.18f) else Color.LightGray.copy(alpha = 0.15f),
                            border = BorderStroke(
                                if (isSelected) 1.5.dp else 1.dp,
                                if (isSelected) sec.color else Color.LightGray.copy(alpha = 0.4f)
                            )
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                            ) {
                                Box(
                                    Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(sec.color)
                                )
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    sec.name,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) sec.color else MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название цели (необязательно)") },
                    placeholder = { Text("Например: На отпуск, Подушка") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )

                OutlinedTextField(
                    value = amountStr,
                    onValueChange = { input ->
                        val filtered = input.filter { it.isDigit() || it == '.' || it == ',' }.replace(',', '.')
                        amountStr = filtered
                    },
                    label = { Text("Целевая сумма (₽)*") },
                    placeholder = { Text("Например: 50000") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )

                Text(
                    "Как рассчитывать прогресс:",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface,
                    modifier = Modifier.padding(bottom = 4.dp)
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { trackMode = "MONTH_ADDITIONS" }
                        .padding(vertical = 4.dp)
                ) {
                    RadioButton(
                        selected = trackMode == "MONTH_ADDITIONS",
                        onClick = { trackMode = "MONTH_ADDITIONS" }
                    )
                    Spacer(Modifier.width(4.dp))
                    Column {
                        Text("Пополнения за месяц", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Сумма взносов, внесенных за выбранный месяц", fontSize = 10.sp, color = Color.Gray)
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { trackMode = "TOTAL_BALANCE" }
                        .padding(vertical = 4.dp)
                ) {
                    RadioButton(
                        selected = trackMode == "TOTAL_BALANCE",
                        onClick = { trackMode = "TOTAL_BALANCE" }
                    )
                    Spacer(Modifier.width(4.dp))
                    Column {
                        Text("Итоговый баланс", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text("Общий накопленный остаток в категории", fontSize = 10.sp, color = Color.Gray)
                    }
                }

                Spacer(Modifier.height(8.dp))

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { isRecurring = !isRecurring }
                        .padding(vertical = 4.dp)
                ) {
                    Checkbox(
                        checked = isRecurring,
                        onCheckedChange = { isRecurring = it }
                    )
                    Spacer(Modifier.width(4.dp))
                    Column {
                        Text("Повторять каждый месяц", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Text(
                            if (isRecurring) "Цель будет активна в каждом месяце" else "Только для: $currentMonthName",
                            fontSize = 10.sp,
                            color = Color.Gray
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    if (amt > 0) {
                        onSave(
                            SavingsGoal(
                                id = goal?.id ?: UUID.randomUUID().toString(),
                                categoryId = selectedCategoryId,
                                title = title.trim(),
                                targetAmount = amt,
                                trackMode = trackMode,
                                monthKey = if (isRecurring) "" else currentMonthKey
                            )
                        )
                    }
                },
                enabled = (amountStr.toDoubleOrNull() ?: 0.0) > 0
            ) {
                Text(if (goal == null) "Создать" else "Сохранить")
            }
        },
        dismissButton = {
            Row {
                if (goal != null && onDelete != null) {
                    TextButton(onClick = { onDelete(goal.id) }) {
                        Text("Удалить", color = Color.Red)
                    }
                }
                TextButton(onClick = onDismiss) {
                    Text("Отмена")
                }
            }
        }
    )
}

