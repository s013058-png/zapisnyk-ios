package com.my.zapisnyk


import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor


// ==========================================
// 7. ЗАДАЧИ & ТРЕКЕР ПРИВЫЧЕК (v.2.14.0 — ПРИВЫЧКИ СО СТРИКАМИ, ЧЕК-ЛИСТЫ, ВРЕМЯ СУТОК, ПРИОРИТЕТЫ)
// ==========================================

fun calculateHabitStreak(historyDates: List<String>): Pair<Int, Int> {
    if (historyDates.isEmpty()) return Pair(0, 0)
    val sdf = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
    val dates = historyDates.mapNotNull {
        try { sdf.parse(it) } catch (e: Exception) { null }
    }.distinct().sorted()
    if (dates.isEmpty()) return Pair(0, 0)

    val cal = Calendar.getInstance().apply {
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    val today = cal.time
    cal.add(Calendar.DAY_OF_YEAR, -1)
    val yesterday = cal.time

    var bestStreak = 0
    var tempStreak = 0
    var prevDate: Date? = null

    for (d in dates) {
        if (prevDate == null) {
            tempStreak = 1
        } else {
            val diff = ((d.time - prevDate.time) / (1000 * 60 * 60 * 24)).toInt()
            if (diff == 1) {
                tempStreak++
            } else if (diff > 1) {
                tempStreak = 1
            }
        }
        if (tempStreak > bestStreak) bestStreak = tempStreak
        prevDate = d
    }

    var currentStreak = 0
    val lastDate = dates.lastOrNull()
    if (lastDate != null && (lastDate == today || lastDate == yesterday)) {
        currentStreak = 1
        val checkCal = Calendar.getInstance().apply { time = lastDate }
        for (i in dates.size - 2 downTo 0) {
            checkCal.add(Calendar.DAY_OF_YEAR, -1)
            if (dates[i] == checkCal.time) {
                currentStreak++
            } else {
                break
            }
        }
    }
    return Pair(currentStreak, maxOf(bestStreak, currentStreak))
}

fun parseSubtasks(json: String, frequency: String = "Однажды", taskLastDoneDate: String = ""): List<SubtaskItem> {
    if (json.isBlank()) return emptyList()
    return try {
        val arr = JSONArray(json)
        val list = mutableListOf<SubtaskItem>()
        val todayStr = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date())
        for (i in 0 until arr.length()) {
            val obj = arr.getJSONObject(i)
            val rawDone = obj.optBoolean("isDone", false)
            val itemDate = obj.optString("lastDoneDate", "")
            val effectiveDate = when {
                itemDate.isNotBlank() -> itemDate
                taskLastDoneDate.isNotBlank() -> taskLastDoneDate
                rawDone -> todayStr
                else -> ""
            }
            val isStillDone = if (rawDone) {
                if (effectiveDate.isNotBlank()) {
                    isDateInCurrentPeriod(effectiveDate, frequency)
                } else {
                    frequency == "Однажды"
                }
            } else {
                false
            }
            list.add(
                SubtaskItem(
                    id = obj.optString("id", UUID.randomUUID().toString()),
                    title = obj.optString("title", ""),
                    isDone = isStillDone,
                    lastDoneDate = if (isStillDone) effectiveDate else ""
                )
            )
        }
        list
    } catch (e: Exception) {
        emptyList()
    }
}

fun serializeSubtasks(list: List<SubtaskItem>): String {
    val arr = JSONArray()
    for (s in list) {
        val obj = JSONObject()
        obj.put("id", s.id)
        obj.put("title", s.title)
        obj.put("isDone", s.isDone)
        obj.put("lastDoneDate", s.lastDoneDate)
        arr.put(obj)
    }
    return arr.toString()
}

fun parseHistoryDates(json: String): List<String> {
    if (json.isBlank()) return emptyList()
    return try {
        val arr = JSONArray(json)
        val list = mutableListOf<String>()
        for (i in 0 until arr.length()) {
            list.add(arr.getString(i))
        }
        list
    } catch (e: Exception) {
        emptyList()
    }
}

fun serializeHistoryDates(list: List<String>): String {
    val arr = JSONArray()
    list.distinct().forEach { arr.put(it) }
    return arr.toString()
}

data class HabitPresetAndroid(val title: String, val icon: String, val category: String, val timeOfDay: String)

val HABIT_PRESETS_ANDROID = listOf(
    HabitPresetAndroid("Зарядка 15 мин", "🤸", "Здоровье", "MORNING"),
    HabitPresetAndroid("10 000 шагов", "👟", "Спорт", "DAY"),
    HabitPresetAndroid("Чтение 20 мин", "📖", "Развитие", "EVENING"),
    HabitPresetAndroid("Принять витамины", "💊", "Здоровье", "MORNING"),
    HabitPresetAndroid("Выпить 2л воды", "💧", "Здоровье", "ANY"),
    HabitPresetAndroid("Медитация 10 мин", "🧘", "Отдых", "EVENING")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TasksScreen(dao: DiaryDao, tasks: List<DiaryTask>, notes: List<DiaryNote> = emptyList()) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val isModernFont = ThemeManager.isModernFont
    val taskFontFamily = ThemeManager.getFontFamily()
    val taskSpacing = ThemeManager.letterSpacing()
    var title by remember { mutableStateOf("") }
    var freq by remember { mutableStateOf("Ежедневно") }
    var isHabit by remember { mutableStateOf(false) }
    var timeOfDay by remember { mutableStateOf("ANY") }
    var priority by remember { mutableStateOf("NORMAL") }
    var category by remember { mutableStateOf("") }
    var tDate by remember { mutableLongStateOf(System.currentTimeMillis()) }
    var attachedVideoUrl by remember { mutableStateOf<String?>(null) }
    var attachedVideoTitle by remember { mutableStateOf<String?>(null) }
    var editingTask by remember { mutableStateOf<DiaryTask?>(null) }
    var showAdvanced by remember { mutableStateOf(false) }
    var activeTab by remember { mutableStateOf(0) } // 0: Все, 1: Привычки, 2: По времени, 3: По приоритету

    val expandedSubtasks = remember { mutableStateMapOf<Int, Boolean>() }
    val newSubtaskInputs = remember { mutableStateMapOf<Int, String>() }

    // Dialog state for attaching video to task
    var taskForVideoAttach by remember { mutableStateOf<DiaryTask?>(null) }
    var isAttachingToNewForm by remember { mutableStateOf(false) }
    var showAttachOptionsDialog by remember { mutableStateOf(false) }
    var showVideoUrlDialog by remember { mutableStateOf(false) }
    var showMediaGalleryDialog by remember { mutableStateOf(false) }

    var inputVideoUrl by remember { mutableStateOf("") }
    var inputVideoCustomTitle by remember { mutableStateOf("") }
    var isDownloadingTaskVideo by remember { mutableStateOf(false) }
    var taskVideoDownloadStatus by remember { mutableStateOf("") }
    var taskVideoDownloadError by remember { mutableStateOf<String?>(null) }

    val todayStr = remember { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date()) }

    // Automatic daily/weekly/monthly checklist updater: reset checklist items when period expires
    LaunchedEffect(tasks, todayStr) {
        tasks.forEach { t ->
            if (t.subtasks.isNotBlank() && t.subtasks != "[]") {
                val parsed = parseSubtasks(t.subtasks, t.frequency, t.lastDoneDate)
                val reSerialized = serializeSubtasks(parsed)
                if (reSerialized != t.subtasks) {
                    dao.updateTask(t.copy(subtasks = reSerialized))
                }
            }
        }
    }

    // Collect all existing video attachments from notes & downloads to choose from
    val allSavedVideos = remember(notes) {
        val list = mutableListOf<String>()
        // From notes
        notes.forEach { n ->
            val paths = parseMediaPaths(n.mediaPaths)
            val main = n.mainMediaPath ?: ""
            val all = if (main.isNotBlank() && !paths.contains(main)) listOf(main) + paths else paths
            all.forEach { p ->
                if (isVideoPath(p) || isYouTubeUrl(p) || isRutubeUrl(p)) {
                    list.add(p)
                }
            }
        }
        // From app storage directory
        try {
            val dir = context.filesDir
            dir.listFiles()?.forEach { f ->
                if (f.isFile && (f.name.endsWith(".mp4", true) || f.name.endsWith(".mkv", true) || f.name.endsWith(".webm", true))) {
                    list.add(f.absolutePath)
                }
            }
        } catch (_: Throwable) {}
        list.distinct()
    }

    // Save video to target task or to new-task creation form
    fun applyVideoToTarget(url: String, videoTitle: String? = null) {
        if (isAttachingToNewForm) {
            attachedVideoUrl = url
            attachedVideoTitle = videoTitle
        } else {
            taskForVideoAttach?.let { target ->
                scope.launch(Dispatchers.Default) {
                    dao.updateTask(target.copy(videoUrl = url, videoTitle = videoTitle))
                }
            }
        }
    }

    // Single video picker launcher (from phone's gallery)
    val taskVideoPickerLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            scope.launch(Dispatchers.Default) {
                try {
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(context.contentResolver.getType(uri)) ?: "mp4"
                    val file = File(context.filesDir, "task_vid_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(6)}.$ext")
                    context.contentResolver.openInputStream(uri)?.use { input ->
                        file.outputStream().use { output -> input.copyTo(output) }
                    }
                    if (file.exists() && file.length() > 0) {
                        VideoLimitManager.recordVideoLoaded(context)
                        applyVideoToTarget(file.absolutePath, "Видео с устройства")
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Видео прикреплено к задаче!", Toast.LENGTH_SHORT).show()
                        }
                    }
                } catch (e: Throwable) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Ошибка сохранения: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    LaunchedEffect(editingTask) {
        editingTask?.let {
            title = it.title
            freq = it.frequency
            tDate = it.targetDate
            isHabit = it.isHabit
            timeOfDay = it.timeOfDay
            priority = it.priority
            category = it.category
            attachedVideoUrl = it.videoUrl
            attachedVideoTitle = it.videoTitle
            showAdvanced = true
        }
    }

    val last7Days = remember {
        val list = mutableListOf<Pair<String, String>>() // Pair(dayLabel, dateStr)
        val cal = Calendar.getInstance()
        val dateSdf = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
        val daySdf = SimpleDateFormat("EE", Locale("ru"))
        for (i in 6 downTo 0) {
            val c = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -i) }
            val label = daySdf.format(c.time).take(2).replaceFirstChar { it.uppercase() }
            val dStr = dateSdf.format(c.time)
            list.add(Pair(label, dStr))
        }
        list
    }

    fun resetInput() {
        title = ""
        freq = "Ежедневно"
        isHabit = activeTab == 1
        timeOfDay = "ANY"
        priority = "NORMAL"
        category = ""
        attachedVideoUrl = null
        attachedVideoTitle = null
        editingTask = null
        showAdvanced = false
    }

    Column(Modifier.fillMaxSize().padding(14.dp)) {
        // Mode Tabs: Все / Привычки / Время / Приоритет
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            val tabs = listOf("Все (${tasks.size})", "🔥 Привычки", "🌅 По времени", "🎯 По приоритету")
            items(tabs.indices.toList()) { idx ->
                FilterChip(
                    selected = activeTab == idx,
                    onClick = {
                        activeTab = idx
                        if (idx == 1) isHabit = true
                    },
                    label = { Text(tabs[idx], fontSize = 11.sp, fontWeight = if (activeTab == idx) FontWeight.Normal else FontWeight.Normal) }
                )
            }
        }

        // Quick presets for habits
        if (activeTab == 1 || isHabit) {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.35f)),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Column(Modifier.padding(8.dp)) {
                    Text("Быстрые привычки (нажмите для добавления):", fontSize = 11.sp, fontWeight = FontWeight.Normal, color = MaterialTheme.colorScheme.onSecondaryContainer)
                    Spacer(Modifier.height(4.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(HABIT_PRESETS_ANDROID) { p ->
                            SuggestionChip(
                                onClick = {
                                    title = p.title
                                    isHabit = true
                                    category = p.category
                                    timeOfDay = p.timeOfDay
                                    freq = "Ежедневно"
                                    showAdvanced = true
                                },
                                label = { Text("${p.icon} ${p.title}", fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        // Input Form
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 45f / 100f)),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier.fillMaxWidth().padding(bottom = 10.dp)
        ) {
            Column(Modifier.padding(10.dp)) {
                if (editingTask != null) {
                    Surface(
                        color = MaterialTheme.colorScheme.primary.copy(alpha = 0.12f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                Text("Редактирование задачи", fontSize = 12.sp, fontWeight = FontWeight.Normal, color = MaterialTheme.colorScheme.primary)
                            }
                            TextButton(
                                onClick = { resetInput() },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                            ) {
                                Text("Отмена", color = Color(0xFFD32F2F), fontSize = 12.sp, fontWeight = FontWeight.Normal)
                            }
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = title,
                        onValueChange = { title = it },
                        modifier = Modifier.weight(1f),
                        label = { Text(if (editingTask != null) "Название задачи" else if (isHabit) "Новая привычка..." else "Новая задача...") },
                        singleLine = true
                    )
                    IconButton(
                        onClick = {
                            val clean = title.trim()
                            if (clean.isNotBlank()) {
                                val targetTask = editingTask
                                if (targetTask != null && targetTask.id != 0) {
                                    val updatedTask = targetTask.copy(
                                        title = clean,
                                        frequency = freq,
                                        targetDate = tDate,
                                        isHabit = isHabit,
                                        timeOfDay = timeOfDay,
                                        priority = priority,
                                        category = category.trim(),
                                        videoUrl = attachedVideoUrl,
                                        videoTitle = attachedVideoTitle
                                    )
                                    scope.launch(Dispatchers.Default) {
                                        dao.updateTask(updatedTask)
                                    }
                                } else {
                                    val newTask = DiaryTask(
                                        title = clean,
                                        frequency = freq,
                                        targetDate = tDate,
                                        isHabit = isHabit,
                                        timeOfDay = timeOfDay,
                                        priority = priority,
                                        category = category.trim(),
                                        videoUrl = attachedVideoUrl,
                                        videoTitle = attachedVideoTitle
                                    )
                                    scope.launch(Dispatchers.Default) {
                                        dao.saveTask(newTask)
                                    }
                                }
                                resetInput()
                            }
                        },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            if (editingTask == null) Icons.Default.AddCircle else Icons.Default.CheckCircle,
                            contentDescription = if (editingTask == null) "Добавить" else "Сохранить",
                            tint = if (editingTask == null) MaterialTheme.colorScheme.primary else Color(0xFF4CAF50),
                            modifier = Modifier.size(34.dp)
                        )
                    }
                    IconButton(
                        onClick = { showAdvanced = !showAdvanced },
                        modifier = Modifier.size(44.dp)
                    ) {
                        Icon(
                            Icons.Default.Tune,
                            contentDescription = "Параметры",
                            tint = if (showAdvanced) MaterialTheme.colorScheme.primary else Color.Gray,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                // Video attachment preview badge in creation/edit form
                if (!attachedVideoUrl.isNullOrBlank()) {
                    val curVid = attachedVideoUrl!!
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth().padding(top = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Default.Videocam,
                                contentDescription = null,
                                tint = if (isYouTubeUrl(curVid)) Color(0xFFCC0000) else if (isRutubeUrl(curVid)) Color(0xFF00A0E3) else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    attachedVideoTitle?.ifBlank { null } ?: (if (isYouTubeUrl(curVid)) "YouTube видео" else if (isRutubeUrl(curVid)) "Rutube видео" else "Видеофайл"),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Normal,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    curVid,
                                    fontSize = 9.sp,
                                    color = Color.Gray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                            IconButton(onClick = { openVideo(context, curVid) }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.PlayArrow, contentDescription = "Смотреть", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                            }
                            IconButton(onClick = { attachedVideoUrl = null; attachedVideoTitle = null }, modifier = Modifier.size(28.dp)) {
                                Icon(Icons.Default.Close, contentDescription = "Убрать", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }

                // Frequency chips + Habit toggle in a single aligned row
                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    item {
                        FilterChip(
                            selected = isHabit,
                            onClick = { isHabit = !isHabit },
                            label = { Text(if (isHabit) "🔥 Привычка" else "Привычка?", fontSize = 10.sp, fontWeight = if (isHabit) FontWeight.Normal else FontWeight.Normal) }
                        )
                    }
                    val freqs = listOf("Ежедневно", "Еженедельно", "Ежемесячно", "Однажды")
                    items(freqs) { f ->
                        val isSelected = freq == f
                        val displayLabel = if (f == "Однажды" && isSelected) {
                            "Однажды: " + SimpleDateFormat("dd.MM.yy", Locale.getDefault()).format(Date(tDate))
                        } else {
                            f
                        }
                        FilterChip(
                            selected = isSelected,
                            onClick = {
                                freq = f
                                if (f == "Однажды") {
                                    val currentCal = Calendar.getInstance().apply { timeInMillis = tDate }
                                    DatePickerDialog(
                                        context,
                                        { _, y, m, d ->
                                            val c = Calendar.getInstance().apply { set(y, m, d) }
                                            tDate = c.timeInMillis
                                        },
                                        currentCal.get(Calendar.YEAR),
                                        currentCal.get(Calendar.MONTH),
                                        currentCal.get(Calendar.DAY_OF_MONTH)
                                    ).show()
                                }
                            },
                            label = { Text(displayLabel, fontSize = 10.sp) }
                        )
                    }
                }

                // Advanced options: Time of Day, Priority, Category, Video attachment button
                if (showAdvanced) {
                    Spacer(Modifier.height(8.dp))
                    HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(Modifier.height(6.dp))

                    Text("Время суток:", fontSize = 10.sp, fontWeight = FontWeight.Normal)
                    LazyRow(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val times = listOf(Triple("ANY", "⏳", "Любое время"), Triple("MORNING", "🌅", "Утро"), Triple("DAY", "☀️", "День"), Triple("EVENING", "🌙", "Вечер"))
                        items(times) { (k, icon, lbl) ->
                            FilterChip(
                                selected = timeOfDay == k,
                                onClick = { timeOfDay = k },
                                label = { Text("$icon $lbl", fontSize = 10.sp) }
                            )
                        }
                    }

                    Spacer(Modifier.height(4.dp))
                    Text("Приоритет:", fontSize = 10.sp, fontWeight = FontWeight.Normal)
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(Triple("NORMAL", "⚪", "Обычный"), Triple("HIGH", "🟡", "Важно"), Triple("URGENT", "🔴", "Срочно")).forEach { (k, icon, lbl) ->
                            FilterChip(
                                selected = priority == k,
                                onClick = { priority = k },
                                label = { Text("$icon $lbl", fontSize = 10.sp) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = category,
                        onValueChange = { category = it },
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                        label = { Text("Категория (Здоровье, Работа, Спорт...)") },
                        singleLine = true
                    )

                    Spacer(Modifier.height(6.dp))
                    OutlinedButton(
                        onClick = {
                            isAttachingToNewForm = true
                            taskForVideoAttach = null
                            showAttachOptionsDialog = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.VideoCall, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(if (attachedVideoUrl.isNullOrBlank()) "Прикрепить обучающее видео" else "Сменить видео", fontSize = 11.sp)
                    }
                }

                // Explicit Save button when editing
                if (editingTask != null) {
                    Spacer(Modifier.height(8.dp))
                    Button(
                        onClick = {
                            val clean = title.trim()
                            if (clean.isNotBlank()) {
                                val targetTask = editingTask
                                if (targetTask != null && targetTask.id != 0) {
                                    val updatedTask = targetTask.copy(
                                        title = clean,
                                        frequency = freq,
                                        targetDate = tDate,
                                        isHabit = isHabit,
                                        timeOfDay = timeOfDay,
                                        priority = priority,
                                        category = category.trim(),
                                        videoUrl = attachedVideoUrl,
                                        videoTitle = attachedVideoTitle
                                    )
                                    scope.launch(Dispatchers.Default) {
                                        dao.updateTask(updatedTask)
                                    }
                                }
                                resetInput()
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF4CAF50))
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Сохранить изменения", fontWeight = FontWeight.Normal, fontSize = 13.sp)
                    }
                }
            }
        }

        // Render Task Card Composable
        @Composable
        fun TaskCardItem(t: DiaryTask) {
            val done = isTaskActuallyDone(t)
            val subtasksList = remember(t.subtasks, t.frequency, t.lastDoneDate, todayStr) { parseSubtasks(t.subtasks, t.frequency, t.lastDoneDate) }
            val historyList = remember(t.historyDates) { parseHistoryDates(t.historyDates) }
            val (currentStreak, bestStreak) = remember(historyList) { calculateHabitStreak(historyList) }
            val isExpanded = expandedSubtasks[t.id] ?: false
            val subDoneCount = subtasksList.count { it.isDone }
            val subTotal = subtasksList.size
            val hasVideo = !t.videoUrl.isNullOrBlank()

            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { editingTask = t },
                colors = CardDefaults.cardColors(
                    containerColor = if (done) {
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.25f)
                    } else {
                        MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
                    },
                    contentColor = MaterialTheme.colorScheme.onSurface
                ),
                border = if (editingTask?.id == t.id) {
                    BorderStroke(2.dp, MaterialTheme.colorScheme.primary)
                } else if (t.priority == "URGENT") {
                    BorderStroke(1.dp, Color(0xFFE53935).copy(alpha = 0.6f))
                } else if (t.priority == "HIGH") {
                    BorderStroke(1.dp, Color(0xFFFFA000).copy(alpha = 0.6f))
                } else {
                    BorderStroke(0.5.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f))
                },
                shape = RoundedCornerShape(14.dp)
            ) {
                Column(Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Checkbox(
                            checked = done,
                            onCheckedChange = { isChecked ->
                                val dateStr = if (isChecked) todayStr else ""
                                val updatedHistory = if (t.isHabit) {
                                    val list = historyList.toMutableList()
                                    if (isChecked) {
                                        if (!list.contains(todayStr)) list.add(todayStr)
                                    } else {
                                        list.remove(todayStr)
                                    }
                                    list
                                } else {
                                    historyList
                                }
                                val (cStreak, bStreak) = calculateHabitStreak(updatedHistory)
                                val updatedSubtasks = if (subtasksList.isNotEmpty()) {
                                    subtasksList.map {
                                        it.copy(isDone = isChecked, lastDoneDate = if (isChecked) todayStr else "")
                                    }
                                } else {
                                    subtasksList
                                }
                                scope.launch {
                                    dao.updateTask(
                                        t.copy(
                                            lastDoneDate = dateStr,
                                            historyDates = serializeHistoryDates(updatedHistory),
                                            streak = cStreak,
                                            bestStreak = maxOf(bStreak, t.bestStreak),
                                            subtasks = serializeSubtasks(updatedSubtasks)
                                        )
                                    )
                                }
                            }
                        )
                        Spacer(Modifier.width(8.dp))
                        Column(Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = t.title.ifBlank { "Без названия" },
                                    textDecoration = if (done) TextDecoration.LineThrough else null,
                                    fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.Bold,
                                    fontFamily = taskFontFamily,
                                    letterSpacing = taskSpacing,
                                    fontSize = 14.sp,
                                    color = if (done) Color.Gray else MaterialTheme.colorScheme.onSurface
                                )
                                if (t.isHabit) {
                                    Text(
                                        "🔥 ${t.streak} дн.",
                                        fontSize = 11.sp,
                                        fontWeight = if (isModernFont) FontWeight.Medium else FontWeight.Normal,
                                        fontFamily = taskFontFamily,
                                        letterSpacing = taskSpacing,
                                        color = if (t.streak > 0) Color(0xFFFF9800) else Color.Gray
                                    )
                                }
                            }
                            Spacer(Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(
                                    text = if (t.frequency == "Однажды") {
                                        SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(t.targetDate))
                                    } else {
                                        t.frequency
                                    },
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f)
                                )
                                if (t.timeOfDay == "MORNING") Text("🌅 Утро", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                                if (t.timeOfDay == "DAY") Text("☀️ День", fontSize = 10.sp, color = Color(0xFFF57C00))
                                if (t.timeOfDay == "EVENING") Text("🌙 Вечер", fontSize = 10.sp, color = Color(0xFF7B1FA2))
                                if (t.priority == "URGENT") Text("🔴 Срочно", fontSize = 10.sp, fontWeight = FontWeight.Normal, color = Color(0xFFD32F2F))
                                if (t.priority == "HIGH") Text("🟡 Важно", fontSize = 10.sp, fontWeight = FontWeight.Normal, color = Color(0xFFFFA000))
                                if (t.category.isNotBlank()) Text("#${t.category}", fontSize = 10.sp, color = MaterialTheme.colorScheme.primary)
                            }
                        }

                        // Attach video icon button directly on task card
                        IconButton(
                            onClick = {
                                isAttachingToNewForm = false
                                taskForVideoAttach = t
                                showAttachOptionsDialog = true
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                if (hasVideo) Icons.Default.Videocam else Icons.Outlined.VideoCall,
                                contentDescription = "Прикрепить видео",
                                tint = if (hasVideo) MaterialTheme.colorScheme.primary else Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        // Edit task button
                        IconButton(
                            onClick = { editingTask = t },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                Icons.Default.Edit,
                                contentDescription = "Редактировать",
                                tint = if (editingTask?.id == t.id) MaterialTheme.colorScheme.primary else Color.Gray,
                                modifier = Modifier.size(18.dp)
                            )
                        }

                        IconButton(
                            onClick = { scope.launch(Dispatchers.Default) { dao.deleteTask(t) } },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.DeleteOutline, contentDescription = "Удалить", tint = Color(0xFFE53935), modifier = Modifier.size(18.dp))
                        }
                    }

                    // Attached Video Preview Box
                    if (hasVideo) {
                        val vid = t.videoUrl!!
                        val isYt = isYouTubeUrl(vid)
                        val isRt = isRutubeUrl(vid)
                        val isVk = isVkVideoUrl(vid)
                        Spacer(Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(
                                1.dp,
                                if (isYt) Color(0xFFCC0000).copy(alpha = 0.4f)
                                else if (isRt) Color(0xFF00A0E3).copy(alpha = 0.4f)
                                else if (isVk) Color(0xFF0077FF).copy(alpha = 0.4f)
                                else MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { openVideo(context, vid) }
                        ) {
                            Row(
                                modifier = Modifier.padding(6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                // Thumbnail with play button overlay
                                Box(
                                    modifier = Modifier
                                        .size(width = 68.dp, height = 46.dp)
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(Color.Black),
                                    contentAlignment = Alignment.Center
                                ) {
                                    SafeMediaThumbnail(
                                        path = vid,
                                        isVideo = true,
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Crop,
                                        showVideoBadge = false
                                    )
                                    Box(
                                        modifier = Modifier
                                            .size(24.dp)
                                            .background(
                                                if (isYt) Color(0xFFCC0000)
                                                else if (isRt) Color(0xFF00A0E3)
                                                else if (isVk) Color(0xFF0077FF)
                                                else Color.Black.copy(alpha = 0.65f),
                                                CircleShape
                                            ),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(Icons.Default.PlayArrow, contentDescription = "Воспроизвести", tint = Color.White, modifier = Modifier.size(16.dp))
                                    }
                                }

                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                        Surface(
                                            color = if (isYt) Color(0xFFCC0000) else if (isRt) Color(0xFF00A0E3) else if (isVk) Color(0xFF0077FF) else MaterialTheme.colorScheme.primary,
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                if (isYt) "YOUTUBE" else if (isRt) "RUTUBE" else if (isVk) "VK ВИДЕО" else "ВИДЕО",
                                                color = Color.White,
                                                fontSize = 8.sp,
                                                fontWeight = FontWeight.Normal,
                                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                            )
                                        }
                                        Text(
                                            "Видеоинструкция",
                                            fontSize = 9.sp,
                                            color = Color.Gray,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        t.videoTitle?.ifBlank { null } ?: (if (isYt) "YouTube видео" else if (isRt) "Rutube видео" else "Скачанное видео"),
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 11.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        "Нажмите, чтобы воспроизвести",
                                        fontSize = 9.sp,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }

                                // Delete video button
                                IconButton(
                                    onClick = {
                                        scope.launch { dao.updateTask(t.copy(videoUrl = null, videoTitle = null)) }
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Открепить видео", tint = Color.Gray, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    // Habit mini-calendar grid (7 days)
                    if (t.isHabit) {
                        Spacer(Modifier.height(6.dp))
                        HorizontalDivider(thickness = 0.5.dp, color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        Spacer(Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Серия дней:", fontSize = 10.sp, fontWeight = FontWeight.Normal)
                            Text("Рекорд: 🏆 ${maxOf(t.bestStreak, bestStreak)} дн.", fontSize = 10.sp, color = Color(0xFFFF9800))
                        }
                        Spacer(Modifier.height(4.dp))
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            last7Days.forEach { (label, dateVal) ->
                                val isCheckedDay = historyList.contains(dateVal)
                                val isTodayDay = dateVal == todayStr
                                Card(
                                    modifier = Modifier
                                        .weight(1f)
                                        .clickable {
                                            val list = historyList.toMutableList()
                                            if (isCheckedDay) list.remove(dateVal) else list.add(dateVal)
                                            val (cs, bs) = calculateHabitStreak(list)
                                            scope.launch {
                                                dao.updateTask(
                                                    t.copy(
                                                        lastDoneDate = if (list.contains(todayStr)) todayStr else "",
                                                        historyDates = serializeHistoryDates(list),
                                                        streak = cs,
                                                        bestStreak = maxOf(bs, t.bestStreak)
                                                    )
                                                )
                                            }
                                        },
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isCheckedDay) Color(0xFF4CAF50) else if (isTodayDay) MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surface
                                    ),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Column(
                                        Modifier.fillMaxWidth().padding(vertical = 4.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(label, fontSize = 9.sp, color = if (isCheckedDay) Color.White else Color.Gray)
                                        Text(
                                            dateVal.split(".").firstOrNull() ?: "",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = if (isCheckedDay) Color.White else MaterialTheme.colorScheme.onSurface
                                        )
                                    }
                                }
                            }
                        }
                    }

                    // Subtasks checklist section
                    Spacer(Modifier.height(6.dp))
                    if (subTotal > 0) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { expandedSubtasks[t.id] = !isExpanded },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Чек-лист ($subDoneCount/$subTotal)", fontSize = 11.sp, fontWeight = FontWeight.Normal, color = MaterialTheme.colorScheme.primary)
                            Icon(
                                if (isExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                        LinearProgressIndicator(
                            progress = { if (subTotal > 0) subDoneCount.toFloat() / subTotal else 0f },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).height(4.dp),
                            color = Color(0xFF4CAF50),
                            trackColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
                        )

                        if (isExpanded) {
                            Column(Modifier.fillMaxWidth().padding(top = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                subtasksList.forEach { st ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Checkbox(
                                            checked = st.isDone,
                                            onCheckedChange = { chk ->
                                                val updated = subtasksList.map {
                                                    if (it.id == st.id) it.copy(isDone = chk, lastDoneDate = if (chk) todayStr else "") else it
                                                }
                                                val allDone = updated.isNotEmpty() && updated.all { it.isDone }
                                                val dateStr = if (allDone) todayStr else if (!chk && done) "" else t.lastDoneDate
                                                val updatedHistory = if (t.isHabit) {
                                                    val list = historyList.toMutableList()
                                                    if (allDone) {
                                                        if (!list.contains(todayStr)) list.add(todayStr)
                                                    } else if (!chk) {
                                                        list.remove(todayStr)
                                                    }
                                                    list
                                                } else {
                                                    historyList
                                                }
                                                val (cStreak, bStreak) = calculateHabitStreak(updatedHistory)
                                                scope.launch {
                                                    dao.updateTask(
                                                        t.copy(
                                                            subtasks = serializeSubtasks(updated),
                                                            lastDoneDate = dateStr,
                                                            historyDates = serializeHistoryDates(updatedHistory),
                                                            streak = cStreak,
                                                            bestStreak = maxOf(bStreak, t.bestStreak)
                                                        )
                                                    )
                                                }
                                            },
                                            modifier = Modifier.size(28.dp)
                                        )
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            st.title,
                                            textDecoration = if (st.isDone) TextDecoration.LineThrough else null,
                                            fontSize = 12.sp,
                                            color = if (st.isDone) Color.Gray else MaterialTheme.colorScheme.onSurface,
                                            modifier = Modifier.weight(1f)
                                        )
                                        IconButton(
                                            onClick = {
                                                val updated = subtasksList.filter { it.id != st.id }
                                                val allDone = updated.isNotEmpty() && updated.all { it.isDone }
                                                val dateStr = if (allDone) todayStr else if (updated.isEmpty()) t.lastDoneDate else if (!allDone && done) "" else t.lastDoneDate
                                                scope.launch { dao.updateTask(t.copy(subtasks = serializeSubtasks(updated), lastDoneDate = dateStr)) }
                                            },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Close, contentDescription = "Удалить подзадачу", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                        }
                                    }
                                }

                                // Quick add subtask input
                                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 2.dp)) {
                                    val currentText = newSubtaskInputs[t.id] ?: ""
                                    OutlinedTextField(
                                        value = currentText,
                                        onValueChange = { newSubtaskInputs[t.id] = it },
                                        placeholder = { Text("Добавить пункт...", fontSize = 11.sp) },
                                        modifier = Modifier.weight(1f),
                                        singleLine = true
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    IconButton(
                                        onClick = {
                                            if (currentText.isNotBlank()) {
                                                val updated = subtasksList + SubtaskItem(title = currentText.trim())
                                                scope.launch { dao.updateTask(t.copy(subtasks = serializeSubtasks(updated))) }
                                                newSubtaskInputs[t.id] = ""
                                            }
                                        },
                                        modifier = Modifier.size(36.dp)
                                    ) {
                                        Icon(Icons.Default.Add, contentDescription = "Добавить", tint = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            }
                        }
                    } else {
                        Text(
                            "+ Добавить чек-лист",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.clickable {
                                val updated = listOf(SubtaskItem(title = "Пункт 1"))
                                expandedSubtasks[t.id] = true
                                scope.launch { dao.updateTask(t.copy(subtasks = serializeSubtasks(updated))) }
                            }
                        )
                    }
                }
            }
        }

        // Filter and display list based on active tab
        val filteredTasks = when (activeTab) {
            1 -> tasks.filter { it.isHabit }.sortedByDescending { it.streak }
            else -> tasks.sortedBy { isTaskActuallyDone(it) }
        }

        if (activeTab == 2) {
            // Grouped by time of day
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val groups = listOf(Triple("MORNING", "🌅 Утро", Color(0xFF1976D2)), Triple("DAY", "☀️ День", Color(0xFFF57C00)), Triple("EVENING", "🌙 Вечер", Color(0xFF7B1FA2)), Triple("ANY", "⏳ В любое время", Color.Gray))
                groups.forEach { (timeKey, titleLbl, grpColor) ->
                    val grpTasks = tasks.filter { (it.timeOfDay.ifBlank { "ANY" }) == timeKey }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                            Text(titleLbl, fontWeight = FontWeight.Normal, fontSize = 14.sp, color = grpColor)
                            Spacer(Modifier.width(6.dp))
                            Text("(${grpTasks.size})", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                    items(grpTasks) { t ->
                        TaskCardItem(t)
                    }
                }
            }
        } else if (activeTab == 3) {
            // Grouped by priority
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                val priorities = listOf(Triple("URGENT", "🔴 Срочные задачи", Color(0xFFD32F2F)), Triple("HIGH", "🟡 Важные задачи", Color(0xFFFFA000)), Triple("NORMAL", "⚪ Обычные дела", Color.Gray))
                priorities.forEach { (priKey, titleLbl, priColor) ->
                    val priTasks = tasks.filter { (it.priority.ifBlank { "NORMAL" }) == priKey }
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 4.dp)) {
                            Text(titleLbl, fontWeight = FontWeight.Normal, fontSize = 14.sp, color = priColor)
                            Spacer(Modifier.width(6.dp))
                            Text("(${priTasks.size})", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                    items(priTasks) { t ->
                        TaskCardItem(t)
                    }
                }
            }
        } else {
            // Normal / Habits list
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filteredTasks) { t ->
                    TaskCardItem(t)
                }
            }
        }
    }

    // -------------------------------------------------------------
    // ДИАЛОГ 1: ВЫБОР СПОСОБА ПРИКРЕПЛЕНИЯ ВИДЕО К ЗАДАЧЕ
    // -------------------------------------------------------------
    if (showAttachOptionsDialog) {
        val targetName = if (isAttachingToNewForm) "новой задаче" else "«${taskForVideoAttach?.title?.take(25) ?: "задаче"}»"
        AlertDialog(
            onDismissRequest = { showAttachOptionsDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Videocam, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Видео к $targetName", fontSize = 16.sp, fontWeight = FontWeight.Normal)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "Выберите, какое видео прикрепить для наглядной инструкции:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (!VideoLimitManager.canLoadVideo(context)) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "Нужно получить PRO версию для последующей загрузки видео",
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    // Вариант 1: Ссылка YouTube / Rutube / Онлайн / Скачать
                    Button(
                        onClick = {
                            if (!VideoLimitManager.checkAndWarn(context)) {
                                return@Button
                            }
                            showAttachOptionsDialog = false
                            inputVideoUrl = ""
                            inputVideoCustomTitle = ""
                            taskVideoDownloadError = null
                            showVideoUrlDialog = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Ссылка на видео (YouTube / Rutube / MP4)", fontSize = 12.sp)
                    }

                    // Вариант 2: Выбрать из уже скачанных / сохранённых видео
                    if (allSavedVideos.isNotEmpty()) {
                        OutlinedButton(
                            onClick = {
                                showAttachOptionsDialog = false
                                showMediaGalleryDialog = true
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Выбрать из существующих видео (${allSavedVideos.size})", fontSize = 12.sp)
                        }
                    }

                    // Вариант 3: Выбрать файл из галереи устройства
                    OutlinedButton(
                        onClick = {
                            if (!VideoLimitManager.checkAndWarn(context)) {
                                return@OutlinedButton
                            }
                            showAttachOptionsDialog = false
                            try {
                                taskVideoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            } catch (_: Throwable) {
                                Toast.makeText(context, "Не удалось открыть выбор видео", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FileOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Выбрать файл с устройства", fontSize = 12.sp)
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showAttachOptionsDialog = false }) {
                    Text("Отмена")
                }
            }
        )
    }

    // -------------------------------------------------------------
    // ДИАЛОГ 2: ВВОД ССЫЛКИ НА ВИДЕО (YOUTUBE / RUTUBE / СКАЧИВАНИЕ)
    // -------------------------------------------------------------
    if (showVideoUrlDialog) {
        val ytId = remember(inputVideoUrl) { extractYouTubeId(inputVideoUrl.trim()) }
        val rtId = remember(inputVideoUrl) { extractRutubeId(inputVideoUrl.trim()) }
        val isRt = remember(inputVideoUrl) { isRutubeUrl(inputVideoUrl.trim()) }
        val isVk = remember(inputVideoUrl) { isVkVideoUrl(inputVideoUrl.trim()) }
        val vkId = remember(inputVideoUrl) { extractVkVideoId(inputVideoUrl.trim()) }
        val hasClipboardText = remember(showVideoUrlDialog) {
            try {
                val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                cm != null && cm.hasPrimaryClip() && (cm.primaryClip?.itemCount ?: 0) > 0
            } catch (_: Throwable) { false }
        }

        AlertDialog(
            onDismissRequest = { if (!isDownloadingTaskVideo) showVideoUrlDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Видео к задаче", fontSize = 16.sp, fontWeight = FontWeight.Normal)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!VideoLimitManager.canLoadVideo(context)) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.5f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    "Нужно получить PRO версию для последующей загрузки видео",
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Text(
                        "Вставьте ссылку на YouTube, Rutube или видеоролик:",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = inputVideoUrl,
                        onValueChange = { inputVideoUrl = it },
                        label = { Text("Ссылка на видео") },
                        placeholder = { Text("https://rutube.ru/... или https://youtu.be/...") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = false,
                        maxLines = 3,
                        trailingIcon = {
                            if (inputVideoUrl.isEmpty() && hasClipboardText) {
                                TextButton(onClick = {
                                    try {
                                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                                        val clip = if (cm != null && cm.hasPrimaryClip() && (cm.primaryClip?.itemCount ?: 0) > 0) {
                                            cm.primaryClip?.getItemAt(0)?.coerceToText(context)?.toString()
                                        } else null
                                        if (!clip.isNullOrBlank()) {
                                            inputVideoUrl = clip.trim()
                                        }
                                    } catch (_: Throwable) {}
                                }) {
                                    Text("Вставить", fontSize = 10.sp)
                                }
                            }
                        }
                    )

                    OutlinedTextField(
                        value = inputVideoCustomTitle,
                        onValueChange = { inputVideoCustomTitle = it },
                        label = { Text("Название видео (опционально)") },
                        placeholder = { Text("например: Техника прокачки пресса") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Preview tags
                    if (ytId != null) {
                        Surface(
                            color = Color(0xFFCC0000).copy(alpha = 0.08f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFFCC0000).copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = Color(0xFFCC0000), modifier = Modifier.size(24.dp))
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text("Обнаружено YouTube видео", fontWeight = FontWeight.Normal, fontSize = 11.sp, color = Color(0xFFCC0000))
                                    Text("ID: $ytId", fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                        }
                    }

                    if (isRt) {
                        Surface(
                            color = Color(0xFF00A0E3).copy(alpha = 0.08f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFF00A0E3).copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = Color(0xFF00A0E3), modifier = Modifier.size(24.dp))
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text("Обнаружено Rutube видео", fontWeight = FontWeight.Normal, fontSize = 11.sp, color = Color(0xFF00A0E3))
                                    Text(rtId?.let { "ID: $it" } ?: "Rutube", fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                        }
                    }

                    if (isVk) {
                        Surface(
                            color = Color(0xFF0077FF).copy(alpha = 0.08f),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, Color(0xFF0077FF).copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PlayCircleFilled, contentDescription = null, tint = Color(0xFF0077FF), modifier = Modifier.size(24.dp))
                                Spacer(Modifier.width(8.dp))
                                Column {
                                    Text("Обнаружено VK Видео", fontWeight = FontWeight.Normal, fontSize = 11.sp, color = Color(0xFF0077FF))
                                    Text(vkId?.let { "ID: $it • Доступно скачивание и онлайн" } ?: "VK Видео / Клип", fontSize = 10.sp, color = Color.Gray)
                                }
                            }
                        }
                    }

                    if (isDownloadingTaskVideo) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    CircularProgressIndicator(modifier = Modifier.size(18.dp), strokeWidth = 2.dp)
                                    Text(taskVideoDownloadStatus.ifBlank { "Загрузка видео..." }, fontSize = 11.sp, fontWeight = FontWeight.Medium)
                                }
                                LinearProgressIndicator(modifier = Modifier.fillMaxWidth().height(4.dp))
                            }
                        }
                    }

                    if (!taskVideoDownloadError.isNullOrBlank()) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.55f),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(
                                    "Не удалось скачать файл: ${taskVideoDownloadError!!}",
                                    color = MaterialTheme.colorScheme.onErrorContainer,
                                    fontSize = 10.5.sp
                                )
                                Button(
                                    onClick = {
                                        val clean = inputVideoUrl.trim()
                                        if (clean.isBlank()) return@Button
                                        val yt = extractYouTubeId(clean)
                                        val rt = extractRutubeId(clean)
                                        val standardUrl = if (yt != null) {
                                            "https://www.youtube.com/watch?v=$yt"
                                        } else if (rt != null && !clean.contains("?")) {
                                            "https://rutube.ru/video/$rt/"
                                        } else {
                                            clean
                                        }
                                        val defaultTitle = when {
                                            yt != null -> "YouTube ($yt)"
                                            rt != null -> "Rutube ($rt)"
                                            isRutubeUrl(clean) -> "Rutube видео"
                                            isVkVideoUrl(clean) -> "VK Видео"
                                            else -> "Видео по ссылке"
                                        }
                                        val finalTitle = inputVideoCustomTitle.trim().ifBlank { defaultTitle }
                                        applyVideoToTarget(standardUrl, finalTitle)
                                        showVideoUrlDialog = false
                                        inputVideoUrl = ""
                                        inputVideoCustomTitle = ""
                                        Toast.makeText(context, "Видео прикреплено онлайн!", Toast.LENGTH_SHORT).show()
                                    },
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (ytId != null) Color(0xFFCC0000)
                                                         else if (rtId != null || isRt) Color(0xFF00A0E3)
                                                         else if (isVk) Color(0xFF0077FF)
                                                         else MaterialTheme.colorScheme.primary
                                    )
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.width(6.dp))
                                    Text("Прикрепить онлайн сейчас (без скачивания)", fontSize = 11.sp, fontWeight = FontWeight.Normal)
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    // Вариант 1: Прикрепить ссылку онлайн (мгновенно, без скачивания больших файлов)
                    Button(
                        onClick = {
                            if (!VideoLimitManager.checkAndWarn(context)) {
                                taskVideoDownloadError = VideoLimitManager.PRO_REQUIRED_MESSAGE
                                return@Button
                            }
                            val clean = inputVideoUrl.trim()
                            if (clean.isBlank()) return@Button
                            val yt = extractYouTubeId(clean)
                            val rt = extractRutubeId(clean)
                            val standardUrl = if (yt != null) {
                                "https://www.youtube.com/watch?v=$yt"
                            } else if (rt != null && !clean.contains("?")) {
                                "https://rutube.ru/video/$rt/"
                            } else {
                                clean
                            }
                            val defaultTitle = when {
                                yt != null -> "YouTube ($yt)"
                                rt != null -> "Rutube ($rt)"
                                isRutubeUrl(clean) -> "Rutube видео"
                                isVkVideoUrl(clean) -> "VK Видео"
                                else -> "Видео по ссылке"
                            }
                            val finalTitle = inputVideoCustomTitle.trim().ifBlank { defaultTitle }
                            VideoLimitManager.recordVideoLoaded(context)
                            applyVideoToTarget(standardUrl, finalTitle)
                            showVideoUrlDialog = false
                            inputVideoUrl = ""
                            inputVideoCustomTitle = ""
                            Toast.makeText(context, "Видео прикреплено к задаче!", Toast.LENGTH_SHORT).show()
                        },
                        enabled = !isDownloadingTaskVideo && inputVideoUrl.isNotBlank(),
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (ytId != null) Color(0xFFCC0000)
                                             else if (rtId != null || isRt) Color(0xFF00A0E3)
                                             else if (isVk) Color(0xFF0077FF)
                                             else MaterialTheme.colorScheme.primary
                        )
                    ) {
                        Text(
                            if (ytId != null) "Прикрепить YouTube (Онлайн) • Рекомендуется"
                            else if (rtId != null || isRt) "Прикрепить RUTUBE (Онлайн) • Рекомендуется"
                            else if (isVk) "Прикрепить VK Видео (Онлайн) • Рекомендуется"
                            else "Прикрепить онлайн • Рекомендуется",
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Normal
                        )
                    }

                    // Вариант 2: Скачать файл на телефон и прикрепить локальный файл
                    OutlinedButton(
                        onClick = {
                            if (!VideoLimitManager.checkAndWarn(context)) {
                                taskVideoDownloadError = VideoLimitManager.PRO_REQUIRED_MESSAGE
                                return@OutlinedButton
                            }
                            val clean = inputVideoUrl.trim()
                            if (clean.isBlank()) return@OutlinedButton
                            val yt = extractYouTubeId(clean)
                            val rt = extractRutubeId(clean)
                            val userTitle = inputVideoCustomTitle.trim()
                            val appContext = context.applicationContext
                            isDownloadingTaskVideo = true
                            taskVideoDownloadStatus = "Подключение к источнику..."
                            taskVideoDownloadError = null

                            scope.launch(Dispatchers.Default) {
                                try {
                                    if (isVk || isVkVideoUrl(clean) || vkId != null) {
                                        withContext(Dispatchers.Main) { taskVideoDownloadStatus = "Получение VK Видео..." }
                                        var vkDownloadError: String? = null
                                        val result = downloadVkVideo(
                                            context = appContext,
                                            vkUrl = clean,
                                            onProgress = { status ->
                                                scope.launch(Dispatchers.Main) { taskVideoDownloadStatus = status }
                                            },
                                            onError = { err ->
                                                vkDownloadError = err
                                            }
                                        )
                                        val downloadedFile = result.file
                                        if (downloadedFile != null && downloadedFile.exists()) {
                                            val finalTitle = userTitle.ifBlank { result.title ?: "VK Видео" }
                                            withContext(Dispatchers.Main) {
                                                VideoLimitManager.recordVideoLoaded(appContext)
                                                applyVideoToTarget(downloadedFile.absolutePath, finalTitle)
                                                isDownloadingTaskVideo = false
                                                showVideoUrlDialog = false
                                                inputVideoUrl = ""
                                                inputVideoCustomTitle = ""
                                                Toast.makeText(appContext, "VK Видео скачано и прикреплено к задаче!", Toast.LENGTH_SHORT).show()
                                            }
                                            return@launch
                                        } else {
                                            withContext(Dispatchers.Main) {
                                                isDownloadingTaskVideo = false
                                                taskVideoDownloadError = vkDownloadError ?: "Не удалось скачать VK Видео. Нажмите «Прикрепить онлайн»"
                                            }
                                            return@launch
                                        }
                                    }

                                    if (rt != null || isRutubeUrl(clean)) {
                                        val activeRtId = rt ?: extractRutubeId(clean)
                                        if (activeRtId != null) {
                                            withContext(Dispatchers.Main) { taskVideoDownloadStatus = "Получение Rutube видео..." }
                                            var rutubeDownloadError: String? = null
                                            val downloadedFile = downloadRutubeVideo(
                                                context = appContext,
                                                rtId = activeRtId,
                                                onProgress = { status ->
                                                    scope.launch(Dispatchers.Main) { taskVideoDownloadStatus = status }
                                                },
                                                onError = { err ->
                                                    rutubeDownloadError = err
                                                }
                                            )
                                            if (downloadedFile != null && downloadedFile.exists()) {
                                                val finalTitle = userTitle.ifBlank { "Rutube ($activeRtId)" }
                                                withContext(Dispatchers.Main) {
                                                    VideoLimitManager.recordVideoLoaded(appContext)
                                                    applyVideoToTarget(downloadedFile.absolutePath, finalTitle)
                                                    isDownloadingTaskVideo = false
                                                    showVideoUrlDialog = false
                                                    inputVideoUrl = ""
                                                    inputVideoCustomTitle = ""
                                                    Toast.makeText(appContext, "Видео скачано и прикреплено к задаче!", Toast.LENGTH_SHORT).show()
                                                }
                                                return@launch
                                            } else {
                                                withContext(Dispatchers.Main) {
                                                    isDownloadingTaskVideo = false
                                                    taskVideoDownloadError = rutubeDownloadError ?: "Сервер Rutube ограничил доступ. Нажмите «Прикрепить онлайн»"
                                                }
                                                return@launch
                                            }
                                        }
                                    }

                                    if (yt != null) {
                                        withContext(Dispatchers.Main) { taskVideoDownloadStatus = "Загрузка YouTube..." }
                                        var ytErr: String? = null
                                        val downloadedFile = downloadYouTubeVideo(
                                            context = appContext,
                                            ytId = yt,
                                            onProgress = { status ->
                                                scope.launch(Dispatchers.Main) { taskVideoDownloadStatus = status }
                                            },
                                            onError = { err -> ytErr = err }
                                        )
                                        if (downloadedFile != null && downloadedFile.exists()) {
                                            val finalTitle = userTitle.ifBlank { "YouTube ($yt)" }
                                            withContext(Dispatchers.Main) {
                                                VideoLimitManager.recordVideoLoaded(appContext)
                                                applyVideoToTarget(downloadedFile.absolutePath, finalTitle)
                                                isDownloadingTaskVideo = false
                                                showVideoUrlDialog = false
                                                inputVideoUrl = ""
                                                inputVideoCustomTitle = ""
                                                Toast.makeText(appContext, "Видео скачано и прикреплено к задаче!", Toast.LENGTH_SHORT).show()
                                            }
                                            return@launch
                                        } else {
                                            withContext(Dispatchers.Main) {
                                                isDownloadingTaskVideo = false
                                                taskVideoDownloadError = ytErr ?: "Не удалось скачать. Нажмите «Прикрепить YouTube (Онлайн)»"
                                            }
                                            return@launch
                                        }
                                    }

                                    // Direct file download (.mp4)
                                    withContext(Dispatchers.Main) { taskVideoDownloadStatus = "Скачивание файла..." }
                                    val conn = (URL(clean).openConnection() as HttpURLConnection).apply {
                                        connectTimeout = 8000
                                        readTimeout = 20000
                                        setRequestProperty("User-Agent", "Mozilla/5.0")
                                    }
                                    if (conn.responseCode in 200..299) {
                                        val outFile = File(appContext.filesDir, "task_vid_${System.currentTimeMillis()}.mp4")
                                        outFile.outputStream().use { out -> conn.inputStream.copyTo(out) }
                                        val finalTitle = userTitle.ifBlank { "Видео файл" }
                                        withContext(Dispatchers.Main) {
                                            VideoLimitManager.recordVideoLoaded(appContext)
                                            applyVideoToTarget(outFile.absolutePath, finalTitle)
                                            isDownloadingTaskVideo = false
                                            showVideoUrlDialog = false
                                            inputVideoUrl = ""
                                            inputVideoCustomTitle = ""
                                            Toast.makeText(appContext, "Видео скачано и прикреплено!", Toast.LENGTH_SHORT).show()
                                        }
                                    } else {
                                        withContext(Dispatchers.Main) {
                                            isDownloadingTaskVideo = false
                                            taskVideoDownloadError = "Ошибка сервера: код ${conn.responseCode}"
                                        }
                                    }
                                } catch (e: Throwable) {
                                    withContext(Dispatchers.Main) {
                                        isDownloadingTaskVideo = false
                                        taskVideoDownloadError = e.message ?: "Ошибка загрузки"
                                    }
                                }
                            }
                        },
                        enabled = !isDownloadingTaskVideo && inputVideoUrl.isNotBlank(),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Скачать файл и прикрепить офлайн", fontSize = 11.5.sp)
                    }
                }
            },
            dismissButton = {
                TextButton(
                    onClick = { showVideoUrlDialog = false },
                    enabled = !isDownloadingTaskVideo
                ) {
                    Text("Закрыть")
                }
            }
        )
    }

    // -------------------------------------------------------------
    // ДИАЛОГ 3: ВЫБОР ИЗ СУЩЕСТВУЮЩИХ / СКАЧАННЫХ ВИДЕО
    // -------------------------------------------------------------
    if (showMediaGalleryDialog) {
        AlertDialog(
            onDismissRequest = { showMediaGalleryDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VideoLibrary, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Сохранённые видео (${allSavedVideos.size})", fontSize = 16.sp, fontWeight = FontWeight.Normal)
                }
            },
            text = {
                Box(modifier = Modifier.fillMaxWidth().heightIn(max = 380.dp)) {
                    if (allSavedVideos.isEmpty()) {
                        Text("Нет сохранённых видео", color = Color.Gray, fontSize = 12.sp, modifier = Modifier.align(Alignment.Center))
                    } else {
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(allSavedVideos) { path ->
                                val isYt = isYouTubeUrl(path)
                                val isRt = isRutubeUrl(path)
                                val isLocal = !path.startsWith("http://") && !path.startsWith("https://")
                                Card(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            val title = when {
                                                isYt -> "YouTube видео"
                                                isRt -> "Rutube видео"
                                                isLocal -> File(path).name
                                                else -> "Видео"
                                            }
                                            applyVideoToTarget(path, title)
                                            showMediaGalleryDialog = false
                                            Toast.makeText(context, "Видео прикреплено к задаче!", Toast.LENGTH_SHORT).show()
                                        },
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(width = 54.dp, height = 36.dp)
                                                .clip(RoundedCornerShape(6.dp))
                                                .background(Color.Black),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            SafeMediaThumbnail(
                                                path = path,
                                                isVideo = true,
                                                modifier = Modifier.fillMaxSize(),
                                                contentScale = ContentScale.Crop,
                                                showVideoBadge = false
                                            )
                                        }

                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                when {
                                                    isYt -> "YouTube"
                                                    isRt -> "RUTUBE"
                                                    isLocal -> File(path).name
                                                    else -> "Онлайн видео"
                                                },
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.Normal,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                if (isLocal) "Скачанное видео (${(try { File(path).length() / (1024 * 1024) } catch (_: Throwable) { 0 })} МБ)" else path,
                                                fontSize = 9.sp,
                                                color = Color.Gray,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }

                                        IconButton(
                                            onClick = { openVideo(context, path) },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(Icons.Default.PlayArrow, contentDescription = "Просмотр", tint = MaterialTheme.colorScheme.primary)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { showMediaGalleryDialog = false }) {
                    Text("Закрыть")
                }
            }
        )
    }
}

