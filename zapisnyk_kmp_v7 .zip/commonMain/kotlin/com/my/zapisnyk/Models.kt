package com.my.zapisnyk


import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor


// ==========================================
// 1. МОДЕЛИ ДАННЫХ (v23)
// ==========================================

enum class CatType { HISTORY, BALANCE, INCOME }
data class CategoryConfig(
    val id: String = "",
    val name: String = "",
    val color: Int = 0,
    val type: CatType? = CatType.HISTORY,
    val iconKey: String? = "",
    val customIconUri: String? = ""
)
data class FinanceItem(val id: Long = System.currentTimeMillis(), val amount: Double, val note: String)
data class CategoryExpenseDetail(val date: Long, val amount: Double, val note: String, val originalItem: FinanceItem? = null)
data class FinanceSectionInfo(
    val id: String,
    val name: String,
    val color: Color,
    val total: Double,
    val type: String, // "INCOME", "EXPENSE", "BALANCE"
    val isExcluded: Boolean = false,
    val balance: Double? = null
)

data class SavingsGoal(
    val id: String = UUID.randomUUID().toString(),
    val categoryId: String,
    val title: String = "",
    val targetAmount: Double = 0.0,
    val trackMode: String = "MONTH_ADDITIONS", // "MONTH_ADDITIONS" (взносы за месяц) или "TOTAL_BALANCE" (общий баланс)
    val monthKey: String = "" // пустая строка = повторять каждый месяц, иначе "YYYY-M"
)

fun getSavingsGoals(context: Context): List<SavingsGoal> {
    return try {
        val sp = context.getSharedPreferences("fin_goals", 0)
        val json = sp.getString("goals", "[]") ?: "[]"
        val type = object : TypeToken<List<SavingsGoal>>() {}.type
        Gson().fromJson<List<SavingsGoal>>(json, type) ?: emptyList()
    } catch (_: Exception) {
        emptyList()
    }
}

fun saveSavingsGoals(context: Context, goals: List<SavingsGoal>) {
    try {
        val sp = context.getSharedPreferences("fin_goals", 0)
        sp.edit().putString("goals", Gson().toJson(goals)).apply()
    } catch (_: Exception) {}
}

@Entity(tableName = "finance")
data class DiaryFinance(
    @PrimaryKey val date: Long,
    val income: Double = 0.0,
    val expense: Double = 0.0,
    val savings_deposit: Double = 0.0,
    val debt: Double = 0.0,
    val incHistory: String = "[]",
    val expHistory: String = "[]",
    val depHistory: String = "[]",
    val dynamicData: String = "{}",
    val dynamicBalances: String = "{}"
)

@Entity(tableName = "notes")
data class DiaryNote(
    @PrimaryKey val date: Long,
    val title: String = "",
    val content: String = "",
    val mediaPaths: String = "[]",
    val mainMediaPath: String = "",
    val mood: String = "",
    val tags: String = "",
    val location: String = ""
)

@Entity(tableName = "shift_config")
data class ShiftConfig(
    @PrimaryKey val id: Int = 1,
    val startDate: Long,
    val isActive: Boolean = false,
    val alarmHour: Int = 7,
    val alarmMinute: Int = 0,
    val isAlarmEnabled: Boolean = false,
    val lastAlarmSetDate: String = "",
    val shiftColor: Int = 0xFFEF9A9A.toInt(),
    val pattern: String = "WRRR"
)

data class SubtaskItem(val id: String = UUID.randomUUID().toString(), val title: String, val isDone: Boolean = false, val lastDoneDate: String = "")

@Entity(tableName = "tasks")
data class DiaryTask(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val title: String,
    val frequency: String,
    val lastDoneDate: String = "",
    val targetDate: Long = System.currentTimeMillis(),
    val isHabit: Boolean = false,
    val streak: Int = 0,
    val bestStreak: Int = 0,
    val historyDates: String = "[]",
    val subtasks: String = "[]",
    val timeOfDay: String = "ANY",
    val priority: String = "NORMAL",
    val category: String = "",
    val videoUrl: String? = null,
    val videoTitle: String? = null
)

@Entity(tableName = "debts")
data class DiaryDebt(@PrimaryKey(autoGenerate = true) val id: Int = 0, val creditor: String, val amount: Double, val dueDate: Long, val isPaid: Boolean = false, val createdAt: Long = System.currentTimeMillis(), val paidDate: Long = 0L)

@Entity(tableName = "expected_finance")
data class ExpectedFinance(@PrimaryKey(autoGenerate = true) val id: Int = 0, val title: String, val amount: Double, val dayOfMonth: Int, val isIncome: Boolean)

data class BackupData(
    val notes: List<DiaryNote>?,
    val tasks: List<DiaryTask>?,
    val shiftConfig: ShiftConfig?,
    val finances: List<DiaryFinance>?,
    val debts: List<DiaryDebt>?,
    val expectedFinances: List<ExpectedFinance>?,
    val categoryList: List<CategoryConfig>?,
    val sectionNames: Map<String, String>? = null,
    val hiddenSections: List<String>? = null,
    val expenseLimit: Double? = null,
    val capitalOverrides: Map<String, Double>? = null,
    val excludedFromLimit: List<String>? = null,
    val savingsGoals: List<SavingsGoal>? = null,
    val hasCar: Boolean? = null,
    val cars: List<CarItem>? = null,
    val carEvents: List<CarEventItem>? = null,
    val carMileageLogs: List<CarMileageItem>? = null,
    val carReminders: List<CarReminderItem>? = null
)

// ==========================================
// CAR GARAGE DATA MODELS (МОЯ МАШИНА / ГАРАЖ)
// ==========================================
data class CarItem(
    val id: String = generateUUID(),
    val brand: String,
    val model: String,
    val carType: String = "Седан",
    val year: Int? = null,
    val plateNumber: String? = null,
    val color: String = "#2563EB",
    val currentOdometer: Int = 0,
    val fuelType: String = "АИ-95",
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

data class CarEventItem(
    val id: String = generateUUID(),
    val carId: String,
    val date: Long = System.currentTimeMillis(),
    val type: String = "FUEL", // FUEL, SERVICE, REPAIR, WASH, OTHER
    val title: String,
    val amount: Double = 0.0,
    val isIncome: Boolean = false,
    val odometer: Int? = null,
    val liters: Double? = null,
    val pricePerLiter: Double? = null,
    val isFullTank: Boolean = true,
    val gasStation: String? = null,
    val fuelType: String? = null,
    val note: String = ""
)

data class CarMileageItem(
    val id: String = generateUUID(),
    val carId: String,
    val date: Long = System.currentTimeMillis(),
    val odometer: Int,
    val title: String,
    val note: String = ""
)

data class CarReminderItem(
    val id: String = generateUUID(),
    val carId: String,
    val title: String,
    val type: String = "BY_MILEAGE", // BY_DATE, BY_MILEAGE, BOTH
    val targetDate: Long? = null,
    val targetOdometer: Int? = null,
    val repeatIntervalKm: Int? = null,
    val isCompleted: Boolean = false,
    val note: String = ""
)

fun getCarEnabled(context: Context): Boolean {
    return try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        sp.getBoolean("has_car", true)
    } catch (_: Exception) { true }
}

fun saveCarEnabled(context: Context, enabled: Boolean) {
    try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        sp.edit().putBoolean("has_car", enabled).apply()
    } catch (_: Exception) {}
}

fun getCarList(context: Context): List<CarItem> {
    return try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        val isInit = sp.getBoolean("cars_initialized", false)
        if (!isInit && !sp.contains("cars")) {
            sp.edit().putBoolean("cars_initialized", true).apply()
            val sample = listOf(
                CarItem(
                    id = "sample_car_1",
                    brand = "Toyota",
                    model = "Camry",
                    carType = "Седан",
                    year = 2020,
                    plateNumber = "A777AA 77",
                    color = "#2563EB",
                    currentOdometer = 84500,
                    fuelType = "АИ-95",
                    notes = "Основной автомобиль"
                )
            )
            saveCarList(context, sample)
            return sample
        }
        val json = sp.getString("cars", "[]") ?: "[]"
        val type = object : TypeToken<List<CarItem>>() {}.type
        Gson().fromJson(json, type) ?: emptyList()
    } catch (_: Exception) { emptyList() }
}

fun saveCarList(context: Context, list: List<CarItem>) {
    try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        sp.edit().putBoolean("cars_initialized", true).putString("cars", Gson().toJson(list)).apply()
    } catch (_: Exception) {}
}

fun getCarEvents(context: Context): List<CarEventItem> {
    return try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        val isInit = sp.getBoolean("events_initialized", false)
        if (!isInit && !sp.contains("events")) {
            sp.edit().putBoolean("events_initialized", true).apply()
            val now = System.currentTimeMillis()
            val sample = listOf(
                CarEventItem(
                    id = "ev_sample_1",
                    carId = "sample_car_1",
                    date = now - 5 * 86400000L,
                    type = "FUEL",
                    title = "Заправка АИ-95",
                    amount = 3200.0,
                    odometer = 84200,
                    liters = 55.0,
                    pricePerLiter = 58.18,
                    gasStation = "Лукойл",
                    fuelType = "АИ-95"
                ),
                CarEventItem(
                    id = "ev_sample_2",
                    carId = "sample_car_1",
                    date = now - 18 * 86400000L,
                    type = "SERVICE",
                    title = "Замена масла и фильтров",
                    amount = 6800.0,
                    odometer = 83500,
                    note = "Масло 5W-30 + фильтр"
                )
            )
            saveCarEvents(context, sample)
            return sample
        }
        val json = sp.getString("events", "[]") ?: "[]"
        val type = object : TypeToken<List<CarEventItem>>() {}.type
        Gson().fromJson(json, type) ?: emptyList()
    } catch (_: Exception) { emptyList() }
}

fun saveCarEvents(context: Context, list: List<CarEventItem>) {
    try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        sp.edit().putBoolean("events_initialized", true).putString("events", Gson().toJson(list)).apply()
    } catch (_: Exception) {}
}

fun getCarMileageLogs(context: Context): List<CarMileageItem> {
    return try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        val isInit = sp.getBoolean("mileage_initialized", false)
        if (!isInit && !sp.contains("mileage")) {
            sp.edit().putBoolean("mileage_initialized", true).apply()
            val now = System.currentTimeMillis()
            val sample = listOf(
                CarMileageItem(id = "m1", carId = "sample_car_1", date = now - 60 * 86400000L, odometer = 81200, title = "Замер"),
                CarMileageItem(id = "m2", carId = "sample_car_1", date = now - 30 * 86400000L, odometer = 82900, title = "Замер"),
                CarMileageItem(id = "m3", carId = "sample_car_1", date = now - 18 * 86400000L, odometer = 83500, title = "ТО"),
                CarMileageItem(id = "m4", carId = "sample_car_1", date = now - 5 * 86400000L, odometer = 84200, title = "Заправка"),
                CarMileageItem(id = "m5", carId = "sample_car_1", date = now, odometer = 84500, title = "Текущий")
            )
            saveCarMileageLogs(context, sample)
            return sample
        }
        val json = sp.getString("mileage", "[]") ?: "[]"
        val type = object : TypeToken<List<CarMileageItem>>() {}.type
        Gson().fromJson(json, type) ?: emptyList()
    } catch (_: Exception) { emptyList() }
}

fun saveCarMileageLogs(context: Context, list: List<CarMileageItem>) {
    try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        sp.edit().putBoolean("mileage_initialized", true).putString("mileage", Gson().toJson(list)).apply()
    } catch (_: Exception) {}
}

fun getCarReminders(context: Context): List<CarReminderItem> {
    return try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        val isInit = sp.getBoolean("reminders_initialized", false)
        if (!isInit && !sp.contains("reminders")) {
            sp.edit().putBoolean("reminders_initialized", true).apply()
            val now = System.currentTimeMillis()
            val sample = listOf(
                CarReminderItem(
                    id = "r1",
                    carId = "sample_car_1",
                    title = "Замена масла (каждые 10 000 км)",
                    type = "BY_MILEAGE",
                    targetOdometer = 93500,
                    repeatIntervalKm = 10000,
                    note = "Синтетическое масло 5W-30"
                ),
                CarReminderItem(
                    id = "r2",
                    carId = "sample_car_1",
                    title = "Продление ОСАГО",
                    type = "BY_DATE",
                    targetDate = now + 45 * 86400000L,
                    note = "Тинькофф Страхование"
                )
            )
            saveCarReminders(context, sample)
            return sample
        }
        val json = sp.getString("reminders", "[]") ?: "[]"
        val type = object : TypeToken<List<CarReminderItem>>() {}.type
        Gson().fromJson(json, type) ?: emptyList()
    } catch (_: Exception) { emptyList() }
}

fun saveCarReminders(context: Context, list: List<CarReminderItem>) {
    try {
        val sp = context.getSharedPreferences("car_prefs", 0)
        sp.edit().putBoolean("reminders_initialized", true).putString("reminders", Gson().toJson(list)).apply()
    } catch (_: Exception) {}
}

@Dao
interface DiaryDao {
    @Query("SELECT * FROM notes ORDER BY date DESC") fun getAllNotes(): Flow<List<DiaryNote>>
    @Query("SELECT * FROM notes") suspend fun getAllNotesDirect(): List<DiaryNote>
    @Query("SELECT * FROM debts") suspend fun getAllDebtsDirect(): List<DiaryDebt>
    @Query("SELECT * FROM expected_finance") suspend fun getAllExpectedFinancesDirect(): List<ExpectedFinance>
    @Query("SELECT * FROM shift_config WHERE id = 1") suspend fun getShiftConfigDirect(): ShiftConfig?
    @Query("SELECT * FROM notes WHERE date = :date LIMIT 1") suspend fun getNoteByDateSync(date: Long): DiaryNote?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertNote(note: DiaryNote)
    suspend fun saveNote(note: DiaryNote) = insertNote(note)
    @Delete suspend fun deleteNote(note: DiaryNote)
    @Query("DELETE FROM notes WHERE date = :date") suspend fun deleteNoteByDate(date: Long)
    @Query("DELETE FROM finance WHERE date = :date") suspend fun deleteFinanceByDate(date: Long)
    @Query("SELECT * FROM shift_config WHERE id = 1") fun getShiftConfig(): Flow<ShiftConfig?>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveShiftConfig(config: ShiftConfig)
    @Query("SELECT * FROM tasks") fun getAllTasks(): Flow<List<DiaryTask>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveTask(task: DiaryTask)
    @Update suspend fun updateTask(task: DiaryTask)
    @Delete suspend fun deleteTask(task: DiaryTask)
    @Query("SELECT * FROM finance ORDER BY date DESC") fun getAllFinances(): Flow<List<DiaryFinance>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveFinance(finance: DiaryFinance)
    @Query("SELECT * FROM debts ORDER BY dueDate ASC") fun getAllDebts(): Flow<List<DiaryDebt>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveDebt(debt: DiaryDebt)
    @Update suspend fun updateDebt(debt: DiaryDebt)
    @Delete suspend fun deleteDebt(debt: DiaryDebt)
    @Query("SELECT * FROM expected_finance ORDER BY dayOfMonth ASC") fun getAllExpectedFinances(): Flow<List<ExpectedFinance>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun saveExpectedFinance(item: ExpectedFinance)
    @Delete suspend fun deleteExpectedFinance(item: ExpectedFinance)
}

val MIGRATION_22_23 = object : Migration(22, 23) {
    override fun migrate(db: SupportSQLiteDatabase) {
        try { db.execSQL("ALTER TABLE finance ADD COLUMN depHistory TEXT NOT NULL DEFAULT '[]'") } catch (_: Throwable) {}
    }
}

val MIGRATION_23_24 = object : Migration(23, 24) {
    override fun migrate(db: SupportSQLiteDatabase) {
        try { db.execSQL("ALTER TABLE debts ADD COLUMN createdAt INTEGER NOT NULL DEFAULT 0") } catch (_: Throwable) {}
        try { db.execSQL("ALTER TABLE debts ADD COLUMN paidDate INTEGER NOT NULL DEFAULT 0") } catch (_: Throwable) {}
    }
}

val MIGRATION_24_25 = object : Migration(24, 25) {
    override fun migrate(db: SupportSQLiteDatabase) {
        try { db.execSQL("ALTER TABLE notes ADD COLUMN location TEXT NOT NULL DEFAULT ''") } catch (_: Throwable) {}
    }
}

val MIGRATION_25_26 = object : Migration(25, 26) {
    override fun migrate(db: SupportSQLiteDatabase) {
        val stmts = listOf(
            "ALTER TABLE tasks ADD COLUMN isHabit INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE tasks ADD COLUMN streak INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE tasks ADD COLUMN bestStreak INTEGER NOT NULL DEFAULT 0",
            "ALTER TABLE tasks ADD COLUMN historyDates TEXT NOT NULL DEFAULT '[]'",
            "ALTER TABLE tasks ADD COLUMN subtasks TEXT NOT NULL DEFAULT '[]'",
            "ALTER TABLE tasks ADD COLUMN timeOfDay TEXT NOT NULL DEFAULT 'ANY'",
            "ALTER TABLE tasks ADD COLUMN priority TEXT NOT NULL DEFAULT 'NORMAL'",
            "ALTER TABLE tasks ADD COLUMN category TEXT NOT NULL DEFAULT ''"
        )
        for (sql in stmts) {
            try { db.execSQL(sql) } catch (_: Throwable) {}
        }
    }
}

val MIGRATION_26_27 = object : Migration(26, 27) {
    override fun migrate(db: SupportSQLiteDatabase) {
        val stmts = listOf(
            "ALTER TABLE tasks ADD COLUMN videoUrl TEXT",
            "ALTER TABLE tasks ADD COLUMN videoTitle TEXT"
        )
        for (sql in stmts) {
            try { db.execSQL(sql) } catch (_: Throwable) {}
        }
    }
}

@Database(entities = [DiaryNote::class, ShiftConfig::class, DiaryTask::class, DiaryFinance::class, DiaryDebt::class, ExpectedFinance::class], version = 27, exportSchema = false)
abstract class AppDatabase : RoomDatabase() { abstract fun diaryDao(): DiaryDao }

