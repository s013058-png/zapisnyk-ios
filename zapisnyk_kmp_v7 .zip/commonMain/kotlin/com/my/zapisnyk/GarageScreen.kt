package com.my.zapisnyk


import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor


// ==========================================
// 11. КОМПОНЕНТЫ «МОЯ МАШИНА / ГАРАЖ»
// ==========================================

fun calculateCarFuelStats(carId: String, events: List<CarEventItem>): Pair<Double?, Double> {
    val carEvents = events.filter { it.carId == carId }
    val totalSpent = carEvents.filter { !it.isIncome }.sumOf { it.amount }
    val fuelEvents = carEvents.filter { it.type == "FUEL" && it.odometer != null && (it.liters ?: 0.0) > 0.0 }
        .sortedBy { it.odometer }

    if (fuelEvents.size >= 2) {
        val firstOdo = fuelEvents.first().odometer ?: 0
        val lastOdo = fuelEvents.last().odometer ?: 0
        val dist = lastOdo - firstOdo
        if (dist > 0) {
            val litersSum = fuelEvents.drop(1).sumOf { it.liters ?: 0.0 }
            if (litersSum > 0) {
                val consumption = (litersSum / dist) * 100.0
                return Pair(consumption, totalSpent)
            }
        }
    }
    return Pair(null, totalSpent)
}

fun getReminderProgress(rem: CarReminderItem, car: CarItem): Triple<String, Float, Color> {
    val now = System.currentTimeMillis()
    if (rem.isCompleted) {
        return Triple("Выполнено", 1f, Color(0xFF2E7D32))
    }
    if (rem.type == "BOTH" || (rem.targetDate != null && rem.targetOdometer != null && rem.type != "BY_DATE" && rem.type != "BY_MILEAGE")) {
        val daysLeft = rem.targetDate?.let { ((it - now) / 86400000L).toInt() } ?: Int.MAX_VALUE
        val kmLeft = rem.targetOdometer?.let { it - car.currentOdometer } ?: Int.MAX_VALUE

        val interval = rem.repeatIntervalKm ?: 10000
        val startOdo = (rem.targetOdometer ?: car.currentOdometer) - interval
        val elapsed = (car.currentOdometer - startOdo).coerceAtLeast(0)
        val fractionKm = (elapsed.toFloat() / interval).coerceIn(0f, 1f)
        val fractionDays = if (daysLeft <= 0) 1f else ((30 - daysLeft).coerceIn(0, 30) / 30f)
        val fraction = maxOf(fractionKm, fractionDays)

        if (kmLeft <= 0 && daysLeft <= 0) {
            return Triple("Пора! Пробег и дата наступили", 1f, Color(0xFFD32F2F))
        }
        if (kmLeft <= 0) {
            return Triple("Пора! Пробег наступил (-${-kmLeft} км)", 1f, Color(0xFFD32F2F))
        }
        if (daysLeft <= 0) {
            val dText = if (daysLeft == 0) "сегодня" else "просрочено на ${-daysLeft} дн."
            return Triple("Пора! Срок наступил ($dText)", 1f, Color(0xFFD32F2F))
        }
        if (kmLeft <= 1000 || daysLeft <= 7) {
            return Triple("Скоро! $kmLeft км или $daysLeft дн. (что раньше)", fraction, Color(0xFFE65100))
        }
        return Triple("Осталось: $kmLeft км или $daysLeft дн. (что раньше)", fraction, Color(0xFF2E7D32))
    }
    if (rem.type == "BY_DATE" && rem.targetDate != null) {
        val daysLeft = ((rem.targetDate - now) / 86400000L).toInt()
        val text = when {
            daysLeft < 0 -> "Просрочено на ${-daysLeft} дн."
            daysLeft == 0 -> "Срок сегодня!"
            daysLeft == 1 -> "Срок завтра"
            daysLeft <= 7 -> "Осталось $daysLeft дн."
            else -> "Осталось $daysLeft дн."
        }
        val color = when {
            daysLeft < 0 -> Color(0xFFD32F2F)
            daysLeft <= 7 -> Color(0xFFE65100)
            else -> Color(0xFF2E7D32)
        }
        val fraction = if (daysLeft <= 0) 1f else ((30 - daysLeft).coerceIn(0, 30) / 30f)
        return Triple(text, fraction, color)
    } else if (rem.targetOdometer != null) {
        val kmLeft = rem.targetOdometer - car.currentOdometer
        val text = when {
            kmLeft <= 0 -> "Пора выполнить! (-${-kmLeft} км)"
            kmLeft <= 1000 -> "Осталось $kmLeft км (скоро)"
            else -> "Осталось $kmLeft км"
        }
        val color = when {
            kmLeft <= 0 -> Color(0xFFD32F2F)
            kmLeft <= 1000 -> Color(0xFFE65100)
            else -> Color(0xFF2E7D32)
        }
        val interval = rem.repeatIntervalKm ?: 10000
        val startOdo = rem.targetOdometer - interval
        val elapsed = (car.currentOdometer - startOdo).coerceAtLeast(0)
        val fraction = (elapsed.toFloat() / interval).coerceIn(0f, 1f)
        return Triple(text, fraction, color)
    }
    return Triple("Активно", 0.5f, Color(0xFF1976D2))
}

@Composable
fun CarGarageSection(
    cars: List<CarItem>,
    events: List<CarEventItem>,
    reminders: List<CarReminderItem>,
    isIncognito: Boolean,
    onSelectCar: (CarItem) -> Unit,
    onAddCar: () -> Unit,
    onAddEvent: (CarItem, String) -> Unit,
    onAddMileage: (CarItem) -> Unit,
    onAddReminder: (CarItem) -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F7FF)),
        border = BorderStroke(1.dp, Color(0xFF90CAF9)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(32.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1976D2)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🚗", fontSize = 16.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("АВТОМОБИЛЬ", fontWeight = FontWeight.Normal, fontSize = 13.sp, color = Color(0xFF0D47A1))
                            Spacer(Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = Color(0xFFBBDEFB)
                            ) {
                                Text(
                                    "${cars.size} авто",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF0D47A1),
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text("Учёт трат, заправок, пробега и ТО", fontSize = 10.sp, color = Color.Gray)
                    }
                }

                Surface(
                    onClick = onAddCar,
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1976D2)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Add, null, tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.width(2.dp))
                        Text("Добавить", fontSize = 11.sp, color = Color.White, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            if (cars.isEmpty()) {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = Color.White,
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("🚗", fontSize = 32.sp)
                        Spacer(Modifier.height(4.dp))
                        Text("Гараж пока пуст", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text(
                            "Добавьте свой автомобиль, чтобы следить за расходами, средним расходом топлива, динамикой пробега и напоминаниями о техобслуживании.",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                        Button(
                            onClick = onAddCar,
                            modifier = Modifier.padding(top = 8.dp)
                        ) {
                            Text("Добавить автомобиль")
                        }
                    }
                }
            } else {
                cars.forEach { car ->
                    val (fuelConsumption, totalSpent) = remember(car.id, events) {
                        calculateCarFuelStats(car.id, events)
                    }
                    val activeReminders = remember(car.id, reminders) {
                        reminders.filter { it.carId == car.id && !it.isCompleted }
                    }

                    Surface(
                        onClick = { onSelectCar(car) },
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White,
                        border = BorderStroke(1.dp, Color(0xFFBBDEFB)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            // Top row: Brand, Model, Plate, Chevron
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(Color(parseHexColorLong(try { car.color } catch (_: Exception) { "#2563EB" }))),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text("🚘", fontSize = 14.sp)
                                    }
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                "${car.brand} ${car.model}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.sp
                                            )
                                            Spacer(Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = Color(0xFFE3F2FD)
                                            ) {
                                                Text(
                                                    car.carType,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF1565C0),
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            if (!car.plateNumber.isNullOrBlank()) car.plateNumber else "Госномер не указан",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        "Детали",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Icon(
                                        Icons.Default.ChevronRight,
                                        null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            Spacer(Modifier.height(8.dp))

                            // 3 Quick metrics
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFF8FAFC),
                                    border = BorderStroke(0.5.dp, Color.LightGray.copy(alpha = 0.5f)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(Modifier.padding(6.dp)) {
                                        Text("ПРОБЕГ", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                        Text(
                                            "${String.format(Locale.US, "%,d", car.currentOdometer).replace(',', ' ')} км",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = Color(0xFF0F172A),
                                            maxLines = 1
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFF8FAFC),
                                    border = BorderStroke(0.5.dp, Color.LightGray.copy(alpha = 0.5f)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(Modifier.padding(6.dp)) {
                                        Text("РАСХОД", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                        Text(
                                            if (fuelConsumption != null) String.format(Locale.US, "%.1f л", fuelConsumption) else "—",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = Color(0xFF0284C7),
                                            maxLines = 1
                                        )
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color(0xFFF8FAFC),
                                    border = BorderStroke(0.5.dp, Color.LightGray.copy(alpha = 0.5f)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(Modifier.padding(6.dp)) {
                                        Text("ТРАТЫ", fontSize = 9.sp, color = Color.Gray, fontWeight = FontWeight.Bold)
                                        Text(
                                            if (isIncognito) "•••• ₽" else "${String.format(Locale.US, "%,.0f", totalSpent).replace(',', ' ')} ₽",
                                            fontSize = 12.sp,
                                            fontWeight = FontWeight.Normal,
                                            color = Color(0xFFD32F2F),
                                            maxLines = 1
                                        )
                                    }
                                }
                            }

                            // Active reminders preview
                            if (activeReminders.isNotEmpty()) {
                                Spacer(Modifier.height(6.dp))
                                val urgentReminder = activeReminders.first()
                                val (statusText, _, statusColor) = getReminderProgress(urgentReminder, car)
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = statusColor.copy(alpha = 0.08f),
                                    border = BorderStroke(0.5.dp, statusColor.copy(alpha = 0.3f)),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("🔔", fontSize = 11.sp)
                                        Spacer(Modifier.width(4.dp))
                                        Text(
                                            urgentReminder.title,
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Medium,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f)
                                        )
                                        Text(
                                            statusText,
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = statusColor
                                        )
                                    }
                                }
                            }

                            Spacer(Modifier.height(8.dp))

                            // Quick actions buttons (все 4 квадратика строго одинакового размера)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                Surface(
                                    onClick = { onAddEvent(car, "FUEL") },
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFFE0F2FE),
                                    modifier = Modifier.weight(1f).defaultMinSize(minWidth = 1.dp)
                                ) {
                                    Text(
                                        "⛽ Заправка",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF0369A1),
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 2.dp, vertical = 5.dp)
                                    )
                                }

                                Surface(
                                    onClick = { onAddEvent(car, "SERVICE") },
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFFFEF3C7),
                                    modifier = Modifier.weight(1f).defaultMinSize(minWidth = 1.dp)
                                ) {
                                    Text(
                                        "🔧 Событие",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFFB45309),
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 2.dp, vertical = 5.dp)
                                    )
                                }

                                Surface(
                                    onClick = { onAddMileage(car) },
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFFF1F5F9),
                                    modifier = Modifier.weight(1f).defaultMinSize(minWidth = 1.dp)
                                ) {
                                    Text(
                                        "⏱ Пробег",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF475569),
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 2.dp, vertical = 5.dp)
                                    )
                                }

                                Surface(
                                    onClick = { onAddReminder(car) },
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFFDCFCE7),
                                    modifier = Modifier.weight(1f).defaultMinSize(minWidth = 1.dp)
                                ) {
                                    Text(
                                        "🔔 Напомнить",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF15803D),
                                        textAlign = TextAlign.Center,
                                        maxLines = 1,
                                        softWrap = false,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(horizontal = 2.dp, vertical = 5.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// -------------------------------------------------------------
// ДЕТАЛЬНОЕ МЕНЮ АВТОМОБИЛЯ (КАК НА ФОТО 3, 4, 5)
// -------------------------------------------------------------
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CarDetailDialog(
    car: CarItem,
    events: List<CarEventItem>,
    mileageLogs: List<CarMileageItem>,
    reminders: List<CarReminderItem>,
    isIncognito: Boolean,
    onDismiss: () -> Unit,
    onEditCar: (CarItem) -> Unit,
    onDeleteCar: (String) -> Unit,
    onAddEvent: (String) -> Unit,
    onEditEvent: (CarEventItem) -> Unit,
    onDeleteEvent: (String) -> Unit,
    onAddMileage: () -> Unit,
    onDeleteMileage: (String) -> Unit,
    onAddReminder: () -> Unit,
    onEditReminder: (CarReminderItem) -> Unit,
    onDeleteReminder: (String) -> Unit,
    onToggleReminderDone: (CarReminderItem) -> Unit
) {
    var selectedTab by remember { mutableStateOf(0) } // 0: События (фото 4), 1: Напоминания (фото 5), 2: История пробега
    val carEvents = remember(car.id, events) {
        events.filter { it.carId == car.id }.sortedByDescending { it.date }
    }
    val carReminders = remember(car.id, reminders) {
        reminders.filter { it.carId == car.id }
    }
    val carMileage = remember(car.id, mileageLogs) {
        mileageLogs.filter { it.carId == car.id }.sortedByDescending { it.date }
    }
    val (fuelConsumption, totalSpent) = remember(car.id, events) {
        calculateCarFuelStats(car.id, events)
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 24.dp),
            shape = RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(Modifier.fillMaxSize()) {
                // Top app bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Назад")
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "${car.brand} ${car.model}",
                            fontWeight = FontWeight.Normal,
                            fontSize = 16.sp
                        )
                        Text(
                            listOfNotNull(car.carType, car.year?.let { "$it г." }, car.plateNumber).joinToString(" • "),
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }

                    Row {
                        IconButton(onClick = { onEditCar(car) }) {
                            Icon(Icons.Default.Edit, contentDescription = "Редактировать", modifier = Modifier.size(20.dp))
                        }
                        IconButton(onClick = { onDeleteCar(car.id) }) {
                            Icon(Icons.Default.Delete, contentDescription = "Удалить", tint = Color.Red, modifier = Modifier.size(20.dp))
                        }
                    }
                }

                // Scrollable content
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(horizontal = 16.dp, vertical = 4.dp)
                ) {
                    // Фото 3: Большие карточки пробега, расхода и трат
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text("ПРОБЕГ", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1E40AF))
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    String.format(Locale.US, "%,d", car.currentOdometer).replace(',', ' '),
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    color = Color(0xFF1E3A8A)
                                )
                                Text("километров", fontSize = 9.sp, color = Color.Gray)
                            }
                        }

                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text("РАСХОД", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF166534))
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    if (fuelConsumption != null) String.format(Locale.US, "%.1f", fuelConsumption) else "—",
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    color = Color(0xFF14532D)
                                )
                                Text("л / 100 км", fontSize = 9.sp, color = Color.Gray)
                            }
                        }

                        Card(
                            modifier = Modifier.weight(1f),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F2)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Text("ТРАТЫ", fontSize = 9.sp, fontWeight = FontWeight.Bold, color = Color(0xFF9F1239))
                                Spacer(Modifier.height(2.dp))
                                Text(
                                    if (isIncognito) "••••" else String.format(Locale.US, "%,.0f", totalSpent).replace(',', ' '),
                                    fontWeight = FontWeight.Normal,
                                    fontSize = 15.sp,
                                    color = Color(0xFF881337)
                                )
                                Text("рублей", fontSize = 9.sp, color = Color.Gray)
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // Action buttons bar (все 4 квадратика строго одинакового размера)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = { onAddEvent("FUEL") },
                            modifier = Modifier.weight(1f).defaultMinSize(minWidth = 1.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 8.dp)
                        ) {
                            Text(
                                "⛽ Заправка",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }

                        Button(
                            onClick = { onAddEvent("SERVICE") },
                            modifier = Modifier.weight(1f).defaultMinSize(minWidth = 1.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD97706)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 8.dp)
                        ) {
                            Text(
                                "🔧 Событие",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }

                        Button(
                            onClick = onAddMileage,
                            modifier = Modifier.weight(1f).defaultMinSize(minWidth = 1.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF475569)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 8.dp)
                        ) {
                            Text(
                                "⏱ Пробег",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }

                        Button(
                            onClick = onAddReminder,
                            modifier = Modifier.weight(1f).defaultMinSize(minWidth = 1.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 2.dp, vertical = 8.dp)
                        ) {
                            Text(
                                "🔔 Напомнить",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                softWrap = false,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(Modifier.height(14.dp))

                    // Tab selector
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFFF1F5F9))
                            .padding(3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "События (${carEvents.size})",
                            "Напоминания (${carReminders.count { !it.isCompleted }})",
                            "Пробег (${carMileage.size})"
                        ).forEachIndexed { idx, label ->
                            val isSel = selectedTab == idx
                            Surface(
                                onClick = { selectedTab = idx },
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSel) Color.White else Color.Transparent,
                                shadowElevation = if (isSel) 2.dp else 0.dp,
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSel) MaterialTheme.colorScheme.primary else Color.Gray,
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // TAB 0: СОБЫТИЯ И РАСХОДЫ (КАК НА ФОТО 4)
                    if (selectedTab == 0) {
                        if (carEvents.isEmpty()) {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC))
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("⛽", fontSize = 28.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Text("Нет добавленных событий", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text("Добавляйте заправки, ремонты, ТО и мойки для учета затрат на автомобиль.", fontSize = 11.sp, color = Color.Gray, textAlign = TextAlign.Center)
                                    Button(onClick = { onAddEvent("FUEL") }, modifier = Modifier.padding(top = 8.dp)) {
                                        Text("Добавить первую запись")
                                    }
                                }
                            }
                        } else {
                            carEvents.forEach { ev ->
                                val df = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(ev.date))
                                val (icon, badgeColor, typeLabel) = when (ev.type) {
                                    "FUEL" -> Triple("⛽", Color(0xFF0284C7), "Заправка")
                                    "SERVICE" -> Triple("🔧", Color(0xFFD97706), "ТО / Сервис")
                                    "REPAIR" -> Triple("🛠", Color(0xFFDC2626), "Ремонт")
                                    "WASH" -> Triple("🚿", Color(0xFF0D9488), "Мойка")
                                    else -> Triple("📝", Color(0xFF64748B), "Прочее")
                                }

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.4f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Column(Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(icon, fontSize = 14.sp)
                                                Spacer(Modifier.width(6.dp))
                                                Surface(
                                                    shape = RoundedCornerShape(4.dp),
                                                    color = badgeColor.copy(alpha = 0.12f)
                                                ) {
                                                    Text(
                                                        typeLabel,
                                                        fontSize = 10.sp,
                                                        fontWeight = FontWeight.Bold,
                                                        color = badgeColor,
                                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                                    )
                                                }
                                                Spacer(Modifier.width(6.dp))
                                                Text(df, fontSize = 11.sp, color = Color.Gray)
                                            }

                                            Text(
                                                "${if (ev.isIncome) "+" else "-"}${String.format(Locale.US, "%,.0f", ev.amount).replace(',', ' ')} ₽",
                                                fontWeight = FontWeight.Normal,
                                                fontSize = 13.sp,
                                                color = if (ev.isIncome) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                                            )
                                        }

                                        Spacer(Modifier.height(4.dp))
                                        Text(ev.title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)

                                        // Fuel details if available
                                        if (ev.type == "FUEL") {
                                            val details = mutableListOf<String>()
                                            ev.liters?.let { details.add("${String.format(Locale.US, "%.1f", it)} л") }
                                            ev.pricePerLiter?.let { details.add("${String.format(Locale.US, "%.2f", it)} ₽/л") }
                                            ev.gasStation?.takeIf { it.isNotBlank() }?.let { details.add(it) }
                                            if (details.isNotEmpty()) {
                                                Text(
                                                    details.joinToString(" • "),
                                                    fontSize = 11.sp,
                                                    color = Color(0xFF0369A1),
                                                    fontWeight = FontWeight.Medium,
                                                    modifier = Modifier.padding(top = 2.dp)
                                                )
                                            }
                                        }

                                        if (ev.odometer != null) {
                                            Text(
                                                "Пробег: ${String.format(Locale.US, "%,d", ev.odometer).replace(',', ' ')} км",
                                                fontSize = 10.sp,
                                                color = Color.Gray,
                                                modifier = Modifier.padding(top = 2.dp)
                                            )
                                        }

                                        if (ev.note.isNotBlank()) {
                                            Text(
                                                ev.note,
                                                fontSize = 11.sp,
                                                color = Color.DarkGray,
                                                modifier = Modifier.padding(top = 2.dp)
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp),
                                            horizontalArrangement = Arrangement.End
                                        ) {
                                            TextButton(
                                                onClick = { onEditEvent(ev) },
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text("Изменить", fontSize = 11.sp)
                                            }
                                            TextButton(
                                                onClick = { onDeleteEvent(ev.id) },
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Text("Удалить", fontSize = 11.sp, color = Color.Red)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // TAB 1: НАПОМИНАНИЯ (КАК НА ФОТО 5)
                    if (selectedTab == 1) {
                        var reminderFilter by remember { mutableStateOf(0) } // 0: Активные, 1: Выполненные
                        val filteredReminders = remember(carReminders, reminderFilter) {
                            if (reminderFilter == 0) carReminders.filter { !it.isCompleted }
                            else carReminders.filter { it.isCompleted }
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Surface(
                                    onClick = { reminderFilter = 0 },
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (reminderFilter == 0) Color(0xFF1E293B) else Color(0xFFE2E8F0)
                                ) {
                                    Text(
                                        "Активные (${carReminders.count { !it.isCompleted }})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (reminderFilter == 0) Color.White else Color(0xFF475569),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }

                                Surface(
                                    onClick = { reminderFilter = 1 },
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (reminderFilter == 1) Color(0xFF1E293B) else Color(0xFFE2E8F0)
                                ) {
                                    Text(
                                        "Выполненные (${carReminders.count { it.isCompleted }})",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (reminderFilter == 1) Color.White else Color(0xFF475569),
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                    )
                                }
                            }

                            Button(
                                onClick = onAddReminder,
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text("+ Создать", fontSize = 11.sp)
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        if (filteredReminders.isEmpty()) {
                            Card(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp),
                                colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC))
                            ) {
                                Column(
                                    modifier = Modifier.padding(20.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("🔔", fontSize = 28.sp)
                                    Spacer(Modifier.height(4.dp))
                                    Text(
                                        if (reminderFilter == 0) "Нет активных напоминаний" else "Нет выполненных напоминаний",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        "Создайте напоминание о замене масла, фильтров, колодок или полисе ОСАГО (по пробегу или дате).",
                                        fontSize = 11.sp,
                                        color = Color.Gray,
                                        textAlign = TextAlign.Center
                                    )
                                    if (reminderFilter == 0) {
                                        Button(onClick = onAddReminder, modifier = Modifier.padding(top = 8.dp)) {
                                            Text("Создать напоминание")
                                        }
                                    }
                                }
                            }
                        } else {
                            filteredReminders.forEach { rem ->
                                val (statusText, fraction, statusColor) = getReminderProgress(rem, car)

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = Color.White,
                                    border = BorderStroke(1.dp, if (rem.isCompleted) Color(0xFF4CAF50).copy(alpha = 0.5f) else Color.LightGray.copy(alpha = 0.4f)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp)
                                ) {
                                    Column(Modifier.padding(12.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column(Modifier.weight(1f)) {
                                                Text(rem.title, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                                val triggerStr = when (rem.type) {
                                                    "BY_DATE" -> "По дате: ${rem.targetDate?.let { SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(it)) } ?: "—"}"
                                                    "BY_MILEAGE" -> "По пробегу: ${rem.targetOdometer?.let { String.format(Locale.US, "%,d", it).replace(',', ' ') + " км" } ?: "—"}"
                                                    else -> "Дата или пробег"
                                                }
                                                Text(triggerStr, fontSize = 11.sp, color = Color.Gray)
                                            }

                                            Surface(
                                                shape = RoundedCornerShape(6.dp),
                                                color = statusColor.copy(alpha = 0.12f)
                                            ) {
                                                Text(
                                                    statusText,
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = statusColor,
                                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                                )
                                            }
                                        }

                                        Spacer(Modifier.height(8.dp))

                                        LinearProgressIndicator(
                                            progress = { fraction },
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(6.dp)
                                                .clip(RoundedCornerShape(3.dp)),
                                            color = statusColor,
                                            trackColor = Color.LightGray.copy(alpha = 0.3f)
                                        )

                                        if (rem.repeatIntervalKm != null && rem.repeatIntervalKm > 0) {
                                            Text(
                                                "Повторять каждые ${String.format(Locale.US, "%,d", rem.repeatIntervalKm).replace(',', ' ')} км",
                                                fontSize = 10.sp,
                                                color = Color(0xFF1565C0),
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier.padding(top = 4.dp)
                                            )
                                        }

                                        if (rem.note.isNotBlank()) {
                                            Text(
                                                rem.note,
                                                fontSize = 11.sp,
                                                color = Color.DarkGray,
                                                modifier = Modifier.padding(top = 2.dp)
                                            )
                                        }

                                        Row(
                                            modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            TextButton(
                                                onClick = { onToggleReminderDone(rem) },
                                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                            ) {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Icon(
                                                        if (rem.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                                                        null,
                                                        tint = if (rem.isCompleted) Color(0xFF2E7D32) else Color.Gray,
                                                        modifier = Modifier.size(16.dp)
                                                    )
                                                    Spacer(Modifier.width(4.dp))
                                                    Text(
                                                        if (rem.isCompleted) "Выполнено" else "Отметить выполненным",
                                                        fontSize = 11.sp,
                                                        color = if (rem.isCompleted) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                                                    )
                                                }
                                            }

                                            Row {
                                                TextButton(
                                                    onClick = { onEditReminder(rem) },
                                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text("Изменить", fontSize = 11.sp)
                                                }
                                                TextButton(
                                                    onClick = { onDeleteReminder(rem.id) },
                                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                                                ) {
                                                    Text("Удалить", fontSize = 11.sp, color = Color.Red)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // TAB 2: ИСТОРИЯ ПРОБЕГА
                    if (selectedTab == 2) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Зафиксированные показания", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            Button(onClick = onAddMileage, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)) {
                                Text("+ Новый замер", fontSize = 11.sp)
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        if (carMileage.isEmpty()) {
                            Text("История пробега пуста. Вносите замеры одометра для построения точного графика динамики.", fontSize = 11.sp, color = Color.Gray, modifier = Modifier.padding(vertical = 12.dp))
                        } else {
                            carMileage.forEachIndexed { idx, log ->
                                val prev = carMileage.getOrNull(idx + 1)
                                val diff = if (prev != null) log.odometer - prev.odometer else 0
                                val df = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(log.date))

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = Color.White,
                                    border = BorderStroke(0.5.dp, Color.LightGray.copy(alpha = 0.5f)),
                                    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(df, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                                if (log.title.isNotBlank()) {
                                                    Text(" • ${log.title}", fontSize = 11.sp, color = Color.Gray)
                                                }
                                            }
                                            if (diff > 0) {
                                                Text("+${String.format(Locale.US, "%,d", diff).replace(',', ' ')} км с прошлого замера", fontSize = 10.sp, color = Color(0xFF16A34A), fontWeight = FontWeight.SemiBold)
                                            }
                                        }

                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                "${String.format(Locale.US, "%,d", log.odometer).replace(',', ' ')} км",
                                                fontWeight = FontWeight.Normal,
                                                fontSize = 13.sp,
                                                color = Color(0xFF0F172A)
                                            )
                                            IconButton(
                                                onClick = { onDeleteMileage(log.id) },
                                                modifier = Modifier.size(24.dp).padding(start = 4.dp)
                                            ) {
                                                Icon(Icons.Default.Delete, null, tint = Color.LightGray, modifier = Modifier.size(16.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(20.dp))
                }
            }
        }
    }
}

// -------------------------------------------------------------
// ДИАЛОГИ ДОБАВЛЕНИЯ / РЕДАКТИРОВАНИЯ
// -------------------------------------------------------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditCarDialog(
    car: CarItem?,
    onDismiss: () -> Unit,
    onSave: (CarItem) -> Unit
) {
    var brand by remember(car) { mutableStateOf(car?.brand ?: "") }
    var model by remember(car) { mutableStateOf(car?.model ?: "") }
    var carType by remember(car) { mutableStateOf(car?.carType ?: "Седан") }
    var yearStr by remember(car) { mutableStateOf(car?.year?.toString() ?: "") }
    var plate by remember(car) { mutableStateOf(car?.plateNumber ?: "") }
    var odoStr by remember(car) { mutableStateOf(car?.currentOdometer?.toString() ?: "") }
    var fuelType by remember(car) { mutableStateOf(car?.fuelType ?: "АИ-95") }
    var notes by remember(car) { mutableStateOf(car?.notes ?: "") }
    var color by remember(car) { mutableStateOf(car?.color ?: "#2563EB") }

    val bodyTypes = listOf("Седан", "Кроссовер", "Внедорожник", "Хэтчбек", "Универсал", "Купе", "Минивэн", "Пикап")
    val fuels = listOf("АИ-92", "АИ-95", "АИ-98", "АИ-100", "Дизель", "Газ", "Электро", "Гибрид")
    val colors = listOf("#2563EB", "#DC2626", "#16A34A", "#D97706", "#9333EA", "#0D9488", "#1E293B", "#64748B")

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (car == null) "Новый автомобиль" else "Редактирование автомобиля", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                OutlinedTextField(
                    value = brand,
                    onValueChange = { brand = it },
                    label = { Text("Марка (напр. Toyota)*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                )

                OutlinedTextField(
                    value = model,
                    onValueChange = { model = it },
                    label = { Text("Модель (напр. Camry)*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )

                Text("Тип кузова:", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    bodyTypes.forEach { t ->
                        val isSel = carType == t
                        Surface(
                            onClick = { carType = t },
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSel) Color(0xFF1E3A8A) else Color(0xFFF1F5F9)
                        ) {
                            Text(
                                t,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) Color.White else Color.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = yearStr,
                        onValueChange = { yearStr = it.filter { c -> c.isDigit() } },
                        label = { Text("Год выпуска") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = plate,
                        onValueChange = { plate = it.uppercase() },
                        label = { Text("Госномер") },
                        placeholder = { Text("А777АА 77") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                OutlinedTextField(
                    value = odoStr,
                    onValueChange = { odoStr = it.filter { c -> c.isDigit() } },
                    label = { Text("Текущий пробег (км)*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )

                Text("Топливо:", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    fuels.forEach { f ->
                        val isSel = fuelType == f
                        Surface(
                            onClick = { fuelType = f },
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSel) Color(0xFF0284C7) else Color(0xFFF1F5F9)
                        ) {
                            Text(
                                f,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) Color.White else Color.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                Text("Цветовой акцент:", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    colors.forEach { c ->
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(CircleShape)
                                .background(parseHexColor(c))
                                .clickable { color = c }
                                .border(if (color == c) 2.dp else 0.dp, Color.Black, CircleShape)
                        )
                    }
                }

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Заметка (необязательно)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val odo = odoStr.toIntOrNull() ?: 0
                    val yr = yearStr.toIntOrNull()
                    onSave(
                        CarItem(
                            id = car?.id ?: UUID.randomUUID().toString(),
                            brand = brand.trim(),
                            model = model.trim(),
                            carType = carType,
                            year = yr,
                            plateNumber = plate.trim().ifBlank { null },
                            color = color,
                            currentOdometer = odo,
                            fuelType = fuelType,
                            notes = notes.trim()
                        )
                    )
                },
                enabled = brand.isNotBlank() && model.isNotBlank()
            ) {
                Text(if (car == null) "Добавить" else "Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

// ДИАЛОГ ДОБАВЛЕНИЯ / РЕДАКТИРОВАНИЯ СОБЫТИЯ (ФОТО 4)
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditCarEventDialog(
    car: CarItem,
    event: CarEventItem?,
    defaultType: String,
    onDismiss: () -> Unit,
    onSave: (CarEventItem, Boolean) -> Unit
) {
    val context = LocalContext.current
    var eventType by remember(event, defaultType) { mutableStateOf(event?.type ?: defaultType) }
    var title by remember(event, defaultType) {
        mutableStateOf(
            event?.title ?: when (defaultType) {
                "FUEL" -> "Заправка ${car.fuelType}"
                "SERVICE" -> "ТО / Обслуживание"
                "REPAIR" -> "Ремонт"
                "WASH" -> "Комплексная мойка"
                else -> "Расход на авто"
            }
        )
    }
    var amountStr by remember(event) { mutableStateOf(if (event != null && event.amount > 0) String.format(Locale.US, "%.0f", event.amount) else "") }
    var dateMillis by remember(event) { mutableStateOf(event?.date ?: System.currentTimeMillis()) }
    var odoStr by remember(event) { mutableStateOf(event?.odometer?.toString() ?: car.currentOdometer.toString()) }
    var litersStr by remember(event) { mutableStateOf(event?.liters?.let { String.format(Locale.US, "%.1f", it) } ?: "") }
    var pricePerLiterStr by remember(event) { mutableStateOf(event?.pricePerLiter?.let { String.format(Locale.US, "%.2f", it) } ?: "") }
    var station by remember(event) { mutableStateOf(event?.gasStation ?: "") }
    var isFullTank by remember(event) { mutableStateOf(event?.isFullTank ?: true) }
    var note by remember(event) { mutableStateOf(event?.note ?: "") }
    var syncToMonthlyFinance by remember { mutableStateOf(true) }

    val types = listOf(
        "FUEL" to "⛽ Заправка",
        "SERVICE" to "🔧 ТО",
        "REPAIR" to "🛠 Ремонт",
        "WASH" to "🚿 Мойка",
        "OTHER" to "📝 Прочее"
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (event == null) "Новое событие" else "Редактирование события", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Type selector
                FlowRow(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    types.forEach { (t, label) ->
                        val isSel = eventType == t
                        Surface(
                            onClick = {
                                eventType = t
                                if (event == null) {
                                    title = when (t) {
                                        "FUEL" -> "Заправка ${car.fuelType}"
                                        "SERVICE" -> "ТО / Обслуживание"
                                        "REPAIR" -> "Ремонт"
                                        "WASH" -> "Комплексная мойка"
                                        else -> "Расход на авто"
                                    }
                                }
                            },
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSel) Color(0xFF1E3A8A) else Color(0xFFF1F5F9)
                        ) {
                            Text(
                                label,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) Color.White else Color.Black,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название события*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                )

                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    OutlinedTextField(
                        value = amountStr,
                        onValueChange = { amountStr = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.replace(',', '.') },
                        label = { Text("Сумма (₽)*") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )

                    OutlinedTextField(
                        value = odoStr,
                        onValueChange = { odoStr = it.filter { c -> c.isDigit() } },
                        label = { Text("Пробег (км)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // Date Picker Button
                Surface(
                    onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = dateMillis }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val newCal = Calendar.getInstance().apply { set(y, m, d) }
                                dateMillis = newCal.timeInMillis
                            },
                            c.get(Calendar.YEAR),
                            c.get(Calendar.MONTH),
                            c.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Дата события:", fontSize = 12.sp, color = Color.Gray)
                        Text(
                            SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(dateMillis)),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Fuel specific fields (Фото 4)
                if (eventType == "FUEL") {
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedTextField(
                            value = litersStr,
                            onValueChange = {
                                litersStr = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.replace(',', '.')
                                val l = litersStr.toDoubleOrNull() ?: 0.0
                                val amt = amountStr.toDoubleOrNull() ?: 0.0
                                if (l > 0 && amt > 0) {
                                    pricePerLiterStr = String.format(Locale.US, "%.2f", amt / l)
                                }
                            },
                            label = { Text("Литры") },
                            placeholder = { Text("50") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        OutlinedTextField(
                            value = pricePerLiterStr,
                            onValueChange = { pricePerLiterStr = it.filter { c -> c.isDigit() || c == '.' || c == ',' }.replace(',', '.') },
                            label = { Text("Цена за 1 л (₽)") },
                            placeholder = { Text("58.50") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )
                    }

                    OutlinedTextField(
                        value = station,
                        onValueChange = { station = it },
                        label = { Text("АЗС (Лукойл, Газпромнефть и т.д.)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(checked = isFullTank, onCheckedChange = { isFullTank = it })
                        Spacer(Modifier.width(4.dp))
                        Text("Полный бак (для расчета среднего расхода)", fontSize = 11.sp)
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Заметка") },
                    modifier = Modifier.fillMaxWidth()
                )

                // ПРЕДЛОЖЕНИЕ СОЗДАТЬ РАЗДЕЛ В ИТОГАХ МЕСЯЦА ДЛЯ УЧЕТА АВТО
                val cal = Calendar.getInstance().apply { timeInMillis = dateMillis }
                val monthTitle = SimpleDateFormat("MMMM", Locale("ru")).format(cal.time)
                val finPrefs = context.getSharedPreferences("fin_cats", 0)
                val isCatAlreadyCreated = remember(car.id) {
                    try {
                        val existingCatsJson = finPrefs.getString("list", "[]") ?: "[]"
                        val cats: List<CategoryConfig> = Gson().fromJson<List<CategoryConfig>>(existingCatsJson, object : TypeToken<List<CategoryConfig>>() {}.type) ?: emptyList()
                        val carCatName = "${car.brand} ${car.model}".trim()
                        cats.any { it.name.equals(carCatName, ignoreCase = true) || it.id == "cat_car_${car.id}" }
                    } catch (_: Exception) { false }
                }
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFE3F2FD),
                    border = BorderStroke(1.dp, Color(0xFF90CAF9)),
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = syncToMonthlyFinance,
                            onCheckedChange = { syncToMonthlyFinance = it }
                        )
                        Spacer(Modifier.width(6.dp))
                        Column(Modifier.weight(1f)) {
                            Text(
                                if (isCatAlreadyCreated) "Внести в раздел «${car.brand} ${car.model}» (Итоги за $monthTitle)"
                                else "Создать раздел «${car.brand} ${car.model}» в «Итоги за $monthTitle»",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0D47A1)
                            )
                            Text(
                                if (isCatAlreadyCreated) "Расход запишется в существующий раздел авто в итогах за $monthTitle"
                                else "Вести весь учет расходов на авто в итогах за $monthTitle",
                                fontSize = 10.sp,
                                color = Color(0xFF1565C0)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val amt = amountStr.toDoubleOrNull() ?: 0.0
                    val odo = odoStr.toIntOrNull()
                    val liters = litersStr.toDoubleOrNull()
                    val pricePerLiter = pricePerLiterStr.toDoubleOrNull()
                    onSave(
                        CarEventItem(
                            id = event?.id ?: UUID.randomUUID().toString(),
                            carId = car.id,
                            date = dateMillis,
                            type = eventType,
                            title = title.trim(),
                            amount = amt,
                            odometer = odo,
                            liters = liters,
                            pricePerLiter = pricePerLiter,
                            isFullTank = isFullTank,
                            gasStation = station.trim().ifBlank { null },
                            note = note.trim()
                        ),
                        syncToMonthlyFinance
                    )
                },
                enabled = title.isNotBlank() && (amountStr.toDoubleOrNull() ?: 0.0) >= 0.0
            ) {
                Text(if (event == null) "Добавить" else "Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

// ДИАЛОГ ЗАМЕРА ПРОБЕГА
@Composable
fun AddCarMileageLogDialog(
    car: CarItem,
    onDismiss: () -> Unit,
    onSave: (CarMileageItem) -> Unit
) {
    val context = LocalContext.current
    var odoStr by remember { mutableStateOf(car.currentOdometer.toString()) }
    var title by remember { mutableStateOf("Замер пробега") }
    var dateMillis by remember { mutableStateOf(System.currentTimeMillis()) }
    var note by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Замер пробега", fontWeight = FontWeight.Bold, fontSize = 16.sp) },
        text = {
            Column(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = odoStr,
                    onValueChange = { odoStr = it.filter { c -> c.isDigit() } },
                    label = { Text("Показания одометра (км)*") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                )

                Surface(
                    onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = dateMillis }
                        DatePickerDialog(
                            context,
                            { _, y, m, d ->
                                val newCal = Calendar.getInstance().apply { set(y, m, d) }
                                dateMillis = newCal.timeInMillis
                            },
                            c.get(Calendar.YEAR),
                            c.get(Calendar.MONTH),
                            c.get(Calendar.DAY_OF_MONTH)
                        ).show()
                    },
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Дата замера:", fontSize = 12.sp, color = Color.Gray)
                        Text(
                            SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(dateMillis)),
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название (напр. Перед поездкой)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                )

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Заметка (необязательно)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val odo = odoStr.toIntOrNull() ?: 0
                    if (odo > 0) {
                        onSave(
                            CarMileageItem(
                                carId = car.id,
                                date = dateMillis,
                                odometer = odo,
                                title = title.trim(),
                                note = note.trim()
                            )
                        )
                    }
                },
                enabled = (odoStr.toIntOrNull() ?: 0) > 0
            ) {
                Text("Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

// ДИАЛОГ НАПОМИНАНИЯ (ФОТО 5)
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AddEditCarReminderDialog(
    car: CarItem,
    reminder: CarReminderItem?,
    onDismiss: () -> Unit,
    onSave: (CarReminderItem) -> Unit
) {
    val context = LocalContext.current
    var title by remember(reminder) { mutableStateOf(reminder?.title ?: "") }
    var remType by remember(reminder) { mutableStateOf(reminder?.type ?: "BY_MILEAGE") }
    var targetOdoStr by remember(reminder) {
        mutableStateOf(reminder?.targetOdometer?.toString() ?: (car.currentOdometer + 10000).toString())
    }
    var repeatKmStr by remember(reminder) {
        mutableStateOf(reminder?.repeatIntervalKm?.toString() ?: "10000")
    }
    var targetDateMillis by remember(reminder) {
        mutableStateOf(reminder?.targetDate ?: (System.currentTimeMillis() + 365L * 86400000L))
    }
    var note by remember(reminder) { mutableStateOf(reminder?.note ?: "") }

    val presets = listOf(
        "Замена масла (10 000 км / 1 год)" to ("BOTH" to 10000),
        "Замена масла (10 000 км)" to ("BY_MILEAGE" to 10000),
        "Замена воздушного фильтра" to ("BY_MILEAGE" to 15000),
        "Тормозные колодки" to ("BY_MILEAGE" to 30000),
        "Свечи зажигания" to ("BY_MILEAGE" to 40000),
        "Продление ОСАГО" to ("BY_DATE" to 0),
        "Техосмотр" to ("BY_DATE" to 0)
    )

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(if (reminder == null) "Новое напоминание" else "Редактирование напоминания", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                Text("Быстрые шаблоны:", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
                FlowRow(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    presets.forEach { (presetTitle, config) ->
                        Surface(
                            onClick = {
                                title = presetTitle
                                remType = config.first
                                if (config.first == "BY_MILEAGE" || config.first == "BOTH") {
                                    repeatKmStr = config.second.toString()
                                    targetOdoStr = (car.currentOdometer + config.second).toString()
                                }
                            },
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFF1F5F9),
                            border = BorderStroke(0.5.dp, Color.LightGray.copy(alpha = 0.5f))
                        ) {
                            Text(presetTitle, fontSize = 10.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp))
                        }
                    }
                }

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Название напоминания*") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                )

                Text("Как напоминать:", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    listOf(
                        "BY_MILEAGE" to "По пробегу",
                        "BY_DATE" to "По дате",
                        "BOTH" to "Что раньше"
                    ).forEach { (typeKey, typeLabel) ->
                        val isSel = remType == typeKey
                        Surface(
                            onClick = { remType = typeKey },
                            shape = RoundedCornerShape(6.dp),
                            color = if (isSel) Color(0xFF1E3A8A) else Color(0xFFF1F5F9),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text(
                                typeLabel,
                                fontSize = 10.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) Color.White else Color.Black,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(vertical = 6.dp)
                            )
                        }
                    }
                }

                if (remType == "BOTH") {
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFEFF6FF),
                        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
                    ) {
                        Text(
                            "⚡ Напоминание сработает по дате или по пробегу — в зависимости от того, что настанет первое!",
                            fontSize = 11.sp,
                            color = Color(0xFF1D4ED8),
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }

                if (remType == "BY_MILEAGE" || remType == "BOTH") {
                    OutlinedTextField(
                        value = targetOdoStr,
                        onValueChange = { targetOdoStr = it.filter { c -> c.isDigit() } },
                        label = { Text("Напомнить при пробеге (км)*") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    )

                    OutlinedTextField(
                        value = repeatKmStr,
                        onValueChange = { repeatKmStr = it.filter { c -> c.isDigit() } },
                        label = { Text("Повторять каждые N км (напр. 10000)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    )
                }

                if (remType == "BY_DATE" || remType == "BOTH") {
                    Text(
                        if (remType == "BOTH") "Или быстрый выбор даты:" else "Быстрый выбор срока:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        listOf(
                            "1 мес." to (1 to 0),
                            "3 мес." to (3 to 0),
                            "Полгода" to (6 to 0),
                            "1 год" to (0 to 1),
                            "5 лет" to (0 to 5)
                        ).forEach { (label, offset) ->
                            Surface(
                                onClick = {
                                    val cal = Calendar.getInstance()
                                    if (offset.first > 0) cal.add(Calendar.MONTH, offset.first)
                                    if (offset.second > 0) cal.add(Calendar.YEAR, offset.second)
                                    targetDateMillis = cal.timeInMillis
                                },
                                shape = RoundedCornerShape(6.dp),
                                color = Color(0xFFF3E8FF),
                                border = BorderStroke(0.5.dp, Color(0xFFD8B4FE)),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text(
                                    label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF6B21A8),
                                    textAlign = TextAlign.Center,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.padding(vertical = 6.dp, horizontal = 2.dp)
                                )
                            }
                        }
                    }

                    Surface(
                        onClick = {
                            val c = Calendar.getInstance().apply { timeInMillis = targetDateMillis }
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val newCal = Calendar.getInstance().apply { set(y, m, d) }
                                    targetDateMillis = newCal.timeInMillis
                                },
                                c.get(Calendar.YEAR),
                                c.get(Calendar.MONTH),
                                c.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth().padding(bottom = 6.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(if (remType == "BOTH") "Целевая дата (календарь):" else "Целевая дата (календарь):", fontSize = 11.sp, color = Color.Gray)
                            Text(
                                SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(targetDateMillis)),
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = note,
                    onValueChange = { note = it },
                    label = { Text("Заметка (марка масла, артикул и т.д.)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val odo = if (remType == "BY_MILEAGE" || remType == "BOTH") targetOdoStr.toIntOrNull() else null
                    val rep = repeatKmStr.toIntOrNull()
                    val dt = if (remType == "BY_DATE" || remType == "BOTH") targetDateMillis else null
                    onSave(
                        CarReminderItem(
                            id = reminder?.id ?: UUID.randomUUID().toString(),
                            carId = car.id,
                            title = title.trim(),
                            type = remType,
                            targetDate = dt,
                            targetOdometer = odo,
                            repeatIntervalKm = rep,
                            isCompleted = reminder?.isCompleted ?: false,
                            note = note.trim()
                        )
                    )
                },
                enabled = title.isNotBlank()
            ) {
                Text(if (reminder == null) "Создать" else "Сохранить")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Отмена") }
        }
    )
}

// -------------------------------------------------------------
// ГРАФИК ПРОБЕГА В АНАЛИТИКЕ (КАК НА РИСУНКЕ 2)
// -------------------------------------------------------------
@Composable
fun CarMileageChartCard(
    cars: List<CarItem>,
    logs: List<CarMileageItem>,
    selectedMonth: Calendar? = null
) {
    if (cars.isEmpty()) return

    var selectedCarId by remember(cars) { mutableStateOf(cars.first().id) }
    val car = cars.find { it.id == selectedCarId } ?: cars.first()

    // Режим периода: "MONTH" (по умолчанию), "YEAR", "ALL"
    var mileagePeriod by remember { mutableStateOf("MONTH") }

    val activeMonthCal = selectedMonth ?: Calendar.getInstance()
    val targetYear = activeMonthCal.get(Calendar.YEAR)
    val targetMonth = activeMonthCal.get(Calendar.MONTH)

    val allCarLogs = remember(car.id, logs) {
        val list = logs.filter { it.carId == car.id }.toMutableList()
        if (list.none { it.odometer == car.currentOdometer }) {
            list.add(CarMileageItem(carId = car.id, date = System.currentTimeMillis(), odometer = car.currentOdometer, title = "Текущий"))
        }
        list.sortedBy { it.date }
    }

    val carLogs = remember(allCarLogs, mileagePeriod, targetYear, targetMonth) {
        when (mileagePeriod) {
            "MONTH" -> {
                val cal = Calendar.getInstance()
                val monthLogs = allCarLogs.filter { log ->
                    cal.timeInMillis = log.date
                    cal.get(Calendar.YEAR) == targetYear && cal.get(Calendar.MONTH) == targetMonth
                }.toMutableList()

                val priorLog = allCarLogs.filter { log ->
                    cal.timeInMillis = log.date
                    val y = cal.get(Calendar.YEAR)
                    val m = cal.get(Calendar.MONTH)
                    y < targetYear || (y == targetYear && m < targetMonth)
                }.maxByOrNull { it.date }

                if (priorLog != null && monthLogs.none { it.id == priorLog.id }) {
                    monthLogs.add(0, priorLog)
                }
                if (monthLogs.size < 2 && allCarLogs.size >= 2) {
                    monthLogs.clear()
                    monthLogs.addAll(allCarLogs)
                }
                monthLogs.sortedBy { it.date }
            }
            "YEAR" -> {
                val cal = Calendar.getInstance()
                val yearLogs = allCarLogs.filter { log ->
                    cal.timeInMillis = log.date
                    cal.get(Calendar.YEAR) == targetYear
                }.toMutableList()
                val priorLog = allCarLogs.filter { log ->
                    cal.timeInMillis = log.date
                    cal.get(Calendar.YEAR) < targetYear
                }.maxByOrNull { it.date }
                if (priorLog != null && yearLogs.none { it.id == priorLog.id }) {
                    yearLogs.add(0, priorLog)
                }
                if (yearLogs.size < 2 && allCarLogs.size >= 2) {
                    yearLogs.clear()
                    yearLogs.addAll(allCarLogs)
                }
                yearLogs.sortedBy { it.date }
            }
            else -> allCarLogs
        }
    }

    val periodDeltaKm = remember(carLogs) {
        if (carLogs.size >= 2) {
            (carLogs.last().odometer - carLogs.first().odometer).coerceAtLeast(0)
        } else 0
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        "ДИНАМИКА ПРОБЕГА",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        "${car.brand} ${car.model} • ${String.format(Locale.US, "%,d", car.currentOdometer).replace(',', ' ')} км" +
                        (if (periodDeltaKm > 0) " (+${String.format(Locale.US, "%,d", periodDeltaKm).replace(',', ' ')} км)" else ""),
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }

                if (cars.size > 1) {
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        Surface(
                            onClick = { expanded = true },
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surface,
                            border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(car.model, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                Icon(Icons.Default.ArrowDropDown, null, modifier = Modifier.size(16.dp))
                            }
                        }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            cars.forEach { c ->
                                DropdownMenuItem(
                                    text = { Text("${c.brand} ${c.model}", fontSize = 12.sp) },
                                    onClick = {
                                        selectedCarId = c.id
                                        expanded = false
                                    }
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Переключатель периода пробега (Месяц / 1 год / Весь период)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf(
                    "MONTH" to "Месяц",
                    "YEAR" to "1 год",
                    "ALL" to "Весь период"
                ).forEach { (mode, label) ->
                    val isSel = mileagePeriod == mode
                    Surface(
                        onClick = { mileagePeriod = mode },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSel) MaterialTheme.colorScheme.primary else Color.White,
                        border = BorderStroke(0.8.dp, if (isSel) MaterialTheme.colorScheme.primary else Color.LightGray.copy(alpha = 0.6f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text(
                            text = label,
                            fontSize = 11.sp,
                            fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSel) Color.White else MaterialTheme.colorScheme.onSurface,
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(vertical = 5.dp)
                        )
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            // Canvas Line Chart (Рисунок 2)
            if (carLogs.size >= 2) {
                val minOdo = carLogs.minOf { it.odometer }
                val maxOdo = carLogs.maxOf { it.odometer }
                val odoRange = (maxOdo - minOdo).coerceAtLeast(100)

                var selectedLogIndex by remember(carLogs) { mutableStateOf<Int?>(carLogs.lastIndex) }

                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color.White)
                        .pointerInput(carLogs) {
                            detectTapGestures { tapOffset ->
                                val n = carLogs.size
                                if (n >= 2 && size.width > 0) {
                                    val relX = (tapOffset.x / size.width).coerceIn(0f, 1f)
                                    val nearestIdx = (relX * (n - 1)).toInt().coerceIn(0, n - 1)
                                    selectedLogIndex = nearestIdx
                                }
                            }
                        }
                        .padding(horizontal = 12.dp, vertical = 12.dp)
                ) {
                    Canvas(modifier = Modifier.fillMaxSize()) {
                        val w = size.width
                        val h = size.height
                        val paddingBottom = 24.dp.toPx()
                        val paddingTop = 16.dp.toPx()
                        val chartHeight = h - paddingBottom - paddingTop

                        val points = carLogs.mapIndexed { idx, log ->
                            val x = if (carLogs.size == 1) w / 2f else (idx.toFloat() / (carLogs.size - 1)) * w
                            val y = paddingTop + chartHeight - ((log.odometer - minOdo).toFloat() / odoRange) * chartHeight
                            Offset(x, y)
                        }

                        // Grid lines
                        for (i in 0..3) {
                            val y = paddingTop + (chartHeight / 3f) * i
                            drawLine(
                                color = Color(0xFFE2E8F0),
                                start = Offset(0f, y),
                                end = Offset(w, y),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        // Gradient fill path
                        val fillPath = Path().apply {
                            moveTo(points.first().x, h - paddingBottom)
                            points.forEach { lineTo(it.x, it.y) }
                            lineTo(points.last().x, h - paddingBottom)
                            close()
                        }
                        drawPath(
                            path = fillPath,
                            brush = Brush.verticalGradient(
                                colors = listOf(Color(0xFF3B82F6).copy(alpha = 0.35f), Color(0xFF3B82F6).copy(alpha = 0.02f)),
                                startY = paddingTop,
                                endY = h - paddingBottom
                            )
                        )

                        // Line
                        val linePath = Path().apply {
                            moveTo(points.first().x, points.first().y)
                            for (i in 1 until points.size) {
                                lineTo(points[i].x, points[i].y)
                            }
                        }
                        drawPath(
                            path = linePath,
                            color = Color(0xFF2563EB),
                            style = Stroke(width = 2.5.dp.toPx())
                        )

                        // Draw selected vertical guide line
                        selectedLogIndex?.let { selIdx ->
                            if (selIdx in points.indices) {
                                val selPt = points[selIdx]
                                drawLine(
                                    color = Color(0xFF2563EB).copy(alpha = 0.4f),
                                    start = Offset(selPt.x, paddingTop),
                                    end = Offset(selPt.x, h - paddingBottom),
                                    strokeWidth = 1.5.dp.toPx()
                                )
                            }
                        }

                        // Points
                        points.forEachIndexed { idx, pt ->
                            val isSel = selectedLogIndex == idx
                            if (isSel) {
                                drawCircle(color = Color(0xFF3B82F6).copy(alpha = 0.25f), radius = 11.dp.toPx(), center = pt)
                                drawCircle(color = Color.White, radius = 7.dp.toPx(), center = pt)
                                drawCircle(color = Color(0xFF1D4ED8), radius = 4.5.dp.toPx(), center = pt)
                            } else {
                                drawCircle(color = Color.White, radius = 5.dp.toPx(), center = pt)
                                drawCircle(color = Color(0xFF2563EB), radius = 3.dp.toPx(), center = pt)
                            }
                        }
                    }
                }

                // Interactive info card when a point is selected
                if (selectedLogIndex != null && selectedLogIndex!! in carLogs.indices) {
                    val selLog = carLogs[selectedLogIndex!!]
                    val fullDateWordStr = SimpleDateFormat("d MMMM yyyy г.", Locale("ru")).format(Date(selLog.date))
                    val fullDateStr = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(selLog.date))
                    val odoFormatted = String.format(Locale.US, "%,d", selLog.odometer).replace(',', ' ') + " км"
                    val prevLog = if (selectedLogIndex!! > 0) carLogs[selectedLogIndex!! - 1] else null
                    val deltaKm = prevLog?.let { selLog.odometer - it.odometer }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color(0xFFEFF6FF),
                        border = BorderStroke(1.dp, Color(0xFFBFDBFE)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 8.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(7.dp)
                                            .clip(CircleShape)
                                            .background(Color(0xFF2563EB))
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        odoFormatted,
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 13.sp,
                                        color = Color(0xFF1D4ED8)
                                    )
                                    if (deltaKm != null && deltaKm > 0) {
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            "(+${String.format(Locale.US, "%,d", deltaKm).replace(',', ' ')} км)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp,
                                            color = Color(0xFF15803D)
                                        )
                                    }
                                }
                                Row(
                                    modifier = Modifier.padding(top = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        "$fullDateWordStr ($fullDateStr)",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = Color(0xFF1E3A8A)
                                    )
                                    if (selLog.title.isNotBlank()) {
                                        Text(
                                            " • ${selLog.title}",
                                            fontSize = 10.sp,
                                            color = Color.Gray
                                        )
                                    }
                                }
                            }
                            IconButton(
                                onClick = { selectedLogIndex = null },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, null, modifier = Modifier.size(14.dp), tint = Color.Gray)
                            }
                        }
                    }
                }

                // Dates with full YEARS below chart
                Row(
                    modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val firstDate = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(carLogs.first().date))
                    val lastDate = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(carLogs.last().date))
                    Text(
                        "$firstDate: ${String.format(Locale.US, "%,d", minOdo).replace(',', ' ')} км",
                        fontSize = 10.sp,
                        color = Color.Gray
                    )
                    Text(
                        "Нажмите на точку для деталей",
                        fontSize = 9.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        "$lastDate: ${String.format(Locale.US, "%,d", maxOdo).replace(',', ' ')} км",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF2563EB)
                    )
                }
            } else {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.White,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("📈", fontSize = 24.sp)
                        Text("Недостаточно данных для графика", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        Text("Добавьте хотя бы два замера пробега автомобиля, чтобы увидеть график роста одометра по времени.", fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center)
                    }
                }
            }
        }
    }
}
