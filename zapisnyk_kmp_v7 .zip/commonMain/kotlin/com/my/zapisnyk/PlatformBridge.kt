package com.my.zapisnyk

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlin.math.pow

// =========================================================================
// PlatformBridge: Полный кроссплатформенный мост (Android + iOS) для Zapisnyk
// Поддерживает нативный проводник Android (DocumentsUI), ZIP, SQLite и Prefs
// через PlatformNativeBridge (Platform.android.kt) + fallback для iOS
// =========================================================================

typealias Bitmap = ImageBitmap

val ImageBitmap.isRecycled: Boolean get() = false
fun ImageBitmap.asImageBitmap(): ImageBitmap = this

interface Cloneable

interface ZipInputStreamDelegate : Closeable {
    fun nextEntryName(): String?
    fun read(b: ByteArray, off: Int, len: Int): Int
    fun closeEntry()
}

interface ZipOutputStreamDelegate : Closeable {
    fun putNextEntry(name: String)
    fun write(b: ByteArray, off: Int, len: Int)
    fun closeEntry()
    fun finish()
    fun flush()
}

interface PlatformNativeBridge {
    fun currentTimeMillis(): Long
    fun getFilesDirPath(): String
    fun getSharedPreferences(name: String): SharedPreferences?
    fun getUriMimeType(uriString: String): String?
    fun openUriInputStream(uriString: String): InputStream?
    fun openUriOutputStream(uriString: String): OutputStream?
    fun fileExists(path: String): Boolean
    fun fileCanRead(path: String): Boolean
    fun fileIsFile(path: String): Boolean
    fun fileIsDirectory(path: String): Boolean
    fun fileMkdirs(path: String): Boolean
    fun fileDelete(path: String): Boolean
    fun fileLength(path: String): Long
    fun fileListFiles(path: String): Array<File>?
    fun openFileInputStream(path: String): InputStream?
    fun openFileOutputStream(path: String): OutputStream?
    fun createZipInputStream(inner: InputStream): ZipInputStreamDelegate?
    fun createZipOutputStream(inner: OutputStream): ZipOutputStreamDelegate?
    fun decodeBitmapStream(stream: InputStream): ImageBitmap?
    fun decodeBitmapFile(path: String): ImageBitmap?
    suspend fun loadThumbnail(path: String): ImageBitmap?
    fun openMedia(path: String): Boolean
    fun showToast(text: String, longDuration: Boolean)
    fun startActivityIntent(intent: Intent): Boolean
    fun launchCreateDocument(mimeType: String, suggestedName: String, onResult: (Uri?) -> Unit): Boolean
    fun launchOpenDocument(mimeTypes: Array<String>, onResult: (Uri?) -> Unit): Boolean
    fun launchGetContent(mimeType: String, onResult: (Uri?) -> Unit): Boolean
    fun launchPickMultipleMedia(onResult: (List<Uri>) -> Unit): Boolean
    fun readLegacyRoomDatabase(): BackupData?
    @Composable
    fun BindContext()
}

object PlatformNative {
    var bridge: PlatformNativeBridge? = null
    private var initAttempted = false

    fun ensureInitialized(): PlatformNativeBridge? {
        if (bridge == null && !initAttempted) {
            initAttempted = true
            try {
                getPlatform()
            } catch (_: Throwable) {}
        }
        return bridge
    }
}

// -------------------------------------------------------------
// System & Math (KMP replacements for java.lang.System / Math)
// -------------------------------------------------------------
object System {
    // Fallback timestamp if native bridge is not active
    private var counter = 1793361600000L
    fun currentTimeMillis(): Long {
        val nativeNow = PlatformNative.ensureInitialized()?.currentTimeMillis()
        if (nativeNow != null && nativeNow > 0L) return nativeNow
        return counter++
    }
    fun nanoTime(): Long = currentTimeMillis() * 1000000L
}

object Math {
    const val PI: Double = kotlin.math.PI
    const val E: Double = kotlin.math.E
    fun abs(x: Double): Double = kotlin.math.abs(x)
    fun abs(x: Float): Float = kotlin.math.abs(x)
    fun abs(x: Int): Int = kotlin.math.abs(x)
    fun abs(x: Long): Long = kotlin.math.abs(x)
    fun cos(x: Double): Double = kotlin.math.cos(x)
    fun sin(x: Double): Double = kotlin.math.sin(x)
    fun tan(x: Double): Double = kotlin.math.tan(x)
    fun atan2(y: Double, x: Double): Double = kotlin.math.atan2(y, x)
    fun sqrt(x: Double): Double = kotlin.math.sqrt(x)
    fun pow(a: Double, b: Double): Double = a.pow(b)
    fun round(x: Double): Long = kotlin.math.round(x).toLong()
    fun round(x: Float): Int = kotlin.math.round(x).toInt()
    fun floor(x: Double): Double = kotlin.math.floor(x)
    fun ceil(x: Double): Double = kotlin.math.ceil(x)
    fun max(a: Double, b: Double): Double = kotlin.math.max(a, b)
    fun max(a: Float, b: Float): Float = kotlin.math.max(a, b)
    fun max(a: Int, b: Int): Int = kotlin.math.max(a, b)
    fun max(a: Long, b: Long): Long = kotlin.math.max(a, b)
    fun min(a: Double, b: Double): Double = kotlin.math.min(a, b)
    fun min(a: Float, b: Float): Float = kotlin.math.min(a, b)
    fun min(a: Int, b: Int): Int = kotlin.math.min(a, b)
    fun min(a: Long, b: Long): Long = kotlin.math.min(a, b)
    fun toRadians(deg: Double): Double = deg * kotlin.math.PI / 180.0
    fun toDegrees(rad: Double): Double = rad * 180.0 / kotlin.math.PI
}

// -------------------------------------------------------------
// UUID
// -------------------------------------------------------------
fun generateUUID(): String {
    val chars = "0123456789abcdef"
    val sb = StringBuilder()
    for (i in 0 until 32) {
        if (i == 8 || i == 12 || i == 16 || i == 20) sb.append("-")
        sb.append(chars.random())
    }
    return sb.toString()
}

class UUID(val value: String = generateUUID()) {
    override fun toString(): String = value
    companion object {
        fun randomUUID(): UUID = UUID(generateUUID())
    }
}

// -------------------------------------------------------------
// Virtual File System & Backup Storage (Multiplatform Fallback)
// -------------------------------------------------------------
data class SavedBackupRecord(
    val fileName: String,
    val jsonContent: String,
    val createdAt: Long = System.currentTimeMillis()
)

object PlatformVirtualFs {
    private val files = mutableMapOf<String, ByteArray>()
    val savedBackups = mutableStateListOf<SavedBackupRecord>()

    fun putBytes(pathOrUri: String, bytes: ByteArray) {
        files[pathOrUri] = bytes
    }

    fun onDocumentExported(pathOrUri: String, bytes: ByteArray) {
        files[pathOrUri] = bytes
        val text = extractBackupJsonOrText(bytes)
        if (text.isNotBlank()) {
            val cleanName = pathOrUri.removePrefix("backup://").substringAfterLast('/').ifBlank { "zapisnyk_backup.zip" }
            if (cleanName.endsWith(".csv", ignoreCase = true)) {
                PlatformDialogController.activeExportData = ExportDialogState(
                    title = "CSV отчёт сформирован",
                    fileName = cleanName,
                    content = text,
                    isCsv = true
                )
            } else {
                savedBackups.removeAll { it.fileName == cleanName }
                savedBackups.add(0, SavedBackupRecord(cleanName, text, System.currentTimeMillis()))
                PlatformDialogController.activeExportData = ExportDialogState(
                    title = "Резервная копия создана",
                    fileName = cleanName,
                    content = text,
                    isCsv = false
                )
            }
        }
    }

    private fun extractBackupJsonOrText(bytes: ByteArray): String {
        if (bytes.size >= 4 && bytes[0] == 0x50.toByte() && bytes[1] == 0x4B.toByte()) {
            val entries = PurePkZip.readStoredEntries(bytes)
            val backupEntry = entries["backup.json"] ?: entries.entries.firstOrNull { it.key.endsWith("backup.json") }?.value
            if (backupEntry != null) {
                return try { backupEntry.decodeToString() } catch (_: Throwable) { "" }
            }
        }
        return try { bytes.decodeToString() } catch (_: Throwable) { "" }
    }

    fun getBytes(pathOrUri: String): ByteArray? = files[pathOrUri]
    fun exists(pathOrUri: String): Boolean = files.containsKey(pathOrUri)
    fun delete(pathOrUri: String): Boolean = files.remove(pathOrUri) != null
}

// -------------------------------------------------------------
// Pure-Kotlin PKZIP reader/writer (for iOS / non-JVM fallback)
// -------------------------------------------------------------
object PurePkZip {
    private val crcTable = IntArray(256).apply {
        for (n in 0 until 256) {
            var c = n
            for (k in 0 until 8) {
                c = if ((c and 1) != 0) (0xEDB88320.toInt() xor (c ushr 1)) else (c ushr 1)
            }
            this[n] = c
        }
    }

    fun crc32(data: ByteArray): Int {
        var c = -1
        for (b in data) {
            c = crcTable[(c xor (b.toInt() and 0xFF)) and 0xFF] xor (c ushr 8)
        }
        return c xor -1
    }

    private fun writeShortLE(out: OutputStream, v: Int) {
        out.write(v and 0xFF)
        out.write((v ushr 8) and 0xFF)
    }

    private fun writeIntLE(out: OutputStream, v: Int) {
        out.write(v and 0xFF)
        out.write((v ushr 8) and 0xFF)
        out.write((v ushr 16) and 0xFF)
        out.write((v ushr 24) and 0xFF)
    }

    private fun readShortLE(b: ByteArray, off: Int): Int {
        if (off + 2 > b.size) return 0
        return (b[off].toInt() and 0xFF) or ((b[off + 1].toInt() and 0xFF) shl 8)
    }

    private fun readIntLE(b: ByteArray, off: Int): Int {
        if (off + 4 > b.size) return 0
        return (b[off].toInt() and 0xFF) or
            ((b[off + 1].toInt() and 0xFF) shl 8) or
            ((b[off + 2].toInt() and 0xFF) shl 16) or
            ((b[off + 3].toInt() and 0xFF) shl 24)
    }

    fun writeZipArchive(entries: Map<String, ByteArray>): ByteArray {
        val out = ByteArrayOutputStream()
        data class CdRecord(val nameBytes: ByteArray, val crc: Int, val size: Int, val offset: Int)
        val cdRecords = mutableListOf<CdRecord>()
        var offset = 0

        for ((name, data) in entries) {
            val nameBytes = name.encodeToByteArray()
            val crc = crc32(data)
            val size = data.size
            cdRecords.add(CdRecord(nameBytes, crc, size, offset))

            // Local file header signature PK\x03\x04
            writeIntLE(out, 0x04034B50)
            writeShortLE(out, 20) // version needed
            writeShortLE(out, 0)  // flags
            writeShortLE(out, 0)  // compression method: 0 = STORED
            writeShortLE(out, 0)  // mod time
            writeShortLE(out, 0)  // mod date
            writeIntLE(out, crc)
            writeIntLE(out, size)
            writeIntLE(out, size)
            writeShortLE(out, nameBytes.size)
            writeShortLE(out, 0) // extra len
            out.write(nameBytes)
            out.write(data)
            offset += 30 + nameBytes.size + size
        }

        val cdStart = offset
        var cdSize = 0
        for (rec in cdRecords) {
            // Central directory header signature PK\x01\x02
            writeIntLE(out, 0x02014B50)
            writeShortLE(out, 20) // version made by
            writeShortLE(out, 20) // version needed
            writeShortLE(out, 0)  // flags
            writeShortLE(out, 0)  // method: STORED
            writeShortLE(out, 0)  // time
            writeShortLE(out, 0)  // date
            writeIntLE(out, rec.crc)
            writeIntLE(out, rec.size)
            writeIntLE(out, rec.size)
            writeShortLE(out, rec.nameBytes.size)
            writeShortLE(out, 0) // extra
            writeShortLE(out, 0) // comment
            writeShortLE(out, 0) // disk
            writeShortLE(out, 0) // internal attrs
            writeIntLE(out, 0)   // external attrs
            writeIntLE(out, rec.offset)
            out.write(rec.nameBytes)
            cdSize += 46 + rec.nameBytes.size
        }

        // End of central directory signature PK\x05\x06
        writeIntLE(out, 0x06054B50)
        writeShortLE(out, 0)
        writeShortLE(out, 0)
        writeShortLE(out, cdRecords.size)
        writeShortLE(out, cdRecords.size)
        writeIntLE(out, cdSize)
        writeIntLE(out, cdStart)
        writeShortLE(out, 0)

        return out.toByteArray()
    }

    fun readStoredEntries(bytes: ByteArray): Map<String, ByteArray> {
        val result = LinkedHashMap<String, ByteArray>()
        var pos = 0
        while (pos + 30 <= bytes.size) {
            val sig = readIntLE(bytes, pos)
            if (sig != 0x04034B50) break
            val method = readShortLE(bytes, pos + 8)
            val compSize = readIntLE(bytes, pos + 18)
            val nameLen = readShortLE(bytes, pos + 26)
            val extraLen = readShortLE(bytes, pos + 28)
            val nameStart = pos + 30
            if (nameStart + nameLen > bytes.size) break
            val name = bytes.copyOfRange(nameStart, nameStart + nameLen).decodeToString()
            val dataStart = nameStart + nameLen + extraLen
            if (method == 0 && compSize >= 0 && dataStart + compSize <= bytes.size) {
                result[name] = bytes.copyOfRange(dataStart, dataStart + compSize)
                pos = dataStart + compSize
            } else {
                break
            }
        }
        return result
    }
}

// -------------------------------------------------------------
// File & IO Streams (KMP replacements for java.io.* & java.util.zip.*)
// -------------------------------------------------------------
object Charsets {
    const val UTF_8 = "UTF-8"
}

interface Closeable {
    fun close() {}
}

inline fun <T : Closeable?, R> T.use(block: (T) -> R): R {
    try {
        return block(this)
    } finally {
        try { this?.close() } catch (_: Throwable) {}
    }
}

open class InputStream : Closeable {
    open fun read(): Int = -1
    open fun read(b: ByteArray): Int = read(b, 0, b.size)
    open fun read(b: ByteArray, off: Int, len: Int): Int {
        if (len <= 0) return 0
        val first = read()
        if (first == -1) return -1
        b[off] = first.toByte()
        var count = 1
        while (count < len) {
            val next = read()
            if (next == -1) break
            b[off + count] = next.toByte()
            count++
        }
        return count
    }
    open fun readAllBytes(): ByteArray {
        val out = ByteArrayOutputStream()
        copyTo(out)
        return out.toByteArray()
    }
    fun copyTo(out: OutputStream, bufferSize: Int = 8192): Long {
        val buf = ByteArray(bufferSize)
        var total = 0L
        while (true) {
            val r = read(buf, 0, buf.size)
            if (r <= 0) break
            out.write(buf, 0, r)
            total += r
        }
        try { out.flush() } catch (_: Throwable) {}
        return total
    }
    fun bufferedReader(charset: Any? = null): BufferedReader = BufferedReader(readAllBytes().decodeToString())
}

class MemoryInputStream(private val data: ByteArray) : InputStream() {
    private var pos = 0
    override fun read(): Int = if (pos < data.size) (data[pos++].toInt() and 0xFF) else -1
    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (pos >= data.size) return -1
        val avail = (data.size - pos).coerceAtMost(len)
        for (i in 0 until avail) {
            b[off + i] = data[pos + i]
        }
        pos += avail
        return avail
    }
    override fun readAllBytes(): ByteArray = data.copyOfRange(pos, data.size).also { pos = data.size }
}

open class OutputStream : Closeable {
    open fun write(b: Int) {}
    open fun write(b: ByteArray) { write(b, 0, b.size) }
    open fun write(b: ByteArray, off: Int, len: Int) {
        for (i in off until (off + len).coerceAtMost(b.size)) write(b[i].toInt())
    }
    open fun flush() {}
}

class MemoryOutputStream(val pathOrUri: String) : OutputStream() {
    private val buf = ByteArrayOutputStream()
    private var closed = false
    override fun write(b: Int) { buf.write(b) }
    override fun write(b: ByteArray, off: Int, len: Int) { buf.write(b, off, len) }
    override fun flush() {
        PlatformVirtualFs.putBytes(pathOrUri, buf.toByteArray())
    }
    override fun close() {
        if (!closed) {
            closed = true
            val bytes = buf.toByteArray()
            if (pathOrUri.startsWith("backup://")) {
                PlatformVirtualFs.onDocumentExported(pathOrUri, bytes)
            } else {
                PlatformVirtualFs.putBytes(pathOrUri, bytes)
            }
        }
    }
}

class BufferedReader(private val content: String = "") : Closeable {
    private val lines = content.lines()
    private var lineIdx = 0
    fun readText(): String = content
    fun readLine(): String? = if (lineIdx < lines.size) lines[lineIdx++] else null
}

class BufferedInputStream(val inner: InputStream? = null) : InputStream() {
    override fun read(): Int = inner?.read() ?: -1
    override fun read(b: ByteArray, off: Int, len: Int): Int = inner?.read(b, off, len) ?: -1
    override fun readAllBytes(): ByteArray = inner?.readAllBytes() ?: ByteArray(0)
    override fun close() { inner?.close() }
}

class BufferedOutputStream(val inner: OutputStream? = null) : OutputStream() {
    override fun write(b: Int) { inner?.write(b) }
    override fun write(b: ByteArray) { inner?.write(b) }
    override fun write(b: ByteArray, off: Int, len: Int) { inner?.write(b, off, len) }
    override fun flush() { inner?.flush() }
    override fun close() { inner?.close() }
}

class ByteArrayOutputStream : OutputStream() {
    private val buf = mutableListOf<Byte>()
    override fun write(b: Int) { buf.add(b.toByte()) }
    override fun write(b: ByteArray, off: Int, len: Int) {
        for (i in off until (off + len).coerceAtMost(b.size)) buf.add(b[i])
    }
    fun reset() { buf.clear() }
    fun toByteArray(): ByteArray = buf.toByteArray()
    fun toString(charset: String): String = buf.toByteArray().decodeToString()
}

class FileInputStream(val file: File? = null) : InputStream() {
    private val delegate: InputStream = run {
        val path = file?.path ?: ""
        val virtualBytes = PlatformVirtualFs.getBytes(path)
        if (virtualBytes != null) {
            MemoryInputStream(virtualBytes)
        } else {
            PlatformNative.ensureInitialized()?.openFileInputStream(path) ?: MemoryInputStream(ByteArray(0))
        }
    }
    override fun read(): Int = delegate.read()
    override fun read(b: ByteArray, off: Int, len: Int): Int = delegate.read(b, off, len)
    override fun readAllBytes(): ByteArray = delegate.readAllBytes()
    override fun close() = delegate.close()
}

class FileOutputStream(val file: File? = null) : OutputStream() {
    private val delegate: OutputStream = run {
        val path = file?.path ?: "memory://temp"
        if (path.startsWith("backup://") || path.startsWith("memory://")) {
            MemoryOutputStream(path)
        } else {
            PlatformNative.ensureInitialized()?.openFileOutputStream(path) ?: MemoryOutputStream(path)
        }
    }
    override fun write(b: Int) = delegate.write(b)
    override fun write(b: ByteArray, off: Int, len: Int) = delegate.write(b, off, len)
    override fun flush() = delegate.flush()
    override fun close() = delegate.close()
}

class ZipEntry(val name: String)

class ZipInputStream(val inner: InputStream? = null) : InputStream() {
    private val nativeDelegate: ZipInputStreamDelegate? = inner?.let {
        PlatformNative.ensureInitialized()?.createZipInputStream(it)
    }

    private val fallbackEntries: List<Pair<String, ByteArray>> by lazy {
        if (nativeDelegate != null || inner == null) {
            emptyList()
        } else {
            val rawBytes = inner.readAllBytes()
            if (rawBytes.isEmpty()) {
                emptyList()
            } else if (rawBytes.size >= 4 && rawBytes[0] == 0x50.toByte() && rawBytes[1] == 0x4B.toByte()) {
                PurePkZip.readStoredEntries(rawBytes).entries.map { it.key to it.value }
            } else {
                listOf("backup.json" to rawBytes)
            }
        }
    }
    private var fallbackIdx = 0
    private var fallbackStream: MemoryInputStream? = null

    val nextEntry: ZipEntry?
        get() {
            if (nativeDelegate != null) {
                val name = nativeDelegate.nextEntryName() ?: return null
                return ZipEntry(name)
            }
            if (fallbackIdx >= fallbackEntries.size) return null
            val (name, bytes) = fallbackEntries[fallbackIdx++]
            fallbackStream = MemoryInputStream(bytes)
            return ZipEntry(name)
        }

    override fun read(): Int {
        if (nativeDelegate != null) {
            val one = ByteArray(1)
            val r = nativeDelegate.read(one, 0, 1)
            return if (r <= 0) -1 else (one[0].toInt() and 0xFF)
        }
        return fallbackStream?.read() ?: -1
    }

    override fun read(b: ByteArray, off: Int, len: Int): Int {
        if (nativeDelegate != null) {
            return nativeDelegate.read(b, off, len)
        }
        return fallbackStream?.read(b, off, len) ?: -1
    }

    fun closeEntry() {
        if (nativeDelegate != null) {
            nativeDelegate.closeEntry()
        } else {
            fallbackStream = null
        }
    }

    override fun close() {
        if (nativeDelegate != null) {
            nativeDelegate.close()
        } else {
            inner?.close()
        }
    }
}

class ZipOutputStream(val inner: OutputStream? = null) : OutputStream() {
    private val nativeDelegate: ZipOutputStreamDelegate? = inner?.let {
        PlatformNative.ensureInitialized()?.createZipOutputStream(it)
    }

    private var currentEntryName: String? = null
    private val currentEntryBuf = ByteArrayOutputStream()
    private val storedEntries = LinkedHashMap<String, ByteArray>()
    private var finished = false

    fun putNextEntry(entry: ZipEntry) {
        if (nativeDelegate != null) {
            nativeDelegate.putNextEntry(entry.name)
            return
        }
        currentEntryName = entry.name
        currentEntryBuf.reset()
    }

    override fun write(b: Int) {
        if (nativeDelegate != null) {
            nativeDelegate.write(byteArrayOf(b.toByte()), 0, 1)
            return
        }
        if (currentEntryName != null) {
            currentEntryBuf.write(b)
        }
    }

    override fun write(b: ByteArray, off: Int, len: Int) {
        if (nativeDelegate != null) {
            nativeDelegate.write(b, off, len)
            return
        }
        if (currentEntryName != null) {
            currentEntryBuf.write(b, off, len)
        }
    }

    fun closeEntry() {
        if (nativeDelegate != null) {
            nativeDelegate.closeEntry()
            return
        }
        val name = currentEntryName
        if (name != null) {
            storedEntries[name] = currentEntryBuf.toByteArray()
        }
        currentEntryName = null
    }

    fun finish() {
        if (nativeDelegate != null) {
            nativeDelegate.finish()
            return
        }
        if (!finished) {
            finished = true
            val curName = currentEntryName
            if (curName != null && !storedEntries.containsKey(curName)) {
                storedEntries[curName] = currentEntryBuf.toByteArray()
            }
            if (storedEntries.isNotEmpty()) {
                val zipBytes = PurePkZip.writeZipArchive(storedEntries)
                inner?.write(zipBytes, 0, zipBytes.size)
                inner?.flush()
            }
        }
    }

    override fun flush() {
        if (nativeDelegate != null) {
            nativeDelegate.flush()
        } else {
            inner?.flush()
        }
    }

    override fun close() {
        if (nativeDelegate != null) {
            nativeDelegate.close()
        } else {
            finish()
            inner?.close()
        }
    }
}

class File(val path: String = "") {
    constructor(parent: File?, child: String) : this(
        if (parent == null || parent.path.isEmpty()) child else "${parent.path.trimEnd('/')}/$child"
    )
    constructor(parent: String?, child: String) : this(
        if (parent.isNullOrEmpty()) child else "${parent.trimEnd('/')}/$child"
    )

    val absolutePath: String get() = path
    val name: String get() = path.substringAfterLast('/')
    val extension: String get() = name.substringAfterLast('.', "")
    val isFile: Boolean
        get() = if (PlatformVirtualFs.exists(path)) true else (PlatformNative.ensureInitialized()?.fileIsFile(path) ?: true)
    val isDirectory: Boolean
        get() = PlatformNative.ensureInitialized()?.fileIsDirectory(path) ?: false

    fun exists(): Boolean = PlatformVirtualFs.exists(path) || (PlatformNative.ensureInitialized()?.fileExists(path) ?: false)
    fun canRead(): Boolean = PlatformVirtualFs.exists(path) || (PlatformNative.ensureInitialized()?.fileCanRead(path) ?: false)
    fun mkdirs(): Boolean = PlatformNative.ensureInitialized()?.fileMkdirs(path) ?: true
    fun delete(): Boolean {
        val vDel = PlatformVirtualFs.delete(path)
        val nDel = PlatformNative.ensureInitialized()?.fileDelete(path) ?: false
        return vDel || nDel
    }
    fun length(): Long {
        PlatformVirtualFs.getBytes(path)?.let { return it.size.toLong() }
        return PlatformNative.ensureInitialized()?.fileLength(path) ?: 0L
    }
    fun listFiles(): Array<File>? = PlatformNative.ensureInitialized()?.fileListFiles(path) ?: emptyArray()
    fun inputStream(): FileInputStream = FileInputStream(this)
    fun outputStream(): FileOutputStream = FileOutputStream(this)
}

// -------------------------------------------------------------
// Network Stubs (URL, HttpURLConnection, URLEncoder)
// -------------------------------------------------------------
class UnknownHostException(message: String = "Offline") : Exception(message)

object URLEncoder {
    fun encode(s: String, enc: String = "UTF-8"): String = s
}

class HttpURLConnection(val url: URL) {
    var connectTimeout: Int = 5000
    var readTimeout: Int = 5000
    var requestMethod: String = "GET"
    var instanceFollowRedirects: Boolean = true
    var doOutput: Boolean = false
    val responseCode: Int = 404
    val contentType: String? = null
    val contentLength: Int = 0
    val contentLengthLong: Long = 0L
    val inputStream: InputStream = InputStream()
    val errorStream: InputStream? = null
    val outputStream: OutputStream = OutputStream()
    val headerFields: Map<String?, List<String>> = emptyMap()

    fun setRequestProperty(key: String, value: String) {}
    fun getHeaderField(name: String): String? = null
    fun connect() {}
    fun disconnect() {}
}

class URL(val spec: String) {
    fun openConnection(): HttpURLConnection = HttpURLConnection(this)
}

// -------------------------------------------------------------
// Real Pure-Kotlin JSON Engine + Gson + JSONObject + JSONArray
// -------------------------------------------------------------
object MiniJson {
    fun escape(s: String): String {
        val sb = StringBuilder(s.length + 2)
        sb.append('"')
        for (ch in s) {
            when (ch) {
                '"' -> sb.append("\\\"")
                '\\' -> sb.append("\\\\")
                '\b' -> sb.append("\\b")
                '\u000C' -> sb.append("\\f")
                '\n' -> sb.append("\\n")
                '\r' -> sb.append("\\r")
                '\t' -> sb.append("\\t")
                else -> {
                    if (ch < ' ') {
                        sb.append("\\u").append(ch.code.toString(16).padStart(4, '0'))
                    } else {
                        sb.append(ch)
                    }
                }
            }
        }
        sb.append('"')
        return sb.toString()
    }

    fun stringify(value: Any?): String {
        return when (value) {
            null -> "null"
            is Boolean -> if (value) "true" else "false"
            is Int, is Long, is Short, is Byte -> value.toString()
            is Number -> {
                val d = value.toDouble()
                if (d.isNaN() || d.isInfinite()) "0.0" else d.toString()
            }
            is String -> escape(value)
            is CharSequence -> escape(value.toString())
            is CatType -> escape(value.name)
            is JSONObject -> value.toJsonString()
            is JSONArray -> value.toJsonString()
            is Map<*, *> -> {
                val entries = value.entries.joinToString(",") { (k, v) ->
                    "${escape(k?.toString() ?: "")}:${stringify(v)}"
                }
                "{$entries}"
            }
            is Iterable<*> -> "[${value.joinToString(",") { stringify(it) }}]"
            is Array<*> -> "[${value.joinToString(",") { stringify(it) }}]"
            else -> {
                val map = modelToMap(value)
                if (map != null) stringify(map) else escape(value.toString())
            }
        }
    }

    fun modelToMap(obj: Any): Map<String, Any?>? = when (obj) {
        is BackupData -> linkedMapOf(
            "notes" to obj.notes,
            "tasks" to obj.tasks,
            "shiftConfig" to obj.shiftConfig,
            "finances" to obj.finances,
            "debts" to obj.debts,
            "expectedFinances" to obj.expectedFinances,
            "categoryList" to obj.categoryList,
            "sectionNames" to obj.sectionNames,
            "hiddenSections" to obj.hiddenSections,
            "expenseLimit" to obj.expenseLimit,
            "capitalOverrides" to obj.capitalOverrides,
            "excludedFromLimit" to obj.excludedFromLimit,
            "savingsGoals" to obj.savingsGoals,
            "hasCar" to obj.hasCar,
            "cars" to obj.cars,
            "carEvents" to obj.carEvents,
            "carMileageLogs" to obj.carMileageLogs,
            "carReminders" to obj.carReminders
        )
        is DiaryNote -> linkedMapOf(
            "date" to obj.date,
            "title" to obj.title,
            "content" to obj.content,
            "mediaPaths" to obj.mediaPaths,
            "mainMediaPath" to obj.mainMediaPath,
            "mood" to obj.mood,
            "tags" to obj.tags,
            "location" to obj.location
        )
        is DiaryTask -> linkedMapOf(
            "id" to obj.id,
            "title" to obj.title,
            "frequency" to obj.frequency,
            "lastDoneDate" to obj.lastDoneDate,
            "targetDate" to obj.targetDate,
            "isHabit" to obj.isHabit,
            "streak" to obj.streak,
            "bestStreak" to obj.bestStreak,
            "historyDates" to obj.historyDates,
            "subtasks" to obj.subtasks,
            "timeOfDay" to obj.timeOfDay,
            "priority" to obj.priority,
            "category" to obj.category,
            "videoUrl" to obj.videoUrl,
            "videoTitle" to obj.videoTitle
        )
        is ShiftConfig -> linkedMapOf(
            "id" to obj.id,
            "startDate" to obj.startDate,
            "isActive" to obj.isActive,
            "alarmHour" to obj.alarmHour,
            "alarmMinute" to obj.alarmMinute,
            "isAlarmEnabled" to obj.isAlarmEnabled,
            "lastAlarmSetDate" to obj.lastAlarmSetDate,
            "shiftColor" to obj.shiftColor,
            "pattern" to obj.pattern
        )
        is DiaryFinance -> linkedMapOf(
            "date" to obj.date,
            "income" to obj.income,
            "expense" to obj.expense,
            "savings_deposit" to obj.savings_deposit,
            "debt" to obj.debt,
            "incHistory" to obj.incHistory,
            "expHistory" to obj.expHistory,
            "depHistory" to obj.depHistory,
            "dynamicData" to obj.dynamicData,
            "dynamicBalances" to obj.dynamicBalances
        )
        is DiaryDebt -> linkedMapOf(
            "id" to obj.id,
            "creditor" to obj.creditor,
            "amount" to obj.amount,
            "dueDate" to obj.dueDate,
            "isPaid" to obj.isPaid,
            "createdAt" to obj.createdAt,
            "paidDate" to obj.paidDate
        )
        is ExpectedFinance -> linkedMapOf(
            "id" to obj.id,
            "title" to obj.title,
            "amount" to obj.amount,
            "dayOfMonth" to obj.dayOfMonth,
            "isIncome" to obj.isIncome
        )
        is CategoryConfig -> linkedMapOf(
            "id" to obj.id,
            "name" to obj.name,
            "color" to obj.color,
            "type" to (obj.type?.name ?: "HISTORY"),
            "iconKey" to (obj.iconKey ?: ""),
            "customIconUri" to (obj.customIconUri ?: "")
        )
        is FinanceItem -> linkedMapOf(
            "id" to obj.id,
            "amount" to obj.amount,
            "note" to obj.note
        )
        is SavingsGoal -> linkedMapOf(
            "id" to obj.id,
            "categoryId" to obj.categoryId,
            "title" to obj.title,
            "targetAmount" to obj.targetAmount,
            "trackMode" to obj.trackMode,
            "monthKey" to obj.monthKey
        )
        is SubtaskItem -> linkedMapOf(
            "id" to obj.id,
            "title" to obj.title,
            "isDone" to obj.isDone,
            "lastDoneDate" to obj.lastDoneDate
        )
        is CarItem -> linkedMapOf(
            "id" to obj.id,
            "brand" to obj.brand,
            "model" to obj.model,
            "carType" to obj.carType,
            "year" to obj.year,
            "plateNumber" to obj.plateNumber,
            "color" to obj.color,
            "currentOdometer" to obj.currentOdometer,
            "fuelType" to obj.fuelType,
            "notes" to obj.notes,
            "createdAt" to obj.createdAt
        )
        is CarEventItem -> linkedMapOf(
            "id" to obj.id,
            "carId" to obj.carId,
            "date" to obj.date,
            "type" to obj.type,
            "title" to obj.title,
            "amount" to obj.amount,
            "isIncome" to obj.isIncome,
            "odometer" to obj.odometer,
            "liters" to obj.liters,
            "pricePerLiter" to obj.pricePerLiter,
            "isFullTank" to obj.isFullTank,
            "gasStation" to obj.gasStation,
            "fuelType" to obj.fuelType,
            "note" to obj.note
        )
        is CarMileageItem -> linkedMapOf(
            "id" to obj.id,
            "carId" to obj.carId,
            "date" to obj.date,
            "odometer" to obj.odometer,
            "title" to obj.title,
            "note" to obj.note
        )
        is CarReminderItem -> linkedMapOf(
            "id" to obj.id,
            "carId" to obj.carId,
            "title" to obj.title,
            "type" to obj.type,
            "targetDate" to obj.targetDate,
            "targetOdometer" to obj.targetOdometer,
            "repeatIntervalKm" to obj.repeatIntervalKm,
            "isCompleted" to obj.isCompleted,
            "note" to obj.note
        )
        else -> null
    }

    fun parse(raw: String): Any? {
        val parser = Parser(raw)
        return parser.parseValue()
    }

    private class Parser(val s: String) {
        var pos = 0
        val len = s.length

        fun skipWhitespace() {
            while (pos < len) {
                val c = s[pos]
                if (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\uFEFF') pos++ else break
            }
        }

        fun parseValue(): Any? {
            skipWhitespace()
            if (pos >= len) return null
            return when (s[pos]) {
                '{' -> parseObject()
                '[' -> parseArray()
                '"' -> parseString()
                't', 'f' -> parseBoolean()
                'n' -> parseNull()
                else -> parseNumber()
            }
        }

        fun parseObject(): Map<String, Any?> {
            val map = LinkedHashMap<String, Any?>()
            pos++ // skip '{'
            skipWhitespace()
            if (pos < len && s[pos] == '}') {
                pos++
                return map
            }
            while (pos < len) {
                skipWhitespace()
                if (pos < len && s[pos] == '}') {
                    pos++
                    break
                }
                val key = if (pos < len && s[pos] == '"') parseString() else parseUnquotedToken()
                skipWhitespace()
                if (pos < len && s[pos] == ':') pos++
                val value = parseValue()
                map[key] = value
                skipWhitespace()
                if (pos < len && s[pos] == ',') {
                    pos++
                } else if (pos < len && s[pos] == '}') {
                    pos++
                    break
                } else {
                    break
                }
            }
            return map
        }

        fun parseArray(): List<Any?> {
            val list = ArrayList<Any?>()
            pos++ // skip '['
            skipWhitespace()
            if (pos < len && s[pos] == ']') {
                pos++
                return list
            }
            while (pos < len) {
                skipWhitespace()
                if (pos < len && s[pos] == ']') {
                    pos++
                    break
                }
                list.add(parseValue())
                skipWhitespace()
                if (pos < len && s[pos] == ',') {
                    pos++
                } else if (pos < len && s[pos] == ']') {
                    pos++
                    break
                } else {
                    break
                }
            }
            return list
        }

        fun parseString(): String {
            pos++ // skip '"'
            val sb = StringBuilder()
            while (pos < len) {
                val c = s[pos++]
                if (c == '"') return sb.toString()
                if (c == '\\' && pos < len) {
                    val esc = s[pos++]
                    when (esc) {
                        '"' -> sb.append('"')
                        '\\' -> sb.append('\\')
                        '/' -> sb.append('/')
                        'b' -> sb.append('\b')
                        'f' -> sb.append('\u000C')
                        'n' -> sb.append('\n')
                        'r' -> sb.append('\r')
                        't' -> sb.append('\t')
                        'u' -> {
                            if (pos + 4 <= len) {
                                val hex = s.substring(pos, pos + 4)
                                pos += 4
                                val code = hex.toIntOrNull(16)
                                if (code != null) sb.append(code.toChar())
                            }
                        }
                        else -> sb.append(esc)
                    }
                } else {
                    sb.append(c)
                }
            }
            return sb.toString()
        }

        fun parseBoolean(): Boolean {
            if (s.startsWith("true", pos)) {
                pos += 4
                return true
            }
            if (s.startsWith("false", pos)) {
                pos += 5
                return false
            }
            pos++
            return false
        }

        fun parseNull(): Any? {
            if (s.startsWith("null", pos)) {
                pos += 4
                return null
            }
            pos++
            return null
        }

        fun parseNumber(): Any {
            val start = pos
            while (pos < len) {
                val c = s[pos]
                if (c in '0'..'9' || c == '-' || c == '+' || c == '.' || c == 'e' || c == 'E') pos++ else break
            }
            val token = s.substring(start, pos)
            if (token.contains('.') || token.contains('e') || token.contains('E')) {
                return token.toDoubleOrNull() ?: 0.0
            }
            return token.toLongOrNull() ?: token.toDoubleOrNull() ?: 0L
        }

        fun parseUnquotedToken(): String {
            val start = pos
            while (pos < len && s[pos] !in charArrayOf(':', ',', '}', ']', ' ', '\t', '\n', '\r')) pos++
            return s.substring(start, pos)
        }
    }

    private fun Map<*, *>.str(k: String, def: String = ""): String = this[k]?.toString() ?: def
    private fun Map<*, *>.strNull(k: String): String? = this[k]?.toString()
    private fun Map<*, *>.int(k: String, def: Int = 0): Int =
        (this[k] as? Number)?.toInt() ?: this[k]?.toString()?.toDoubleOrNull()?.toInt() ?: def
    private fun Map<*, *>.intNull(k: String): Int? =
        (this[k] as? Number)?.toInt() ?: this[k]?.toString()?.toDoubleOrNull()?.toInt()
    private fun Map<*, *>.long(k: String, def: Long = 0L): Long =
        (this[k] as? Number)?.toLong() ?: this[k]?.toString()?.toDoubleOrNull()?.toLong() ?: def
    private fun Map<*, *>.longNull(k: String): Long? =
        (this[k] as? Number)?.toLong() ?: this[k]?.toString()?.toDoubleOrNull()?.toLong()
    private fun Map<*, *>.dbl(k: String, def: Double = 0.0): Double =
        (this[k] as? Number)?.toDouble() ?: this[k]?.toString()?.toDoubleOrNull() ?: def
    private fun Map<*, *>.dblNull(k: String): Double? =
        (this[k] as? Number)?.toDouble() ?: this[k]?.toString()?.toDoubleOrNull()
    private fun Map<*, *>.bool(k: String, def: Boolean = false): Boolean =
        (this[k] as? Boolean) ?: this[k]?.toString()?.lowercase()?.toBooleanStrictOrNull() ?: def
    private fun Map<*, *>.jsonStr(k: String, def: String = "[]"): String {
        val v = this[k] ?: return def
        return if (v is String) v else stringify(v)
    }

    fun mapToDiaryNote(m: Map<*, *>): DiaryNote = DiaryNote(
        date = m.long("date", System.currentTimeMillis().toMidnight()),
        title = m.str("title", ""),
        content = m.str("content", ""),
        mediaPaths = m.jsonStr("mediaPaths", "[]"),
        mainMediaPath = m.str("mainMediaPath", ""),
        mood = m.str("mood", ""),
        tags = m.str("tags", ""),
        location = m.str("location", "")
    )

    fun mapToDiaryTask(m: Map<*, *>): DiaryTask = DiaryTask(
        id = m.int("id", 0),
        title = m.str("title", ""),
        frequency = m.str("frequency", "Ежедневно"),
        lastDoneDate = m.str("lastDoneDate", ""),
        targetDate = m.long("targetDate", System.currentTimeMillis()),
        isHabit = m.bool("isHabit", false),
        streak = m.int("streak", 0),
        bestStreak = m.int("bestStreak", 0),
        historyDates = m.jsonStr("historyDates", "[]"),
        subtasks = m.jsonStr("subtasks", "[]"),
        timeOfDay = m.str("timeOfDay", "ANY"),
        priority = m.str("priority", "NORMAL"),
        category = m.str("category", ""),
        videoUrl = m.strNull("videoUrl"),
        videoTitle = m.strNull("videoTitle")
    )

    fun mapToShiftConfig(m: Map<*, *>): ShiftConfig = ShiftConfig(
        id = m.int("id", 1),
        startDate = m.long("startDate", System.currentTimeMillis()),
        isActive = m.bool("isActive", false),
        alarmHour = m.int("alarmHour", 7),
        alarmMinute = m.int("alarmMinute", 0),
        isAlarmEnabled = m.bool("isAlarmEnabled", false),
        lastAlarmSetDate = m.str("lastAlarmSetDate", ""),
        shiftColor = m.int("shiftColor", 0xFFEF9A9A.toInt()),
        pattern = m.str("pattern", "WRRR")
    )

    fun mapToDiaryFinance(m: Map<*, *>): DiaryFinance = DiaryFinance(
        date = m.long("date", System.currentTimeMillis().toMidnight()),
        income = m.dbl("income", 0.0),
        expense = m.dbl("expense", 0.0),
        savings_deposit = m.dbl("savings_deposit", 0.0),
        debt = m.dbl("debt", 0.0),
        incHistory = m.jsonStr("incHistory", "[]"),
        expHistory = m.jsonStr("expHistory", "[]"),
        depHistory = m.jsonStr("depHistory", "[]"),
        dynamicData = m.jsonStr("dynamicData", "{}"),
        dynamicBalances = m.jsonStr("dynamicBalances", "{}")
    )

    fun mapToDiaryDebt(m: Map<*, *>): DiaryDebt = DiaryDebt(
        id = m.int("id", 0),
        creditor = m.str("creditor", ""),
        amount = m.dbl("amount", 0.0),
        dueDate = m.long("dueDate", System.currentTimeMillis()),
        isPaid = m.bool("isPaid", false),
        createdAt = m.long("createdAt", System.currentTimeMillis()),
        paidDate = m.long("paidDate", 0L)
    )

    fun mapToExpectedFinance(m: Map<*, *>): ExpectedFinance = ExpectedFinance(
        id = m.int("id", 0),
        title = m.str("title", ""),
        amount = m.dbl("amount", 0.0),
        dayOfMonth = m.int("dayOfMonth", 1),
        isIncome = m.bool("isIncome", false)
    )

    fun mapToCategoryConfig(m: Map<*, *>): CategoryConfig {
        val rawType = m.str("type", "HISTORY").uppercase()
        val catType = try { CatType.valueOf(rawType) } catch (_: Throwable) { CatType.HISTORY }
        val colorVal = (m["color"] as? Number)?.toInt()
            ?: m["color"]?.toString()?.let { s ->
                if (s.startsWith("#")) {
                    val clean = s.removePrefix("#")
                    val parsed = clean.toLongOrNull(16) ?: 0x2E7D32L
                    (if (clean.length <= 6) (0xFF000000L or parsed) else parsed).toInt()
                } else s.toDoubleOrNull()?.toInt()
            } ?: 0
        return CategoryConfig(
            id = m.str("id", ""),
            name = m.str("name", ""),
            color = colorVal,
            type = catType,
            iconKey = m.str("iconKey", ""),
            customIconUri = m.str("customIconUri", "")
        )
    }

    fun mapToFinanceItem(m: Map<*, *>): FinanceItem = FinanceItem(
        id = m.long("id", System.currentTimeMillis()),
        amount = m.dbl("amount", 0.0),
        note = m.str("note", "")
    )

    fun mapToSavingsGoal(m: Map<*, *>): SavingsGoal = SavingsGoal(
        id = m.str("id", generateUUID()),
        categoryId = m.str("categoryId", ""),
        title = m.str("title", ""),
        targetAmount = m.dbl("targetAmount", 0.0),
        trackMode = m.str("trackMode", "MONTH_ADDITIONS"),
        monthKey = m.str("monthKey", "")
    )

    fun mapToSubtaskItem(m: Map<*, *>): SubtaskItem = SubtaskItem(
        id = m.str("id", generateUUID()),
        title = m.str("title", ""),
        isDone = m.bool("isDone", false),
        lastDoneDate = m.str("lastDoneDate", "")
    )

    fun mapToCarItem(m: Map<*, *>): CarItem = CarItem(
        id = m.str("id", generateUUID()),
        brand = m.str("brand", ""),
        model = m.str("model", ""),
        carType = m.str("carType", "Седан"),
        year = m.intNull("year"),
        plateNumber = m.strNull("plateNumber"),
        color = m.str("color", "#2563EB"),
        currentOdometer = m.int("currentOdometer", 0),
        fuelType = m.str("fuelType", "АИ-95"),
        notes = m.str("notes", ""),
        createdAt = m.long("createdAt", System.currentTimeMillis())
    )

    fun mapToCarEventItem(m: Map<*, *>): CarEventItem = CarEventItem(
        id = m.str("id", generateUUID()),
        carId = m.str("carId", ""),
        date = m.long("date", System.currentTimeMillis()),
        type = m.str("type", "FUEL"),
        title = m.str("title", ""),
        amount = m.dbl("amount", 0.0),
        isIncome = m.bool("isIncome", false),
        odometer = m.intNull("odometer"),
        liters = m.dblNull("liters"),
        pricePerLiter = m.dblNull("pricePerLiter"),
        isFullTank = m.bool("isFullTank", true),
        gasStation = m.strNull("gasStation"),
        fuelType = m.strNull("fuelType"),
        note = m.str("note", "")
    )

    fun mapToCarMileageItem(m: Map<*, *>): CarMileageItem = CarMileageItem(
        id = m.str("id", generateUUID()),
        carId = m.str("carId", ""),
        date = m.long("date", System.currentTimeMillis()),
        odometer = m.int("odometer", 0),
        title = m.str("title", ""),
        note = m.str("note", "")
    )

    fun mapToCarReminderItem(m: Map<*, *>): CarReminderItem = CarReminderItem(
        id = m.str("id", generateUUID()),
        carId = m.str("carId", ""),
        title = m.str("title", ""),
        type = m.str("type", "BY_MILEAGE"),
        targetDate = m.longNull("targetDate"),
        targetOdometer = m.intNull("targetOdometer"),
        repeatIntervalKm = m.intNull("repeatIntervalKm"),
        isCompleted = m.bool("isCompleted", false),
        note = m.str("note", "")
    )

    fun mapToBackupData(m: Map<*, *>): BackupData = BackupData(
        notes = (m["notes"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToDiaryNote) },
        tasks = (m["tasks"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToDiaryTask) },
        shiftConfig = (m["shiftConfig"] as? Map<*, *>)?.let(::mapToShiftConfig),
        finances = (m["finances"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToDiaryFinance) },
        debts = (m["debts"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToDiaryDebt) },
        expectedFinances = ((m["expectedFinances"] ?: m["expected"]) as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToExpectedFinance) },
        categoryList = ((m["categoryList"] ?: m["categories"]) as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToCategoryConfig) },
        sectionNames = (m["sectionNames"] as? Map<*, *>)?.entries?.associate { it.key.toString() to (it.value?.toString() ?: "") },
        hiddenSections = (m["hiddenSections"] as? List<*>)?.mapNotNull { it?.toString() },
        expenseLimit = m.dblNull("expenseLimit"),
        capitalOverrides = (m["capitalOverrides"] as? Map<*, *>)?.entries?.mapNotNull { (k, v) ->
            val d = (v as? Number)?.toDouble() ?: v?.toString()?.toDoubleOrNull()
            if (k != null && d != null) k.toString() to d else null
        }?.toMap(),
        excludedFromLimit = (m["excludedFromLimit"] as? List<*>)?.mapNotNull { it?.toString() },
        savingsGoals = (m["savingsGoals"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToSavingsGoal) },
        hasCar = if (m.containsKey("hasCar") && m["hasCar"] != null) m.bool("hasCar", true) else null,
        cars = (m["cars"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToCarItem) },
        carEvents = (m["carEvents"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToCarEventItem) },
        carMileageLogs = (m["carMileageLogs"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToCarMileageItem) },
        carReminders = (m["carReminders"] as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(::mapToCarReminderItem) }
    )

    fun mapToInferredModel(m: Map<*, *>): Any {
        return when {
            m.containsKey("notes") && (m.containsKey("finances") || m.containsKey("tasks") || m.containsKey("shiftConfig")) -> mapToBackupData(m)
            m.containsKey("brand") && m.containsKey("model") -> mapToCarItem(m)
            m.containsKey("carId") && (m.containsKey("isFullTank") || m.containsKey("liters") || m.containsKey("gasStation") || m.containsKey("isIncome")) -> mapToCarEventItem(m)
            m.containsKey("carId") && (m.containsKey("targetOdometer") || m.containsKey("repeatIntervalKm") || m.containsKey("isCompleted")) -> mapToCarReminderItem(m)
            m.containsKey("carId") && m.containsKey("odometer") -> mapToCarMileageItem(m)
            m.containsKey("categoryId") && m.containsKey("targetAmount") -> mapToSavingsGoal(m)
            m.containsKey("color") && m.containsKey("name") && m.containsKey("id") -> mapToCategoryConfig(m)
            m.containsKey("amount") && m.containsKey("note") && !m.containsKey("carId") -> mapToFinanceItem(m)
            m.containsKey("isDone") && m.containsKey("title") -> mapToSubtaskItem(m)
            m.containsKey("incHistory") || m.containsKey("expHistory") -> mapToDiaryFinance(m)
            m.containsKey("mediaPaths") && m.containsKey("content") -> mapToDiaryNote(m)
            m.containsKey("frequency") && m.containsKey("title") -> mapToDiaryTask(m)
            m.containsKey("creditor") && m.containsKey("dueDate") -> mapToDiaryDebt(m)
            m.containsKey("dayOfMonth") && m.containsKey("isIncome") -> mapToExpectedFinance(m)
            m.containsKey("pattern") && m.containsKey("startDate") -> mapToShiftConfig(m)
            else -> m
        }
    }
}

class JSONObject(raw: String = "{}") {
    private val map = LinkedHashMap<String, Any?>()

    init {
        val trimmed = raw.trim()
        val cached = jsonObjCache[trimmed]
        if (cached != null) {
            map.putAll(cached)
        } else if (trimmed.startsWith("{") && trimmed != "{}") {
            val parsed = MiniJson.parse(trimmed) as? Map<*, *>
            if (parsed != null) {
                for ((k, v) in parsed) {
                    if (k != null) {
                        map[k.toString()] = wrapJsonValue(v)
                    }
                }
            }
        }
    }

    constructor(fromMap: Map<*, *>) : this("{}") {
        for ((k, v) in fromMap) {
            if (k != null) map[k.toString()] = wrapJsonValue(v)
        }
    }

    fun put(key: String, value: Any?): JSONObject {
        map[key] = value
        return this
    }
    fun has(key: String): Boolean = map.containsKey(key)
    fun optString(key: String, fallback: String = ""): String = map[key]?.toString() ?: fallback
    fun getString(key: String): String = optString(key, "")
    fun optBoolean(key: String, fallback: Boolean = false): Boolean =
        (map[key] as? Boolean) ?: map[key]?.toString()?.lowercase()?.toBooleanStrictOrNull() ?: fallback
    fun getBoolean(key: String): Boolean = optBoolean(key, false)
    fun optInt(key: String, fallback: Int = 0): Int =
        (map[key] as? Number)?.toInt() ?: map[key]?.toString()?.toDoubleOrNull()?.toInt() ?: fallback
    fun getInt(key: String): Int = optInt(key, 0)
    fun optLong(key: String, fallback: Long = 0L): Long =
        (map[key] as? Number)?.toLong() ?: map[key]?.toString()?.toDoubleOrNull()?.toLong() ?: fallback
    fun getLong(key: String): Long = optLong(key, 0L)
    fun optDouble(key: String, fallback: Double = 0.0): Double =
        (map[key] as? Number)?.toDouble() ?: map[key]?.toString()?.toDoubleOrNull() ?: fallback
    fun getDouble(key: String): Double = optDouble(key, 0.0)
    fun optJSONObject(key: String): JSONObject? = when (val v = map[key]) {
        is JSONObject -> v
        is Map<*, *> -> JSONObject(v)
        else -> null
    }
    fun getJSONObject(key: String): JSONObject = optJSONObject(key) ?: JSONObject()
    fun optJSONArray(key: String): JSONArray? = when (val v = map[key]) {
        is JSONArray -> v
        is List<*> -> JSONArray(v)
        else -> null
    }
    fun getJSONArray(key: String): JSONArray = optJSONArray(key) ?: JSONArray()
    fun keys(): Iterator<String> = map.keys.iterator()

    fun toJsonString(): String {
        if (map.isEmpty()) return "{}"
        val entries = map.entries.joinToString(",") { (k, v) ->
            "${MiniJson.escape(k)}:${MiniJson.stringify(v)}"
        }
        return "{$entries}"
    }

    override fun toString(): String = toJsonString()

    companion object {
        val jsonObjCache = mutableMapOf<String, Map<String, Any?>>()
        internal fun wrapJsonValue(v: Any?): Any? = when (v) {
            is Map<*, *> -> JSONObject(v)
            is List<*> -> JSONArray(v)
            else -> v
        }
    }
}

class JSONArray(raw: String = "[]") {
    private val list = ArrayList<Any?>()

    init {
        val trimmed = raw.trim()
        val cached = jsonArrCache[trimmed]
        if (cached != null) {
            list.addAll(cached)
        } else if (trimmed.startsWith("[") && trimmed != "[]") {
            val parsed = MiniJson.parse(trimmed) as? List<*>
            if (parsed != null) {
                for (item in parsed) {
                    list.add(JSONObject.wrapJsonValue(item))
                }
            }
        }
    }

    constructor(fromList: List<*>) : this("[]") {
        for (item in fromList) {
            list.add(JSONObject.wrapJsonValue(item))
        }
    }

    fun length(): Int = list.size
    fun put(value: Any?): JSONArray {
        list.add(value)
        return this
    }
    fun get(index: Int): Any? = list.getOrNull(index)
    fun opt(index: Int): Any? = list.getOrNull(index)
    fun getString(index: Int): String = list.getOrNull(index)?.toString() ?: ""
    fun optString(index: Int, fallback: String = ""): String = list.getOrNull(index)?.toString() ?: fallback
    fun getJSONObject(index: Int): JSONObject = optJSONObject(index) ?: JSONObject()
    fun optJSONObject(index: Int): JSONObject? = when (val v = list.getOrNull(index)) {
        is JSONObject -> v
        is Map<*, *> -> JSONObject(v)
        else -> null
    }

    fun toJsonString(): String {
        if (list.isEmpty()) return "[]"
        return "[${list.joinToString(",") { MiniJson.stringify(it) }}]"
    }

    override fun toString(): String = toJsonString()

    companion object {
        val jsonArrCache = mutableMapOf<String, List<Any?>>()
    }
}

class Gson {
    companion object {
        private val objCache = mutableMapOf<String, Any?>()
    }

    fun toJson(src: Any?): String {
        if (src == null) return "null"
        val json = MiniJson.stringify(src)
        when (src) {
            is Collection<*> -> if (src.isNotEmpty()) objCache[json] = ArrayList(src)
            is Map<*, *> -> if (src.isNotEmpty()) objCache[json] = LinkedHashMap(src)
            else -> objCache[json] = src
        }
        return json
    }

    @Suppress("UNCHECKED_CAST")
    fun <T> fromJson(json: String?, type: Any?): T? {
        if (json.isNullOrBlank()) return null
        val trimmed = json.trim().removePrefix("\uFEFF").trim()
        if (trimmed == "null") return null
        if (trimmed == "[]") return mutableListOf<Any?>() as? T
        if (trimmed == "{}") return mutableMapOf<String, Any?>() as? T

        if (type != BackupData::class) {
            val cached = objCache[trimmed]
            if (cached != null) {
                return when (cached) {
                    is List<*> -> ArrayList(cached) as? T
                    is Map<*, *> -> LinkedHashMap(cached) as? T
                    else -> cached as? T
                }
            }
        }

        val parsed = MiniJson.parse(trimmed) ?: return null
        if (type == BackupData::class && parsed is Map<*, *>) {
            return MiniJson.mapToBackupData(parsed) as? T
        }

        return when (parsed) {
            is List<*> -> {
                val mapped = ArrayList(parsed.map { elem ->
                    if (elem is Map<*, *>) MiniJson.mapToInferredModel(elem) else elem
                })
                objCache[trimmed] = mapped
                ArrayList(mapped) as? T
            }
            is Map<*, *> -> {
                if (parsed.containsKey("notes") && (parsed.containsKey("finances") || parsed.containsKey("tasks") || parsed.containsKey("shiftConfig"))) {
                    return MiniJson.mapToBackupData(parsed) as? T
                }
                val allNumbers = parsed.isNotEmpty() && parsed.values.all { it is Number }
                val resultMap = LinkedHashMap<String, Any?>()
                if (allNumbers) {
                    for ((k, v) in parsed) {
                        if (k != null && v is Number) {
                            resultMap[k.toString()] = v.toDouble()
                        }
                    }
                } else {
                    for ((k, v) in parsed) {
                        if (k != null) {
                            resultMap[k.toString()] = when (v) {
                                null -> ""
                                is String -> v
                                is Number, is Boolean -> v.toString()
                                else -> MiniJson.stringify(v)
                            }
                        }
                    }
                }
                objCache[trimmed] = resultMap
                LinkedHashMap(resultMap) as? T
            }
            else -> parsed as? T
        }
    }
}

open class TypeToken<T> {
    val type: Any = this
}

// -------------------------------------------------------------
// Context, SharedPreferences, ContentResolver, ActivityResult
// -------------------------------------------------------------
class ContentResolver {
    fun getType(uri: Uri?): String? {
        val raw = uri?.raw ?: return null
        PlatformNative.ensureInitialized()?.getUriMimeType(raw)?.let { return it }
        return if (raw.endsWith(".mp4", true) || raw.endsWith(".mov", true)) "video/mp4" else "image/jpeg"
    }
    fun openInputStream(uri: Uri?): InputStream? {
        val key = uri?.raw ?: return null
        PlatformVirtualFs.getBytes(key)?.let { return MemoryInputStream(it) }
        PlatformNative.ensureInitialized()?.openUriInputStream(key)?.let { return it }
        return null
    }
    fun openOutputStream(uri: Uri?): OutputStream? {
        val key = uri?.raw ?: return null
        if (key.startsWith("backup://") || key.startsWith("memory://")) {
            return MemoryOutputStream(key)
        }
        PlatformNative.ensureInitialized()?.openUriOutputStream(key)?.let { return it }
        return MemoryOutputStream(key)
    }
    fun loadThumbnail(uri: Uri?, size: Any?, signal: Any?): Bitmap? = null
}

class PackageManager {
    fun getLaunchIntentForPackage(pkg: String): Intent? = Intent()
    companion object {
        const val PERMISSION_GRANTED = 0
    }
}

class Context(val tag: String = "App") {
    val packageName: String = "com.my.zapisnyk"
    val filesDir: File
        get() = File(PlatformNative.ensureInitialized()?.getFilesDirPath() ?: "/data/zapisnyk")
    val applicationContext: Context get() = this
    val contentResolver: ContentResolver = ContentResolver()
    val packageManager: PackageManager = PackageManager()

    fun getSharedPreferences(name: String, mode: Int = 0): SharedPreferences {
        return PlatformPreferences.get(name)
    }

    fun getSystemService(name: String): Any? = when (name) {
        CLIPBOARD_SERVICE -> ClipboardManager.instance
        else -> null
    }

    fun startActivity(intent: Intent?) {
        if (intent == null) return
        val handled = PlatformNative.ensureInitialized()?.startActivityIntent(intent) ?: false
        if (!handled) {
            val sharedText = intent.getStringExtra(Intent.EXTRA_TEXT)
            if (!sharedText.isNullOrBlank()) {
                PlatformDialogController.activeExportData = ExportDialogState(
                    title = "Экспорт данных",
                    fileName = if (intent.type == "text/csv") "finances_report.csv" else "shared_data.txt",
                    content = sharedText,
                    isCsv = intent.type == "text/csv"
                )
            }
        }
    }

    companion object {
        const val MODE_PRIVATE = 0
        const val CLIPBOARD_SERVICE = "clipboard"
        const val NOTIFICATION_SERVICE = "notification"
        const val ALARM_SERVICE = "alarm"
    }
}

object LocalContext {
    val current: Context = Context()
}

fun Any?.getSharedPreferences(name: String, mode: Int = 0): SharedPreferences {
    return PlatformPreferences.get(name)
}

interface SharedPreferences {
    fun getString(key: String, defValue: String?): String?
    fun getFloat(key: String, defValue: Float): Float
    fun getLong(key: String, defValue: Long): Long
    fun getInt(key: String, defValue: Int): Int
    fun getBoolean(key: String, defValue: Boolean): Boolean
    fun getStringSet(key: String, defValues: Set<String>? = null): Set<String>?
    fun contains(key: String): Boolean
    val all: Map<String, Any?>
    fun edit(): Editor

    interface Editor {
        fun putString(key: String, value: String?): Editor
        fun putFloat(key: String, value: Float): Editor
        fun putLong(key: String, value: Long): Editor
        fun putInt(key: String, value: Int): Editor
        fun putBoolean(key: String, value: Boolean): Editor
        fun putStringSet(key: String, values: Set<String>?): Editor
        fun remove(key: String): Editor
        fun clear(): Editor
        fun apply()
        fun commit(): Boolean
    }
}

class InMemorySharedPreferences(val name: String) : SharedPreferences {
    private val data = mutableMapOf<String, Any?>()

    override fun getString(key: String, defValue: String?): String? = (data[key] as? String) ?: defValue
    override fun getFloat(key: String, defValue: Float): Float = (data[key] as? Number)?.toFloat() ?: defValue
    override fun getLong(key: String, defValue: Long): Long = (data[key] as? Number)?.toLong() ?: defValue
    override fun getInt(key: String, defValue: Int): Int = (data[key] as? Number)?.toInt() ?: defValue
    override fun getBoolean(key: String, defValue: Boolean): Boolean = (data[key] as? Boolean) ?: defValue
    @Suppress("UNCHECKED_CAST")
    override fun getStringSet(key: String, defValues: Set<String>?): Set<String>? = (data[key] as? Set<String>) ?: defValues
    override fun contains(key: String): Boolean = data.containsKey(key)
    override val all: Map<String, Any?> get() = data.toMap()

    override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
        private val temp = mutableMapOf<String, Any?>()
        private val removed = mutableSetOf<String>()
        private var cleared = false

        override fun putString(key: String, value: String?): SharedPreferences.Editor { temp[key] = value; return this }
        override fun putFloat(key: String, value: Float): SharedPreferences.Editor { temp[key] = value; return this }
        override fun putLong(key: String, value: Long): SharedPreferences.Editor { temp[key] = value; return this }
        override fun putInt(key: String, value: Int): SharedPreferences.Editor { temp[key] = value; return this }
        override fun putBoolean(key: String, value: Boolean): SharedPreferences.Editor { temp[key] = value; return this }
        override fun putStringSet(key: String, values: Set<String>?): SharedPreferences.Editor { temp[key] = values?.toSet(); return this }
        override fun remove(key: String): SharedPreferences.Editor { removed.add(key); return this }
        override fun clear(): SharedPreferences.Editor { cleared = true; return this }
        override fun apply() { commit() }
        override fun commit(): Boolean {
            if (cleared) data.clear()
            for (k in removed) data.remove(k)
            for ((k, v) in temp) {
                if (v == null) data.remove(k) else data[k] = v
            }
            return true
        }
    }
}

object PlatformPreferences {
    private val fallbackStores = mutableMapOf<String, SharedPreferences>()
    fun get(name: String): SharedPreferences {
        PlatformNative.ensureInitialized()?.getSharedPreferences(name)?.let { return it }
        return fallbackStores.getOrPut(name) { InMemorySharedPreferences(name) }
    }
}

// -------------------------------------------------------------
// ActivityResultContracts & rememberLauncherForActivityResult
// -------------------------------------------------------------
abstract class ActivityResultContract<I, O>

class ManagedActivityResultLauncher<I, O>(
    val contract: ActivityResultContract<I, O>,
    val onResult: (O) -> Unit
) {
    @Suppress("UNCHECKED_CAST")
    fun launch(input: I) {
        val bridge = PlatformNative.ensureInitialized()
        when (contract) {
            is ActivityResultContracts.CreateDocument -> {
                val fileName = (input as? String)?.ifBlank { "zapisnyk_backup.zip" } ?: "zapisnyk_backup.zip"
                if (bridge != null && bridge.launchCreateDocument(contract.mimeType, fileName) { uri ->
                        (onResult as (Uri?) -> Unit).invoke(uri)
                    }) {
                    return
                }
                val uri = Uri("backup://$fileName")
                (onResult as (Uri?) -> Unit).invoke(uri)
            }
            is ActivityResultContracts.OpenDocument -> {
                val mimeTypes = (input as? Array<String>) ?: arrayOf("*/*")
                if (bridge != null && bridge.launchOpenDocument(mimeTypes) { uri ->
                        (onResult as (Uri?) -> Unit).invoke(uri)
                    }) {
                    return
                }
                PlatformDialogController.activeImportCallback = { uri ->
                    (onResult as (Uri?) -> Unit).invoke(uri)
                }
            }
            is ActivityResultContracts.GetContent -> {
                val mime = (input as? String) ?: "*/*"
                if (bridge != null && bridge.launchGetContent(mime) { uri ->
                        (onResult as (Uri?) -> Unit).invoke(uri)
                    }) {
                    return
                }
                Toast.makeText(LocalContext.current, "Выбор файла недоступен", Toast.LENGTH_SHORT).show()
            }
            is ActivityResultContracts.PickVisualMedia -> {
                if (bridge != null && bridge.launchGetContent("image/*") { uri ->
                        (onResult as (Uri?) -> Unit).invoke(uri)
                    }) {
                    return
                }
                Toast.makeText(LocalContext.current, "Выбор медиа недоступен", Toast.LENGTH_SHORT).show()
            }
            is ActivityResultContracts.PickMultipleVisualMedia -> {
                if (bridge != null && bridge.launchPickMultipleMedia { uris ->
                        (onResult as (List<Uri>) -> Unit).invoke(uris)
                    }) {
                    return
                }
                Toast.makeText(LocalContext.current, "Выбор медиафайлов недоступен", Toast.LENGTH_SHORT).show()
            }
            else -> {
                Toast.makeText(LocalContext.current, "Операция выбора файла", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

@Composable
fun <I, O> rememberLauncherForActivityResult(
    contract: ActivityResultContract<I, O>,
    onResult: (O) -> Unit
): ManagedActivityResultLauncher<I, O> {
    val currentOnResult by rememberUpdatedState(onResult)
    return remember(contract) {
        ManagedActivityResultLauncher(contract) { res -> currentOnResult(res) }
    }
}

class PickVisualMediaRequest(val mediaType: Any? = null)

object ActivityResultContracts {
    class PickMultipleVisualMedia(val maxItems: Int = 10) : ActivityResultContract<PickVisualMediaRequest, List<Uri>>()
    class PickVisualMedia : ActivityResultContract<PickVisualMediaRequest, Uri?>() {
        object ImageAndVideo
        object ImageOnly
        object VideoOnly
    }
    class GetContent : ActivityResultContract<String, Uri?>()
    class OpenDocument : ActivityResultContract<Array<String>, Uri?>()
    class CreateDocument(val mimeType: String = "*/*") : ActivityResultContract<String, Uri?>()
}

// -------------------------------------------------------------
// DatePickerDialog, TimePickerDialog, Export/Import & Toast Host
// -------------------------------------------------------------
data class ExportDialogState(
    val title: String,
    val fileName: String,
    val content: String,
    val isCsv: Boolean = false
)

object PlatformDialogController {
    var activeDatePicker by mutableStateOf<DatePickerDialog?>(null)
    var activeTimePicker by mutableStateOf<TimePickerDialog?>(null)
    var activeExportData by mutableStateOf<ExportDialogState?>(null)
    var activeImportCallback by mutableStateOf<((Uri?) -> Unit)?>(null)
    var activeToastMessage by mutableStateOf<String?>(null)
    var activeToastSeq by mutableIntStateOf(0)
}

class DatePickerDialog(
    val context: Any?,
    val listener: (Any?, Int, Int, Int) -> Unit,
    val year: Int,
    val month: Int,
    val dayOfMonth: Int
) {
    fun show() {
        PlatformDialogController.activeDatePicker = this
    }
}

class TimePickerDialog(
    val context: Any?,
    val listener: (Any?, Int, Int) -> Unit,
    val hourOfDay: Int,
    val minute: Int,
    val is24HourView: Boolean = true
) {
    fun show() {
        PlatformDialogController.activeTimePicker = this
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PlatformDialogHost() {
    val clipboardManager = LocalClipboardManager.current

    val dp = PlatformDialogController.activeDatePicker
    if (dp != null) {
        val initMillis = remember(dp) {
            Calendar.getInstance().apply {
                set(dp.year, dp.month, dp.dayOfMonth, 12, 0, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
        }
        val dpState = rememberDatePickerState(initialSelectedDateMillis = initMillis)
        androidx.compose.material3.DatePickerDialog(
            onDismissRequest = { PlatformDialogController.activeDatePicker = null },
            confirmButton = {
                TextButton(onClick = {
                    val ms = dpState.selectedDateMillis ?: initMillis
                    val c = Calendar.getInstance().apply { timeInMillis = ms }
                    dp.listener(null, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH))
                    PlatformDialogController.activeDatePicker = null
                }) {
                    Text("ОК")
                }
            },
            dismissButton = {
                TextButton(onClick = { PlatformDialogController.activeDatePicker = null }) {
                    Text("Отмена")
                }
            }
        ) {
            DatePicker(state = dpState)
        }
    }

    val tp = PlatformDialogController.activeTimePicker
    if (tp != null) {
        val tpState = rememberTimePickerState(
            initialHour = tp.hourOfDay,
            initialMinute = tp.minute,
            is24Hour = tp.is24HourView
        )
        AlertDialog(
            onDismissRequest = { PlatformDialogController.activeTimePicker = null },
            confirmButton = {
                TextButton(onClick = {
                    tp.listener(null, tpState.hour, tpState.minute)
                    PlatformDialogController.activeTimePicker = null
                }) {
                    Text("ОК")
                }
            },
            dismissButton = {
                TextButton(onClick = { PlatformDialogController.activeTimePicker = null }) {
                    Text("Отмена")
                }
            },
            text = {
                TimePicker(state = tpState)
            }
        )
    }

    // ДИАЛОГ ЭКСПОРТА РЕЗЕРВНОЙ КОПИИ / CSV (fallback для iOS)
    val exportData = PlatformDialogController.activeExportData
    if (exportData != null) {
        var copied by remember(exportData) { mutableStateOf(false) }
        LaunchedEffect(exportData) {
            try {
                clipboardManager.setText(AnnotatedString(exportData.content))
                ClipboardManager.instance.setPrimaryClip(ClipData.newPlainText("Backup", exportData.content))
                copied = true
            } catch (_: Throwable) {}
        }

        AlertDialog(
            onDismissRequest = { PlatformDialogController.activeExportData = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32))
                    Text(exportData.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        color = Color(0xFFE8F5E9),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text(
                                "Файл: ${exportData.fileName}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = Color(0xFF1B5E20)
                            )
                            Text(
                                if (exportData.isCsv) "✅ CSV-отчёт скопирован в буфер обмена!"
                                else "✅ Резервная копия сохранена в памяти приложения и скопирована в буфер обмена!",
                                fontSize = 11.sp,
                                color = Color(0xFF2E7D32),
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    OutlinedTextField(
                        value = exportData.content.take(4000),
                        onValueChange = {},
                        readOnly = true,
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 10.sp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        try {
                            clipboardManager.setText(AnnotatedString(exportData.content))
                            ClipboardManager.instance.setPrimaryClip(ClipData.newPlainText("Backup", exportData.content))
                            copied = true
                            Toast.makeText(LocalContext.current, "Скопировано в буфер обмена!", Toast.LENGTH_SHORT).show()
                        } catch (_: Throwable) {}
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                ) {
                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(if (copied) "Скопировано в буфер" else "Скопировать", fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { PlatformDialogController.activeExportData = null }) {
                    Text("Закрыть")
                }
            }
        )
    }

    // ДИАЛОГ ИМПОРТА РЕЗЕРВНОЙ КОПИИ (fallback, если не подключён Platform.android.kt)
    val importCb = PlatformDialogController.activeImportCallback
    if (importCb != null) {
        var manualJson by remember { mutableStateOf("") }
        val savedList = PlatformVirtualFs.savedBackups

        AlertDialog(
            onDismissRequest = { PlatformDialogController.activeImportCallback = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.Restore, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Text("Импорт резервной копии", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (savedList.isNotEmpty()) {
                        Text(
                            "1. Сохранённые резервные копии (${savedList.size}):",
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                        savedList.forEach { rec ->
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            rec.fileName,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                        Text(
                                            "Размер: ${rec.jsonContent.length} байт",
                                            fontSize = 10.sp,
                                            color = Color.Gray
                                        )
                                    }
                                    Spacer(Modifier.width(8.dp))
                                    Button(
                                        onClick = {
                                            val uriKey = "backup://${rec.fileName}"
                                            PlatformVirtualFs.putBytes(uriKey, rec.jsonContent.encodeToByteArray())
                                            PlatformDialogController.activeExportData = null
                                            val cb = PlatformDialogController.activeImportCallback
                                            PlatformDialogController.activeImportCallback = null
                                            cb?.invoke(Uri(uriKey))
                                        },
                                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                                    ) {
                                        Text("Восстановить", fontSize = 11.sp)
                                    }
                                }
                            }
                        }
                        HorizontalDivider(Modifier.padding(vertical = 4.dp))
                    }

                    Text(
                        if (savedList.isNotEmpty()) "2. Или вставьте JSON резервной копии:" else "Вставьте JSON резервной копии из буфера обмена:",
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )

                    OutlinedButton(
                        onClick = {
                            val sysText = try { clipboardManager.getText()?.text } catch (_: Throwable) { null }
                            val fallbackText = ClipboardManager.instance.primaryClip?.getItemAt(0)?.coerceToText(null)?.toString()
                            val pasted = sysText?.takeIf { it.isNotBlank() } ?: fallbackText ?: ""
                            if (pasted.isNotBlank()) {
                                manualJson = pasted.trim()
                            } else {
                                Toast.makeText(LocalContext.current, "Буфер обмена пуст", Toast.LENGTH_SHORT).show()
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.ContentPaste, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Вставить из буфера обмена", fontSize = 12.sp)
                    }

                    OutlinedTextField(
                        value = manualJson,
                        onValueChange = { manualJson = it },
                        label = { Text("JSON данные резервной копии") },
                        placeholder = { Text("{\"notes\":[...],\"finances\":[...]}") },
                        maxLines = 8,
                        modifier = Modifier.fillMaxWidth(),
                        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 11.sp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clean = manualJson.trim()
                        if (clean.isNotBlank()) {
                            val uriKey = "backup://manual_import.json"
                            PlatformVirtualFs.putBytes(uriKey, clean.encodeToByteArray())
                            PlatformDialogController.activeExportData = null
                            val cb = PlatformDialogController.activeImportCallback
                            PlatformDialogController.activeImportCallback = null
                            cb?.invoke(Uri(uriKey))
                        }
                    },
                    enabled = manualJson.isNotBlank()
                ) {
                    Icon(Icons.Default.CloudDownload, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Восстановить из JSON", fontSize = 12.sp)
                }
            },
            dismissButton = {
                TextButton(onClick = { PlatformDialogController.activeImportCallback = null }) {
                    Text("Отмена")
                }
            }
        )
    }

    // ВСПЛЫВАЮЩЕЕ УВЕДОМЛЕНИЕ TOAST ПОВЕРХ ЭКРАНА
    val toastMsg = PlatformDialogController.activeToastMessage
    val toastSeq = PlatformDialogController.activeToastSeq
    if (!toastMsg.isNullOrBlank()) {
        LaunchedEffect(toastSeq) {
            delay(3200)
            if (PlatformDialogController.activeToastSeq == toastSeq) {
                PlatformDialogController.activeToastMessage = null
            }
        }
        Box(
            modifier = Modifier.fillMaxSize().padding(bottom = 84.dp, start = 16.dp, end = 16.dp),
            contentAlignment = Alignment.BottomCenter
        ) {
            Surface(
                color = Color(0xEE1E293B),
                contentColor = Color.White,
                shape = RoundedCornerShape(12.dp),
                shadowElevation = 8.dp,
                modifier = Modifier.clickable { PlatformDialogController.activeToastMessage = null }
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(Icons.Default.Info, contentDescription = null, tint = Color(0xFF38BDF8), modifier = Modifier.size(18.dp))
                    Text(toastMsg, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, color = Color.White)
                }
            }
        }
    }
}

data class Date(val time: Long = System.currentTimeMillis()) : Comparable<Date> {
    override fun compareTo(other: Date): Int = time.compareTo(other.time)
}

class Calendar : Cloneable {
    var firstDayOfWeek: Int = MONDAY

    private val fields = mutableMapOf<Int, Int>()
    private var _timeInMillis: Long = 0L

    var timeInMillis: Long
        get() = _timeInMillis
        set(value) {
            _timeInMillis = value
            syncFromMillis(value)
        }

    init {
        timeInMillis = System.currentTimeMillis()
    }

    private fun floorDivLong(a: Long, b: Long): Long {
        var r = a / b
        if ((a xor b) < 0L && (r * b != a)) r--
        return r
    }

    private fun floorModLong(a: Long, b: Long): Long {
        return a - floorDivLong(a, b) * b
    }

    private fun isLeap(y: Int): Boolean = (y % 4 == 0 && y % 100 != 0) || (y % 400 == 0)

    private fun daysInMonth(y: Int, m0: Int): Int {
        return when (((m0 % 12) + 12) % 12) {
            0, 2, 4, 6, 7, 9, 11 -> 31
            3, 5, 8, 10 -> 30
            1 -> if (isLeap(y)) 29 else 28
            else -> 30
        }
    }

    private fun daysFromCivil(y: Int, m1: Int, d: Int): Long {
        val yr = (if (m1 <= 2) y - 1 else y).toLong()
        val era = (if (yr >= 0L) yr else yr - 399L) / 400L
        val yoe = yr - era * 400L
        val mp = (m1 + (if (m1 > 2) -3 else 9)).toLong()
        val doy = (153L * mp + 2L) / 5L + d.toLong() - 1L
        val doe = yoe * 365L + yoe / 4L - yoe / 100L + doy
        return era * 146097L + doe - 719468L
    }

    private fun civilFromDays(z0: Long): Triple<Int, Int, Int> {
        val z = z0 + 719468L
        val era = (if (z >= 0L) z else z - 146096L) / 146097L
        val doe = z - era * 146097L
        val yoe = (doe - doe / 1460L + doe / 36524L - doe / 146096L) / 365L
        val y = yoe + era * 400L
        val doy = doe - (365L * yoe + yoe / 4L - yoe / 100L)
        val mp = (5L * doy + 2L) / 153L
        val d = doy - (153L * mp + 2L) / 5L + 1L
        val m = mp + (if (mp < 10L) 3L else -9L)
        val finalY = y + (if (m <= 2L) 1L else 0L)
        return Triple(finalY.toInt(), m.toInt(), d.toInt())
    }

    private fun syncFromMillis(ms: Long) {
        val epochDay = floorDivLong(ms, 86400000L)
        val dayMs = floorModLong(ms, 86400000L).toInt()

        val (y, m1, d) = civilFromDays(epochDay)
        val m0 = m1 - 1

        val h = dayMs / 3600000
        val rem1 = dayMs % 3600000
        val min = rem1 / 60000
        val rem2 = rem1 % 60000
        val s = rem2 / 1000
        val millis = rem2 % 1000

        val dow0 = floorModLong(epochDay + 4L, 7L).toInt()
        val dow = dow0 + 1

        val jan1EpochDay = daysFromCivil(y, 1, 1)
        val doy = (epochDay - jan1EpochDay).toInt() + 1
        val woy = ((doy - 1) / 7) + 1

        fields[YEAR] = y
        fields[MONTH] = m0
        fields[DAY_OF_MONTH] = d
        fields[DAY_OF_WEEK] = dow
        fields[DAY_OF_YEAR] = doy
        fields[WEEK_OF_YEAR] = woy
        fields[HOUR_OF_DAY] = h
        fields[MINUTE] = min
        fields[SECOND] = s
        fields[MILLISECOND] = millis
    }

    private fun syncFromFields() {
        var y = fields[YEAR] ?: 2026
        var m0 = fields[MONTH] ?: 0
        val d = fields[DAY_OF_MONTH] ?: 1
        val h = fields[HOUR_OF_DAY] ?: 0
        val min = fields[MINUTE] ?: 0
        val s = fields[SECOND] ?: 0
        val millis = fields[MILLISECOND] ?: 0

        if (m0 < 0 || m0 >= 12) {
            val totalM = y * 12 + m0
            y = if (totalM >= 0) totalM / 12 else (totalM - 11) / 12
            m0 = ((totalM % 12) + 12) % 12
        }

        val epochDay = daysFromCivil(y, m0 + 1, 1) + (d - 1).toLong()
        val dayMs = h.toLong() * 3600000L + min.toLong() * 60000L + s.toLong() * 1000L + millis.toLong()
        _timeInMillis = epochDay * 86400000L + dayMs
        syncFromMillis(_timeInMillis)
    }

    fun get(field: Int): Int = fields[field] ?: 0

    fun set(field: Int, value: Int) {
        if (field == DAY_OF_YEAR) {
            fields[MONTH] = 0
            fields[DAY_OF_MONTH] = value
        } else {
            fields[field] = value
        }
        syncFromFields()
    }

    fun set(y: Int, m: Int, d: Int) {
        fields[YEAR] = y
        fields[MONTH] = m
        fields[DAY_OF_MONTH] = d
        syncFromFields()
    }

    fun set(y: Int, m: Int, d: Int, h: Int, min: Int, s: Int = 0) {
        fields[YEAR] = y
        fields[MONTH] = m
        fields[DAY_OF_MONTH] = d
        fields[HOUR_OF_DAY] = h
        fields[MINUTE] = min
        fields[SECOND] = s
        syncFromFields()
    }

    fun add(field: Int, amount: Int) {
        when (field) {
            YEAR -> {
                val newY = get(YEAR) + amount
                val m0 = get(MONTH)
                val maxD = daysInMonth(newY, m0)
                fields[YEAR] = newY
                if (get(DAY_OF_MONTH) > maxD) fields[DAY_OF_MONTH] = maxD
                syncFromFields()
            }
            MONTH -> {
                val totalM = get(YEAR) * 12 + get(MONTH) + amount
                val newY = if (totalM >= 0) totalM / 12 else (totalM - 11) / 12
                val newM = ((totalM % 12) + 12) % 12
                val maxD = daysInMonth(newY, newM)
                fields[YEAR] = newY
                fields[MONTH] = newM
                if (get(DAY_OF_MONTH) > maxD) fields[DAY_OF_MONTH] = maxD
                syncFromFields()
            }
            WEEK_OF_YEAR -> {
                timeInMillis = _timeInMillis + amount.toLong() * 7L * 86400000L
            }
            DAY_OF_MONTH, DAY_OF_YEAR, DAY_OF_WEEK -> {
                timeInMillis = _timeInMillis + amount.toLong() * 86400000L
            }
            HOUR_OF_DAY -> {
                timeInMillis = _timeInMillis + amount.toLong() * 3600000L
            }
            MINUTE -> {
                timeInMillis = _timeInMillis + amount.toLong() * 60000L
            }
            SECOND -> {
                timeInMillis = _timeInMillis + amount.toLong() * 1000L
            }
            MILLISECOND -> {
                timeInMillis = _timeInMillis + amount.toLong()
            }
            else -> {
                fields[field] = get(field) + amount
                syncFromFields()
            }
        }
    }

    fun getActualMaximum(field: Int): Int = when (field) {
        DAY_OF_MONTH -> daysInMonth(get(YEAR), get(MONTH))
        DAY_OF_YEAR -> if (isLeap(get(YEAR))) 366 else 365
        else -> 31
    }

    var time: Date
        get() = Date(_timeInMillis)
        set(value) { timeInMillis = value.time }

    fun clone(): Any {
        val c = Calendar()
        c.firstDayOfWeek = this.firstDayOfWeek
        c.timeInMillis = this._timeInMillis
        return c
    }

    companion object {
        const val YEAR = 1
        const val MONTH = 2
        const val WEEK_OF_YEAR = 3
        const val DAY_OF_MONTH = 5
        const val DAY_OF_YEAR = 6
        const val DAY_OF_WEEK = 7
        const val HOUR_OF_DAY = 11
        const val MINUTE = 12
        const val SECOND = 13
        const val MILLISECOND = 14

        const val JANUARY = 0
        const val DECEMBER = 11
        const val SUNDAY = 1
        const val MONDAY = 2
        const val SATURDAY = 7

        fun getInstance(): Calendar = Calendar()
    }
}

class SimpleDateFormat(val pattern: String, val locale: Any? = null) {
    private val monthNamesNom = arrayOf("Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь")
    private val monthNamesGen = arrayOf("января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря")
    private val dayOfWeekNames = arrayOf("воскресенье", "понедельник", "вторник", "среда", "четверг", "пятница", "суббота")

    fun format(date: Any?): String {
        val cal = when (date) {
            is Calendar -> date
            is Date -> Calendar.getInstance().apply { timeInMillis = date.time }
            is Long -> Calendar.getInstance().apply { timeInMillis = date }
            else -> Calendar.getInstance()
        }
        val m = cal.get(Calendar.MONTH).coerceIn(0, 11)
        val y = cal.get(Calendar.YEAR)
        val d = cal.get(Calendar.DAY_OF_MONTH).coerceIn(1, 31)
        val dowIdx = (cal.get(Calendar.DAY_OF_WEEK) - 1).coerceIn(0, 6)
        val dd = d.toString().padStart(2, '0')
        val mm = (m + 1).toString().padStart(2, '0')
        return when {
            pattern.contains("EEEE") -> "$d ${monthNamesGen[m]} $y, ${dayOfWeekNames[dowIdx]}"
            pattern.contains("LLLL yyyy") || pattern.contains("MMMM yyyy") -> "${monthNamesNom[m]} $y"
            pattern.contains("dd MMMM yyyy") -> "$dd ${monthNamesGen[m]} $y"
            pattern.contains("d MMMM yyyy") -> "$d ${monthNamesGen[m]} $y"
            pattern.contains("dd MMMM") -> "$dd ${monthNamesGen[m]}"
            pattern.contains("d MMMM") -> "$d ${monthNamesGen[m]}"
            pattern.contains("LLLL") || pattern.contains("MMMM") -> monthNamesNom[m]
            pattern.contains("MMM") -> monthNamesNom[m].take(3)
            pattern == "yyyyMMdd_HHmm" -> {
                val hh = cal.get(Calendar.HOUR_OF_DAY).toString().padStart(2, '0')
                val min = cal.get(Calendar.MINUTE).toString().padStart(2, '0')
                "${y}${mm}${dd}_${hh}${min}"
            }
            pattern == "yyyyMMdd" -> "$y$mm$dd"
            pattern.contains("dd.MM.yyyy") -> "$dd.$mm.$y"
            pattern.contains("dd.MM.yy") -> "$dd.$mm.${(y % 100).toString().padStart(2, '0')}"
            pattern.contains("dd.MM") -> "$dd.$mm"
            else -> "$dd.$mm.$y"
        }
    }

    fun parse(text: String?): Date? {
        if (text.isNullOrBlank()) return null
        val clean = text.trim()
        return try {
            if (clean.contains(".")) {
                val parts = clean.split(".")
                if (parts.size >= 3) {
                    val d = parts[0].toInt()
                    val m = parts[1].toInt() - 1
                    val y = parts[2].let { if (it.length == 2) 2000 + it.toInt() else it.toInt() }
                    val c = Calendar.getInstance().apply {
                        set(y, m, d, 0, 0, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    return Date(c.timeInMillis)
                }
            } else if (clean.contains("-")) {
                val parts = clean.split("-")
                if (parts.size >= 3) {
                    val y = parts[0].toInt()
                    val m = parts[1].toInt() - 1
                    val d = parts[2].take(2).toInt()
                    val c = Calendar.getInstance().apply {
                        set(y, m, d, 0, 0, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    return Date(c.timeInMillis)
                }
            } else if (clean.length == 8 && clean.all { it.isDigit() }) {
                val y = clean.substring(0, 4).toInt()
                val m = clean.substring(4, 6).toInt() - 1
                val d = clean.substring(6, 8).toInt()
                val c = Calendar.getInstance().apply {
                    set(y, m, d, 0, 0, 0)
                    set(Calendar.MILLISECOND, 0)
                }
                return Date(c.timeInMillis)
            }
            null
        } catch (_: Throwable) {
            null
        }
    }
}

class Locale(val lang: String, val country: String = "") {
    companion object {
        val US = Locale("en", "US")
        val ROOT = Locale("")
        val ENGLISH = Locale("en")
        val GERMAN = Locale("de")
        fun getDefault(): Locale = Locale("ru", "RU")
    }
}

private fun formatWithThousands(intStr: String): String {
    val isNeg = intStr.startsWith("-")
    val digits = if (isNeg) intStr.substring(1) else intStr
    val sb = StringBuilder()
    for (i in digits.indices) {
        if (i > 0 && (digits.length - i) % 3 == 0) sb.append(',')
        sb.append(digits[i])
    }
    return if (isNeg) "-$sb" else sb.toString()
}

fun String.Companion.format(locale: Any?, format: String, vararg args: Any?): String {
    if (args.isEmpty()) return format
    if (format == "%02d:%02d" && args.size >= 2) {
        val h = (args[0] as? Number)?.toInt() ?: 0
        val m = (args[1] as? Number)?.toInt() ?: 0
        return "${h.toString().padStart(2, '0')}:${m.toString().padStart(2, '0')}"
    }
    if (format == "%02d") {
        val v = (args[0] as? Number)?.toInt() ?: 0
        return v.toString().padStart(2, '0')
    }
    val arg = args[0] ?: ""
    if (arg is Number) {
        val d = arg.toDouble()
        val useComma = format.contains(",")
        return when {
            format.contains(".0f") || format.contains("%d") -> {
                val s = kotlin.math.round(d).toLong().toString()
                if (useComma) formatWithThousands(s) else s
            }
            format.contains(".1f") -> {
                val r = kotlin.math.round(d * 10.0) / 10.0
                val parts = r.toString().split(".")
                val intPart = if (useComma) formatWithThousands(parts[0]) else parts[0]
                val dec = (parts.getOrNull(1) ?: "0").take(1)
                "$intPart.$dec"
            }
            format.contains(".2f") -> {
                val r = kotlin.math.round(d * 100.0) / 100.0
                val parts = r.toString().split(".")
                val intPart = if (useComma) formatWithThousands(parts[0]) else parts[0]
                val dec = (parts.getOrNull(1) ?: "").padEnd(2, '0').take(2)
                "$intPart.$dec"
            }
            else -> if (d == d.toLong().toDouble()) d.toLong().toString() else d.toString()
        }
    }
    return arg.toString()
}

fun String.Companion.format(format: String, vararg args: Any?): String {
    return format(null, format, *args)
}

// -------------------------------------------------------------
// Navigation, Room, & Persistent Reactive Database
// -------------------------------------------------------------
class NavController {
    private val backStack = mutableStateListOf("main")
    val currentRoute: String
        get() = backStack.lastOrNull() ?: "main"

    fun navigate(route: String) {
        backStack.add(route)
    }

    fun popBackStack(): Boolean {
        if (backStack.size > 1) {
            backStack.removeAt(backStack.size - 1)
            return true
        }
        return false
    }
}
class NavType

annotation class SuppressLint(vararg val value: String)
annotation class Entity(val tableName: String = "")
annotation class PrimaryKey(val autoGenerate: Boolean = false)
annotation class Dao
annotation class Query(val value: String)
annotation class Insert(val onConflict: Int = 0)
annotation class Update
annotation class Delete
annotation class Database(
    val entities: Array<kotlin.reflect.KClass<*>> = [],
    val version: Int = 1,
    val exportSchema: Boolean = false
)

object OnConflictStrategy {
    const val REPLACE = 1
    const val ABORT = 2
}

class SupportSQLiteDatabase {
    fun execSQL(sql: String) {}
}

open class Migration(val startVersion: Int, val endVersion: Int) {
    open fun migrate(db: SupportSQLiteDatabase) {}
}

abstract class RoomDatabase

object Room {
    fun <T : Any> databaseBuilder(context: Any?, klass: Any?, name: String): Builder<T> = Builder()
    class Builder<T> {
        fun addMigrations(vararg migrations: Migration): Builder<T> = this
        fun fallbackToDestructiveMigration(): Builder<T> = this
        fun fallbackToDestructiveMigrationOnDowngrade(): Builder<T> = this
        fun build(): AppDatabase = object : AppDatabase() {
            override fun diaryDao(): DiaryDao = InMemoryDiaryDaoInstance
        }
    }
}

object InMemoryDiaryDaoInstance : DiaryDao {
    private const val STORE_NAME = "zapisnyk_kmp_dao_v1"
    private val notesFlow = MutableStateFlow<List<DiaryNote>>(emptyList())
    private val financesFlow = MutableStateFlow<List<DiaryFinance>>(emptyList())
    private val debtsFlow = MutableStateFlow<List<DiaryDebt>>(emptyList())
    private val expectedFlow = MutableStateFlow<List<ExpectedFinance>>(emptyList())
    private val tasksFlow = MutableStateFlow<List<DiaryTask>>(emptyList())
    private val shiftFlow = MutableStateFlow<ShiftConfig?>(null)
    private var loadedFromDisk = false

    fun reloadFromStorage() {
        try {
            val sp = PlatformPreferences.get(STORE_NAME)
            val notesJson = sp.getString("notes", null)
            val financesJson = sp.getString("finances", null)
            val debtsJson = sp.getString("debts", null)
            val expectedJson = sp.getString("expected", null)
            val tasksJson = sp.getString("tasks", null)
            val shiftJson = sp.getString("shift", null)

            var hasAnyStored = false
            if (!notesJson.isNullOrBlank()) {
                val parsed = (MiniJson.parse(notesJson) as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(MiniJson::mapToDiaryNote) }
                if (parsed != null) {
                    notesFlow.value = parsed.sortedByDescending { it.date }
                    if (parsed.isNotEmpty()) hasAnyStored = true
                }
            }
            if (!financesJson.isNullOrBlank()) {
                val parsed = (MiniJson.parse(financesJson) as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(MiniJson::mapToDiaryFinance) }
                if (parsed != null) {
                    financesFlow.value = parsed.sortedByDescending { it.date }
                    if (parsed.isNotEmpty()) hasAnyStored = true
                }
            }
            if (!debtsJson.isNullOrBlank()) {
                val parsed = (MiniJson.parse(debtsJson) as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(MiniJson::mapToDiaryDebt) }
                if (parsed != null) {
                    debtsFlow.value = parsed.sortedBy { it.dueDate }
                    if (parsed.isNotEmpty()) hasAnyStored = true
                }
            }
            if (!expectedJson.isNullOrBlank()) {
                val parsed = (MiniJson.parse(expectedJson) as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(MiniJson::mapToExpectedFinance) }
                if (parsed != null) {
                    expectedFlow.value = parsed.sortedBy { it.dayOfMonth }
                    if (parsed.isNotEmpty()) hasAnyStored = true
                }
            }
            if (!tasksJson.isNullOrBlank()) {
                val parsed = (MiniJson.parse(tasksJson) as? List<*>)?.mapNotNull { (it as? Map<*, *>)?.let(MiniJson::mapToDiaryTask) }
                if (parsed != null) {
                    tasksFlow.value = parsed
                    if (parsed.isNotEmpty()) hasAnyStored = true
                }
            }
            if (!shiftJson.isNullOrBlank() && shiftJson != "null") {
                val parsed = (MiniJson.parse(shiftJson) as? Map<*, *>)?.let(MiniJson::mapToShiftConfig)
                if (parsed != null) {
                    shiftFlow.value = parsed
                    hasAnyStored = true
                }
            }

            if (!hasAnyStored && !sp.getBoolean("legacy_room_migrated", false)) {
                val legacy = PlatformNative.ensureInitialized()?.readLegacyRoomDatabase()
                if (legacy != null) {
                    legacy.notes?.takeIf { it.isNotEmpty() }?.let { notesFlow.value = it.sortedByDescending { n -> n.date } }
                    legacy.finances?.takeIf { it.isNotEmpty() }?.let { financesFlow.value = it.sortedByDescending { f -> f.date } }
                    legacy.debts?.takeIf { it.isNotEmpty() }?.let { debtsFlow.value = it.sortedBy { d -> d.dueDate } }
                    legacy.expectedFinances?.takeIf { it.isNotEmpty() }?.let { expectedFlow.value = it.sortedBy { e -> e.dayOfMonth } }
                    legacy.tasks?.takeIf { it.isNotEmpty() }?.let { tasksFlow.value = it }
                    legacy.shiftConfig?.let { shiftFlow.value = it }
                    persistAll()
                    sp.edit().putBoolean("legacy_room_migrated", true).apply()
                }
            }
            loadedFromDisk = true
        } catch (_: Throwable) {}
    }

    private fun ensureLoaded() {
        if (!loadedFromDisk) {
            reloadFromStorage()
        }
    }

    private fun persistNotes() {
        try { PlatformPreferences.get(STORE_NAME).edit().putString("notes", MiniJson.stringify(notesFlow.value)).apply() } catch (_: Throwable) {}
    }
    private fun persistFinances() {
        try { PlatformPreferences.get(STORE_NAME).edit().putString("finances", MiniJson.stringify(financesFlow.value)).apply() } catch (_: Throwable) {}
    }
    private fun persistDebts() {
        try { PlatformPreferences.get(STORE_NAME).edit().putString("debts", MiniJson.stringify(debtsFlow.value)).apply() } catch (_: Throwable) {}
    }
    private fun persistExpected() {
        try { PlatformPreferences.get(STORE_NAME).edit().putString("expected", MiniJson.stringify(expectedFlow.value)).apply() } catch (_: Throwable) {}
    }
    private fun persistTasks() {
        try { PlatformPreferences.get(STORE_NAME).edit().putString("tasks", MiniJson.stringify(tasksFlow.value)).apply() } catch (_: Throwable) {}
    }
    private fun persistShift() {
        try { PlatformPreferences.get(STORE_NAME).edit().putString("shift", MiniJson.stringify(shiftFlow.value)).apply() } catch (_: Throwable) {}
    }
    private fun persistAll() {
        persistNotes()
        persistFinances()
        persistDebts()
        persistExpected()
        persistTasks()
        persistShift()
    }

    override fun getAllNotes(): Flow<List<DiaryNote>> { ensureLoaded(); return notesFlow }
    override suspend fun getAllNotesDirect(): List<DiaryNote> { ensureLoaded(); return notesFlow.value }
    override suspend fun getAllDebtsDirect(): List<DiaryDebt> { ensureLoaded(); return debtsFlow.value }
    override suspend fun getAllExpectedFinancesDirect(): List<ExpectedFinance> { ensureLoaded(); return expectedFlow.value }
    override suspend fun getShiftConfigDirect(): ShiftConfig? { ensureLoaded(); return shiftFlow.value }
    override suspend fun getNoteByDateSync(date: Long): DiaryNote? { ensureLoaded(); return notesFlow.value.find { it.date == date } }

    override suspend fun insertNote(note: DiaryNote) {
        ensureLoaded()
        notesFlow.value = (notesFlow.value.filterNot { it.date == note.date } + note).sortedByDescending { it.date }
        persistNotes()
    }
    override suspend fun deleteNote(note: DiaryNote) {
        ensureLoaded()
        notesFlow.value = notesFlow.value.filterNot { it.date == note.date }
        persistNotes()
    }
    override suspend fun deleteNoteByDate(date: Long) {
        ensureLoaded()
        notesFlow.value = notesFlow.value.filterNot { it.date == date }
        persistNotes()
    }
    override suspend fun deleteFinanceByDate(date: Long) {
        ensureLoaded()
        financesFlow.value = financesFlow.value.filterNot { it.date == date }
        persistFinances()
    }
    override fun getShiftConfig(): Flow<ShiftConfig?> { ensureLoaded(); return shiftFlow }
    override suspend fun saveShiftConfig(config: ShiftConfig) {
        ensureLoaded()
        shiftFlow.value = config
        persistShift()
    }
    override fun getAllTasks(): Flow<List<DiaryTask>> { ensureLoaded(); return tasksFlow }
    override suspend fun saveTask(task: DiaryTask) {
        ensureLoaded()
        val id = if (task.id == 0) (tasksFlow.value.maxOfOrNull { it.id } ?: 0) + 1 else task.id
        val item = task.copy(id = id)
        tasksFlow.value = tasksFlow.value.filterNot { it.id == id } + item
        persistTasks()
    }
    override suspend fun updateTask(task: DiaryTask) {
        ensureLoaded()
        tasksFlow.value = tasksFlow.value.map { if (it.id == task.id) task else it }
        persistTasks()
    }
    override suspend fun deleteTask(task: DiaryTask) {
        ensureLoaded()
        tasksFlow.value = tasksFlow.value.filterNot { it.id == task.id }
        persistTasks()
    }
    override fun getAllFinances(): Flow<List<DiaryFinance>> { ensureLoaded(); return financesFlow }
    override suspend fun saveFinance(finance: DiaryFinance) {
        ensureLoaded()
        financesFlow.value = (financesFlow.value.filterNot { it.date == finance.date } + finance).sortedByDescending { it.date }
        persistFinances()
    }
    override fun getAllDebts(): Flow<List<DiaryDebt>> { ensureLoaded(); return debtsFlow }
    override suspend fun saveDebt(debt: DiaryDebt) {
        ensureLoaded()
        val id = if (debt.id == 0) (debtsFlow.value.maxOfOrNull { it.id } ?: 0) + 1 else debt.id
        val item = debt.copy(id = id)
        debtsFlow.value = (debtsFlow.value.filterNot { it.id == id } + item).sortedBy { it.dueDate }
        persistDebts()
    }
    override suspend fun updateDebt(debt: DiaryDebt) {
        ensureLoaded()
        debtsFlow.value = debtsFlow.value.map { if (it.id == debt.id) debt else it }
        persistDebts()
    }
    override suspend fun deleteDebt(debt: DiaryDebt) {
        ensureLoaded()
        debtsFlow.value = debtsFlow.value.filterNot { it.id == debt.id }
        persistDebts()
    }
    override fun getAllExpectedFinances(): Flow<List<ExpectedFinance>> { ensureLoaded(); return expectedFlow }
    override suspend fun saveExpectedFinance(item: ExpectedFinance) {
        ensureLoaded()
        val id = if (item.id == 0) (expectedFlow.value.maxOfOrNull { it.id } ?: 0) + 1 else item.id
        val copy = item.copy(id = id)
        expectedFlow.value = (expectedFlow.value.filterNot { it.id == id } + copy).sortedBy { it.dayOfMonth }
        persistExpected()
    }
    override suspend fun deleteExpectedFinance(item: ExpectedFinance) {
        ensureLoaded()
        expectedFlow.value = expectedFlow.value.filterNot { it.id == item.id }
        persistExpected()
    }
}

// -------------------------------------------------------------
// BiometricPrompt, Intents, Uris, Media & UI Helpers
// -------------------------------------------------------------
class FragmentActivity
object ContextCompat {
    fun getMainExecutor(act: Any?): Any = Any()
    fun checkSelfPermission(ctx: Any?, perm: String): Int = 0
}
class BiometricPrompt(act: Any?, exec: Any?, val callback: Any?) {
    open class AuthenticationCallback {
        open fun onAuthenticationSucceeded(res: AuthenticationResult) {}
    }
    class AuthenticationResult
    class PromptInfo {
        class Builder {
            fun setTitle(t: String) = this
            fun setNegativeButtonText(t: String) = this
            fun build() = PromptInfo()
        }
    }
    fun authenticate(info: Any?) {
        (callback as? AuthenticationCallback)?.onAuthenticationSucceeded(AuthenticationResult())
    }
}

class Uri(val raw: String = "") {
    override fun toString(): String = raw
    companion object {
        fun parse(s: String): Uri = Uri(s)
    }
}

class Intent(val action: String = "") {
    constructor(ctx: Any?, cls: Any?) : this("")
    var type: String? = null
    var dataUri: Uri? = null
    var flags: Int = 0
    val extras = mutableMapOf<String, Any?>()
    fun putExtra(key: String, value: Any?): Intent {
        extras[key] = value
        return this
    }
    fun addFlags(flags: Int): Intent {
        this.flags = this.flags or flags
        return this
    }
    fun setDataAndType(uri: Uri?, type: String?): Intent {
        this.dataUri = uri
        this.type = type
        return this
    }
    fun getStringExtra(key: String): String? = extras[key]?.toString()
    fun getIntExtra(key: String, def: Int): Int = (extras[key] as? Number)?.toInt() ?: def

    companion object {
        const val ACTION_VIEW = "android.intent.action.VIEW"
        const val ACTION_SEND = "android.intent.action.SEND"
        const val EXTRA_TEXT = "android.intent.extra.TEXT"
        const val EXTRA_STREAM = "android.intent.extra.STREAM"
        const val FLAG_ACTIVITY_NEW_TASK = 1
        const val FLAG_ACTIVITY_CLEAR_TOP = 2
        const val FLAG_GRANT_READ_URI_PERMISSION = 4

        fun createChooser(target: Intent, title: CharSequence?): Intent = target
    }
}

object FileProvider {
    fun getUriForFile(context: Any?, authority: String, file: File): Uri = Uri(file.absolutePath)
}

class MimeTypeMap {
    companion object {
        fun getSingleton(): MimeTypeMap = MimeTypeMap()
    }
    fun getMimeTypeFromExtension(ext: String?): String? = when (ext?.lowercase()) {
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "mp4" -> "video/mp4"
        "mov" -> "video/quicktime"
        "mkv" -> "video/x-matroska"
        "webm" -> "video/webm"
        else -> "video/mp4"
    }
    fun getExtensionFromMimeType(mime: String?): String? = when (mime?.lowercase()) {
        "image/png" -> "png"
        "image/webp" -> "webp"
        "image/gif" -> "gif"
        "video/mp4" -> "mp4"
        "video/quicktime" -> "mov"
        "video/x-matroska" -> "mkv"
        "video/webm" -> "webm"
        "video/3gpp" -> "3gp"
        else -> "jpg"
    }
}

object AlarmClock {
    const val ACTION_SET_ALARM = "android.intent.action.SET_ALARM"
    const val EXTRA_HOUR = "android.intent.extra.alarm.HOUR"
    const val EXTRA_MINUTES = "android.intent.extra.alarm.MINUTES"
    const val EXTRA_MESSAGE = "android.intent.extra.alarm.MESSAGE"
    const val EXTRA_SKIP_UI = "android.intent.extra.alarm.SKIP_UI"
}

object Toast {
    const val LENGTH_SHORT = 0
    const val LENGTH_LONG = 1
    fun makeText(ctx: Any?, text: String, len: Int = 0): ToastInstance = ToastInstance(text, len == LENGTH_LONG)
    class ToastInstance(val text: String, val isLong: Boolean = false) {
        fun show() {
            println("[Toast]: $text")
            val bridge = PlatformNative.ensureInitialized()
            if (bridge != null) {
                bridge.showToast(text, isLong)
            } else {
                PlatformDialogController.activeToastMessage = text
                PlatformDialogController.activeToastSeq++
            }
        }
    }
}

object Log {
    fun d(tag: String, msg: String) = println("[$tag] $msg")
    fun i(tag: String, msg: String) = println("[$tag] $msg")
    fun w(tag: String, msg: String, tr: Throwable? = null) = println("[$tag WARN] $msg ${tr?.message ?: ""}")
    fun e(tag: String, msg: String, tr: Throwable? = null) = println("[$tag ERROR] $msg ${tr?.message ?: ""}")
}

fun parseHexColor(hex: String, defaultColor: Color = Color(0xFF2563EB)): Color {
    return try {
        val clean = hex.removePrefix("#")
        val parsed = clean.toLong(16)
        if (clean.length <= 6) Color(0xFF000000 or parsed) else Color(parsed)
    } catch (_: Exception) {
        defaultColor
    }
}

fun parseHexColorLong(hex: String): Long {
    return try {
        val clean = hex.removePrefix("#")
        val parsed = clean.toLong(16)
        if (clean.length <= 6) 0xFF000000 or parsed else parsed
    } catch (_: Exception) {
        0xFF2563EBL
    }
}

object BitmapFactory {
    fun decodeStream(stream: Any?): ImageBitmap? {
        val inp = stream as? InputStream ?: return null
        return PlatformNative.ensureInitialized()?.decodeBitmapStream(inp)
    }
    fun decodeFile(path: String?): ImageBitmap? {
        if (path.isNullOrBlank()) return null
        return PlatformNative.ensureInitialized()?.decodeBitmapFile(path)
    }
}

object ThumbnailUtils {
    fun createVideoThumbnail(path: String, kind: Int): Bitmap? = null
}

class ClipData(val text: String = "") {
    class Item(val text: String = "") {
        fun coerceToText(context: Any?): CharSequence = text
    }
    val itemCount: Int get() = if (text.isNotEmpty()) 1 else 0
    fun getItemAt(index: Int): Item? = if (index == 0) Item(text) else null

    companion object {
        fun newPlainText(label: CharSequence?, text: CharSequence?): ClipData =
            ClipData(text?.toString() ?: "")
    }
}

class ClipboardManager {
    private var _clip: ClipData? = null
    val primaryClip: ClipData? get() = _clip
    fun setPrimaryClip(clip: ClipData?) { _clip = clip }
    fun hasPrimaryClip(): Boolean = _clip != null && (_clip?.itemCount ?: 0) > 0

    companion object {
        val instance = ClipboardManager()
    }
}

class ConcurrentHashMap<K, V> : LinkedHashMap<K, V>()

open class LruCache<K, V>(val maxSize: Int) {
    private val map = LinkedHashMap<K, V>()
    open fun sizeOf(key: K, value: V): Int = 1
    fun get(key: K): V? = map[key]
    fun put(key: K, value: V): V? = map.put(key, value)
}

class MediaMetadataRetriever {
    fun setDataSource(path: String) {}
    fun getFrameAtTime(timeUs: Long, option: Int): Bitmap? = null
    fun release() {}
}
