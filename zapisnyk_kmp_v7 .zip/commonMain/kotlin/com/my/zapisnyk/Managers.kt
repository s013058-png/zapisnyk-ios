package com.my.zapisnyk


import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor


// ==========================================
// 3. МЕНЕДЖЕРЫ
// ==========================================

object SecurityManager {
    fun getSecurityType(c: Context) = c.getSharedPreferences("security", 0).getString("type", "Нет") ?: "Нет"
    fun getSecurityValue(c: Context) = c.getSharedPreferences("security", 0).getString("value", "") ?: ""
    fun setSecurity(c: Context, t: String, v: String) { c.getSharedPreferences("security", 0).edit().putString("type", t).putString("value", v).apply() }
    fun authenticateBiometric(activity: FragmentActivity, onResult: (Boolean) -> Unit) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onResult(true) }
        })
        val info = BiometricPrompt.PromptInfo.Builder().setTitle("Вход").setNegativeButtonText("Отмена").build()
        prompt.authenticate(info)
    }
}

object ProManager {
    private fun getS(): String = intArrayOf(80, 87, 102, 95, 105, 100, 111, 97, 40, 38, 40, 44).map { (it + 10).toChar() }.joinToString("")
    fun getDeviceId(c: Context): String {
        val p = c.getSharedPreferences("prefs", 0); var id = p.getString("id", null)
        if (id == null) { id = UUID.randomUUID().toString().take(6).uppercase(); p.edit().putString("id", id).apply() }; return id
    }
    fun isPro(c: Context) = c.getSharedPreferences("prefs", 0).getBoolean("pro", true)
    fun activatePro(c: Context, code: String): Boolean {
        val correct = (getDeviceId(c) + getS()).hashCode().let { if(it < 0) -it else it }.toString().take(6)
        if (code == correct) { c.getSharedPreferences("prefs", 0).edit().putBoolean("pro", true).apply(); return true }; return false
    }
}

object VideoLimitManager {
    const val PRO_REQUIRED_MESSAGE = "Нужно получить PRO версию"
    private const val PREFS_KEY_COUNT = "video_load_count"

    fun getVideoLoadCount(context: Context): Int {
        return context.getSharedPreferences("prefs", 0).getInt(PREFS_KEY_COUNT, 0)
    }

    fun canLoadVideo(context: Context): Boolean {
        if (ProManager.isPro(context)) return true
        return getVideoLoadCount(context) < 1
    }

    fun recordVideoLoaded(context: Context) {
        val p = context.getSharedPreferences("prefs", 0)
        val cur = p.getInt(PREFS_KEY_COUNT, 0)
        p.edit().putInt(PREFS_KEY_COUNT, cur + 1).apply()
    }

    fun checkAndWarn(context: Context): Boolean {
        if (canLoadVideo(context)) return true
        Toast.makeText(
            context,
            "$PRO_REQUIRED_MESSAGE. В обычном режиме доступна только 1 загрузка видео.",
            Toast.LENGTH_LONG
        ).show()
        return false
    }
}

val LocalIsModernFont = compositionLocalOf { true }

object ThemeManager {
    enum class ThemeOption(val color: Color) { Blue(Color(0xFF3F51B5)), Green(Color(0xFF2E7D32)), Pink(Color(0xFFD81B60)), Graphite(Color(0xFF37474F)) }
    var isModernFont by mutableStateOf(true)
        private set

    fun init(c: Context) {
        isModernFont = true
    }

    fun setModernFont(c: Context, modern: Boolean) {
        isModernFont = modern
        c.getSharedPreferences("fin_prefs", Context.MODE_PRIVATE).edit().putBoolean("finance_modern_font", modern).apply()
    }

    // Dynamic typography weights & styling for 1Money thin geometric style (never heavy bold):
    // 1Money clean thin geometric typography:
    fun numWeight(): FontWeight = FontWeight.Light
    fun numBoldWeight(): FontWeight = FontWeight.Light
    fun numExtraBoldWeight(): FontWeight = FontWeight.Light
    fun catWeight(): FontWeight = FontWeight.Normal
    fun titleWeight(): FontWeight = FontWeight.Normal
    fun headerWeight(): FontWeight = FontWeight.Normal
    fun letterSpacing(): androidx.compose.ui.unit.TextUnit = 0.5.sp
    fun numSpacing(): androidx.compose.ui.unit.TextUnit = 0.8.sp
    fun getFontFamily(): androidx.compose.ui.text.font.FontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif
    fun numFontFamily(): androidx.compose.ui.text.font.FontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif

    fun getThemeColor(c: Context): Color {
        val idx = c.getSharedPreferences("theme", 0).getInt("idx", 0)
        return ThemeOption.entries.getOrElse(idx) { ThemeOption.Blue }.color
    }
    fun setTheme(c: Context, o: ThemeOption) { c.getSharedPreferences("theme", 0).edit().putInt("idx", o.ordinal).apply() }
    fun isDarkMode(c: Context): Boolean = c.getSharedPreferences("theme", 0).getBoolean("dark_mode", false)
    fun setDarkMode(c: Context, isDark: Boolean) { c.getSharedPreferences("theme", 0).edit().putBoolean("dark_mode", isDark).apply() }
}

object ReminderManager {
    const val CHANNEL_ID = "zapisnyk_reminders"
    private const val PREFS_REMINDERS = "reminder_settings"
    private const val PREFS_SENT_LOG = "reminder_sent_log"
    private const val PREFS_DISMISSED = "reminder_dismissed_log"

    fun isExpectedRemindersEnabled(c: Context): Boolean =
        c.getSharedPreferences(PREFS_REMINDERS, Context.MODE_PRIVATE).getBoolean("remind_expected", true)

    fun setExpectedRemindersEnabled(c: Context, enabled: Boolean) {
        c.getSharedPreferences(PREFS_REMINDERS, Context.MODE_PRIVATE).edit().putBoolean("remind_expected", enabled).apply()
    }

    fun isDebtRemindersEnabled(c: Context): Boolean =
        c.getSharedPreferences(PREFS_REMINDERS, Context.MODE_PRIVATE).getBoolean("remind_debts", true)

    fun setDebtRemindersEnabled(c: Context, enabled: Boolean) {
        c.getSharedPreferences(PREFS_REMINDERS, Context.MODE_PRIVATE).edit().putBoolean("remind_debts", enabled).apply()
    }

    fun isShiftRemindersEnabled(c: Context): Boolean =
        c.getSharedPreferences(PREFS_REMINDERS, Context.MODE_PRIVATE).getBoolean("remind_shifts", true)

    fun setShiftRemindersEnabled(c: Context, enabled: Boolean) {
        c.getSharedPreferences(PREFS_REMINDERS, Context.MODE_PRIVATE).edit().putBoolean("remind_shifts", enabled).apply()
    }

    fun getDismissedKeys(c: Context): Set<String> {
        return try {
            c.getSharedPreferences(PREFS_DISMISSED, Context.MODE_PRIVATE).all.keys
        } catch (_: Throwable) {
            emptySet()
        }
    }

    fun isReminderDismissed(c: Context, key: String): Boolean =
        c.getSharedPreferences(PREFS_DISMISSED, Context.MODE_PRIVATE).getBoolean(key, false)

    fun dismissReminder(c: Context, key: String) {
        c.getSharedPreferences(PREFS_DISMISSED, Context.MODE_PRIVATE).edit().putBoolean(key, true).apply()
    }

    fun clearDismissedReminders(c: Context) {
        c.getSharedPreferences(PREFS_DISMISSED, Context.MODE_PRIVATE).edit().clear().apply()
    }

    fun createNotificationChannel(context: Context) {}

    fun scheduleDailyAlarms(context: Context) {}

    fun sendNotification(context: Context, notifId: Int, title: String, text: String, dismissKey: String? = null) {
        Toast.makeText(context, "$title: $text", Toast.LENGTH_LONG).show()
    }

    suspend fun checkAndSendReminders(context: Context, dao: DiaryDao): Int {
        var sentCount = 0
        try {
            val sentLog = context.getSharedPreferences(PREFS_SENT_LOG, Context.MODE_PRIVATE)
            val todayKey = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())
            val now = Calendar.getInstance()
            val todayDay = now.get(Calendar.DAY_OF_MONTH)
            val tomorrowCal = (now.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) }
            val tomorrowDay = tomorrowCal.get(Calendar.DAY_OF_MONTH)
            val todayMidnight = System.currentTimeMillis().toMidnight()
            val tomorrowMidnight = todayMidnight + 86400000L

            // 1. НАПОМИНАНИЯ: ПЛАН ДО КОНЦА МЕСЯЦА (EXPECTED FINANCE)
            if (isExpectedRemindersEnabled(context)) {
                val expectedList = dao.getAllExpectedFinancesDirect()
                for (item in expectedList) {
                    val amountStr = String.format(Locale.US, "%.0f", item.amount)

                    // А. За сутки (день платежа завтра)
                    if (item.dayOfMonth == tomorrowDay) {
                        val key = "exp_tomorrow_${item.id}_${todayKey}"
                        if (!isReminderDismissed(context, key) && !sentLog.getBoolean(key, false)) {
                            val title = if (item.isIncome) "Ожидаемый доход (завтра)" else "Напоминание о платеже (завтра)"
                            val msg = "Завтра по плану: ${item.title} — $amountStr ₽"
                            sendNotification(context, 10000 + item.id * 10 + 1, title, msg, key)
                            sentLog.edit().putBoolean(key, true).apply()
                            sentCount++
                        }
                    }

                    // Б. В этот день (день платежа сегодня)
                    if (item.dayOfMonth == todayDay) {
                        val key = "exp_today_${item.id}_${todayKey}"
                        if (!isReminderDismissed(context, key) && !sentLog.getBoolean(key, false)) {
                            val title = if (item.isIncome) "Ожидаемый доход сегодня" else "Срок платежа сегодня!"
                            val msg = "Сегодня по плану: ${item.title} — $amountStr ₽"
                            sendNotification(context, 10000 + item.id * 10 + 2, title, msg, key)
                            sentLog.edit().putBoolean(key, true).apply()
                            sentCount++
                        }
                    }
                }
            }

            // 2. НАПОМИНАНИЯ: КРЕДИТЫ И ДОЛГИ (DIARY DEBT)
            if (isDebtRemindersEnabled(context)) {
                val debtsList = dao.getAllDebtsDirect().filter { !it.isPaid }
                for (debt in debtsList) {
                    val dueMid = debt.dueDate.toMidnight()
                    val amountStr = String.format(Locale.US, "%.0f", debt.amount)

                    // А. За сутки
                    if (dueMid == tomorrowMidnight) {
                        val key = "debt_tomorrow_${debt.id}_${todayKey}"
                        if (!isReminderDismissed(context, key) && !sentLog.getBoolean(key, false)) {
                            val title = "Напоминание по кредиту / долгу"
                            val msg = "Завтра срок платежа: ${debt.creditor} на сумму $amountStr ₽"
                            sendNotification(context, 20000 + debt.id * 10 + 1, title, msg, key)
                            sentLog.edit().putBoolean(key, true).apply()
                            sentCount++
                        }
                    }

                    // Б. В этот день
                    if (dueMid == todayMidnight) {
                        val key = "debt_today_${debt.id}_${todayKey}"
                        if (!isReminderDismissed(context, key) && !sentLog.getBoolean(key, false)) {
                            val title = "Срок платежа по кредиту сегодня!"
                            val msg = "Сегодня необходимо оплатить: ${debt.creditor} ($amountStr ₽)"
                            sendNotification(context, 20000 + debt.id * 10 + 2, title, msg, key)
                            sentLog.edit().putBoolean(key, true).apply()
                            sentCount++
                        }
                    }

                    // В. Просроченный платеж
                    if (dueMid < todayMidnight) {
                        val key = "debt_overdue_${debt.id}_${todayKey}"
                        if (!isReminderDismissed(context, key) && !sentLog.getBoolean(key, false)) {
                            val title = "Просроченный платеж по кредиту!"
                            val msg = "Внимание: просрочен платеж ${debt.creditor} на сумму $amountStr ₽"
                            sendNotification(context, 20000 + debt.id * 10 + 3, title, msg, key)
                            sentLog.edit().putBoolean(key, true).apply()
                            sentCount++
                        }
                    }
                }
            }

            // 3. НАПОМИНАНИЕ: ЗАВТРА РАБОЧИЙ ДЕНЬ (ДАЖЕ ЕСЛИ БУДИЛЬНИК ВЫКЛЮЧЕН)
            if (isShiftRemindersEnabled(context)) {
                val shiftConfig = dao.getShiftConfigDirect()
                if (shiftConfig != null && shiftConfig.isActive) {
                    val isTomWork = isWorkDay(tomorrowMidnight, shiftConfig)
                    if (isTomWork) {
                        val key = "shift_tomorrow_work_${todayKey}"
                        if (!isReminderDismissed(context, key) && !sentLog.getBoolean(key, false)) {
                            val alarmInfo = if (shiftConfig.isAlarmEnabled) {
                                "Будильник установлен на ${String.format(Locale.getDefault(), "%02d:%02d", shiftConfig.alarmHour, shiftConfig.alarmMinute)}"
                            } else {
                                "Будильник не включен"
                            }
                            val title = "График смен"
                            val msg = "Завтра рабочий день по вашему графику! ($alarmInfo)"
                            sendNotification(context, 30001, title, msg, key)
                            sentLog.edit().putBoolean(key, true).apply()
                            sentCount++
                        }
                    }
                }
            }
        } catch (e: Throwable) {
            Log.e("Zapisnyk", "checkAndSendReminders error", e)
        }
        return sentCount
    }
}

