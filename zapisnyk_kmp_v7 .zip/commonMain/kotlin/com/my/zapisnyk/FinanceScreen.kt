package com.my.zapisnyk


import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor


// ==========================================
// 6. ФИНАНСЫ (v.2.1)
// ==========================================

@OptIn(ExperimentalLayoutApi::class, ExperimentalMaterial3Api::class)
@Composable
fun FinanceScreen(
    dao: DiaryDao,
    allFinances: List<DiaryFinance>,
    debts: List<DiaryDebt>,
    expected: List<ExpectedFinance>,
    selectedDate: Long,
    isIncognito: Boolean,
    notes: List<DiaryNote> = emptyList(),
    onDateChange: (Long) -> Unit
) {
    val context = LocalContext.current; val scope = rememberCoroutineScope(); val prefs = context.getSharedPreferences("fin_cats", 0)
    var categories by remember { mutableStateOf(Gson().fromJson<List<CategoryConfig>>(prefs.getString("list", "[]"), object : TypeToken<List<CategoryConfig>>() {}.type) ?: emptyList()) }

    // Кастомные названия разделов (включая доход, расход, депозит)
    val namesPref = context.getSharedPreferences("section_names", 0)
    var sectionNames by remember {
        mutableStateOf(
            mapOf(
                "inc" to (namesPref.getString("inc", "Доход") ?: "Доход"),
                "exp" to (namesPref.getString("exp", "Расход") ?: "Расход"),
                "dep" to (namesPref.getString("dep", "Депозит") ?: "Депозит")
            )
        )
    }
    // Скрытые/удаленные разделы (включая встроенные)
    var hiddenSections by remember {
        mutableStateOf(namesPref.getStringSet("hidden", emptySet()) ?: emptySet())
    }

    val finPrefs = context.getSharedPreferences("fin_prefs", 0)
    val isColorFinance = finPrefs.getBoolean("finance_color_scheme", false)
    val isModernFont = ThemeManager.isModernFont
    val numWeight = ThemeManager.numWeight()
    val numBoldWeight = ThemeManager.numBoldWeight()
    val numExtraBoldWeight = ThemeManager.numExtraBoldWeight()
    val catWeight = ThemeManager.catWeight()
    val titleWeight = ThemeManager.titleWeight()
    val headerWeight = ThemeManager.headerWeight()
    val numSpacing = ThemeManager.numSpacing()
    val spacing = ThemeManager.letterSpacing()
    val modernFontFamily = ThemeManager.getFontFamily()
    var expenseLimit by remember { mutableStateOf(getSafeExpenseLimit(context)) }
    var excludedFromLimit by remember { mutableStateOf(getExcludedFromLimit(context)) }
    var showLimitDialog by remember { mutableStateOf(false) }

    fun toggleExcludeCategory(catId: String) {
        val newSet = if (excludedFromLimit.contains(catId)) excludedFromLimit - catId else excludedFromLimit + catId
        excludedFromLimit = newSet
        saveExcludedFromLimit(context, newSet)
    }

    var debtsExpanded by remember { mutableStateOf(false) }; var showAddDebt by remember { mutableStateOf(false) }; var editingDebt by remember { mutableStateOf<DiaryDebt?>(null) }
    var showAddCat by remember { mutableStateOf(false) }
    var addCatInitialType by remember { mutableStateOf(CatType.INCOME) }
    var newlyCreatedCatId by remember { mutableStateOf<String?>(null) }
    var showAddTransactionDialog by remember { mutableStateOf(false) }
    var addTransactionInitialType by remember { mutableStateOf("EXPENSE") }
    var editingHistoryItem by remember { mutableStateOf<Triple<String, FinanceItem, String>?>(null) }
    var editingBalanceCat by remember { mutableStateOf<Pair<String, String>?>(null) }
    var showAddExpected by remember { mutableStateOf(false) }
    var showUpcomingSheet by remember { mutableStateOf(false) }
    var editingSectionInfo by remember { mutableStateOf<Triple<String, String, Boolean>?>(null) } // id, currentName, isCustom
    var selectedCategoryForDetail by remember { mutableStateOf<FinanceSectionInfo?>(null) }

    var summaryPeriodMode by remember { mutableStateOf("MONTH") } // "MONTH", "HALF_YEAR", "YEAR", "CUSTOM"
    var summaryCal by remember(selectedDate) { mutableStateOf(Calendar.getInstance().apply { timeInMillis = selectedDate }) }
    val cal = Calendar.getInstance().apply { timeInMillis = selectedDate }
    var summaryCustomStart by remember { mutableLongStateOf(Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }.timeInMillis.toMidnight()) }
    var summaryCustomEnd by remember { mutableLongStateOf(System.currentTimeMillis().toMidnight()) }
    var showCustomRangeDialog by remember { mutableStateOf(false) }
    var showAllInvestDialog by remember { mutableStateOf(false) }
    var showAllIncomeDialog by remember { mutableStateOf(false) }
    var showAllExpenseDialog by remember { mutableStateOf(false) }

    var savingsGoals by remember { mutableStateOf(getSavingsGoals(context)) }
    var showAddGoalDialog by remember { mutableStateOf(false) }
    var editingGoal by remember { mutableStateOf<SavingsGoal?>(null) }
    var goalsExpanded by remember { mutableStateOf(false) }

    fun onSaveGoal(goal: SavingsGoal) {
        val idx = savingsGoals.indexOfFirst { it.id == goal.id }
        val updated = if (idx >= 0) {
            savingsGoals.toMutableList().apply { set(idx, goal) }
        } else {
            savingsGoals + goal
        }
        savingsGoals = updated
        saveSavingsGoals(context, updated)
    }

    fun onDeleteGoal(goalId: String) {
        val updated = savingsGoals.filter { it.id != goalId }
        savingsGoals = updated
        saveSavingsGoals(context, updated)
    }

    fun onDeleteGoal(goal: SavingsGoal) {
        onDeleteGoal(goal.id)
    }

    var hasCar by remember { mutableStateOf(getCarEnabled(context)) }
    var cars by remember { mutableStateOf(getCarList(context)) }
    var carEvents by remember { mutableStateOf(getCarEvents(context)) }
    var carMileageLogs by remember { mutableStateOf(getCarMileageLogs(context)) }
    var carReminders by remember { mutableStateOf(getCarReminders(context)) }

    var selectedCarForDetail by remember { mutableStateOf<CarItem?>(null) }
    var editingCar by remember { mutableStateOf<CarItem?>(null) }
    var showAddCarDialog by remember { mutableStateOf(false) }

    var editingCarEvent by remember { mutableStateOf<CarEventItem?>(null) }
    var eventCarTarget by remember { mutableStateOf<CarItem?>(null) }
    var eventDefaultType by remember { mutableStateOf("FUEL") }
    var showAddCarEventDialog by remember { mutableStateOf(false) }

    var mileageCarTarget by remember { mutableStateOf<CarItem?>(null) }
    var showAddMileageDialog by remember { mutableStateOf(false) }

    var editingCarReminder by remember { mutableStateOf<CarReminderItem?>(null) }
    var reminderCarTarget by remember { mutableStateOf<CarItem?>(null) }
    var showAddReminderDialog by remember { mutableStateOf(false) }

    fun refreshCarData() {
        hasCar = getCarEnabled(context)
        cars = getCarList(context)
        carEvents = getCarEvents(context)
        carMileageLogs = getCarMileageLogs(context)
        carReminders = getCarReminders(context)
        if (selectedCarForDetail != null) {
            selectedCarForDetail = cars.find { it.id == selectedCarForDetail?.id }
        }
    }

    fun onSaveCar(car: CarItem) {
        val idx = cars.indexOfFirst { it.id == car.id }
        val updated = if (idx >= 0) cars.toMutableList().apply { set(idx, car) } else cars + car
        cars = updated
        saveCarList(context, updated)
        refreshCarData()
    }

    fun onDeleteCar(carId: String) {
        val updatedCars = cars.filter { it.id != carId }
        cars = updatedCars
        saveCarList(context, updatedCars)
        val updatedEvents = carEvents.filter { it.carId != carId }
        carEvents = updatedEvents
        saveCarEvents(context, updatedEvents)
        val updatedMileage = carMileageLogs.filter { it.carId != carId }
        carMileageLogs = updatedMileage
        saveCarMileageLogs(context, updatedMileage)
        val updatedRem = carReminders.filter { it.carId != carId }
        carReminders = updatedRem
        saveCarReminders(context, updatedRem)
        selectedCarForDetail = null
        refreshCarData()
    }

    fun onSaveCarEvent(ev: CarEventItem) {
        val idx = carEvents.indexOfFirst { it.id == ev.id }
        val updated = if (idx >= 0) carEvents.toMutableList().apply { set(idx, ev) } else listOf(ev) + carEvents
        carEvents = updated
        saveCarEvents(context, updated)

        ev.odometer?.let { odo ->
            val c = cars.find { it.id == ev.carId }
            if (c != null && odo > c.currentOdometer) {
                onSaveCar(c.copy(currentOdometer = odo))
                val newLog = CarMileageItem(carId = c.id, date = ev.date, odometer = odo, title = ev.title)
                val mLogs = carMileageLogs + newLog
                carMileageLogs = mLogs
                saveCarMileageLogs(context, mLogs)
            }
        }
        refreshCarData()
    }

    fun onDeleteCarEvent(evId: String) {
        val updated = carEvents.filter { it.id != evId }
        carEvents = updated
        saveCarEvents(context, updated)
        refreshCarData()
    }

    fun onSaveMileageLog(log: CarMileageItem) {
        val updated = carMileageLogs + log
        carMileageLogs = updated
        saveCarMileageLogs(context, updated)
        val c = cars.find { it.id == log.carId }
        if (c != null && log.odometer > c.currentOdometer) {
            onSaveCar(c.copy(currentOdometer = log.odometer))
        }
        refreshCarData()
    }

    fun onDeleteMileageLog(logId: String) {
        val updated = carMileageLogs.filter { it.id != logId }
        carMileageLogs = updated
        saveCarMileageLogs(context, updated)
        refreshCarData()
    }

    fun onSaveReminder(rem: CarReminderItem) {
        val idx = carReminders.indexOfFirst { it.id == rem.id }
        val updated = if (idx >= 0) carReminders.toMutableList().apply { set(idx, rem) } else carReminders + rem
        carReminders = updated
        saveCarReminders(context, updated)
        refreshCarData()
    }

    fun onDeleteReminder(remId: String) {
        val updated = carReminders.filter { it.id != remId }
        carReminders = updated
        saveCarReminders(context, updated)
        refreshCarData()
    }

    fun onToggleReminderDone(rem: CarReminderItem) {
        val nextDone = !rem.isCompleted
        val updatedRem = if (nextDone && (rem.repeatIntervalKm ?: 0) > 0 && rem.targetOdometer != null) {
            rem.copy(
                targetOdometer = rem.targetOdometer + rem.repeatIntervalKm!!,
                isCompleted = false
            )
        } else {
            rem.copy(isCompleted = nextDone)
        }
        onSaveReminder(updatedRem)
    }

    val currentFinance = allFinances.find { it.date == selectedDate }; val todayDay = Calendar.getInstance().get(Calendar.DAY_OF_MONTH)

    fun renameSection(id: String, newName: String) {
        if (id in listOf("inc", "exp", "dep")) {
            namesPref.edit().putString(id, newName).apply()
            sectionNames = sectionNames + (id to newName)
        } else {
            val newList = categories.map { if (it.id == id) it.copy(name = newName) else it }
            categories = newList
            prefs.edit().putString("list", Gson().toJson(newList)).apply()
        }
    }

    fun deleteSection(id: String) {
        if (id in listOf("inc", "exp", "dep")) {
            val newSet = hiddenSections + id
            hiddenSections = newSet
            namesPref.edit().putStringSet("hidden", newSet).apply()
        } else {
            val newList = categories.filter { it.id != id }
            categories = newList
            prefs.edit().putString("list", Gson().toJson(newList)).apply()
        }
    }

    fun restoreSection(id: String) {
        val newSet = hiddenSections - id
        hiddenSections = newSet
        namesPref.edit().putStringSet("hidden", newSet).apply()
    }

    fun getFullBalance(catId: String, targetDate: Long): Double {
        val typeToken = object : TypeToken<List<FinanceItem>>() {}.type
        return allFinances.filter { it.date <= targetDate }.sumOf { f ->
            try {
                if(catId == "dep") Gson().fromJson<List<FinanceItem>>(f.depHistory ?: "[]", typeToken)?.sumOf { it.amount } ?: 0.0
                else {
                    val map = Gson().fromJson<Map<String, String>>(f.dynamicBalances ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                    Gson().fromJson<List<FinanceItem>>(map[catId] ?: "[]", typeToken)?.sumOf { it.amount } ?: 0.0
                }
            } catch (e: Exception) { 0.0 }
        }
    }

    fun parseMutableStringMap(json: String?): MutableMap<String, String> {
        if (json.isNullOrBlank() || json.trim() == "{}") return mutableMapOf()
        return try {
            val raw = Gson().fromJson<Map<String, Any?>>(json, object : TypeToken<MutableMap<String, String>>() {}.type)
            val result = mutableMapOf<String, String>()
            raw?.forEach { (k, v) ->
                if (k != null && v != null) {
                    result[k.toString()] = if (v is String) v else Gson().toJson(v)
                }
            }
            result
        } catch (_: Throwable) {
            mutableMapOf()
        }
    }

    fun parseFinanceItemList(json: String?): MutableList<FinanceItem> {
        if (json.isNullOrBlank() || json.trim() == "[]") return mutableListOf()
        return try {
            val typeToken = object : TypeToken<List<FinanceItem>>() {}.type
            (Gson().fromJson<List<FinanceItem>>(json, typeToken) ?: emptyList()).toMutableList()
        } catch (_: Throwable) {
            mutableListOf()
        }
    }

    fun saveEntry(catId: String, amount: Double, note: String, targetDate: Long = selectedDate) {
        val normDate = targetDate.toMidnight()
        val f = allFinances.find { it.date.toMidnight() == normDate } ?: (if (normDate == selectedDate.toMidnight()) currentFinance?.copy(date = normDate) ?: DiaryFinance(date = normDate) else DiaryFinance(date = normDate))
        val newItem = FinanceItem(amount = amount, note = note)
        val updatedF = when(catId) {
            "inc" -> { val list = parseFinanceItemList(f.incHistory).apply { add(newItem) }; f.copy(date = normDate, incHistory = Gson().toJson(list), income = list.sumOf { it.amount }) }
            "exp" -> { val list = parseFinanceItemList(f.expHistory).apply { add(newItem) }; f.copy(date = normDate, expHistory = Gson().toJson(list), expense = list.sumOf { it.amount }) }
            "dep" -> { val list = parseFinanceItemList(f.depHistory).apply { add(newItem) }; f.copy(date = normDate, depHistory = Gson().toJson(list), savings_deposit = list.sumOf { it.amount }) }
            else -> {
                val cat = categories.find { it.id == catId }
                if (cat?.type == CatType.BALANCE) {
                    val balMap = parseMutableStringMap(f.dynamicBalances)
                    val list = parseFinanceItemList(balMap[catId]).apply { add(newItem) }
                    balMap[catId] = Gson().toJson(list)
                    f.copy(date = normDate, dynamicBalances = Gson().toJson(balMap))
                } else {
                    val dataMap = parseMutableStringMap(f.dynamicData)
                    val list = parseFinanceItemList(dataMap[catId]).apply { add(newItem) }
                    dataMap[catId] = Gson().toJson(list)
                    f.copy(date = normDate, dynamicData = Gson().toJson(dataMap))
                }
            }
        }
        scope.launch { dao.saveFinance(updatedF) }
        if (normDate != selectedDate.toMidnight()) {
            onDateChange(normDate)
        }
    }

    fun updateHistoryItem(catId: String, updatedItem: FinanceItem, isDelete: Boolean = false) {
        val targetF = allFinances.find { fin ->
            when (catId) {
                "inc" -> parseFinanceItemList(fin.incHistory).any { it.id == updatedItem.id }
                "exp" -> parseFinanceItemList(fin.expHistory).any { it.id == updatedItem.id }
                "dep" -> parseFinanceItemList(fin.depHistory).any { it.id == updatedItem.id }
                else -> {
                    val cat = categories.find { it.id == catId }
                    if (cat?.type == CatType.BALANCE) {
                        val balMap = parseMutableStringMap(fin.dynamicBalances)
                        parseFinanceItemList(balMap[catId]).any { it.id == updatedItem.id }
                    } else {
                        val dataMap = parseMutableStringMap(fin.dynamicData)
                        parseFinanceItemList(dataMap[catId]).any { it.id == updatedItem.id }
                    }
                }
            }
        } ?: currentFinance ?: return

        val updatedF = when(catId) {
            "inc" -> { val list = parseFinanceItemList(targetF.incHistory).apply { val idx = indexOfFirst { it.id == updatedItem.id }; if(idx != -1) if(isDelete) removeAt(idx) else set(idx, updatedItem) }; targetF.copy(incHistory = Gson().toJson(list), income = list.sumOf { it.amount }) }
            "exp" -> { val list = parseFinanceItemList(targetF.expHistory).apply { val idx = indexOfFirst { it.id == updatedItem.id }; if(idx != -1) if(isDelete) removeAt(idx) else set(idx, updatedItem) }; targetF.copy(expHistory = Gson().toJson(list), expense = list.sumOf { it.amount }) }
            "dep" -> { val list = parseFinanceItemList(targetF.depHistory).apply { val idx = indexOfFirst { it.id == updatedItem.id }; if(idx != -1) if(isDelete) removeAt(idx) else set(idx, updatedItem) }; targetF.copy(depHistory = Gson().toJson(list), savings_deposit = list.sumOf { it.amount }) }
            else -> {
                val cat = categories.find { it.id == catId }
                if(cat?.type == CatType.BALANCE) {
                    val balMap = parseMutableStringMap(targetF.dynamicBalances)
                    val list = parseFinanceItemList(balMap[catId]).apply { val idx = indexOfFirst { it.id == updatedItem.id }; if(idx != -1) if(isDelete) removeAt(idx) else set(idx, updatedItem) }
                    balMap[catId] = Gson().toJson(list)
                    targetF.copy(dynamicBalances = Gson().toJson(balMap))
                } else {
                    val dataMap = parseMutableStringMap(targetF.dynamicData)
                    val list = parseFinanceItemList(dataMap[catId]).apply { val idx = indexOfFirst { it.id == updatedItem.id }; if(idx != -1) if(isDelete) removeAt(idx) else set(idx, updatedItem) }
                    dataMap[catId] = Gson().toJson(list)
                    targetF.copy(dynamicData = Gson().toJson(dataMap))
                }
            }
        }
        scope.launch { dao.saveFinance(updatedF) }
    }

    // ИТОГИ МЕСЯЦА / ПЕРИОДА (СО ВСЕМИ ДОБАВЛЕННЫМИ РАЗДЕЛАМИ И ДЕТАЛЯМИ ПО ЧИСЛАМ)
    val mFin = when (summaryPeriodMode) {
        "MONTH" -> {
            val m = summaryCal.get(Calendar.MONTH)
            val y = summaryCal.get(Calendar.YEAR)
            allFinances.filter {
                val c = Calendar.getInstance().apply { timeInMillis = it.date }
                c.get(Calendar.MONTH) == m && c.get(Calendar.YEAR) == y
            }
        }
        "HALF_YEAR" -> {
            val endCal = (summaryCal.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
            }
            val startCal = (summaryCal.clone() as Calendar).apply {
                add(Calendar.MONTH, -5)
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            allFinances.filter { it.date in startCal.timeInMillis..endCal.timeInMillis }
        }
        "YEAR" -> {
            val y = summaryCal.get(Calendar.YEAR)
            allFinances.filter {
                val c = Calendar.getInstance().apply { timeInMillis = it.date }
                c.get(Calendar.YEAR) == y
            }
        }
        else -> {
            val s = summaryCustomStart.toMidnight()
            val e = summaryCustomEnd.toMidnight() + 86399999L
            allFinances.filter { it.date in s..e }
        }
    }

    val summaryEndDate = when (summaryPeriodMode) {
        "MONTH" -> {
            val c = (summaryCal.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
            }
            c.timeInMillis
        }
        "HALF_YEAR" -> {
            val c = (summaryCal.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
            }
            c.timeInMillis
        }
        "YEAR" -> {
            val c = (summaryCal.clone() as Calendar).apply {
                set(Calendar.MONTH, Calendar.DECEMBER)
                set(Calendar.DAY_OF_MONTH, 31)
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
            }
            c.timeInMillis
        }
        else -> summaryCustomEnd.toMidnight() + 86399999L
    }

    val summaryTitleText = when (summaryPeriodMode) {
        "MONTH" -> "ИТОГИ ЗА ${SimpleDateFormat("MMMM yyyy", Locale("ru")).format(summaryCal.time).uppercase()}"
        "HALF_YEAR" -> {
            val startCal = (summaryCal.clone() as Calendar).apply { add(Calendar.MONTH, -5) }
            val sStr = SimpleDateFormat("LLL", Locale("ru")).format(startCal.time)
            val eStr = SimpleDateFormat("LLL yyyy", Locale("ru")).format(summaryCal.time)
            "ИТОГИ ЗА 6 МЕСЯЦЕВ ($sStr — $eStr)".uppercase()
        }
        "YEAR" -> "ИТОГИ ЗА ${summaryCal.get(Calendar.YEAR)} ГОД"
        else -> {
            val sStr = SimpleDateFormat("dd.MM.yy", Locale("ru")).format(Date(summaryCustomStart))
            val eStr = SimpleDateFormat("dd.MM.yy", Locale("ru")).format(Date(summaryCustomEnd))
            "ИТОГИ: $sStr — $eStr"
        }
    }

    val summaryPeriodSub = when (summaryPeriodMode) {
        "MONTH" -> "всего за месяц"
        "HALF_YEAR" -> "за 6 месяцев"
        "YEAR" -> "за ${summaryCal.get(Calendar.YEAR)} г."
        else -> "за период"
    }

    val typeTokenFin = object : TypeToken<List<FinanceItem>>() {}.type

    val isSysExpExcluded = excludedFromLimit.contains("exp")
    val totalSysExp = mFin.sumOf { it.expense }
    val totalSysInc = mFin.sumOf { it.income }
    val totalSysDep = mFin.sumOf { it.savings_deposit }

    // ДОХОДЫ: системный + ВСЕ добавленные категории CatType.INCOME
    val allIncomeSections = mutableListOf<FinanceSectionInfo>()
    if (totalSysInc > 0 || !hiddenSections.contains("inc")) {
        allIncomeSections.add(
            FinanceSectionInfo(
                id = "inc",
                name = sectionNames["inc"] ?: "Доход",
                color = Color(0xFF2E7D32),
                total = totalSysInc,
                type = "INCOME"
            )
        )
    }
    categories.filter { it.type == CatType.INCOME }.forEach { cat ->
        val total = mFin.sumOf { f ->
            try {
                val map = Gson().fromJson<Map<String, String>>(f.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                Gson().fromJson<List<FinanceItem>>(map[cat.id] ?: "[]", typeTokenFin)?.sumOf { it.amount } ?: 0.0
            } catch (e: Exception) { 0.0 }
        }
        allIncomeSections.add(
            FinanceSectionInfo(
                id = cat.id,
                name = cat.name,
                color = Color(cat.color),
                total = total,
                type = "INCOME"
            )
        )
    }

    // РАСХОДЫ: системный + ВСЕ добавленные категории CatType.HISTORY (включая авто)
    val allExpenseSections = mutableListOf<FinanceSectionInfo>()
    if (totalSysExp > 0 || !hiddenSections.contains("exp")) {
        allExpenseSections.add(
            FinanceSectionInfo(
                id = "exp",
                name = sectionNames["exp"] ?: "Расход",
                color = Color(0xFFD32F2F),
                total = totalSysExp,
                type = "EXPENSE",
                isExcluded = isSysExpExcluded
            )
        )
    }
    categories.filter { it.type == CatType.HISTORY }.forEach { cat ->
        val total = mFin.sumOf { f ->
            try {
                val map = Gson().fromJson<Map<String, String>>(f.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                Gson().fromJson<List<FinanceItem>>(map[cat.id] ?: "[]", typeTokenFin)?.sumOf { it.amount } ?: 0.0
            } catch (e: Exception) { 0.0 }
        }
        allExpenseSections.add(
            FinanceSectionInfo(
                id = cat.id,
                name = cat.name,
                color = Color(cat.color),
                total = total,
                type = "EXPENSE",
                isExcluded = excludedFromLimit.contains(cat.id)
            )
        )
    }

    // НАКОПЛЕНИЯ / БАЛАНСЫ / ИНВЕСТИЦИИ: системный депозит + ВСЕ добавленные категории CatType.BALANCE (Акции, Инвестиции, Вклады)
    val allBalanceSections = mutableListOf<FinanceSectionInfo>()
    if (totalSysDep > 0 || getFullBalance("dep", summaryEndDate) > 0 || !hiddenSections.contains("dep")) {
        allBalanceSections.add(
            FinanceSectionInfo(
                id = "dep",
                name = sectionNames["dep"] ?: "Депозит",
                color = Color(0xFFE65100),
                total = totalSysDep,
                type = "BALANCE",
                balance = getFullBalance("dep", summaryEndDate)
            )
        )
    }
    categories.filter { it.type == CatType.BALANCE }.forEach { cat ->
        val total = mFin.sumOf { f ->
            try {
                val map = Gson().fromJson<Map<String, String>>(f.dynamicBalances ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                Gson().fromJson<List<FinanceItem>>(map[cat.id] ?: "[]", typeTokenFin)?.sumOf { it.amount } ?: 0.0
            } catch (e: Exception) { 0.0 }
        }
        allBalanceSections.add(
            FinanceSectionInfo(
                id = cat.id,
                name = cat.name,
                color = Color(cat.color),
                total = total,
                type = "BALANCE",
                balance = getFullBalance(cat.id, summaryEndDate)
            )
        )
    }

    val totalMonthIncome = allIncomeSections.sumOf { it.total }
    val totalMonthExpenses = allExpenseSections.sumOf { it.total }
    val totalMonthDeposits = allBalanceSections.sumOf { it.total }
    // Вся сумма депозита и акций (всех накоплений и балансов)
    val totalInvestBalance = allBalanceSections.sumOf { it.balance ?: 0.0 }

    val limitTargetExpenses = allExpenseSections.filter { !it.isExcluded }.sumOf { it.total }
    val excludedExpensesTotal = totalMonthExpenses - limitTargetExpenses

    val isOverLimit = expenseLimit > 0 && limitTargetExpenses > expenseLimit
    val expensePct = if (expenseLimit > 0) ((limitTargetExpenses / expenseLimit) * 100).toInt() else 0

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        val unpaidDebts = debts.filter { !it.isPaid }; val totalDebt = unpaidDebts.sumOf { it.amount }
        var totalAssets = if (!hiddenSections.contains("dep")) getFullBalance("dep", selectedDate) else 0.0
        categories.filter { it.type == CatType.BALANCE }.forEach { totalAssets += getFullBalance(it.id, selectedDate) }

        // РАСЧЁТ ВСЕХ ОПЕРАЦИЙ ЗА ВЫБРАННЫЙ ДЕНЬ
        data class DayFinanceRecord(
            val id: Long,
            val catId: String,
            val catName: String,
            val color: Color,
            val amount: Double,
            val note: String,
            val type: String, // "INCOME", "EXPENSE", "BALANCE"
            val originalItem: FinanceItem
        )

        val dayRecords = remember(currentFinance, categories, sectionNames, hiddenSections) {
            val list = mutableListOf<DayFinanceRecord>()
            val typeToken = object : TypeToken<List<FinanceItem>>() {}.type
            val f = currentFinance
            if (f != null) {
                // 1. Системные доходы
                if (!hiddenSections.contains("inc")) {
                    val items: List<FinanceItem> = try { Gson().fromJson(f.incHistory ?: "[]", typeToken) ?: emptyList() } catch (_: Throwable) { emptyList() }
                    items.forEach { item ->
                        list.add(DayFinanceRecord(item.id, "inc", sectionNames["inc"] ?: "Доход", Color(0xFF2E7D32), item.amount, item.note, "INCOME", item))
                    }
                }
                // 2. Пользовательские доходы
                categories.filter { it.type == CatType.INCOME && !hiddenSections.contains(it.id) }.forEach { cat ->
                    val dataMap = try { Gson().fromJson<Map<String, String>>(f.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch (_: Throwable) { emptyMap() }
                    val items: List<FinanceItem> = try { Gson().fromJson(dataMap[cat.id] ?: "[]", typeToken) ?: emptyList() } catch (_: Throwable) { emptyList() }
                    items.forEach { item ->
                        list.add(DayFinanceRecord(item.id, cat.id, cat.name, Color(cat.color), item.amount, item.note, "INCOME", item))
                    }
                }
                // 3. Системные расходы
                if (!hiddenSections.contains("exp")) {
                    val items: List<FinanceItem> = try { Gson().fromJson(f.expHistory ?: "[]", typeToken) ?: emptyList() } catch (_: Throwable) { emptyList() }
                    items.forEach { item ->
                        list.add(DayFinanceRecord(item.id, "exp", sectionNames["exp"] ?: "Расход", Color(0xFFD32F2F), item.amount, item.note, "EXPENSE", item))
                    }
                }
                // 4. Пользовательские расходы
                categories.filter { it.type == CatType.HISTORY && !hiddenSections.contains(it.id) }.forEach { cat ->
                    val dataMap = try { Gson().fromJson<Map<String, String>>(f.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch (_: Throwable) { emptyMap() }
                    val items: List<FinanceItem> = try { Gson().fromJson(dataMap[cat.id] ?: "[]", typeToken) ?: emptyList() } catch (_: Throwable) { emptyList() }
                    items.forEach { item ->
                        list.add(DayFinanceRecord(item.id, cat.id, cat.name, Color(cat.color), item.amount, item.note, "EXPENSE", item))
                    }
                }
                // 5. Депозит / Балансы
                if (!hiddenSections.contains("dep")) {
                    val items: List<FinanceItem> = try { Gson().fromJson(f.depHistory ?: "[]", typeToken) ?: emptyList() } catch (_: Throwable) { emptyList() }
                    items.forEach { item ->
                        list.add(DayFinanceRecord(item.id, "dep", sectionNames["dep"] ?: "Депозит", Color(0xFFE65100), item.amount, item.note, "BALANCE", item))
                    }
                }
                categories.filter { it.type == CatType.BALANCE && !hiddenSections.contains(it.id) }.forEach { cat ->
                    val balMap = try { Gson().fromJson<Map<String, String>>(f.dynamicBalances ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch (_: Throwable) { emptyMap() }
                    val items: List<FinanceItem> = try { Gson().fromJson(balMap[cat.id] ?: "[]", typeToken) ?: emptyList() } catch (_: Throwable) { emptyList() }
                    items.forEach { item ->
                        list.add(DayFinanceRecord(item.id, cat.id, cat.name, Color(cat.color), item.amount, item.note, "BALANCE", item))
                    }
                }
            }
            list.sortedByDescending { it.id }
        }

        // УПРАВЛЕНИЕ ДАТОЙ И ПЛЮСИК СПРАВА (В САМОМ ВЕРХУ РАЗДЕЛА ФИНАНСЫ)
        Row(
            Modifier.fillMaxWidth().padding(bottom = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { onDateChange(selectedDate - 86400000) }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.KeyboardArrowLeft, contentDescription = "Предыдущий день")
                }
                Column(
                    Modifier
                        .clip(RoundedCornerShape(6.dp))
                        .clickable {
                            val c = Calendar.getInstance().apply { timeInMillis = selectedDate }
                            DatePickerDialog(
                                context,
                                { _, y, m, d ->
                                    val newCal = Calendar.getInstance().apply {
                                        set(y, m, d, 0, 0, 0)
                                        set(Calendar.MILLISECOND, 0)
                                    }
                                    onDateChange(newCal.timeInMillis)
                                },
                                c.get(Calendar.YEAR),
                                c.get(Calendar.MONTH),
                                c.get(Calendar.DAY_OF_MONTH)
                            ).show()
                        }
                        .padding(horizontal = 6.dp, vertical = 2.dp)
                ) {
                    Text(
                        SimpleDateFormat("dd MMMM yyyy", Locale("ru")).format(Date(selectedDate)),
                        fontWeight = FontWeight.Normal,
                        fontSize = 14.sp,
                        color = MaterialTheme.colorScheme.primary
                    )
                    if (selectedDate.toMidnight() == System.currentTimeMillis().toMidnight()) {
                        Text("Сегодня", fontSize = 10.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                    }
                }
                IconButton(onClick = { onDateChange(selectedDate + 86400000) }, modifier = Modifier.size(36.dp)) {
                    Icon(Icons.Default.KeyboardArrowRight, contentDescription = "Следующий день")
                }
            }

            // ПЛЮСИК СПРАВА
            Box {
                FilledIconButton(
                    onClick = {
                        addTransactionInitialType = "EXPENSE"
                        showAddTransactionDialog = true
                    },
                    modifier = Modifier.size(40.dp),
                    colors = IconButtonDefaults.filledIconButtonColors(
                        containerColor = Color(0xFF8BD3F8),
                        contentColor = Color.White
                    )
                ) {
                    Icon(Icons.Default.Add, contentDescription = "Добавить", modifier = Modifier.size(24.dp))
                }
            }
        }

        // СПИСОК ОПЕРАЦИЙ ЗА ВЫБРАННЫЙ ДЕНЬ (РАСХОДЫ, ДОХОДЫ, НАКОПЛЕНИЯ)
        if (dayRecords.isEmpty()) {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f),
                border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.35f)),
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp)
            ) {
                Column(
                    Modifier.padding(16.dp).fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "Нет операций за ${SimpleDateFormat("dd MMMM", Locale("ru")).format(Date(selectedDate))}",
                        fontSize = 12.sp,
                        color = Color.Gray,
                        fontWeight = FontWeight.Medium
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(
                            onClick = {
                                addTransactionInitialType = "EXPENSE"
                                showAddTransactionDialog = true
                            },
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.TrendingDown, null, tint = Color(0xFFD32F2F), modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Расход", color = Color(0xFFD32F2F), fontSize = 12.sp, fontWeight = FontWeight.Normal)
                        }
                        OutlinedButton(
                            onClick = {
                                addTransactionInitialType = "INCOME"
                                showAddTransactionDialog = true
                            },
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.TrendingUp, null, tint = Color(0xFF2E7D32), modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Доход", color = Color(0xFF2E7D32), fontSize = 12.sp, fontWeight = FontWeight.Normal)
                        }
                        OutlinedButton(
                            onClick = {
                                addTransactionInitialType = "BALANCE"
                                showAddTransactionDialog = true
                            },
                            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                        ) {
                            Icon(Icons.Default.Savings, null, tint = Color(0xFFFF9800), modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Накопление", color = Color(0xFFFF9800), fontSize = 12.sp, fontWeight = FontWeight.Normal)
                        }
                    }
                }
            }
        } else {
            Column(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                dayRecords.forEach { rec ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surface,
                        border = BorderStroke(0.8.dp, Color.LightGray.copy(alpha = 0.4f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                Modifier.size(10.dp).clip(CircleShape).background(rec.color)
                            )
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(rec.catName, fontWeight = catWeight, fontFamily = modernFontFamily, fontSize = 13.sp)
                                if (rec.note.isNotBlank()) {
                                    Text(rec.note, fontSize = 11.sp, fontFamily = modernFontFamily, color = Color.Gray, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            Text(
                                (if (rec.type == "INCOME" || rec.type == "BALANCE") "+" else "-") + mask(rec.amount, isIncognito) + " ₽",
                                fontWeight = numWeight,
                                fontSize = 13.sp,
                                letterSpacing = numSpacing,
                                fontFamily = modernFontFamily,
                                color = if (isColorFinance) (if (rec.type == "INCOME") Color(0xFF2E7D32) else if (rec.type == "BALANCE") Color(0xFFE65100) else Color(0xFFD32F2F)) else Color(0xFF0F172A)
                            )
                            Spacer(Modifier.width(6.dp))
                            IconButton(
                                onClick = {
                                    editingHistoryItem = Triple(rec.catId, rec.originalItem, rec.catName)
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Редактировать", tint = Color.Gray, modifier = Modifier.size(15.dp))
                            }
                            IconButton(
                                onClick = {
                                    updateHistoryItem(rec.catId, rec.originalItem, isDelete = true)
                                },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.DeleteOutline, contentDescription = "Удалить", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }

        // БЛОК ДОЛГОВ
        Card(Modifier.fillMaxWidth().padding(bottom = 8.dp).animateContentSize(), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0))) {
            Column(Modifier.padding(12.dp).clickable { debtsExpanded = !debtsExpanded }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.PriorityHigh, null, tint = Color(0xFFE65100))
                    Text(" ДОЛГИ АКТИВНЫЕ", fontWeight = titleWeight, letterSpacing = spacing, fontFamily = modernFontFamily, fontSize = 12.sp)
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = { showAddDebt = true }, Modifier.size(24.dp)) { Icon(Icons.Default.Add, null) }
                    Icon(if(debtsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null)
                }
                if (debtsExpanded) {
                    if(unpaidDebts.isEmpty()) Text("Долгов нет", fontSize = 11.sp, fontFamily = modernFontFamily, color = Color.Gray, modifier = Modifier.padding(top = 8.dp))
                    unpaidDebts.forEach { d ->
                        Row(Modifier.fillMaxWidth().padding(top = 8.dp).clickable { editingDebt = d }, verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(d.creditor, fontWeight = catWeight, fontFamily = modernFontFamily, fontSize = 13.sp)
                                val createdStr = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(if (d.createdAt > 0) d.createdAt else d.dueDate))
                                val dueStr = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(d.dueDate))
                                Text("Взят: $createdStr • Срок: $dueStr", fontSize = 10.sp, fontFamily = modernFontFamily, color = Color.Gray)
                            }
                            Text(mask(d.amount, isIncognito), fontWeight = numWeight, letterSpacing = numSpacing, fontFamily = modernFontFamily, color = if (isColorFinance) Color(0xFFD32F2F) else Color(0xFF0F172A))
                            IconButton(onClick = { editingDebt = d }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.Edit, contentDescription = "Редактировать долг", tint = Color.Gray, modifier = Modifier.size(16.dp))
                            }
                            IconButton(onClick = { scope.launch(Dispatchers.Default) { dao.updateDebt(d.copy(isPaid = true, paidDate = System.currentTimeMillis())) } }, modifier = Modifier.size(32.dp)) {
                                Icon(Icons.Default.CheckCircle, contentDescription = "Погасить долг", tint = Color(0xFF4CAF50), modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }
            }
        }

        // ОБЪЕДИНЕННАЯ СВОДКА КАПИТАЛА, АКТИВОВ И ДОЛГОВ
        Card(
            Modifier.fillMaxWidth().padding(bottom = 8.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(14.dp)) {
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("ЧИСТЫЙ КАПИТАЛ", fontSize = 11.sp, fontWeight = titleWeight, letterSpacing = spacing, fontFamily = modernFontFamily, color = Color(0xFF64748B))
                        Text(
                            mask(totalAssets - totalDebt, isIncognito),
                            fontSize = 24.sp,
                            fontWeight = numWeight,
                            letterSpacing = numSpacing,
                            fontFamily = modernFontFamily,
                            color = if (isColorFinance) (if (totalAssets - totalDebt >= 0) Color(0xFF0F172A) else Color(0xFFDC2626)) else Color(0xFF0F172A)
                        )
                    }
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFFF1F5F9)
                    ) {
                        Text(
                            if (totalAssets - totalDebt >= 0) "Профицит" else "Дефицит",
                            fontSize = 11.sp,
                            fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.SemiBold,
                            fontFamily = modernFontFamily,
                            color = if (isColorFinance) (if (totalAssets - totalDebt >= 0) Color(0xFF16A34A) else Color(0xFFDC2626)) else Color(0xFF0F172A),
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 10.dp), color = Color(0xFFF1F5F9))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column {
                        Text("Всего активы", fontSize = 11.sp, fontFamily = modernFontFamily, color = Color(0xFF64748B))
                        Text(mask(totalAssets, isIncognito), fontWeight = numWeight, fontSize = 14.sp, letterSpacing = numSpacing, fontFamily = modernFontFamily, color = if (isColorFinance) Color(0xFF16A34A) else Color(0xFF0F172A))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Всего долги", fontSize = 11.sp, fontFamily = modernFontFamily, color = Color(0xFF64748B))
                        Text(mask(totalDebt, isIncognito), fontWeight = numWeight, fontSize = 14.sp, letterSpacing = numSpacing, fontFamily = modernFontFamily, color = if (isColorFinance) Color(0xFFDC2626) else Color(0xFF0F172A))
                    }
                }
            }
        }

        Card(
            Modifier.fillMaxWidth().padding(bottom = 16.dp),
            colors = CardDefaults.cardColors(
                containerColor = if (isOverLimit) Color(0xFFFFEBEE) else Color.White
            ),
            border = BorderStroke(1.dp, if (isOverLimit) Color(0xFFD32F2F) else Color(0xFFE2E8F0)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(12.dp)) {
                // ПЕРЕКЛЮЧАТЕЛЬ ПЕРИОДОВ (МЕСЯЦ, ПОЛГОДА, ГОД, ДИАПАЗОН)
                Row(
                    Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier.background(Color.White.copy(alpha = 0.7f), RoundedCornerShape(8.dp)).padding(2.dp)
                    ) {
                        listOf(
                            "MONTH" to "Месяц",
                            "HALF_YEAR" to "Полгода",
                            "YEAR" to "Год",
                            "CUSTOM" to "Диапазон"
                        ).forEach { (mode, label) ->
                            val isSel = summaryPeriodMode == mode
                            Surface(
                                onClick = {
                                    summaryPeriodMode = mode
                                    if (mode == "CUSTOM") showCustomRangeDialog = true
                                },
                                shape = RoundedCornerShape(6.dp),
                                color = if (isSel) MaterialTheme.colorScheme.primary else Color.Transparent
                            ) {
                                Text(
                                    label,
                                    fontSize = 11.sp,
                                    fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.Bold,
                                    fontFamily = modernFontFamily,
                                    color = if (isSel) Color.White else Color.DarkGray,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Кнопка Лимита
                    Surface(
                        onClick = { showLimitDialog = true },
                        shape = RoundedCornerShape(8.dp),
                        color = if (isOverLimit) Color(0xFFD32F2F).copy(alpha = 0.15f) else if (expenseLimit > 0) MaterialTheme.colorScheme.primary.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface.copy(alpha = 0.7f),
                        border = BorderStroke(1.dp, if (isOverLimit) Color(0xFFD32F2F) else if (expenseLimit > 0) MaterialTheme.colorScheme.primary.copy(alpha = 0.4f) else Color.Gray.copy(alpha = 0.4f))
                    ) {
                        Row(
                            Modifier.padding(horizontal = 7.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (isOverLimit) Icons.Default.PriorityHigh else Icons.Default.Edit,
                                null,
                                modifier = Modifier.size(12.dp),
                                tint = if (isOverLimit) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary
                            )
                            Spacer(Modifier.width(3.dp))
                            Text(
                                if (expenseLimit > 0) "Лимит: ${mask(expenseLimit, isIncognito)}" else "Лимит",
                                fontSize = 11.sp,
                                fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.Bold,
                                fontFamily = modernFontFamily,
                                color = if (isOverLimit) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                }

                // ЗАГОЛОВОК С КНОПКАМИ ПЕРЕЛИСТЫВАНИЯ (НАПРИМЕР ОКТЯБРЬ -> СЕНТЯБРЬ)
                Row(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            if (isOverLimit) {
                                Icon(Icons.Default.PriorityHigh, null, tint = Color(0xFFD32F2F), modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                            }

                            if (summaryPeriodMode == "MONTH") {
                                IconButton(
                                    onClick = {
                                        summaryCal = (summaryCal.clone() as Calendar).apply { add(Calendar.MONTH, -1) }
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ChevronLeft, "Предыдущий месяц", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(2.dp))
                                Text(
                                    summaryTitleText,
                                    fontWeight = headerWeight,
                                    letterSpacing = spacing,
                                    fontFamily = modernFontFamily,
                                    fontSize = 11.sp,
                                    color = if (isOverLimit) Color(0xFFC62828) else Color.Unspecified
                                )
                                Spacer(Modifier.width(2.dp))
                                IconButton(
                                    onClick = {
                                        summaryCal = (summaryCal.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ChevronRight, "Следующий месяц", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }

                                val isDiff = summaryCal.get(Calendar.MONTH) != Calendar.getInstance().get(Calendar.MONTH) || summaryCal.get(Calendar.YEAR) != Calendar.getInstance().get(Calendar.YEAR)
                                if (isDiff) {
                                    Text(
                                        "К текущему",
                                        fontSize = 10.sp,
                                        fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.Bold,
                                        fontFamily = modernFontFamily,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.clickable {
                                            summaryCal = Calendar.getInstance().apply { timeInMillis = selectedDate }
                                        }.padding(start = 4.dp)
                                    )
                                }
                            } else if (summaryPeriodMode == "YEAR") {
                                IconButton(
                                    onClick = {
                                        summaryCal = (summaryCal.clone() as Calendar).apply { add(Calendar.YEAR, -1) }
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ChevronLeft, "Предыдущий год", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                                Spacer(Modifier.width(2.dp))
                                Text(
                                    summaryTitleText,
                                    fontWeight = headerWeight,
                                    letterSpacing = spacing,
                                    fontFamily = modernFontFamily,
                                    fontSize = 11.sp,
                                    color = if (isOverLimit) Color(0xFFC62828) else Color.Unspecified
                                )
                                Spacer(Modifier.width(2.dp))
                                IconButton(
                                    onClick = {
                                        summaryCal = (summaryCal.clone() as Calendar).apply { add(Calendar.YEAR, 1) }
                                    },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.ChevronRight, "Следующий год", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                            } else {
                                Text(
                                    summaryTitleText,
                                    fontWeight = headerWeight,
                                    letterSpacing = spacing,
                                    fontFamily = modernFontFamily,
                                    fontSize = 11.sp,
                                    color = if (isOverLimit) Color(0xFFC62828) else Color.Unspecified
                                )
                                if (summaryPeriodMode == "CUSTOM") {
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        "Выбрать",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.clickable { showCustomRangeDialog = true }
                                    )
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 1.dp)) {
                            Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(12.dp))
                            Spacer(Modifier.width(3.dp))
                            Text(
                                "Нажмите на раздел для деталей",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    }
                }

                if (expenseLimit > 0) {
                    Spacer(Modifier.height(6.dp))
                    Column(Modifier.fillMaxWidth().clickable { showLimitDialog = true }) {
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (isOverLimit) "⚠️ Превышение лимита на ${mask(limitTargetExpenses - expenseLimit, isIncognito)}!"
                                else "Остаток лимита: ${mask(expenseLimit - limitTargetExpenses, isIncognito)}",
                                fontSize = 11.sp,
                                fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.Bold,
                                color = if (isOverLimit) Color(0xFFD32F2F) else Color(0xFF2E7D32)
                            )
                            Text(
                                "${mask(limitTargetExpenses, isIncognito)} / ${mask(expenseLimit, isIncognito)} (${expensePct}%)",
                                fontSize = 10.sp,
                                fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.SemiBold,
                                color = if (isOverLimit) Color(0xFFD32F2F) else Color.Gray
                            )
                        }
                        LinearProgressIndicator(
                            progress = { (limitTargetExpenses / expenseLimit).toFloat().coerceIn(0f, 1f) },
                            modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 4.dp).height(5.dp).clip(RoundedCornerShape(3.dp)),
                            color = if (isOverLimit) Color(0xFFD32F2F) else MaterialTheme.colorScheme.primary,
                            trackColor = if (isOverLimit) Color(0xFFFFCDD2) else MaterialTheme.colorScheme.surfaceVariant
                        )
                        if (excludedExpensesTotal > 0.0) {
                            Text(
                                "В лимите: ${mask(limitTargetExpenses, isIncognito)} • Вне лимита: ${mask(excludedExpensesTotal, isIncognito)}",
                                fontSize = 10.sp,
                                color = Color(0xFFE65100),
                                fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.SemiBold,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }
                }

                // ВЕРХНИЕ СВОДНЫЕ ПЛИТКИ (КЛИКАБЕЛЬНЫЕ)
                Row(
                    Modifier.fillMaxWidth().padding(top = 8.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Surface(
                        onClick = {
                            showAllIncomeDialog = true
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.9f),
                        border = BorderStroke(1.dp, Color(0xFF2E7D32).copy(alpha = 0.3f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(Modifier.padding(6.dp)) {
                            Text("ДОХОД", fontSize = 9.sp, fontWeight = titleWeight, letterSpacing = spacing, color = Color.Gray)
                            Text("+${mask(totalMonthIncome, isIncognito)}", fontSize = 12.sp, fontWeight = numWeight, color = if (isColorFinance) Color(0xFF2E7D32) else Color(0xFF0F172A), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("все доходы", fontSize = 8.sp, fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.SemiBold, color = if (isColorFinance) Color(0xFF2E7D32).copy(alpha = 0.8f) else Color.Gray)
                        }
                    }

                    Surface(
                        onClick = {
                            showAllExpenseDialog = true
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.9f),
                        border = BorderStroke(1.dp, if (isOverLimit) Color(0xFFD32F2F) else Color(0xFFD32F2F).copy(alpha = 0.3f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(Modifier.padding(6.dp)) {
                            Text("РАСХОД", fontSize = 9.sp, fontWeight = titleWeight, letterSpacing = spacing, color = Color.Gray)
                            Text("-${mask(totalMonthExpenses, isIncognito)}", fontSize = 12.sp, fontWeight = numWeight, color = if (isColorFinance) (if (isOverLimit) Color(0xFFD32F2F) else Color(0xFFB71C1C)) else Color(0xFF0F172A), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text("все траты", fontSize = 8.sp, fontWeight = if (isModernFont) FontWeight.Normal else FontWeight.SemiBold, color = if (isOverLimit) Color(0xFFD32F2F) else Color.Gray)
                        }
                    }

                    Surface(
                        onClick = {
                            showAllInvestDialog = true
                        },
                        shape = RoundedCornerShape(8.dp),
                        color = Color.White.copy(alpha = 0.9f),
                        border = BorderStroke(1.dp, Color(0xFFE65100).copy(alpha = 0.3f)),
                        modifier = Modifier.weight(1f)
                    ) {
                        Column(Modifier.padding(6.dp)) {
                            Text("ИНВЕСТ БАЛАНС", fontSize = 9.sp, fontWeight = titleWeight, letterSpacing = spacing, color = Color.Gray)
                            Text(mask(totalInvestBalance, isIncognito), fontSize = 12.sp, fontWeight = numWeight, color = if (isColorFinance) Color(0xFFE65100) else Color(0xFF0F172A), maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                if (totalMonthDeposits != 0.0) "${if (totalMonthDeposits > 0) "+" else ""}${mask(totalMonthDeposits, isIncognito)}"
                                else "все активы",
                                fontSize = 8.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isColorFinance) Color(0xFFE65100).copy(alpha = 0.8f) else Color.Gray,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // ПОЛНЫЙ СТРУКТУРИРОВАННЫЙ СПИСОК ПО РАЗДЕЛАМ (ИТОГИ МЕСЯЦА СПИСКОМ)
                Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                    val visibleIncomeSections = allIncomeSections.filter { it.total > 0 }
                    val visibleExpenseSections = allExpenseSections.filter { it.total > 0 }
                    val visibleBalanceSections = allBalanceSections.filter { it.total != 0.0 || (it.balance ?: 0.0) != 0.0 }

                    // ГРУППА ДОХОДОВ
                        if (visibleIncomeSections.isNotEmpty()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { showAllIncomeDialog = true }
                                    .padding(vertical = 4.dp, horizontal = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "ПОСТУПЛЕНИЯ / ДОХОДЫ (${visibleIncomeSections.size})",
                                    fontSize = 10.sp,
                                    fontWeight = headerWeight,
                                    letterSpacing = spacing,
                                    fontFamily = modernFontFamily,
                                    color = if (isColorFinance) Color(0xFF2E7D32) else Color(0xFF0F172A)
                                )
                                Text("Все доходы →", fontSize = 10.sp, fontWeight = titleWeight, fontFamily = modernFontFamily, color = if (isColorFinance) Color(0xFF2E7D32) else Color(0xFF0F172A))
                            }
                            visibleIncomeSections.forEach { sec ->
                                val pct = if (totalMonthIncome > 0) ((sec.total / totalMonthIncome) * 100).toInt() else 0
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { selectedCategoryForDetail = sec }
                                        .padding(vertical = 4.dp, horizontal = 4.dp)
                                ) {
                                    Box(Modifier.size(10.dp).clip(CircleShape).background(sec.color))
                                    Spacer(Modifier.width(8.dp))
                                    Text(sec.name, fontSize = 12.sp, fontWeight = catWeight, fontFamily = modernFontFamily, modifier = Modifier.weight(1f))
                                    Text("+${mask(sec.total, isIncognito)}", fontSize = 12.sp, fontWeight = numWeight, letterSpacing = numSpacing, fontFamily = modernFontFamily, color = if (isColorFinance) Color(0xFF2E7D32) else Color(0xFF0F172A))
                                    Text(" ($pct%)", fontSize = 10.sp, color = Color.Gray, fontFamily = modernFontFamily, modifier = Modifier.padding(start = 4.dp))
                                    Spacer(Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { editingSectionInfo = Triple(sec.id, sec.name, sec.id != "inc") },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.MoreVert, "Опции", modifier = Modifier.size(16.dp), tint = Color.Gray)
                                    }
                                }
                            }
                        }

                        // ГРУППА РАСХОДОВ
                        if (visibleExpenseSections.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { showAllExpenseDialog = true }
                                    .padding(vertical = 4.dp, horizontal = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "ТРАТЫ / РАСХОДЫ (${visibleExpenseSections.size})",
                                    fontSize = 10.sp,
                                    fontWeight = headerWeight,
                                    letterSpacing = spacing,
                                    fontFamily = modernFontFamily,
                                    color = if (isColorFinance) Color(0xFFD32F2F) else Color(0xFF0F172A)
                                )
                                Text("Все расходы →", fontSize = 10.sp, fontWeight = titleWeight, fontFamily = modernFontFamily, color = if (isColorFinance) Color(0xFFD32F2F) else Color(0xFF0F172A))
                            }
                            visibleExpenseSections.forEach { sec ->
                                val pct = if (totalMonthExpenses > 0) ((sec.total / totalMonthExpenses) * 100).toInt() else 0
                                val label = sec.name + (if (sec.isExcluded) " (вне лимита)" else "")
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { selectedCategoryForDetail = sec }
                                        .then(
                                            if (isOverLimit && !sec.isExcluded) Modifier.background(Color(0xFFFFCDD2).copy(alpha = 0.5f))
                                             else Modifier
                                        )
                                        .padding(vertical = 4.dp, horizontal = 4.dp)
                                ) {
                                    Box(Modifier.size(10.dp).clip(CircleShape).background(sec.color))
                                    Spacer(Modifier.width(8.dp))
                                    Text(label, fontSize = 12.sp, fontWeight = catWeight, fontFamily = modernFontFamily, modifier = Modifier.weight(1f))
                                    Text("-${mask(sec.total, isIncognito)}", fontSize = 12.sp, fontWeight = numWeight, letterSpacing = numSpacing, fontFamily = modernFontFamily, color = if (isColorFinance) (if (sec.isExcluded) Color(0xFFE65100) else Color(0xFFD32F2F)) else Color(0xFF0F172A))
                                    Text(" ($pct%)", fontSize = 10.sp, color = Color.Gray, fontFamily = modernFontFamily, modifier = Modifier.padding(start = 4.dp))
                                    Spacer(Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { editingSectionInfo = Triple(sec.id, sec.name, sec.id != "exp") },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.MoreVert, "Опции", modifier = Modifier.size(16.dp), tint = Color.Gray)
                                    }
                                }
                            }
                        }

                        // ГРУППА НАКОПЛЕНИЙ / БАЛАНСОВ / ИНВЕСТИЦИЙ
                        if (visibleBalanceSections.isNotEmpty()) {
                            Spacer(Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp, top = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    "НАКОПЛЕНИЯ / БАЛАНСЫ / ИНВЕСТИЦИИ (${visibleBalanceSections.size})",
                                    fontSize = 10.sp,
                                    fontWeight = headerWeight,
                                    letterSpacing = spacing,
                                    fontFamily = modernFontFamily,
                                    color = if (isColorFinance) Color(0xFFE65100) else Color(0xFF0F172A)
                                )
                                Text(
                                    "Всего: ${mask(totalInvestBalance, isIncognito)}",
                                    fontSize = 10.sp,
                                    fontWeight = numWeight,
                                    letterSpacing = numSpacing,
                                    fontFamily = modernFontFamily,
                                    color = if (isColorFinance) Color(0xFFE65100) else Color(0xFF0F172A)
                                )
                            }
                            visibleBalanceSections.forEach { sec ->
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { selectedCategoryForDetail = sec }
                                        .padding(vertical = 4.dp, horizontal = 4.dp)
                                ) {
                                    Box(Modifier.size(10.dp).clip(CircleShape).background(sec.color))
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(sec.name, fontSize = 12.sp, fontWeight = catWeight, fontFamily = modernFontFamily)
                                        Text(
                                            if (sec.total != 0.0) "за месяц: ${if (sec.total > 0) "+" else ""}${mask(sec.total, isIncognito)}"
                                            else "за месяц: 0 ₽",
                                            fontSize = 10.sp,
                                            fontFamily = modernFontFamily,
                                            color = Color.Gray
                                        )
                                    }
                                    Text(mask(sec.balance ?: 0.0, isIncognito), fontSize = 12.sp, fontWeight = numWeight, letterSpacing = numSpacing, fontFamily = modernFontFamily, color = if (isColorFinance) Color(0xFFE65100) else Color(0xFF0F172A))
                                    Spacer(Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { editingBalanceCat = Pair(sec.id, sec.name) },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, "Изменить баланс", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                                    }
                                    IconButton(
                                        onClick = { editingSectionInfo = Triple(sec.id, sec.name, sec.id != "dep") },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.MoreVert, "Опции", modifier = Modifier.size(16.dp), tint = Color.Gray)
                                    }
                                }
                            }
                        }
                    }

            }
        }

        // РАЗДЕЛ: МОЯ МАШИНА / ГАРАЖ (НАД ЦЕЛЯМИ)
        if (hasCar) {
            CarGarageSection(
                cars = cars,
                events = carEvents,
                reminders = carReminders,
                isIncognito = isIncognito,
                onSelectCar = { selectedCarForDetail = it },
                onAddCar = {
                    editingCar = null
                    showAddCarDialog = true
                },
                onAddEvent = { car, defType ->
                    eventCarTarget = car
                    eventDefaultType = defType
                    editingCarEvent = null
                    showAddCarEventDialog = true
                },
                onAddMileage = { car ->
                    mileageCarTarget = car
                    showAddMileageDialog = true
                },
                onAddReminder = { car ->
                    reminderCarTarget = car
                    editingCarReminder = null
                    showAddReminderDialog = true
                }
            )
        }

        // БЛОК: ЦЕЛИ НА МЕСЯЦ
        val currentMonthKey = "${cal.get(Calendar.YEAR)}-${cal.get(Calendar.MONTH)}"
        val currentMonthName = SimpleDateFormat("LLLL yyyy", Locale("ru")).format(Date(selectedDate)).replaceFirstChar { it.uppercase() }
        val monthGoals = savingsGoals.filter { it.monthKey.isEmpty() || it.monthKey == currentMonthKey }
        val completedGoalsCount = monthGoals.count { g ->
            val sec = allBalanceSections.find { it.id == g.categoryId }
            val cur = if (g.trackMode == "TOTAL_BALANCE") (sec?.balance ?: getFullBalance(g.categoryId, selectedDate)) else (sec?.total ?: 0.0)
            g.targetAmount > 0 && cur >= g.targetAmount
        }

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .animateContentSize(),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Column(Modifier.padding(12.dp)) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { goalsExpanded = !goalsExpanded },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Savings,
                        contentDescription = null,
                        tint = if (isColorFinance) Color(0xFF2E7D32) else Color(0xFF0F172A),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        "ЦЕЛИ НА МЕСЯЦ",
                        fontWeight = numWeight,
                        fontSize = 11.sp,
                        color = Color(0xFF0F172A)
                    )
                    if (monthGoals.isNotEmpty()) {
                        Spacer(Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (completedGoalsCount == monthGoals.size && monthGoals.isNotEmpty()) (if (isColorFinance) Color(0xFF2E7D32) else Color(0xFF0F172A)) else (if (isColorFinance) Color(0xFF81C784).copy(alpha = 0.35f) else Color(0xFFE2E8F0))
                        ) {
                            Text(
                                "$completedGoalsCount/${monthGoals.size}",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (completedGoalsCount == monthGoals.size && monthGoals.isNotEmpty()) Color.White else (if (isColorFinance) Color(0xFF1B5E20) else Color(0xFF0F172A)),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(
                        onClick = {
                            editingGoal = null
                            showAddGoalDialog = true
                        },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            Icons.Default.AddCircleOutline,
                            contentDescription = "Добавить цель",
                            tint = if (isColorFinance) Color(0xFF2E7D32) else Color(0xFF0F172A),
                            modifier = Modifier.size(18.dp)
                        )
                    }
                    IconButton(
                        onClick = { goalsExpanded = !goalsExpanded },
                        modifier = Modifier.size(26.dp)
                    ) {
                        Icon(
                            if (goalsExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                            contentDescription = null,
                            tint = Color.Gray,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }

                if (goalsExpanded) {
                    Spacer(Modifier.height(8.dp))
                    if (monthGoals.isEmpty()) {
                        Text(
                            "У вас пока нет финансовых целей на этот месяц. Нажмите «+», чтобы запланировать накопление.",
                            fontSize = 11.sp,
                            color = Color.Gray,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    } else {
                        monthGoals.forEach { goal ->
                            val sec = allBalanceSections.find { it.id == goal.categoryId }
                            val catName = sec?.name ?: (sectionNames[goal.categoryId] ?: "Категория")
                            val currentAmount = if (goal.trackMode == "TOTAL_BALANCE") {
                                sec?.balance ?: getFullBalance(goal.categoryId, selectedDate)
                            } else {
                                sec?.total ?: 0.0
                            }
                            val target = goal.targetAmount
                            val progress = if (target > 0) (currentAmount / target).coerceIn(0.0, 1.0).toFloat() else 0f
                            val isReached = target > 0 && currentAmount >= target

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isReached) Color(0xFFE8F5E9) else Color(0xFFF8FAFC),
                                border = BorderStroke(1.dp, if (isReached) Color(0xFF81C784) else Color(0xFFE2E8F0)),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp)
                            ) {
                                Column(Modifier.padding(8.dp)) {
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                            if (isReached) {
                                                Icon(
                                                    Icons.Default.CheckCircle,
                                                    contentDescription = null,
                                                    tint = Color(0xFF2E7D32),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(Modifier.width(4.dp))
                                            }
                                            Text(
                                                goal.title,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                        }
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            IconButton(
                                                onClick = {
                                                    editingGoal = goal
                                                    showAddGoalDialog = true
                                                },
                                                modifier = Modifier.size(22.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.Edit,
                                                    contentDescription = "Редактировать",
                                                    tint = Color.Gray,
                                                    modifier = Modifier.size(13.dp)
                                                )
                                            }
                                            IconButton(
                                                onClick = { onDeleteGoal(goal.id) },
                                                modifier = Modifier.size(22.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.DeleteOutline,
                                                    contentDescription = "Удалить",
                                                    tint = Color.Gray,
                                                    modifier = Modifier.size(13.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(Modifier.height(4.dp))
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            "«$catName» • ${if (goal.trackMode == "TOTAL_BALANCE") "Все накопления" else "Отложено за месяц"}",
                                            fontSize = 10.sp,
                                            color = Color.Gray
                                        )
                                        Text(
                                            "${mask(currentAmount, isIncognito)} / ${mask(target, isIncognito)} ₽ (${(progress * 100).toInt()}%)",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold,
                                            color = if (isReached) Color(0xFF2E7D32) else Color(0xFF0F172A)
                                        )
                                    }

                                    Spacer(Modifier.height(4.dp))
                                    LinearProgressIndicator(
                                        progress = { progress },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp)),
                                        color = if (isReached) Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary,
                                        trackColor = Color(0xFFE2E8F0)
                                    )

                                    Spacer(Modifier.height(3.dp))
                                    Row(
                                        Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        if (isReached) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Icon(
                                                    Icons.Default.Celebration,
                                                    null,
                                                    tint = Color(0xFF2E7D32),
                                                    modifier = Modifier.size(12.dp)
                                                )
                                                Spacer(Modifier.width(2.dp))
                                                Text(
                                                    "Цель достигнута!",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF2E7D32)
                                                )
                                            }
                                        } else {
                                            val remaining = maxOf(0.0, target - currentAmount)
                                            Text(
                                                "Осталось накопить: ${mask(remaining, isIncognito)} ₽",
                                                fontSize = 10.sp,
                                                color = Color.Gray
                                            )
                                        }
                                        if (goal.monthKey.isNotEmpty()) {
                                            Text("Только $currentMonthName", fontSize = 9.sp, color = Color.Gray)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (showAddGoalDialog) {
            SavingsGoalDialog(
                goal = editingGoal,
                balanceCategories = allBalanceSections,
                currentMonthKey = currentMonthKey,
                currentMonthName = currentMonthName,
                onDismiss = {
                    showAddGoalDialog = false
                    editingGoal = null
                },
                onSave = {
                    onSaveGoal(it)
                    showAddGoalDialog = false
                    editingGoal = null
                },
                onDelete = {
                    onDeleteGoal(it)
                    showAddGoalDialog = false
                    editingGoal = null
                }
            )
        }

        // ВОССТАНОВЛЕННЫЙ БЛОК: ПЛАН ДО КОНЦА МЕСЯЦА (ПОД ЦЕЛЯМИ)
        val remInc = expected.filter { it.isIncome && it.dayOfMonth >= todayDay }.sumOf { it.amount }
        val remExp = expected.filter { !it.isIncome && it.dayOfMonth >= todayDay }.sumOf { it.amount }
        Card(
            Modifier.fillMaxWidth().padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            border = BorderStroke(1.dp, Color(0xFFE2E8F0)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Row(Modifier.padding(12.dp).fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ПЛАН ДО КОНЦА МЕСЯЦА", fontSize = 10.sp, fontWeight = titleWeight, letterSpacing = spacing, fontFamily = modernFontFamily, color = Color(0xFF0F172A))
                    Row {
                        Text("+${mask(remInc, isIncognito)}", color = if (isColorFinance) Color(0xFF2E7D32) else Color(0xFF0F172A), fontWeight = numWeight, letterSpacing = numSpacing, fontFamily = modernFontFamily)
                        Spacer(Modifier.width(12.dp))
                        Text("-${mask(remExp, isIncognito)}", color = if (isColorFinance) Color(0xFFD32F2F) else Color(0xFF0F172A), fontWeight = numWeight, letterSpacing = numSpacing, fontFamily = modernFontFamily)
                    }
                }
                IconButton(onClick = { showAddExpected = true }) { Icon(Icons.Default.EditCalendar, null, tint = if (isColorFinance) Color(0xFF7B1FA2) else Color(0xFF0F172A)) }
                IconButton(onClick = { showUpcomingSheet = true }) { Icon(Icons.Default.CalendarMonth, null, tint = if (isColorFinance) Color(0xFF7B1FA2) else Color(0xFF0F172A)) }
            }
        }





        // УПРАВЛЕНИЕ РАЗДЕЛАМИ
        if (hiddenSections.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            OutlinedButton(onClick = {
                hiddenSections.forEach { restoreSection(it) }
            }, modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Restore, null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.width(4.dp))
                Text("Восстановить скрытые разделы", fontSize = 12.sp)
            }
        }
    }

    // ДИАЛОГ УПРАВЛЕНИЯ РАЗДЕЛОМ (ПЕРЕИМЕНОВАНИЕ, ИКОНКА, ЦВЕТ И УДАЛЕНИЕ)
    if (editingSectionInfo != null) {
        val (secId, currentName, isCustom) = editingSectionInfo!!
        val matchedCat = categories.find { it.id == secId }
        var newTitle by remember { mutableStateOf(currentName) }
        val isExpCat = secId == "exp" || categories.any { it.id == secId && it.type == CatType.HISTORY }
        var isExcluded by remember { mutableStateOf(excludedFromLimit.contains(secId)) }

        val colors = listOf(0xFF2E7D32, 0xFF00897B, 0xFF43A047, 0xFF673AB7, 0xFF009688, 0xFF2196F3, 0xFFFF5722, 0xFF795548, 0xFF607D8B, 0xFFE91E63)
        var selectedColor by remember { mutableStateOf(matchedCat?.color ?: 0xFF2196F3.toInt()) }
        var selectedIconKey by remember { mutableStateOf(matchedCat?.iconKey ?: "") }
        var selectedCustomUri by remember { mutableStateOf(matchedCat?.customIconUri ?: "") }

        AlertDialog(
            onDismissRequest = { editingSectionInfo = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(selectedColor)),
                        contentAlignment = Alignment.Center
                    ) {
                        CategoryIconDisplay(
                            iconKey = selectedIconKey,
                            customIconUri = selectedCustomUri,
                            categoryName = newTitle,
                            categoryId = secId,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Раздел: $currentName")
                }
            },
            text = {
                Column(modifier = Modifier.fillMaxWidth().verticalScroll(rememberScrollState())) {
                    OutlinedTextField(
                        value = newTitle,
                        onValueChange = { newTitle = it },
                        label = { Text("Название раздела") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(12.dp))

                    // Блок выбора иконки / загрузки своего фото
                    CategoryIconSelectorView(
                        selectedIconKey = selectedIconKey,
                        selectedCustomUri = selectedCustomUri,
                        accentColor = Color(selectedColor),
                        onSelectPreset = { selectedIconKey = it },
                        onSelectCustomUri = { selectedCustomUri = it },
                        onClearCustomUri = { selectedCustomUri = "" }
                    )

                    if (matchedCat != null) {
                        Spacer(Modifier.height(12.dp))
                        Text("ЦВЕТ:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(Modifier.height(6.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(colors) { cInt ->
                                val isSel = selectedColor == cInt.toInt()
                                Box(
                                    modifier = Modifier
                                        .size(32.dp)
                                        .clip(CircleShape)
                                        .background(Color(cInt))
                                        .border(if (isSel) 2.5.dp else 0.5.dp, if (isSel) MaterialTheme.colorScheme.primary else Color.White, CircleShape)
                                    .clickable { selectedColor = cInt.toInt() },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (isSel) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    if (isExpCat) {
                        Spacer(Modifier.height(12.dp))
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { isExcluded = !isExcluded }
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isExcluded,
                                onCheckedChange = { isExcluded = it }
                            )
                            Spacer(Modifier.width(8.dp))
                            Column {
                                Text("Не учитывать в лимите расходов", fontSize = 12.sp, fontWeight = FontWeight.Normal)
                                Text("Траты из этого раздела не влияют на лимит (например: оплата квартиры)", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (newTitle.isNotBlank()) {
                        renameSection(secId, newTitle)
                        if (matchedCat != null) {
                            val updated = categories.map { c ->
                                if (c.id == secId) c.copy(name = newTitle.trim(), iconKey = selectedIconKey, customIconUri = selectedCustomUri, color = selectedColor)
                                else c
                            }
                            categories = updated
                            prefs.edit().putString("list", Gson().toJson(updated)).apply()
                        }
                    }
                    if (isExpCat) {
                        val newSet = if (isExcluded) excludedFromLimit + secId else excludedFromLimit - secId
                        excludedFromLimit = newSet
                        saveExcludedFromLimit(context, newSet)
                    }
                    editingSectionInfo = null
                }) { Text("Сохранить") }
            },
            dismissButton = {
                TextButton(onClick = {
                    deleteSection(secId)
                    editingSectionInfo = null
                }) { Text("Удалить раздел", color = Color.Red) }
            }
        )
    }

    if (showAddDebt || editingDebt != null) {
        val targetDebt = editingDebt
        DebtDialog(
            targetDebt,
            { showAddDebt = false; editingDebt = null },
            { c, a, d, start ->
                showAddDebt = false
                editingDebt = null
                scope.launch(Dispatchers.Default) {
                    if (targetDebt != null && targetDebt.id != 0) {
                        dao.updateDebt(targetDebt.copy(creditor = c, amount = a, dueDate = d, createdAt = start))
                    } else {
                        dao.saveDebt(DiaryDebt(creditor = c, amount = a, dueDate = d, createdAt = start))
                    }
                    try {
                        ReminderManager.checkAndSendReminders(context, dao)
                    } catch (_: Throwable) {}
                }
            }
        )
    }

    if (showAddCat) {
        var name by remember { mutableStateOf("") }
        var type by remember(showAddCat, addCatInitialType) { mutableStateOf(addCatInitialType) }
        val colors = listOf(0xFF2E7D32, 0xFF00897B, 0xFF43A047, 0xFF673AB7, 0xFF009688, 0xFF2196F3, 0xFFFF5722, 0xFF795548, 0xFF607D8B, 0xFFE91E63)
        var selectedColor by remember { mutableStateOf(colors[categories.size % colors.size].toInt()) }
        var selectedIconKey by remember(showAddCat, addCatInitialType) {
            mutableStateOf(
                when (addCatInitialType) {
                    CatType.INCOME -> "income"
                    CatType.BALANCE -> "savings"
                    else -> "cart"
                }
            )
        }
        var selectedCustomUri by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showAddCat = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(24.dp)
                            .clip(CircleShape)
                            .background(Color(selectedColor)),
                        contentAlignment = Alignment.Center
                    ) {
                        CategoryIconDisplay(
                            iconKey = selectedIconKey,
                            customIconUri = selectedCustomUri,
                            tint = Color.White,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Text("Новый раздел")
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                ) {
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Название (напр. Продукты, Сбер, Кафе)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))

                    Text("ТИП РАЗДЕЛА:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(type == CatType.INCOME, {
                            type = CatType.INCOME
                            if (selectedIconKey == "cart") selectedIconKey = "income"
                        })
                        Text("История (Доходы)", fontSize = 12.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(type == CatType.HISTORY, {
                            type = CatType.HISTORY
                            if (selectedIconKey == "income") selectedIconKey = "cart"
                        })
                        Text("История (Траты)", fontSize = 12.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(type == CatType.BALANCE, {
                            type = CatType.BALANCE
                            if (selectedIconKey == "income" || selectedIconKey == "cart") selectedIconKey = "savings"
                        })
                        Text("Баланс (Переносится)", fontSize = 12.sp)
                    }

                    Spacer(Modifier.height(12.dp))

                    // Блок выбора иконки / загрузки фото
                    CategoryIconSelectorView(
                        selectedIconKey = selectedIconKey,
                        selectedCustomUri = selectedCustomUri,
                        accentColor = Color(selectedColor),
                        onSelectPreset = { selectedIconKey = it },
                        onSelectCustomUri = { selectedCustomUri = it },
                        onClearCustomUri = { selectedCustomUri = "" }
                    )

                    Spacer(Modifier.height(12.dp))

                    // Выбор цвета
                    Text("ЦВЕТ:", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(colors) { cInt ->
                            val isSel = selectedColor == cInt.toInt()
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(Color(cInt))
                                    .border(if (isSel) 2.5.dp else 0.5.dp, if (isSel) MaterialTheme.colorScheme.primary else Color.White, CircleShape)
                                    .clickable { selectedColor = cInt.toInt() },
                                contentAlignment = Alignment.Center
                            ) {
                                if (isSel) Icon(Icons.Default.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    if (name.isNotBlank()) {
                        val newCat = CategoryConfig(
                            id = "cat_${System.currentTimeMillis()}",
                            name = name.trim(),
                            color = selectedColor,
                            type = type,
                            iconKey = selectedIconKey,
                            customIconUri = selectedCustomUri
                        )
                        val newList = categories + newCat
                        categories = newList
                        prefs.edit().putString("list", Gson().toJson(newList)).apply()
                        newlyCreatedCatId = newCat.id
                        showAddCat = false
                    }
                }) { Text("Создать") }
            },
            dismissButton = {
                TextButton(onClick = { showAddCat = false }) { Text("Отмена") }
            }
        )
    }

    // ВОССТАНОВЛЕННЫЕ ДИАЛОГИ: ПЛАН ПЛАТЕЖЕЙ (Чек-лист v.2.13.7)
    if (showAddExpected) {
        ExpectedFinanceDialog(
            items = expected,
            todayDay = todayDay,
            onDismiss = { showAddExpected = false },
            onSave = {
                scope.launch(Dispatchers.Default) {
                    dao.saveExpectedFinance(it)
                    try {
                        ReminderManager.checkAndSendReminders(context, dao)
                    } catch (_: Throwable) {}
                }
            },
            onDelete = { scope.launch { dao.deleteExpectedFinance(it) } }
        )
    }

    if (showUpcomingSheet) {
        ModalBottomSheet(onDismissRequest = { showUpcomingSheet = false }) {
            Column(Modifier.fillMaxWidth().padding(16.dp).padding(bottom = 32.dp)) {
                Text("Ближайшие платежи до конца месяца", fontWeight = titleWeight, fontSize = 18.sp)
                val upcoming = expected.filter { it.dayOfMonth >= todayDay }.sortedBy { it.dayOfMonth }
                if (upcoming.isEmpty()) {
                    Text("Платежей до конца месяца нет", modifier = Modifier.padding(top = 16.dp), color = Color.Gray)
                } else {
                    LazyColumn(Modifier.padding(top = 8.dp)) {
                        items(upcoming) { f ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text("${f.dayOfMonth}-е", Modifier.width(44.dp), fontWeight = FontWeight.Normal, color = MaterialTheme.colorScheme.primary)
                                Text(f.title, Modifier.weight(1f), fontSize = 14.sp)
                                Text(
                                    "${if(f.isIncome) "+" else "-"}${mask(f.amount, isIncognito)}",
                                    color = if(f.isIncome) Color(0xFF2E7D32) else Color(0xFFD32F2F),
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showLimitDialog) {
        var inputLimit by remember(showLimitDialog) {
            mutableStateOf(if (expenseLimit > 0) String.format(Locale.US, "%.0f", expenseLimit) else "")
        }
        AlertDialog(
            onDismissRequest = { showLimitDialog = false },
            title = { Text("Лимит расходов на месяц", fontSize = 16.sp, fontWeight = titleWeight) },
            text = {
                Column {
                    Text(
                        "Укажите ежемесячный лимит расходов. Если общая сумма расходов за месяц превысит эту сумму, итоги расходов будут подсвечиваться красным цветом.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                    OutlinedTextField(
                        value = inputLimit,
                        onValueChange = { inputLimit = it },
                        label = { Text("Сумма лимита (₽)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Исключить категории из лимита:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        "Траты из отмеченных категорий (например, оплата квартиры) не учитываются в лимите.",
                        fontSize = 10.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )

                    val expCategories = mutableListOf<Pair<String, String>>()
                    if (!hiddenSections.contains("exp")) expCategories.add("exp" to (sectionNames["exp"] ?: "Расход"))
                    categories.filter { it.type == CatType.HISTORY && !hiddenSections.contains(it.id) }.forEach {
                        expCategories.add(it.id to it.name)
                    }

                    expCategories.forEach { (catId, catName) ->
                        val isEx = excludedFromLimit.contains(catId)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { toggleExcludeCategory(catId) }
                                .padding(vertical = 1.dp, horizontal = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isEx,
                                onCheckedChange = { toggleExcludeCategory(catId) },
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(catName, fontSize = 11.sp, fontWeight = FontWeight.Normal)
                            if (isEx) {
                                Spacer(Modifier.width(4.dp))
                                Text("• вне лимита", fontSize = 10.sp, color = Color(0xFFE65100), fontWeight = FontWeight.Normal)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    val clean = inputLimit.replace(",", ".").replace(" ", "").trim()
                    val newLimit = clean.toDoubleOrNull() ?: 0.0
                    saveSafeExpenseLimit(context, newLimit)
                    expenseLimit = newLimit
                    showLimitDialog = false
                }) { Text("Сохранить") }
            },
            dismissButton = {
                Row {
                    if (expenseLimit > 0) {
                        TextButton(onClick = {
                            saveSafeExpenseLimit(context, 0.0)
                            expenseLimit = 0.0
                            showLimitDialog = false
                        }) { Text("Сбросить", color = Color.Red) }
                    }
                    TextButton(onClick = { showLimitDialog = false }) { Text("Отмена") }
                }
            }
        )
    }

    // МОДАЛЬНОЕ ОКНО СО СПИСКОМ ОПЕРАЦИЙ РАЗДЕЛА В ЭТОМ МЕСЯЦЕ ПО ДНЯМ (КАК В АНАЛИТИКЕ)
    if (selectedCategoryForDetail != null) {
        val cat = selectedCategoryForDetail!!
        val isIncome = cat.type == "INCOME"
        val isBalance = cat.type == "BALANCE"
        val typeToken = object : TypeToken<List<FinanceItem>>() {}.type
        val detailItems = mutableListOf<CategoryExpenseDetail>()

        val mFinForDetail = mFin

        mFinForDetail.forEach { fin ->
            when (cat.id) {
                "exp" -> {
                    val items = try { Gson().fromJson<List<FinanceItem>>(fin.expHistory ?: "[]", typeToken) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
                    items.forEach { detailItems.add(CategoryExpenseDetail(fin.date, it.amount, it.note)) }
                }
                "inc" -> {
                    val items = try { Gson().fromJson<List<FinanceItem>>(fin.incHistory ?: "[]", typeToken) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
                    items.forEach { detailItems.add(CategoryExpenseDetail(fin.date, it.amount, it.note)) }
                }
                "dep" -> {
                    val items = try { Gson().fromJson<List<FinanceItem>>(fin.depHistory ?: "[]", typeToken) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
                    items.forEach { detailItems.add(CategoryExpenseDetail(fin.date, it.amount, it.note)) }
                }
                else -> {
                    if (isBalance) {
                        val map = try { Gson().fromJson<Map<String, String>>(fin.dynamicBalances ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch(e: Exception) { emptyMap() }
                        val items = try { Gson().fromJson<List<FinanceItem>>(map[cat.id] ?: "[]", typeToken) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
                        items.forEach { detailItems.add(CategoryExpenseDetail(fin.date, it.amount, it.note)) }
                    } else {
                        val map = try { Gson().fromJson<Map<String, String>>(fin.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch(e: Exception) { emptyMap() }
                        val items = try { Gson().fromJson<List<FinanceItem>>(map[cat.id] ?: "[]", typeToken) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
                        items.forEach { detailItems.add(CategoryExpenseDetail(fin.date, it.amount, it.note)) }
                    }
                }
            }
        }
        detailItems.sortBy { it.date }

        AlertDialog(
            onDismissRequest = { selectedCategoryForDetail = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(14.dp).clip(CircleShape).background(cat.color))
                    Spacer(Modifier.width(8.dp))
                    Text(
                        "${cat.name}: ${if (isIncome) "список поступлений" else if (isBalance) "список операций" else "список трат"}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 420.dp)) {
                    Row(
                        Modifier.fillMaxWidth().padding(bottom = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "$summaryPeriodSub:",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = Color.Gray
                        )
                        Text(
                            "${if (isIncome) "+" else if (isBalance) "" else "-"}${mask(cat.total, isIncognito)}",
                            fontWeight = numWeight,
                            fontSize = 14.sp,
                            color = if (isIncome) Color(0xFF2E7D32) else if (isBalance) Color(0xFFE65100) else Color(0xFFD32F2F)
                        )
                    }
                    if (isBalance && cat.balance != null) {
                        Row(
                            Modifier.fillMaxWidth().padding(bottom = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                "Текущий баланс:",
                                fontSize = 12.sp,
                                color = Color.Gray
                            )
                            Text(
                                mask(cat.balance, isIncognito),
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp,
                                color = cat.color
                            )
                        }
                    }
                    Divider()
                    Spacer(Modifier.height(8.dp))
                    if (detailItems.isEmpty()) {
                        Box(
                            Modifier.fillMaxWidth().padding(vertical = 24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                "За выбранный период операций по данному разделу нет",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f, fill = false)) {
                            items(detailItems) { item ->
                                val dayStr = SimpleDateFormat("d MMMM yyyy (EE)", Locale("ru")).format(Date(item.date))
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(dayStr, fontWeight = FontWeight.Normal, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        Text(if (item.note.isBlank()) "Без описания" else item.note, fontSize = 11.sp, color = Color.DarkGray)
                                    }
                                    Text(
                                        "${if (isIncome) "+" else if (isBalance) "" else "-"}${mask(item.amount, isIncognito)}",
                                        fontWeight = numWeight,
                                        fontSize = 13.sp,
                                        color = if (isIncome) Color(0xFF2E7D32) else if (isBalance) Color(0xFFE65100) else Color(0xFFD32F2F)
                                    )
                                }
                                Divider(color = Color.LightGray.copy(alpha = 0.3f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { selectedCategoryForDetail = null }) { Text("Закрыть") }
            }
        )
    }

    // ДИАЛОГ «ИНВЕСТ БАЛАНС» (ОТОБРАЖАЕТ ДЕПОЗИТ, АКЦИИ И ВСЕ НАКОПЛЕНИЯ)
    if (showAllInvestDialog) {
        val typeTokenFinInvest = object : TypeToken<List<FinanceItem>>() {}.type
        val allInvestOps = mutableListOf<Triple<Long, FinanceSectionInfo, FinanceItem>>()

        mFin.forEach { fin ->
            val depSec = allBalanceSections.find { it.id == "dep" }
            if (depSec != null) {
                val items = try { Gson().fromJson<List<FinanceItem>>(fin.depHistory ?: "[]", typeTokenFinInvest) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
                items.forEach { item -> allInvestOps.add(Triple(fin.date, depSec, item)) }
            }
            try {
                val map = Gson().fromJson<Map<String, String>>(fin.dynamicBalances ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                categories.filter { it.type == CatType.BALANCE }.forEach { cat ->
                    val sec = allBalanceSections.find { it.id == cat.id }
                    if (sec != null) {
                        val items = Gson().fromJson<List<FinanceItem>>(map[cat.id] ?: "[]", typeTokenFinInvest) ?: emptyList()
                        items.forEach { item -> allInvestOps.add(Triple(fin.date, sec, item)) }
                    }
                }
            } catch (e: Exception) {}
        }
        allInvestOps.sortByDescending { it.first }

        AlertDialog(
            onDismissRequest = { showAllInvestDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(16.dp).clip(CircleShape).background(Color(0xFFE65100)))
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("ИНВЕСТ БАЛАНС И АКТИВЫ", fontSize = 14.sp, fontWeight = titleWeight, letterSpacing = spacing, fontFamily = modernFontFamily, color = Color(0xFFE65100))
                        Text(summaryTitleText, fontSize = 11.sp, fontFamily = modernFontFamily, color = Color.Gray)
                    }
                }
            },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 500.dp)) {
                    // Главная карточка общего инвест баланса
                    Card(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                        border = BorderStroke(1.dp, Color(0xFFFFB74D))
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text("ОБЩИЙ ИНВЕСТИЦИОННЫЙ БАЛАНС", fontSize = 10.sp, fontWeight = titleWeight, letterSpacing = spacing, fontFamily = modernFontFamily, color = Color(0xFFE65100))
                            Text(
                                "${mask(totalInvestBalance, isIncognito)} ₽",
                                fontSize = 22.sp,
                                fontWeight = numWeight,
                                letterSpacing = numSpacing,
                                fontFamily = modernFontFamily,
                                color = Color(0xFFBF360C)
                            )
                            Row(Modifier.padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    "Движение за период: ",
                                    fontSize = 11.sp,
                                    fontFamily = modernFontFamily,
                                    color = Color.DarkGray
                                )
                                Text(
                                    "${if (totalMonthDeposits > 0) "+" else ""}${mask(totalMonthDeposits, isIncognito)} ₽",
                                    fontSize = 11.sp,
                                    fontWeight = numWeight,
                                    fontFamily = modernFontFamily,
                                    color = if (totalMonthDeposits >= 0) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                                )
                            }
                        }
                    }

                    Text(
                        "АКТИВЫ И НАКОПЛЕНИЯ (${allBalanceSections.size})",
                        fontSize = 11.sp,
                        fontWeight = titleWeight,
                        letterSpacing = spacing,
                        fontFamily = modernFontFamily,
                        color = Color.DarkGray,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )

                    // Список всех активов (Депозит, Акции и др.)
                    Column(
                        Modifier
                            .fillMaxWidth()
                            .background(Color.White.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                            .padding(4.dp)
                    ) {
                        allBalanceSections.forEach { sec ->
                            Row(
                                Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp, horizontal = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(Modifier.size(12.dp).clip(CircleShape).background(sec.color))
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text(sec.name, fontSize = 13.sp, fontWeight = catWeight, fontFamily = modernFontFamily)
                                    Row {
                                        Text(
                                            "Баланс: ${mask(sec.balance ?: 0.0, isIncognito)} ₽",
                                            fontSize = 11.sp,
                                            fontWeight = numWeight,
                                            fontFamily = modernFontFamily,
                                            color = Color(0xFFE65100)
                                        )
                                        if (sec.total != 0.0) {
                                            Spacer(Modifier.width(8.dp))
                                            Text(
                                                "За период: ${if (sec.total > 0) "+" else ""}${mask(sec.total, isIncognito)} ₽",
                                                fontSize = 11.sp,
                                                fontWeight = numWeight,
                                                fontFamily = modernFontFamily,
                                                color = if (sec.total >= 0) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                                            )
                                        }
                                    }
                                }
                                IconButton(
                                    onClick = {
                                        editingBalanceCat = Pair(sec.id, sec.name)
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Edit, "Изменить сумму", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                }
                            }
                            Divider(color = Color.LightGray.copy(alpha = 0.3f))
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(
                        "ОПЕРАЦИИ ЗА ВЫБРАННЫЙ ПЕРИОД (${allInvestOps.size})",
                        fontSize = 11.sp,
                        fontWeight = titleWeight,
                        letterSpacing = spacing,
                        fontFamily = modernFontFamily,
                        color = Color.DarkGray,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    if (allInvestOps.isEmpty()) {
                        Box(
                            Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Операций по балансам за период не найдено", fontSize = 11.sp, fontFamily = modernFontFamily, color = Color.Gray)
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f, fill = false)) {
                            items(allInvestOps) { (opDate, sec, item) ->
                                val dateStr = SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(Date(opDate))
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(8.dp).clip(CircleShape).background(sec.color))
                                    Spacer(Modifier.width(6.dp))
                                    Column(Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(sec.name, fontSize = 11.sp, fontWeight = catWeight, color = sec.color, fontFamily = modernFontFamily)
                                            Spacer(Modifier.width(6.dp))
                                            Text(dateStr, fontSize = 10.sp, fontFamily = modernFontFamily, color = Color.Gray)
                                        }
                                        Text(if (item.note.isBlank()) "Без описания" else item.note, fontSize = 11.sp, fontFamily = modernFontFamily, color = Color.DarkGray)
                                    }
                                    Text(
                                        "${if (item.amount > 0) "+" else ""}${mask(item.amount, isIncognito)}",
                                        fontSize = 12.sp,
                                        fontWeight = numWeight,
                                        letterSpacing = numSpacing,
                                        fontFamily = modernFontFamily,
                                        color = if (item.amount >= 0) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                                    )
                                }
                                Divider(color = Color.LightGray.copy(alpha = 0.2f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        showAllInvestDialog = false
                        addTransactionInitialType = "BALANCE"
                        showAddTransactionDialog = true
                    }) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Внести / операция")
                    }
                    Button(onClick = { showAllInvestDialog = false }) {
                        Text("Закрыть")
                    }
                }
            }
        )
    }

    // ДИАЛОГ: ВСЕ ДОХОДЫ И ПОСТУПЛЕНИЯ
    if (showAllIncomeDialog) {
        val typeTokenFinIncome = object : TypeToken<List<FinanceItem>>() {}.type
        val allIncomeOps = mutableListOf<Triple<Long, FinanceSectionInfo, FinanceItem>>()

        mFin.forEach { fin ->
            val incSec = allIncomeSections.find { it.id == "inc" } ?: FinanceSectionInfo("inc", "Доход", Color(0xFF2E7D32), 0.0, "INCOME")
            val sysItems = try { Gson().fromJson<List<FinanceItem>>(fin.incHistory ?: "[]", typeTokenFinIncome) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
            sysItems.forEach { item -> allIncomeOps.add(Triple(fin.date, incSec, item)) }

            try {
                val map = Gson().fromJson<Map<String, String>>(fin.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                categories.filter { it.type == CatType.INCOME }.forEach { cat ->
                    val sec = allIncomeSections.find { it.id == cat.id } ?: FinanceSectionInfo(cat.id, cat.name, Color(cat.color), 0.0, "INCOME")
                    val items = Gson().fromJson<List<FinanceItem>>(map[cat.id] ?: "[]", typeTokenFinIncome) ?: emptyList()
                    items.forEach { item -> allIncomeOps.add(Triple(fin.date, sec, item)) }
                }
            } catch (e: Exception) {}
        }
        allIncomeOps.sortByDescending { it.first }

        AlertDialog(
            onDismissRequest = { showAllIncomeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(16.dp).clip(CircleShape).background(Color(0xFF2E7D32)))
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("ВСЕ ДОХОДЫ И ПОСТУПЛЕНИЯ", fontSize = 14.sp, fontWeight = titleWeight, color = Color(0xFF2E7D32))
                        Text(summaryTitleText, fontSize = 11.sp, color = Color.Gray)
                    }
                }
            },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 500.dp)) {
                    // Главная карточка общих доходов
                    Card(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                        border = BorderStroke(1.dp, Color(0xFFA5D6A7))
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text("ОБЩИЙ ДОХОД ЗА ПЕРИОД", fontSize = 10.sp, fontWeight = titleWeight, letterSpacing = spacing, fontFamily = modernFontFamily, color = Color(0xFF2E7D32))
                            Text(
                                "+${mask(totalMonthIncome, isIncognito)} ₽",
                                fontSize = 22.sp,
                                fontWeight = numWeight,
                                letterSpacing = numSpacing,
                                fontFamily = modernFontFamily,
                                color = Color(0xFF1B5E20)
                            )
                            Text(
                                "Операций: ${allIncomeOps.size} • Категорий: ${allIncomeSections.size}",
                                fontSize = 11.sp,
                                fontFamily = modernFontFamily,
                                color = Color.DarkGray,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    // Список категорий доходов
                    if (allIncomeSections.isNotEmpty()) {
                        Text(
                            "КАТЕГОРИИ ДОХОДОВ (${allIncomeSections.size})",
                            fontSize = 11.sp,
                            fontWeight = titleWeight,
                            letterSpacing = spacing,
                            fontFamily = modernFontFamily,
                            color = Color.DarkGray,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(4.dp)
                        ) {
                            allIncomeSections.forEach { sec ->
                                val pct = if (totalMonthIncome > 0) ((sec.total / totalMonthIncome) * 100).toInt() else 0
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(10.dp).clip(CircleShape).background(sec.color))
                                    Spacer(Modifier.width(8.dp))
                                    Text(sec.name, fontSize = 12.sp, fontWeight = catWeight, fontFamily = modernFontFamily, modifier = Modifier.weight(1f))
                                    Text("+${mask(sec.total, isIncognito)} ₽", fontSize = 12.sp, fontWeight = numWeight, letterSpacing = numSpacing, fontFamily = modernFontFamily, color = Color(0xFF2E7D32))
                                    Text(" ($pct%)", fontSize = 10.sp, fontFamily = modernFontFamily, color = Color.Gray, modifier = Modifier.padding(start = 4.dp))
                                }
                                Divider(color = Color.LightGray.copy(alpha = 0.2f))
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(
                        "ОПЕРАЦИИ ПО ДОХОДАМ (${allIncomeOps.size})",
                        fontSize = 11.sp,
                        fontWeight = titleWeight,
                        letterSpacing = spacing,
                        fontFamily = modernFontFamily,
                        color = Color.DarkGray,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    if (allIncomeOps.isEmpty()) {
                        Box(
                            Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Поступлений за выбранный период не найдено", fontSize = 11.sp, fontFamily = modernFontFamily, color = Color.Gray)
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f, fill = false)) {
                            items(allIncomeOps) { (opDate, sec, item) ->
                                val dateStr = SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(Date(opDate))
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(8.dp).clip(CircleShape).background(sec.color))
                                    Spacer(Modifier.width(6.dp))
                                    Column(Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(sec.name, fontSize = 11.sp, fontWeight = catWeight, color = sec.color, fontFamily = modernFontFamily)
                                            Spacer(Modifier.width(6.dp))
                                            Text(dateStr, fontSize = 10.sp, fontFamily = modernFontFamily, color = Color.Gray)
                                        }
                                        Text(if (item.note.isBlank()) "Без описания" else item.note, fontSize = 11.sp, fontFamily = modernFontFamily, color = Color.DarkGray)
                                    }
                                    Text(
                                        "+${mask(item.amount, isIncognito)} ₽",
                                        fontSize = 12.sp,
                                        fontWeight = numWeight,
                                        letterSpacing = numSpacing,
                                        fontFamily = modernFontFamily,
                                        color = Color(0xFF2E7D32)
                                    )
                                    IconButton(
                                        onClick = {
                                            editingHistoryItem = Triple(sec.id, item, sec.name)
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Редактировать", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            updateHistoryItem(sec.id, item, isDelete = true)
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Удалить", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    }
                                }
                                Divider(color = Color.LightGray.copy(alpha = 0.2f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        showAllIncomeDialog = false
                        addTransactionInitialType = "INCOME"
                        showAddTransactionDialog = true
                    }) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Добавить доход")
                    }
                    Button(onClick = { showAllIncomeDialog = false }) {
                        Text("Закрыть")
                    }
                }
            }
        )
    }

    // ДИАЛОГ: ВСЕ РАСХОДЫ И ТРАТЫ
    if (showAllExpenseDialog) {
        val typeTokenFinExpense = object : TypeToken<List<FinanceItem>>() {}.type
        val allExpenseOps = mutableListOf<Triple<Long, FinanceSectionInfo, FinanceItem>>()

        mFin.forEach { fin ->
            val expSec = allExpenseSections.find { it.id == "exp" } ?: FinanceSectionInfo("exp", "Расход", Color(0xFFD32F2F), 0.0, "EXPENSE")
            val sysItems = try { Gson().fromJson<List<FinanceItem>>(fin.expHistory ?: "[]", typeTokenFinExpense) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
            sysItems.forEach { item -> allExpenseOps.add(Triple(fin.date, expSec, item)) }

            try {
                val map = Gson().fromJson<Map<String, String>>(fin.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                categories.filter { it.type == CatType.HISTORY }.forEach { cat ->
                    val sec = allExpenseSections.find { it.id == cat.id } ?: FinanceSectionInfo(cat.id, cat.name, Color(cat.color), 0.0, "EXPENSE")
                    val items = Gson().fromJson<List<FinanceItem>>(map[cat.id] ?: "[]", typeTokenFinExpense) ?: emptyList()
                    items.forEach { item -> allExpenseOps.add(Triple(fin.date, sec, item)) }
                }
            } catch (e: Exception) {}
        }
        allExpenseOps.sortByDescending { it.first }

        AlertDialog(
            onDismissRequest = { showAllExpenseDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(16.dp).clip(CircleShape).background(Color(0xFFD32F2F)))
                    Spacer(Modifier.width(8.dp))
                    Column {
                        Text("ВСЕ РАСХОДЫ И ТРАТЫ", fontSize = 14.sp, fontWeight = titleWeight, color = Color(0xFFD32F2F))
                        Text(summaryTitleText, fontSize = 11.sp, color = Color.Gray)
                    }
                }
            },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 500.dp)) {
                    // Главная карточка общих расходов
                    Card(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = if (isOverLimit) Color(0xFFFFEBEE) else Color(0xFFFFEBEE).copy(alpha = 0.5f)
                        ),
                        border = BorderStroke(1.dp, if (isOverLimit) Color(0xFFD32F2F) else Color(0xFFEF9A9A))
                    ) {
                        Column(Modifier.padding(12.dp)) {
                            Text("ОБЩИЕ РАСХОДЫ ЗА ПЕРИОД", fontSize = 10.sp, fontWeight = titleWeight, letterSpacing = spacing, fontFamily = modernFontFamily, color = Color(0xFFD32F2F))
                            Text(
                                "-${mask(totalMonthExpenses, isIncognito)} ₽",
                                fontSize = 22.sp,
                                fontWeight = numWeight,
                                letterSpacing = numSpacing,
                                fontFamily = modernFontFamily,
                                color = Color(0xFFB71C1C)
                            )
                            if (expenseLimit > 0) {
                                Text(
                                    if (isOverLimit) "⚠️ Превышение лимита на ${mask(limitTargetExpenses - expenseLimit, isIncognito)} ₽"
                                    else "Остаток лимита: ${mask(expenseLimit - limitTargetExpenses, isIncognito)} ₽ (из ${mask(expenseLimit, isIncognito)})",
                                    fontSize = 11.sp,
                                    fontWeight = numWeight,
                                    fontFamily = modernFontFamily,
                                    color = if (isOverLimit) Color(0xFFD32F2F) else Color(0xFF2E7D32),
                                    modifier = Modifier.padding(top = 2.dp)
                                )
                            }
                            Text(
                                "Операций: ${allExpenseOps.size} • Категорий расходов: ${allExpenseSections.size}",
                                fontSize = 10.sp,
                                fontFamily = modernFontFamily,
                                color = Color.DarkGray,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                    }

                    // Список категорий расходов (Продукты, Аренда, Кафе и др.)
                    if (allExpenseSections.isNotEmpty()) {
                        Text(
                            "КАТЕГОРИИ РАСХОДОВ (${allExpenseSections.size})",
                            fontSize = 11.sp,
                            fontWeight = titleWeight,
                            letterSpacing = spacing,
                            fontFamily = modernFontFamily,
                            color = Color.DarkGray,
                            modifier = Modifier.padding(bottom = 6.dp)
                        )
                        Column(
                            Modifier
                                .fillMaxWidth()
                                .background(Color.White.copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .padding(4.dp)
                        ) {
                            allExpenseSections.forEach { sec ->
                                val pct = if (totalMonthExpenses > 0) ((sec.total / totalMonthExpenses) * 100).toInt() else 0
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp, horizontal = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(10.dp).clip(CircleShape).background(sec.color))
                                    Spacer(Modifier.width(8.dp))
                                    Text(sec.name, fontSize = 12.sp, fontWeight = catWeight, fontFamily = modernFontFamily, modifier = Modifier.weight(1f))
                                    Text("-${mask(sec.total, isIncognito)} ₽", fontSize = 12.sp, fontWeight = numWeight, letterSpacing = numSpacing, fontFamily = modernFontFamily, color = if (sec.isExcluded) Color(0xFFE65100) else Color(0xFFD32F2F))
                                    Text(" ($pct%)", fontSize = 10.sp, fontFamily = modernFontFamily, color = Color.Gray, modifier = Modifier.padding(start = 4.dp))
                                }
                                Divider(color = Color.LightGray.copy(alpha = 0.2f))
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(
                        "ОПЕРАЦИИ ПО РАСХОДАМ (${allExpenseOps.size})",
                        fontSize = 11.sp,
                        fontWeight = titleWeight,
                        letterSpacing = spacing,
                        fontFamily = modernFontFamily,
                        color = Color.DarkGray,
                        modifier = Modifier.padding(bottom = 4.dp)
                    )

                    if (allExpenseOps.isEmpty()) {
                        Box(
                            Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Расходов за выбранный период не найдено", fontSize = 11.sp, fontFamily = modernFontFamily, color = Color.Gray)
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f, fill = false)) {
                            items(allExpenseOps) { (opDate, sec, item) ->
                                val dateStr = SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(Date(opDate))
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 4.dp, horizontal = 2.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(8.dp).clip(CircleShape).background(sec.color))
                                    Spacer(Modifier.width(6.dp))
                                    Column(Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(sec.name, fontSize = 11.sp, fontWeight = catWeight, color = sec.color, fontFamily = modernFontFamily)
                                            Spacer(Modifier.width(6.dp))
                                            Text(dateStr, fontSize = 10.sp, fontFamily = modernFontFamily, color = Color.Gray)
                                        }
                                        Text(if (item.note.isBlank()) "Без описания" else item.note, fontSize = 11.sp, fontFamily = modernFontFamily, color = Color.DarkGray)
                                    }
                                    Text(
                                        "-${mask(item.amount, isIncognito)} ₽",
                                        fontSize = 12.sp,
                                        fontWeight = numWeight,
                                        letterSpacing = numSpacing,
                                        fontFamily = modernFontFamily,
                                        color = if (sec.isExcluded) Color(0xFFE65100) else Color(0xFFD32F2F)
                                    )
                                    IconButton(
                                        onClick = {
                                            editingHistoryItem = Triple(sec.id, item, sec.name)
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Редактировать", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    }
                                    IconButton(
                                        onClick = {
                                            updateHistoryItem(sec.id, item, isDelete = true)
                                        },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.DeleteOutline, contentDescription = "Удалить", tint = Color.Gray, modifier = Modifier.size(14.dp))
                                    }
                                }
                                Divider(color = Color.LightGray.copy(alpha = 0.2f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(onClick = {
                        showAllExpenseDialog = false
                        addTransactionInitialType = "EXPENSE"
                        showAddTransactionDialog = true
                    }) {
                        Icon(Icons.Default.Add, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Добавить расход")
                    }
                    Button(onClick = { showAllExpenseDialog = false }) {
                        Text("Закрыть")
                    }
                }
            }
        )
    }

    // ДИАЛОГ ВЫБОРА ПРОИЗВОЛЬНОГО ДИАПАЗОНА (С ПРЕСЕТАМИ)
    if (showCustomRangeDialog) {
        var tempStart by remember(showCustomRangeDialog) { mutableLongStateOf(summaryCustomStart) }
        var tempEnd by remember(showCustomRangeDialog) { mutableLongStateOf(summaryCustomEnd) }

        AlertDialog(
            onDismissRequest = { showCustomRangeDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DateRange, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(8.dp))
                    Text("Выбор диапазона итогов", fontSize = 16.sp, fontWeight = titleWeight)
                }
            },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    Text("Быстрые периоды:", fontSize = 11.sp, fontWeight = FontWeight.Normal, color = Color.Gray)
                    Spacer(Modifier.height(4.dp))

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedButton(
                            onClick = {
                                val c = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1) }
                                tempStart = c.timeInMillis.toMidnight()
                                tempEnd = System.currentTimeMillis().toMidnight()
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Тек. месяц", fontSize = 10.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                val s = Calendar.getInstance().apply {
                                    add(Calendar.MONTH, -1)
                                    set(Calendar.DAY_OF_MONTH, 1)
                                }
                                val e = (s.clone() as Calendar).apply {
                                    set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                                }
                                tempStart = s.timeInMillis.toMidnight()
                                tempEnd = e.timeInMillis.toMidnight()
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Прошлый", fontSize = 10.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                tempStart = (System.currentTimeMillis() - 30L * 86400000L).toMidnight()
                                tempEnd = System.currentTimeMillis().toMidnight()
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("30 дней", fontSize = 10.sp)
                        }
                    }

                    Spacer(Modifier.height(4.dp))

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        OutlinedButton(
                            onClick = {
                                tempStart = (System.currentTimeMillis() - 90L * 86400000L).toMidnight()
                                tempEnd = System.currentTimeMillis().toMidnight()
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("90 дней", fontSize = 10.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                val c = Calendar.getInstance().apply {
                                    set(Calendar.MONTH, Calendar.JANUARY)
                                    set(Calendar.DAY_OF_MONTH, 1)
                                }
                                tempStart = c.timeInMillis.toMidnight()
                                tempEnd = System.currentTimeMillis().toMidnight()
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("С начала года", fontSize = 10.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                val minD = allFinances.minOfOrNull { it.date } ?: (System.currentTimeMillis() - 365L * 86400000L)
                                tempStart = minD.toMidnight()
                                tempEnd = System.currentTimeMillis().toMidnight()
                            },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("Всё время", fontSize = 10.sp)
                        }
                    }

                    Spacer(Modifier.height(12.dp))
                    Divider()
                    Spacer(Modifier.height(8.dp))

                    Text("Выбрать точные даты:", fontSize = 11.sp, fontWeight = FontWeight.Normal, color = Color.Gray)
                    Spacer(Modifier.height(6.dp))

                    val startFormatted = SimpleDateFormat("dd.MM.yyyy", Locale("ru")).format(Date(tempStart))
                    val endFormatted = SimpleDateFormat("dd.MM.yyyy", Locale("ru")).format(Date(tempEnd))

                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedCard(
                            onClick = {
                                val c = Calendar.getInstance().apply { timeInMillis = tempStart }
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val nc = Calendar.getInstance().apply {
                                            set(year, month, dayOfMonth)
                                        }
                                        tempStart = nc.timeInMillis.toMidnight()
                                        if (tempStart > tempEnd) tempEnd = tempStart
                                    },
                                    c.get(Calendar.YEAR),
                                    c.get(Calendar.MONTH),
                                    c.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(Modifier.padding(8.dp)) {
                                Text("Начало:", fontSize = 10.sp, color = Color.Gray)
                                Text(startFormatted, fontSize = 12.sp, fontWeight = FontWeight.Normal)
                            }
                        }

                        OutlinedCard(
                            onClick = {
                                val c = Calendar.getInstance().apply { timeInMillis = tempEnd }
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val nc = Calendar.getInstance().apply {
                                            set(year, month, dayOfMonth)
                                        }
                                        tempEnd = nc.timeInMillis.toMidnight()
                                        if (tempEnd < tempStart) tempStart = tempEnd
                                    },
                                    c.get(Calendar.YEAR),
                                    c.get(Calendar.MONTH),
                                    c.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            },
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(Modifier.padding(8.dp)) {
                                Text("Конец:", fontSize = 10.sp, color = Color.Gray)
                                Text(endFormatted, fontSize = 12.sp, fontWeight = FontWeight.Normal)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = {
                    summaryCustomStart = tempStart
                    summaryCustomEnd = tempEnd
                    summaryPeriodMode = "CUSTOM"
                    showCustomRangeDialog = false
                }) {
                    Text("Применить")
                }
            },
            dismissButton = {
                TextButton(onClick = { showCustomRangeDialog = false }) {
                    Text("Отмена")
                }
            }
        )
    }

    // ДИАЛОГ ДОБАВЛЕНИЯ ОПЕРАЦИИ (РАСХОД / ДОХОД)
    if (showAddTransactionDialog) {
        FinanceAddTransactionDialog(
            initialType = addTransactionInitialType,
            initialDate = selectedDate,
            categories = categories,
            hiddenSections = hiddenSections,
            sectionNames = sectionNames,
            cars = cars,
            preselectedCatId = newlyCreatedCatId,
            onDismiss = {
                newlyCreatedCatId = null
                showAddTransactionDialog = false
            },
            onCreateCategory = { currentDialogType ->
                addCatInitialType = when (currentDialogType) {
                    "INCOME" -> CatType.INCOME
                    "BALANCE" -> CatType.BALANCE
                    else -> CatType.HISTORY
                }
                showAddCat = true
            },
            onAddCategory = { newCat ->
                categories = categories + newCat
                prefs.edit().putString("list", Gson().toJson(categories)).apply()
            },
            onSave = { catId, amount, note, targetDate ->
                newlyCreatedCatId = null
                saveEntry(catId, amount, note, targetDate)
                showAddTransactionDialog = false
            },
            onSaveCarEvent = { ev ->
                onSaveCarEvent(ev)
            }
        )
    }

    // ДИАЛОГ РЕДАКТИРОВАНИЯ СУММЫ / БАЛАНСА В РАЗДЕЛЕ НАКОПЛЕНИЙ И БАЛАНСОВ
    if (editingBalanceCat != null) {
        val (catId, catName) = editingBalanceCat!!
        val currentBal = getFullBalance(catId, selectedDate)
        var newBalanceText by remember(editingBalanceCat) {
            mutableStateOf(if (currentBal == 0.0) "" else String.format(Locale.US, "%.0f", currentBal))
        }
        var adjustNote by remember(editingBalanceCat) { mutableStateOf("Корректировка баланса") }
        AlertDialog(
            onDismissRequest = { editingBalanceCat = null },
            title = {
                Column {
                    Text("Баланс: $catName", fontWeight = FontWeight.Normal, fontSize = 16.sp)
                    Text("Текущий: ${mask(currentBal, isIncognito)} ₽", fontSize = 12.sp, color = Color.Gray)
                }
            },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    Text("Укажите точную сумму баланса:", fontSize = 13.sp, fontWeight = FontWeight.Normal)
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = newBalanceText,
                        onValueChange = { newBalanceText = it },
                        label = { Text("Сумма баланса (₽)") },
                        placeholder = { Text("0") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf(1000, 5000, 10000, 50000).forEach { step ->
                            OutlinedButton(
                                onClick = {
                                    val cur = newBalanceText.replace(",", ".").replace(" ", "").toDoubleOrNull() ?: currentBal
                                    newBalanceText = String.format(Locale.US, "%.0f", cur + step)
                                },
                                contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Text("+$step", fontSize = 10.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        value = adjustNote,
                        onValueChange = { adjustNote = it },
                        label = { Text("Комментарий к операции") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val computed = if (newBalanceText.isNotBlank()) evalMathExpression(newBalanceText) else null
                        val clean = newBalanceText.replace(",", ".").replace(" ", "").trim()
                        val targetBal = computed ?: clean.toDoubleOrNull() ?: 0.0
                        val diff = targetBal - currentBal
                        if (diff != 0.0) {
                            val note = if (adjustNote.isNotBlank()) adjustNote.trim() else "Корректировка баланса"
                            saveEntry(catId, diff, note, selectedDate)
                        }
                        editingBalanceCat = null
                    }
                ) {
                    Text("Сохранить сумму")
                }
            },
            dismissButton = {
                TextButton(onClick = { editingBalanceCat = null }) {
                    Text("Отмена")
                }
            }
        )
    }

    // ДИАЛОГ РЕДАКТИРОВАНИЯ ОПЕРАЦИИ
    if (editingHistoryItem != null) {
        val (catId, item, catName) = editingHistoryItem!!
        var editAmount by remember(editingHistoryItem) { mutableStateOf(String.format(Locale.US, "%.0f", item.amount)) }
        var editNote by remember(editingHistoryItem) { mutableStateOf(item.note) }
        AlertDialog(
            onDismissRequest = { editingHistoryItem = null },
            title = { Text("Редактировать: $catName", fontSize = 16.sp, fontWeight = FontWeight.Normal) },
            text = {
                Column(Modifier.fillMaxWidth()) {
                    OutlinedTextField(
                        value = editAmount,
                        onValueChange = { editAmount = it },
                        label = { Text("Сумма (₽)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        value = editNote,
                        onValueChange = { editNote = it },
                        label = { Text("Заметка (комментарий)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(onClick = {
                    val amt = editAmount.replace(",", ".").replace(" ", "").trim().toDoubleOrNull() ?: 0.0
                    if (amt > 0.0) {
                        updateHistoryItem(catId, item.copy(amount = amt, note = editNote.trim()))
                    }
                    editingHistoryItem = null
                }) { Text("Сохранить") }
            },
            dismissButton = {
                TextButton(onClick = {
                    updateHistoryItem(catId, item, isDelete = true)
                    editingHistoryItem = null
                }) { Text("Удалить", color = Color.Red) }
            }
        )
    }

    if (selectedCarForDetail != null) {
        val cur = cars.find { it.id == selectedCarForDetail?.id } ?: selectedCarForDetail!!
        CarDetailDialog(
            car = cur,
            events = carEvents,
            mileageLogs = carMileageLogs,
            reminders = carReminders,
            isIncognito = isIncognito,
            onDismiss = { selectedCarForDetail = null },
            onEditCar = { c ->
                editingCar = c
                showAddCarDialog = true
            },
            onDeleteCar = { cId ->
                onDeleteCar(cId)
            },
            onAddEvent = { defType ->
                eventCarTarget = cur
                eventDefaultType = defType
                editingCarEvent = null
                showAddCarEventDialog = true
            },
            onEditEvent = { ev ->
                eventCarTarget = cars.find { it.id == ev.carId } ?: cur
                editingCarEvent = ev
                showAddCarEventDialog = true
            },
            onDeleteEvent = { evId ->
                onDeleteCarEvent(evId)
            },
            onAddMileage = {
                mileageCarTarget = cur
                showAddMileageDialog = true
            },
            onDeleteMileage = { mId ->
                onDeleteMileageLog(mId)
            },
            onAddReminder = {
                reminderCarTarget = cur
                editingCarReminder = null
                showAddReminderDialog = true
            },
            onEditReminder = { rem ->
                reminderCarTarget = cars.find { it.id == rem.carId } ?: cur
                editingCarReminder = rem
                showAddReminderDialog = true
            },
            onDeleteReminder = { rId ->
                onDeleteReminder(rId)
            },
            onToggleReminderDone = { rem ->
                onToggleReminderDone(rem)
            }
        )
    }

    if (showAddCarDialog) {
        AddEditCarDialog(
            car = editingCar,
            onDismiss = {
                showAddCarDialog = false
                editingCar = null
            },
            onSave = { c ->
                onSaveCar(c)
                showAddCarDialog = false
                editingCar = null
            }
        )
    }

    if (showAddCarEventDialog && eventCarTarget != null) {
        val car = eventCarTarget!!
        AddEditCarEventDialog(
            car = car,
            event = editingCarEvent,
            defaultType = eventDefaultType,
            onDismiss = {
                showAddCarEventDialog = false
                editingCarEvent = null
                eventCarTarget = null
            },
            onSave = { ev, syncToMonthlyFinance ->
                onSaveCarEvent(ev)
                if (syncToMonthlyFinance && ev.amount > 0.0) {
                    val carCatName = "${car.brand} ${car.model}".trim()
                    var targetCat = categories.find { it.name.equals(carCatName, ignoreCase = true) }
                    if (targetCat == null) {
                        val newCat = CategoryConfig(
                            id = "cat_car_${car.id}",
                            name = carCatName,
                            color = 0xFF1976D2.toInt(),
                            type = CatType.HISTORY,
                            iconKey = "car"
                        )
                        categories = categories + newCat
                        prefs.edit().putString("list", Gson().toJson(categories)).apply()
                        targetCat = newCat
                        val cPrefs = context.getSharedPreferences("car_prefs", 0)
                        val curSet = cPrefs.getStringSet("created_car_sections", emptySet())?.toMutableSet() ?: mutableSetOf()
                        curSet.add(car.id)
                        cPrefs.edit().putStringSet("created_car_sections", curSet).apply()
                    } else if (targetCat.type != CatType.HISTORY) {
                        val fixedCat = targetCat.copy(type = CatType.HISTORY)
                        categories = categories.map { if (it.id == fixedCat.id) fixedCat else it }
                        prefs.edit().putString("list", Gson().toJson(categories)).apply()
                        targetCat = fixedCat
                    }
                    saveEntry(targetCat.id, ev.amount, "${ev.title}${if (ev.note.isNotBlank()) ": " + ev.note else ""}", ev.date.toMidnight())
                    val calEv = Calendar.getInstance().apply { timeInMillis = ev.date }
                    val mName = SimpleDateFormat("MMMM", Locale("ru")).format(calEv.time)
                    Toast.makeText(context, "Расход учтён в разделе «$carCatName» (Итоги за $mName)", Toast.LENGTH_SHORT).show()
                }
                showAddCarEventDialog = false
                editingCarEvent = null
                eventCarTarget = null
            }
        )
    }

    if (showAddMileageDialog && mileageCarTarget != null) {
        AddCarMileageLogDialog(
            car = mileageCarTarget!!,
            onDismiss = {
                showAddMileageDialog = false
                mileageCarTarget = null
            },
            onSave = { log ->
                onSaveMileageLog(log)
                showAddMileageDialog = false
                mileageCarTarget = null
            }
        )
    }

    if (showAddReminderDialog && reminderCarTarget != null) {
        AddEditCarReminderDialog(
            car = reminderCarTarget!!,
            reminder = editingCarReminder,
            onDismiss = {
                showAddReminderDialog = false
                editingCarReminder = null
                reminderCarTarget = null
            },
            onSave = { rem ->
                onSaveReminder(rem)
                showAddReminderDialog = false
                editingCarReminder = null
                reminderCarTarget = null
            }
        )
    }
}

fun safeCategoryColor(colorInt: Int, fallback: Color = Color(0xFF2196F3)): Color {
    return try {
        if (colorInt == 0) fallback else Color(colorInt)
    } catch (_: Throwable) {
        fallback
    }
}

@Composable
fun FinanceAddTransactionDialog(
    initialType: String,
    initialDate: Long,
    categories: List<CategoryConfig>,
    hiddenSections: Set<String>,
    sectionNames: Map<String, String>,
    cars: List<CarItem> = emptyList(),
    preselectedCatId: String? = null,
    onDismiss: () -> Unit,
    onCreateCategory: (String) -> Unit,
    onAddCategory: (CategoryConfig) -> Unit = {},
    onSave: (catId: String, amount: Double, note: String, targetDate: Long) -> Unit,
    onSaveCarEvent: ((CarEventItem) -> Unit)? = null
) {
    val context = LocalContext.current
    var selectedType by remember { mutableStateOf(initialType) }
    var amountText by remember { mutableStateOf("") }
    var noteText by remember { mutableStateOf("") }
    var selectedDateMillis by remember { mutableStateOf(initialDate) }
    var showCategoryPicker by remember { mutableStateOf(false) }

    // Доступные категории согласно выбранному типу (Расходы, Доходы или Накопления/Балансы)
    val availableCategories = remember(selectedType, categories, hiddenSections, sectionNames) {
        val list = mutableListOf<Triple<String, String, Color>>()
        if (selectedType == "EXPENSE") {
            if (!hiddenSections.contains("exp")) {
                list.add(Triple("exp", sectionNames["exp"] ?: "Расход", Color(0xFFD32F2F)))
            }
            categories.filter { (it.type ?: CatType.HISTORY) == CatType.HISTORY && !hiddenSections.contains(it.id ?: "") }.forEach {
                list.add(Triple(it.id ?: "", it.name ?: "", safeCategoryColor(it.color, Color(0xFFD32F2F))))
            }
        } else if (selectedType == "INCOME") {
            if (!hiddenSections.contains("inc")) {
                list.add(Triple("inc", sectionNames["inc"] ?: "Доход", Color(0xFF2E7D32)))
            }
            categories.filter { (it.type ?: CatType.HISTORY) == CatType.INCOME && !hiddenSections.contains(it.id ?: "") }.forEach {
                list.add(Triple(it.id ?: "", it.name ?: "", safeCategoryColor(it.color, Color(0xFF2E7D32))))
            }
        } else {
            // BALANCE / НАКОПЛЕНИЯ
            if (!hiddenSections.contains("dep")) {
                list.add(Triple("dep", sectionNames["dep"] ?: "Депозит", Color(0xFFFF9800)))
            }
            categories.filter { (it.type ?: CatType.HISTORY) == CatType.BALANCE && !hiddenSections.contains(it.id ?: "") }.forEach {
                list.add(Triple(it.id ?: "", it.name ?: "", safeCategoryColor(it.color, Color(0xFFFF9800))))
            }
        }
        list
    }

    var selectedCatId by remember(selectedType) { mutableStateOf<String?>(null) }

    LaunchedEffect(preselectedCatId, availableCategories) {
        if (!preselectedCatId.isNullOrBlank() && availableCategories.any { it.first == preselectedCatId }) {
            selectedCatId = preselectedCatId
        }
    }

    val selectedCategoryInfo = remember(selectedCatId, availableCategories) {
        availableCategories.find { it.first == selectedCatId }
    }

    val dateFormatted = remember(selectedDateMillis) {
        val calSelected = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
        val calToday = Calendar.getInstance()
        val isToday = calSelected.get(Calendar.YEAR) == calToday.get(Calendar.YEAR) &&
                calSelected.get(Calendar.DAY_OF_YEAR) == calToday.get(Calendar.DAY_OF_YEAR)
        if (isToday) "Сегодня" else SimpleDateFormat("d MMMM yyyy", Locale("ru")).format(Date(selectedDateMillis))
    }

    val isExpense = selectedType == "EXPENSE"
    val isIncome = selectedType == "INCOME"
    val isBalance = selectedType == "BALANCE"
    val accentColor = if (isExpense) Color(0xFFD32F2F) else if (isIncome) Color(0xFF2E7D32) else Color(0xFFFF9800)
    val badgeBg = if (isExpense) Color(0xFFFFEBEE) else if (isIncome) Color(0xFFE8F5E9) else Color(0xFFFFF3E0)

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = true)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp)),
            color = MaterialTheme.colorScheme.surface,
            shadowElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                    // ВЕРХНЯЯ СТРОКА: НАЗАД И ВЫБОР РАСХОДЫ / ДОХОДЫ / НАКОПЛЕНИЯ
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "Назад", tint = MaterialTheme.colorScheme.onSurface)
                        }

                        Spacer(Modifier.weight(1f))

                        // ПЕРЕКЛЮЧАТЕЛЬ ТИПА СВЕРХУ (3 РЕЖИМА)
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                            modifier = Modifier.padding(vertical = 2.dp)
                        ) {
                            Row(modifier = Modifier.padding(2.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (isExpense) Color(0xFFD32F2F) else Color.Transparent,
                                    modifier = Modifier.clickable {
                                        selectedType = "EXPENSE"
                                        selectedCatId = null
                                    }
                                ) {
                                    Text(
                                        "Расход",
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isExpense) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (isIncome) Color(0xFF2E7D32) else Color.Transparent,
                                    modifier = Modifier.clickable {
                                        selectedType = "INCOME"
                                        selectedCatId = null
                                    }
                                ) {
                                    Text(
                                        "Доход",
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isIncome) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Surface(
                                    shape = RoundedCornerShape(16.dp),
                                    color = if (isBalance) Color(0xFFFF9800) else Color.Transparent,
                                    modifier = Modifier.clickable {
                                        selectedType = "BALANCE"
                                        selectedCatId = null
                                    }
                                ) {
                                    Text(
                                        "Накопление",
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isBalance) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }

                        Spacer(Modifier.weight(1f))
                        Spacer(Modifier.size(36.dp))
                    }

                    Spacer(Modifier.height(14.dp))

                    // КРУГЛАЯ ИКОНКА ПО ЦЕНТРУ
                    Box(
                        modifier = Modifier
                            .size(58.dp)
                            .clip(CircleShape)
                            .background(badgeBg),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            if (isExpense) Icons.Default.TrendingDown else if (isIncome) Icons.Default.TrendingUp else Icons.Default.Savings,
                            contentDescription = null,
                            tint = accentColor,
                            modifier = Modifier.size(30.dp)
                        )
                    }

                    Spacer(Modifier.height(14.dp))

                    // ПОЛЕ ВВОДА СУММЫ (НАДЕЖНЫЙ OutlinedTextField С ПОЛНЫМ ВВОДОМ)
                    OutlinedTextField(
                        value = amountText,
                        onValueChange = { amountText = it },
                        label = { Text("Сумма (₽)", fontWeight = FontWeight.Normal) },
                        placeholder = { Text("0") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        textStyle = TextStyle(
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        ),
                        trailingIcon = {
                            Text(
                                "₽",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = accentColor,
                                modifier = Modifier.padding(end = 12.dp)
                            )
                        },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(12.dp))

                    // ПРЕДЛОЖЕНИЕ СОЗДАТЬ РАЗДЕЛ ДЛЯ АВТО В ИТОГАХ МЕСЯЦА (ПОКАЗЫВАТЬ ТОЛЬКО ЕСЛИ РАЗДЕЛ ЕЩЁ НЕ СОЗДАН)
                    val carPrefs = context.getSharedPreferences("car_prefs", 0)
                    var createdCarSections by remember {
                        mutableStateOf(carPrefs.getStringSet("created_car_sections", emptySet())?.toSet() ?: emptySet())
                    }
                    var proposalDismissed by remember { mutableStateOf(false) }

                    val carsWithoutCategory = remember(cars, categories, createdCarSections) {
                        cars.filter { car ->
                            if (createdCarSections.contains(car.id)) return@filter false
                            val brand = car.brand.trim()
                            val model = car.model.trim()
                            val fullName = "$brand $model".trim()

                            val hasExistingCategory = categories.any { c ->
                                val cName = c.name.trim()
                                c.id == "cat_car_${car.id}" ||
                                (fullName.isNotBlank() && cName.equals(fullName, ignoreCase = true)) ||
                                (brand.isNotBlank() && cName.contains(brand, ignoreCase = true)) ||
                                (model.isNotBlank() && cName.contains(model, ignoreCase = true)) ||
                                cName.equals("Авто", ignoreCase = true) ||
                                cName.equals("Автомобиль", ignoreCase = true) ||
                                cName.equals("Машина", ignoreCase = true) ||
                                cName.equals("Учет по авто", ignoreCase = true) ||
                                cName.equals("Моя машина", ignoreCase = true) ||
                                cName.startsWith("Авто:", ignoreCase = true)
                            }
                            !hasExistingCategory
                        }
                    }

                    if (isExpense && carsWithoutCategory.isNotEmpty() && !proposalDismissed) {
                        val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                        val monthName = SimpleDateFormat("MMMM", Locale("ru")).format(cal.time)
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFFE3F2FD),
                            border = BorderStroke(1.dp, Color(0xFF90CAF9)),
                            modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                        ) {
                            Column(Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.DirectionsCar, null, tint = Color(0xFF1976D2), modifier = Modifier.size(18.dp))
                                        Spacer(Modifier.width(6.dp))
                                        Text(
                                            "Учет по автомобилю (Итоги за $monthName)",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFF0D47A1)
                                        )
                                    }
                                    IconButton(
                                        onClick = {
                                            val newSet = createdCarSections.toMutableSet()
                                            carsWithoutCategory.forEach { newSet.add(it.id) }
                                            createdCarSections = newSet
                                            carPrefs.edit().putStringSet("created_car_sections", newSet).apply()
                                            proposalDismissed = true
                                        },
                                        modifier = Modifier.size(20.dp)
                                    ) {
                                        Icon(Icons.Default.Close, null, modifier = Modifier.size(14.dp), tint = Color(0xFF1565C0))
                                    }
                                }
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "Создайте раздел с названием автомобиля в «Итоги за $monthName» для ведения всего учета:",
                                    fontSize = 10.sp,
                                    color = Color(0xFF1565C0)
                                )
                                Spacer(Modifier.height(6.dp))
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                                    modifier = Modifier.horizontalScroll(rememberScrollState())
                                ) {
                                    carsWithoutCategory.forEach { car ->
                                        val carCatName = "${car.brand} ${car.model}".trim()
                                        Surface(
                                            onClick = {
                                                val newCat = CategoryConfig(
                                                    id = "cat_car_${car.id}",
                                                    name = carCatName,
                                                    color = 0xFF1976D2.toInt(),
                                                    type = CatType.HISTORY
                                                )
                                                onAddCategory(newCat)
                                                selectedCatId = newCat.id
                                                if (noteText.isBlank()) {
                                                    noteText = "Расход на авто"
                                                }
                                                // Persist that section for this car has been created so proposal never reappears until new car is added
                                                val newSet = createdCarSections.toMutableSet()
                                                newSet.add(car.id)
                                                createdCarSections = newSet
                                                carPrefs.edit().putStringSet("created_car_sections", newSet).apply()
                                            },
                                            shape = RoundedCornerShape(8.dp),
                                            color = Color.White,
                                            border = BorderStroke(1.dp, Color(0xFF1976D2))
                                        ) {
                                            Row(
                                                Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    Icons.Default.Add,
                                                    null,
                                                    modifier = Modifier.size(13.dp),
                                                    tint = Color(0xFF1976D2)
                                                )
                                                Spacer(Modifier.width(4.dp))
                                                Text(
                                                    "+ Раздел «$carCatName»",
                                                    fontSize = 11.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = Color(0xFF1976D2)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // ПОЛЕ ВЫБОРА КАТЕГОРИИ (КЛИКАЯ ПО НЕЙ МОЖНО ВЫБРАТЬ ВСЕ КАТЕГОРИИ)
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(1.dp, if (selectedCatId == null) Color.LightGray.copy(alpha = 0.5f) else accentColor.copy(alpha = 0.8f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showCategoryPicker = true }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                if (isBalance) Icons.Default.Savings else Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = accentColor,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(Modifier.width(12.dp))
                            if (selectedCategoryInfo != null) {
                                val catConfig = categories.find { it.id == selectedCategoryInfo.first }
                                Box(
                                    modifier = Modifier
                                        .size(24.dp)
                                        .clip(CircleShape)
                                        .background(selectedCategoryInfo.third.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CategoryIconDisplay(
                                        iconKey = catConfig?.iconKey ?: "",
                                        customIconUri = catConfig?.customIconUri ?: "",
                                        categoryName = selectedCategoryInfo.second,
                                        categoryId = selectedCategoryInfo.first,
                                        tint = selectedCategoryInfo.third,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                                Spacer(Modifier.width(8.dp))
                                Text(
                                    selectedCategoryInfo.second,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                            } else {
                                Text(
                                    "Категория",
                                    fontSize = 14.sp,
                                    color = Color.Gray,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                            Icon(Icons.Default.ExpandMore, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // ПОЛЕ СЕГОДНЯ (КЛИКАЯ ОТКРЫВАЕТСЯ КАЛЕНДАРЬ С ВЫБОРОМ ДАТЫ)
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                        border = BorderStroke(1.dp, Color.LightGray.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable {
                                val cal = Calendar.getInstance().apply { timeInMillis = selectedDateMillis }
                                DatePickerDialog(
                                    context,
                                    { _, year, month, dayOfMonth ->
                                        val newCal = Calendar.getInstance().apply {
                                            set(year, month, dayOfMonth, 0, 0, 0)
                                            set(Calendar.MILLISECOND, 0)
                                        }
                                        selectedDateMillis = newCal.timeInMillis
                                    },
                                    cal.get(Calendar.YEAR),
                                    cal.get(Calendar.MONTH),
                                    cal.get(Calendar.DAY_OF_MONTH)
                                ).show()
                            }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.DateRange, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(12.dp))
                            Text(
                                dateFormatted,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface,
                                modifier = Modifier.weight(1f)
                            )
                            Icon(Icons.Default.KeyboardArrowRight, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(20.dp))
                        }
                    }

                    Spacer(Modifier.height(12.dp))

                    // ПОЛЕ ЗАМЕТКИ (НАДЕЖНЫЙ OutlinedTextField С ПОЛНЫМ ВВОДОМ)
                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        label = { Text("Заметка (комментарий)") },
                        placeholder = { Text("Например: покупка, зарплата, перевод...") },
                        singleLine = true,
                        leadingIcon = { Icon(Icons.Default.Edit, contentDescription = null, tint = Color.Gray) },
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(18.dp))

                    // КНОПКА СОХРАНИТЬ
                    Button(
                        onClick = {
                            val computed = if (amountText.isNotBlank()) evalMathExpression(amountText) else null
                            val clean = amountText.replace(",", ".").replace(" ", "").trim()
                            val amount = computed ?: clean.toDoubleOrNull() ?: 0.0
                            if (amount <= 0.0) {
                                Toast.makeText(context, "Укажите сумму", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            val targetCatId = selectedCatId ?: if (isExpense) "exp" else if (isIncome) "inc" else "dep"
                            onSave(targetCatId, amount, noteText.trim(), selectedDateMillis)

                            val matchedCar = cars.find { targetCatId == "cat_car_${it.id}" || categories.find { c -> c.id == targetCatId }?.name.equals("${it.brand} ${it.model}".trim(), ignoreCase = true) }
                            if (matchedCar != null && onSaveCarEvent != null) {
                                onSaveCarEvent(
                                    CarEventItem(
                                        id = "ev_${System.currentTimeMillis()}",
                                        carId = matchedCar.id,
                                        date = selectedDateMillis,
                                        type = "SERVICE",
                                        title = noteText.ifBlank { "Расход на ${matchedCar.brand} ${matchedCar.model}" },
                                        amount = amount,
                                        note = "Учтено в итогах месяца"
                                    )
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color(0xFF8BD3F8),
                            contentColor = Color(0xFF00325A)
                        )
                    ) {
                        Text("Сохранить", fontSize = 16.sp, fontWeight = FontWeight.Medium)
                    }
                }
            }
        }

    // ДИАЛОГ ВЫБОРА КАТЕГОРИИ
    if (showCategoryPicker) {
        AlertDialog(
            onDismissRequest = { showCategoryPicker = false },
            title = {
                Text(
                    if (isExpense) "Выберите категорию расходов" else if (isIncome) "Выберите категорию доходов" else "Выберите раздел накоплений",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    if (availableCategories.isEmpty()) {
                        Text("Нет созданных категорий", color = Color.Gray, fontSize = 12.sp)
                    }
                    availableCategories.forEach { (catId, catName, catColor) ->
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (selectedCatId == catId) accentColor.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = BorderStroke(
                                1.dp,
                                if (selectedCatId == catId) accentColor else Color.LightGray.copy(alpha = 0.3f)
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable {
                                    selectedCatId = catId
                                    showCategoryPicker = false
                                }
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val catConfig = categories.find { it.id == catId }
                                Box(
                                    modifier = Modifier
                                        .size(28.dp)
                                        .clip(CircleShape)
                                        .background(catColor.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CategoryIconDisplay(
                                        iconKey = catConfig?.iconKey ?: "",
                                        customIconUri = catConfig?.customIconUri ?: "",
                                        categoryName = catName,
                                        categoryId = catId,
                                        tint = catColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Spacer(Modifier.width(10.dp))
                                Text(
                                    catName,
                                    fontSize = 13.sp,
                                    fontWeight = if (selectedCatId == catId) FontWeight.Bold else FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                if (selectedCatId == catId) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = accentColor, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    // СОЗДАТЬ РАЗДЕЛ В СПИСКЕ КАТЕГОРИЙ
                    OutlinedButton(
                        onClick = {
                            showCategoryPicker = false
                            onCreateCategory(selectedType)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Создать раздел", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showCategoryPicker = false }) { Text("Отмена") }
            }
        )
    }
}

@Composable
fun SummaryItem(
    label: String,
    amount: String,
    color: Color,
    isHighlighted: Boolean = false,
    onClick: (() -> Unit)? = null
) {
    Column(
        Modifier
            .padding(end = 8.dp, bottom = 6.dp)
            .clip(RoundedCornerShape(8.dp))
            .then(
                if (onClick != null) Modifier.clickable { onClick() } else Modifier
            )
            .then(
                if (isHighlighted) Modifier
                    .background(Color(0xFFFFCDD2).copy(alpha = 0.65f))
                    .border(1.dp, Color(0xFFD32F2F), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                else if (onClick != null) Modifier
                    .background(MaterialTheme.colorScheme.surface.copy(alpha = 0.7f))
                    .border(0.5.dp, color.copy(alpha = 0.35f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
                else Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(7.dp).clip(CircleShape).background(color))
            Spacer(Modifier.width(4.dp))
            Text(
                label,
                fontSize = 10.sp,
                color = if (isHighlighted) Color(0xFFB71C1C) else MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = if (isHighlighted) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.height(2.dp))
        Text(
            amount,
            color = if (isHighlighted) Color(0xFFD32F2F) else color,
            fontWeight = ThemeManager.numWeight(),
            fontSize = 12.sp
        )
    }
}

// ==========================================
// МАТЕМАТИЧЕСКИЙ КАЛЬКУЛЯТОР ДЛЯ СУММ ТРАТ И ДОХОДОВ
// Позволяет вводить выражения: 450 + 120 + 80, 150 * 3, 1200 / 4 и т.д.
// ==========================================
fun evalMathExpression(expr: String): Double? {
    if (expr.isBlank()) return null
    val clean = expr.replace(",", ".").replace("×", "*").replace("÷", "/").replace(" ", "")
    if (!clean.matches(Regex("^[0-9.+\\-*/()]+$"))) return null

    val tokens = mutableListOf<String>()
    var i = 0
    while (i < clean.length) {
        val ch = clean[i]
        if (ch in "+-*/()") {
            if ((ch == '-' || ch == '+') && (tokens.isEmpty() || tokens.last() in listOf("+", "-", "*", "/", "("))) {
                var numStr = ch.toString()
                i++
                while (i < clean.length && (clean[i].isDigit() || clean[i] == '.')) {
                    numStr += clean[i]
                    i++
                }
                if (numStr == "-" || numStr == "+") return null
                tokens.add(numStr)
            } else {
                tokens.add(ch.toString())
                i++
            }
        } else if (ch.isDigit() || ch == '.') {
            var numStr = ""
            while (i < clean.length && (clean[i].isDigit() || clean[i] == '.')) {
                numStr += clean[i]
                i++
            }
            tokens.add(numStr)
        } else {
            return null
        }
    }

    val precedence = mapOf("+" to 1, "-" to 1, "*" to 2, "/" to 2)
    val outputQueue = mutableListOf<Any>()
    val opStack = mutableListOf<String>()

    for (token in tokens) {
        val num = token.toDoubleOrNull()
        if (num != null) {
            outputQueue.add(num)
        } else if (precedence.containsKey(token)) {
            while (opStack.isNotEmpty() && precedence.containsKey(opStack.last()) && precedence[opStack.last()]!! >= precedence[token]!!) {
                outputQueue.add(opStack.removeAt(opStack.size - 1))
            }
            opStack.add(token)
        } else if (token == "(") {
            opStack.add(token)
        } else if (token == ")") {
            var foundOpen = false
            while (opStack.isNotEmpty()) {
                val top = opStack.removeAt(opStack.size - 1)
                if (top == "(") {
                    foundOpen = true
                    break
                }
                outputQueue.add(top)
            }
            if (!foundOpen) return null
        } else {
            return null
        }
    }

    while (opStack.isNotEmpty()) {
        val top = opStack.removeAt(opStack.size - 1)
        if (top == "(" || top == ")") return null
        outputQueue.add(top)
    }

    if (outputQueue.isEmpty()) return null

    val evalStack = mutableListOf<Double>()
    for (item in outputQueue) {
        if (item is Double) {
            evalStack.add(item)
        } else if (item is String) {
            if (evalStack.size < 2) return null
            val b = evalStack.removeAt(evalStack.size - 1)
            val a = evalStack.removeAt(evalStack.size - 1)
            val res = when (item) {
                "+" -> a + b
                "-" -> a - b
                "*" -> a * b
                "/" -> if (b == 0.0) return null else a / b
                else -> return null
            }
            evalStack.add(res)
        }
    }

    if (evalStack.size != 1 || evalStack[0].isNaN() || evalStack[0].isInfinite()) return null
    return Math.round(evalStack[0] * 100.0) / 100.0
}

fun hasMathOperators(str: String): Boolean {
    return str.any { it in "+-*×/÷" }
}

@Composable
fun FinanceHistoryRow(
    label: String,
    catId: String,
    valInput: String = "",
    noteInput: String = "",
    historyJson: String,
    icon: ImageVector,
    color: Color,
    isIncognito: Boolean,
    onValChange: (String) -> Unit = {},
    onNoteChange: (String) -> Unit = {},
    onAdd: () -> Unit = {},
    onEdit: (String, FinanceItem, Boolean) -> Unit,
    currentBalanceLabel: String? = null,
    onManageSection: () -> Unit = {},
    isExpenseType: Boolean = false,
    isExcludedFromLimit: Boolean = false,
    onToggleExcludeLimit: (() -> Unit)? = null,
    onEditBalance: (() -> Unit)? = null,
    isColorFinance: Boolean = true
) {
    var expanded by remember { mutableStateOf(false) }; var editingItem by remember { mutableStateOf<FinanceItem?>(null) }
    val history = try { Gson().fromJson<List<FinanceItem>>(historyJson ?: "[]", object : TypeToken<List<FinanceItem>>() {}.type) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }

    Column(Modifier.fillMaxWidth().padding(vertical = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = color, modifier = Modifier.size(20.dp)); Spacer(Modifier.width(8.dp))
            Row(Modifier.weight(1f).clickable { onManageSection() }, verticalAlignment = Alignment.CenterVertically) {
                Text(label, fontWeight = FontWeight.Normal, fontSize = 12.sp)
                Icon(Icons.Default.MoreVert, null, Modifier.size(16.dp).padding(start = 2.dp), tint = Color.Gray)
                if (isExpenseType && onToggleExcludeLimit != null) {
                    Spacer(Modifier.width(6.dp))
                    Surface(
                        onClick = onToggleExcludeLimit,
                        shape = RoundedCornerShape(6.dp),
                        color = if (isExcludedFromLimit) Color(0xFFFFF3E0) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = BorderStroke(1.dp, if (isExcludedFromLimit) Color(0xFFFFB300) else Color.LightGray.copy(alpha = 0.5f))
                    ) {
                        Row(Modifier.padding(horizontal = 5.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                if (isExcludedFromLimit) Icons.Default.RemoveCircleOutline else Icons.Default.CheckCircle,
                                null,
                                modifier = Modifier.size(11.dp),
                                tint = if (isExcludedFromLimit) Color(0xFFE65100) else Color.Gray
                            )
                            Spacer(Modifier.width(3.dp))
                            Text(
                                if (isExcludedFromLimit) "Вне лимита" else "В лимите",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isExcludedFromLimit) Color(0xFFE65100) else Color.Gray
                            )
                        }
                    }
                }
            }
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = if (onEditBalance != null) Modifier.clip(RoundedCornerShape(6.dp)).clickable { onEditBalance() }.padding(horizontal = 4.dp, vertical = 2.dp) else Modifier
            ) {
                Text(currentBalanceLabel ?: mask(history.sumOf { it.amount }, isIncognito), fontWeight = ThemeManager.numWeight(), color = if (isColorFinance) color else Color(0xFF0F172A))
                if (onEditBalance != null) {
                    Spacer(Modifier.width(4.dp))
                    Icon(Icons.Default.Edit, contentDescription = "Редактировать баланс", tint = color.copy(alpha = 0.7f), modifier = Modifier.size(13.dp))
                }
            }
            IconButton(onClick = { expanded = !expanded }) { Icon(if(expanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore, null) }
        }

        if (expanded) Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = color.copy(0.05f))) {
            Column(Modifier.padding(8.dp)) {
                if(history.isEmpty()) Text("Нет записей за дату", fontSize = 10.sp, color = Color.Gray)
                history.forEach { item ->
                    Row(Modifier.fillMaxWidth().clickable { editingItem = item }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if(item.note.isEmpty()) "Запись" else item.note, fontSize = 11.sp, modifier = Modifier.weight(1f))
                        Text(mask(item.amount, isIncognito), fontWeight = ThemeManager.numWeight(), fontSize = 11.sp)
                        Icon(Icons.Default.Edit, null, Modifier.size(14.dp).padding(start = 4.dp), tint = Color.Gray)
                    }
                }
            }
        }
    }

    if(editingItem != null) {
        var eAmt by remember { mutableStateOf(editingItem!!.amount.toString()) }; var eNote by remember { mutableStateOf(editingItem!!.note) }
        val editComputed = remember(eAmt) { if (eAmt.isNotBlank()) evalMathExpression(eAmt) else null }
        val isEditExpr = remember(eAmt) { hasMathOperators(eAmt) }

        AlertDialog(
            onDismissRequest = { editingItem = null },
            title = { Text("Редактировать запись") },
            text = {
                Column {
                    OutlinedTextField(
                        value = eAmt,
                        onValueChange = { eAmt = it },
                        label = { Text(if (isEditExpr && editComputed != null) "Сумма (=$editComputed)" else "Сумма") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Text),
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (isEditExpr && editComputed != null) {
                        Text(
                            "Итого: $editComputed ₽",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF2E7D32),
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                    OutlinedTextField(value = eNote, onValueChange = { eNote = it }, label = { Text("Описание") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                }
            },
            confirmButton = {
                Button(onClick = {
                    val finalAmt = editComputed ?: eAmt.toDoubleOrNull() ?: editingItem!!.amount
                    onEdit(catId, editingItem!!.copy(amount = finalAmt, note = eNote), false)
                    editingItem = null
                }) { Text("ОК") }
            },
            dismissButton = { TextButton(onClick = { onEdit(catId, editingItem!!, true); editingItem = null }) { Text("Удалить", color = Color.Red) } }
        )
    }
}

