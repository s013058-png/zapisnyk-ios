package com.my.zapisnyk


import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor


// ==========================================
// 9. ДНЕВНИК И РЕДАКТОР (С ПРОСМОТРОМ ФОТО И ВИДЕО)
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddNoteScreen(dao: DiaryDao, date: Long, onBack: () -> Unit) {
    val context = LocalContext.current; val scope = rememberCoroutineScope(); val d = date.toMidnight()
    var title by remember { mutableStateOf("") }; var content by remember { mutableStateOf("") }; var tags by remember { mutableStateOf("") }
    var media by remember { mutableStateOf<List<String>>(emptyList()) }; var mainM by remember { mutableStateOf("") }; var mood by remember { mutableStateOf("") }
    var location by remember { mutableStateOf("") }
    var loading by remember { mutableStateOf(true) }; var fsPath by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(d) {
        val n = withContext(Dispatchers.Default) { dao.getNoteByDateSync(d) }
        n?.let {
            title = it.title ?: ""; content = it.content ?: ""; tags = it.tags ?: ""; mainM = it.mainMediaPath ?: ""; mood = it.mood ?: ""
            location = it.location ?: ""
            media = parseMediaPaths(it.mediaPaths)
        }
        loading = false
    }
    LaunchedEffect(title, content, tags, media, mainM, mood, location) {
        if(!loading) withContext(Dispatchers.Default){ dao.insertNote(DiaryNote(d, title, content, Gson().toJson(media), mainM, mood, tags, location)) }
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
        scope.launch {
            var hasBlockedVideo = false
            val paths = uris.mapNotNull { u ->
                val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(context.contentResolver.getType(u)) ?: "jpg"
                val isVid = isVideoPath("temp.$ext") || (context.contentResolver.getType(u)?.startsWith("video/") == true)
                if (isVid) {
                    if (!VideoLimitManager.canLoadVideo(context)) {
                        hasBlockedVideo = true
                        return@mapNotNull null
                    }
                    VideoLimitManager.recordVideoLoaded(context)
                }
                val f = File(context.filesDir, "media_${System.currentTimeMillis()}.$ext")
                context.contentResolver.openInputStream(u)?.use { it.copyTo(f.outputStream()) }
                f.absolutePath
            }
            if (hasBlockedVideo) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(context, "${VideoLimitManager.PRO_REQUIRED_MESSAGE}. В обычном режиме доступна только 1 загрузка видео.", Toast.LENGTH_LONG).show()
                }
            }
            media = media + paths
        }
    }
    Scaffold(topBar = { TopAppBar(title = { Text(SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(d))) }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { p ->
        Column(Modifier.padding(p).padding(16.dp).verticalScroll(rememberScrollState())) {
            Row(Modifier.fillMaxWidth(), Arrangement.SpaceEvenly) {
                listOf("🤩", "😊", "😐", "😔", "😡").forEach { em ->
                    Box(Modifier.size(48.dp).clip(CircleShape).background(if(mood==em) MaterialTheme.colorScheme.primary.copy(0.2f) else Color.Transparent).clickable { mood = if(mood==em) "" else em }.padding(8.dp), Alignment.Center) { Text(em, fontSize = 24.sp) }
                }
            }
            TextField(value = title, onValueChange = { title = it }, placeholder = { Text("Заголовок") }, modifier = Modifier.fillMaxWidth().padding(top = 16.dp), colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent))
            
            // Поле ввода местаположения
            OutlinedTextField(
                value = location,
                onValueChange = { location = it },
                label = { Text("Местоположение") },
                placeholder = { Text("Например: Парк Горького, Москва") },
                leadingIcon = { Icon(Icons.Default.Place, null, tint = MaterialTheme.colorScheme.primary) },
                trailingIcon = {
                    if (location.isNotEmpty()) {
                        IconButton(onClick = { location = "" }) {
                            Icon(Icons.Default.Close, null, modifier = Modifier.size(18.dp))
                        }
                    }
                },
                modifier = Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 4.dp),
                shape = RoundedCornerShape(10.dp),
                singleLine = true
            )
            // Быстрые теги мест
            Row(
                modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                listOf("Дом", "Работа", "Кафе", "Парк", "Зал", "В пути").forEach { place ->
                    val isSel = location.contains(place)
                    FilterChip(
                        selected = isSel,
                        onClick = { location = if (isSel) "" else place },
                        label = { Text(place, fontSize = 11.sp) }
                    )
                }
            }

            TextField(value = content, onValueChange = { content = it }, placeholder = { Text("Описание...") }, modifier = Modifier.fillMaxWidth(), minLines = 5, colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent))
            TextField(value = tags, onValueChange = { tags = it }, placeholder = { Text("Теги через запятую...") }, modifier = Modifier.fillMaxWidth(), colors = TextFieldDefaults.colors(focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent))
            media.forEach { path ->
                Box(Modifier.height(220.dp).fillMaxWidth().padding(vertical = 4.dp)) {
                    SafeMediaThumbnail(
                        path = path,
                        isVideo = isVideoPath(path),
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                if (isVideoPath(path)) openVideo(context, path) else fsPath = path
                            }
                    )
                    Row(Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                        IconButton(onClick = { mainM = if(mainM==path) "" else path }, Modifier.background(Color.Black.copy(0.4f), CircleShape)) { Icon(if(mainM==path) Icons.Default.Star else Icons.Default.StarOutline, null, tint = Color.Yellow) }
                        IconButton(onClick = { media = media.filter { it != path }; if(mainM==path) mainM = "" }, Modifier.background(Color.Black.copy(0.4f), CircleShape).padding(start = 8.dp)) { Icon(Icons.Default.Delete, null, tint = Color.White) }
                    }
                }
            }
            Button(onClick = { launcher.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)) }, Modifier.fillMaxWidth().padding(top = 16.dp)) { Text("Добавить медиа") }
        }
    }
    if(fsPath != null) {
        Dialog(onDismissRequest = { fsPath = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize().background(Color.Black).clickable { fsPath = null }) {
                SafeMediaThumbnail(
                    path = fsPath!!,
                    isVideo = isVideoPath(fsPath!!),
                    contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxSize()
                )
            }
        }
    }
}

// ==========================================
// 10. СИСТЕМНЫЕ ФУНКЦИИ (Settings, About, Cell, ExpectedFinanceDialog)
// ==========================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    dao: DiaryDao,
    nav: NavController,
    isDarkMode: Boolean = false,
    onTheme: (Color) -> Unit,
    onDarkModeChange: (Boolean) -> Unit = {}
) {
    val context = LocalContext.current; val scope = rememberCoroutineScope(); val prefs = context.getSharedPreferences("fin_cats", 0)
    val namesPref = context.getSharedPreferences("section_names", 0)
    val shiftConfig by dao.getShiftConfig().collectAsState(initial = null); val notes by dao.getAllNotes().collectAsState(initial = emptyList())
    val tasks by dao.getAllTasks().collectAsState(initial = emptyList()); val finances by dao.getAllFinances().collectAsState(initial = emptyList())
    val debts by dao.getAllDebts().collectAsState(initial = emptyList()); val expected by dao.getAllExpectedFinances().collectAsState(initial = emptyList())
    var isPro by remember { mutableStateOf(ProManager.isPro(context)) }; var code by remember { mutableStateOf("") }; var securityType by remember { mutableStateOf(SecurityManager.getSecurityType(context)) }

    val exportL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        uri?.let { fileUri ->
            scope.launch(Dispatchers.Default) {
                try {
                    context.contentResolver.openOutputStream(fileUri)?.use { os ->
                        ZipOutputStream(BufferedOutputStream(os)).use { zos ->
                        val addedEntryNames = mutableSetOf<String>()

                        // 1. Запись структуры данных в backup.json
                        zos.putNextEntry(ZipEntry("backup.json"))
                        addedEntryNames.add("backup.json")
                        val cats = try {
                            Gson().fromJson<List<CategoryConfig>>(prefs.getString("list", "[]"), object : TypeToken<List<CategoryConfig>>() {}.type)
                        } catch (_: Throwable) { emptyList<CategoryConfig>() }

                        val sNames = mapOf(
                            "inc" to (namesPref.getString("inc", "Доход") ?: "Доход"),
                            "exp" to (namesPref.getString("exp", "Расход") ?: "Расход"),
                            "dep" to (namesPref.getString("dep", "Депозит") ?: "Депозит")
                        )
                        val hiddenList = (namesPref.getStringSet("hidden", emptySet()) ?: emptySet()).toList()
                        val curExpenseLimit = getSafeExpenseLimit(context)
                        val curCapitalOverrides = getCapitalOverrides(context)
                        val curExcluded = getExcludedFromLimit(context).toList()
                        val curGoals = getSavingsGoals(context)
                        val curHasCar = getCarEnabled(context)
                        val curCars = getCarList(context)
                        val curCarEvents = getCarEvents(context)
                        val curMileageLogs = getCarMileageLogs(context)
                        val curReminders = getCarReminders(context)

                        val backupObj = BackupData(
                            notes = notes,
                            tasks = tasks,
                            shiftConfig = shiftConfig,
                            finances = finances,
                            debts = debts,
                            expectedFinances = expected,
                            categoryList = cats,
                            sectionNames = sNames,
                            hiddenSections = hiddenList,
                            expenseLimit = curExpenseLimit,
                            capitalOverrides = curCapitalOverrides,
                            excludedFromLimit = curExcluded,
                            savingsGoals = curGoals,
                            hasCar = curHasCar,
                            cars = curCars,
                            carEvents = curCarEvents,
                            carMileageLogs = curMileageLogs,
                            carReminders = curReminders
                        )
                        val jsonBytes = Gson().toJson(backupObj).encodeToByteArray()
                        zos.write(jsonBytes)
                        zos.closeEntry()

                        // 2. Безопасное сохранение медиафайлов (без дубликатов и без падений на несуществующих файлах)
                        notes.flatMap { n -> parseMediaPaths(n.mediaPaths) }.distinct().forEach { p ->
                            try {
                                if (!p.startsWith("http://") && !p.startsWith("https://") && !p.startsWith("yt:") && !p.startsWith("rutube:") && !p.startsWith("vk:")) {
                                    val cleanPath = when {
                                        p.startsWith("file://") -> p.removePrefix("file://")
                                        p.startsWith("file:") -> p.removePrefix("file:")
                                        else -> p
                                    }
                                    val f = File(cleanPath)
                                    if (f.exists() && f.isFile && f.canRead()) {
                                        val entryName = "media/${f.name}"
                                        if (addedEntryNames.add(entryName)) {
                                            zos.putNextEntry(ZipEntry(entryName))
                                            f.inputStream().use { it.copyTo(zos) }
                                            zos.closeEntry()
                                        }
                                    }
                                }
                            } catch (_: Throwable) {}
                        }

                        zos.finish()
                            zos.flush()
                        }
                        withContext(Dispatchers.Main) { Toast.makeText(context, "Резервная копия сохранена!", Toast.LENGTH_SHORT).show() }
                    }
                } catch(e: Exception) {
                    withContext(Dispatchers.Main) { Toast.makeText(context, "Ошибка сохранения: ${e.message ?: "сбой"}", Toast.LENGTH_LONG).show() }
                }
            }
        }
    }

    val importL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri?.let { fileUri ->
            scope.launch(Dispatchers.Default) {
                try {
                    var jsonText: String? = null

                    // 1. Попытка прочесть как ZIP-архив (читаем по байтам, без over-buffer стрима)
                    try {
                        context.contentResolver.openInputStream(fileUri)?.use { rawInput ->
                            val bis = BufferedInputStream(rawInput)
                            val zis = ZipInputStream(bis)
                            var entry: ZipEntry? = null
                            try { entry = zis.nextEntry } catch (_: Throwable) { entry = null }

                            while (entry != null) {
                                val name = entry.name
                                if (name == "backup.json" || name.endsWith("/backup.json")) {
                                    val baos = ByteArrayOutputStream()
                                    val buf = ByteArray(8192)
                                    var count: Int
                                    while (zis.read(buf).also { count = it } > 0) {
                                        baos.write(buf, 0, count)
                                    }
                                    jsonText = baos.toString("UTF-8")
                                } else if (name.startsWith("media/")) {
                                    val fileName = name.removePrefix("media/")
                                    if (fileName.isNotBlank()) {
                                        try {
                                            val f = File(context.filesDir, fileName)
                                            f.outputStream().use { fos ->
                                                val buf = ByteArray(8192)
                                                var count: Int
                                                while (zis.read(buf).also { count = it } > 0) {
                                                    fos.write(buf, 0, count)
                                                }
                                            }
                                        } catch (_: Throwable) {}
                                    }
                                }
                                try { zis.closeEntry() } catch (_: Throwable) {}
                                entry = try { zis.nextEntry } catch (_: Throwable) { null }
                            }
                        }
                    } catch (_: Throwable) {}

                    // 2. Если это не ZIP или backup.json внутри ZIP не найден, читаем файл напрямую как JSON
                    if (jsonText.isNullOrBlank()) {
                        try {
                            context.contentResolver.openInputStream(fileUri)?.use { rawInput ->
                                jsonText = rawInput.bufferedReader(Charsets.UTF_8).use { it.readText() }
                            }
                        } catch (_: Throwable) {}
                    }

                    if (jsonText.isNullOrBlank()) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Не удалось прочитать файл резервной копии (файл пуст или не читается)", Toast.LENGTH_LONG).show()
                        }
                        return@launch
                    }

                    val data: BackupData? = try {
                        Gson().fromJson(jsonText, BackupData::class)
                    } catch (t: Throwable) {
                        Log.e("Zapisnyk", "Gson parse error", t)
                        null
                    }

                    if (data == null) {
                        withContext(Dispatchers.Main) {
                            Toast.makeText(context, "Неверный формат резервной копии (структура JSON не распознана)", Toast.LENGTH_LONG).show()
                        }
                        return@launch
                    }

                    // 3. Безопасное восстановление всех сущностей без прерывания цепочки
                    var notesRestored = 0
                    var finRestored = 0

                    data.notes?.forEach { n ->
                        try {
                            val rawPaths = parseMediaPaths(n.mediaPaths)
                            val remappedPaths = rawPaths.map { p ->
                                if (!p.startsWith("http://") && !p.startsWith("https://") && !p.startsWith("yt:") && !p.startsWith("rutube:") && !p.startsWith("vk:")) {
                                    val fName = p.substringAfterLast('/')
                                    val localFile = File(context.filesDir, fName)
                                    if (fName.isNotBlank() && localFile.exists()) localFile.absolutePath else p
                                } else p
                            }
                            val rawMain = n.mainMediaPath ?: ""
                            val remappedMain = if (rawMain.isNotBlank() && !rawMain.startsWith("http") && !rawMain.startsWith("yt:") && !rawMain.startsWith("rutube:") && !rawMain.startsWith("vk:")) {
                                val fName = rawMain.substringAfterLast('/')
                                val localFile = File(context.filesDir, fName)
                                if (fName.isNotBlank() && localFile.exists()) localFile.absolutePath else rawMain
                            } else rawMain

                            dao.insertNote(n.copy(
                                tags = n.tags ?: "",
                                mood = n.mood ?: "",
                                mediaPaths = if (remappedPaths.isNotEmpty()) Gson().toJson(remappedPaths) else (n.mediaPaths ?: "[]"),
                                mainMediaPath = remappedMain
                            ))
                            notesRestored++
                        } catch (_: Throwable) {}
                    }

                    data.tasks?.forEach { t ->
                        try { dao.saveTask(t) } catch (_: Throwable) {}
                    }

                    data.finances?.forEach { f ->
                        try {
                            dao.saveFinance(f.copy(
                                incHistory = f.incHistory ?: "[]",
                                expHistory = f.expHistory ?: "[]",
                                depHistory = f.depHistory ?: "[]",
                                dynamicData = f.dynamicData ?: "{}",
                                dynamicBalances = f.dynamicBalances ?: "{}"
                            ))
                            finRestored++
                        } catch (_: Throwable) {}
                    }

                    data.debts?.forEach { d ->
                        try { dao.saveDebt(d) } catch (_: Throwable) {}
                    }

                    data.expectedFinances?.forEach { e ->
                        try { dao.saveExpectedFinance(e) } catch (_: Throwable) {}
                    }

                    data.shiftConfig?.let {
                        try { dao.saveShiftConfig(it) } catch (_: Throwable) {}
                    }

                    data.categoryList?.let { cats ->
                        try { prefs.edit().putString("list", Gson().toJson(cats)).apply() } catch (_: Throwable) {}
                    }

                    data.sectionNames?.forEach { (k, v) ->
                        try { namesPref.edit().putString(k, v).apply() } catch (_: Throwable) {}
                    }

                    data.hiddenSections?.let { hidden ->
                        try { namesPref.edit().putStringSet("hidden", hidden.toSet()).apply() } catch (_: Throwable) {}
                    }

                    data.expenseLimit?.let {
                        try { saveSafeExpenseLimit(context, it) } catch (_: Throwable) {}
                    }

                    data.excludedFromLimit?.let {
                        try { saveExcludedFromLimit(context, it.toSet()) } catch (_: Throwable) {}
                    }

                    data.capitalOverrides?.let { map ->
                        try {
                            val sp = context.getSharedPreferences("capital_overrides", 0)
                            val cur = getCapitalOverrides(context).toMutableMap()
                            cur.putAll(map)
                            sp.edit().putString("map", Gson().toJson(cur)).apply()
                        } catch (_: Throwable) {}
                    }

                    data.savingsGoals?.let {
                        try { saveSavingsGoals(context, it) } catch (_: Throwable) {}
                    }

                    data.hasCar?.let {
                        try { saveCarEnabled(context, it) } catch (_: Throwable) {}
                    }

                    data.cars?.let {
                        try { saveCarList(context, it) } catch (_: Throwable) {}
                    }

                    data.carEvents?.let {
                        try { saveCarEvents(context, it) } catch (_: Throwable) {}
                    }

                    data.carMileageLogs?.let {
                        try { saveCarMileageLogs(context, it) } catch (_: Throwable) {}
                    }

                    data.carReminders?.let {
                        try { saveCarReminders(context, it) } catch (_: Throwable) {}
                    }

                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Восстановлено! (Заметок: $notesRestored, Записей финансов: $finRestored)", Toast.LENGTH_LONG).show()
                    }
                } catch(e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Ошибка импорта: ${e.message ?: "сбой"}", Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }

    var showCsvMonthDialog by remember { mutableStateOf(false) }
    var selectedExportCal by remember { mutableStateOf(Calendar.getInstance()) }
    var csvDataToExport by remember { mutableStateOf<String?>(null) }
    val exportCsvLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/csv")
    ) { uri ->
        uri?.let { destUri ->
            val data = csvDataToExport ?: return@let
            scope.launch(Dispatchers.Default) {
                try {
                    context.contentResolver.openOutputStream(destUri)?.use { os ->
                        os.write(data.encodeToByteArray())
                    }
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Итоги месяца успешно экспортированы в CSV!", Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(context, "Ошибка сохранения CSV: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
    }

    fun generateAndExportCsv(cal: Calendar, isShare: Boolean = false) {
        val mFinForExport = finances.filter {
            val c = Calendar.getInstance().apply { timeInMillis = it.date }
            c.get(Calendar.MONTH) == cal.get(Calendar.MONTH) && c.get(Calendar.YEAR) == cal.get(Calendar.YEAR)
        }
        val monthName = SimpleDateFormat("LLLL yyyy", Locale("ru")).format(cal.time).replaceFirstChar { it.uppercase() }
        val dfDate = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

        fun esc(s: String): String {
            val clean = s.replace("\"", "\"\"")
            return if (clean.contains(";") || clean.contains("\n") || clean.contains("\r") || clean.contains("\"")) {
                "\"$clean\""
            } else {
                clean
            }
        }
        fun formatAmt(v: Double): String = String.format(Locale.US, "%.2f", v)

        val categories = try {
            Gson().fromJson<List<CategoryConfig>>(prefs.getString("list", "[]"), object : TypeToken<List<CategoryConfig>>() {}.type) ?: emptyList()
        } catch (e: Exception) { emptyList() }
        val sectionNames = mapOf(
            "inc" to (namesPref.getString("inc", "Доход") ?: "Доход"),
            "exp" to (namesPref.getString("exp", "Расход") ?: "Расход"),
            "dep" to (namesPref.getString("dep", "Депозит") ?: "Депозит")
        )
        val hiddenSections = namesPref.getStringSet("hidden", emptySet()) ?: emptySet()
        val expenseLimit = getSafeExpenseLimit(context)
        val excludedFromLimit = getExcludedFromLimit(context)
        val typeTokenFin = object : TypeToken<List<FinanceItem>>() {}.type

        var totalMonthIncome = 0.0
        var totalMonthExpenses = 0.0
        var totalMonthDeposits = 0.0
        var limitTargetExpenses = 0.0
        var excludedExpensesTotal = 0.0

        val incSecTotals = mutableMapOf<String, Double>()
        val expSecTotals = mutableMapOf<String, Double>()
        val balSecTotals = mutableMapOf<String, Double>()

        mFinForExport.forEach { fin ->
            if (!hiddenSections.contains("inc")) {
                val items = try { Gson().fromJson<List<FinanceItem>>(fin.incHistory ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                val sum = if (items.isNotEmpty()) items.sumOf { it.amount } else fin.income
                totalMonthIncome += sum
                incSecTotals["inc"] = (incSecTotals["inc"] ?: 0.0) + sum
            }
            if (!hiddenSections.contains("exp")) {
                val items = try { Gson().fromJson<List<FinanceItem>>(fin.expHistory ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                val sum = if (items.isNotEmpty()) items.sumOf { it.amount } else fin.expense
                totalMonthExpenses += sum
                expSecTotals["exp"] = (expSecTotals["exp"] ?: 0.0) + sum
                if (excludedFromLimit.contains("exp")) excludedExpensesTotal += sum else limitTargetExpenses += sum
            }
            if (!hiddenSections.contains("dep")) {
                val items = try { Gson().fromJson<List<FinanceItem>>(fin.depHistory ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                val sum = if (items.isNotEmpty()) items.sumOf { it.amount } else fin.savings_deposit
                totalMonthDeposits += sum
                balSecTotals["dep"] = (balSecTotals["dep"] ?: 0.0) + sum
            }
            val dataMap = try { Gson().fromJson<Map<String, String>>(fin.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch(e: Exception) { emptyMap() }
            categories.filter { it.type != CatType.BALANCE && !hiddenSections.contains(it.id) }.forEach { cat ->
                val items = try { Gson().fromJson<List<FinanceItem>>(dataMap[cat.id] ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                val sum = items.sumOf { it.amount }
                if (cat.type == CatType.INCOME) {
                    totalMonthIncome += sum
                    incSecTotals[cat.id] = (incSecTotals[cat.id] ?: 0.0) + sum
                } else {
                    totalMonthExpenses += sum
                    expSecTotals[cat.id] = (expSecTotals[cat.id] ?: 0.0) + sum
                    if (excludedFromLimit.contains(cat.id)) excludedExpensesTotal += sum else limitTargetExpenses += sum
                }
            }
            val balMap = try { Gson().fromJson<Map<String, String>>(fin.dynamicBalances ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch(e: Exception) { emptyMap() }
            categories.filter { it.type == CatType.BALANCE && !hiddenSections.contains(it.id) }.forEach { cat ->
                val items = try { Gson().fromJson<List<FinanceItem>>(balMap[cat.id] ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                val sum = items.sumOf { it.amount }
                totalMonthDeposits += sum
                balSecTotals[cat.id] = (balSecTotals[cat.id] ?: 0.0) + sum
            }
        }

        val sb = StringBuilder()
        sb.append("=== ИТОГИ ЗА МЕСЯЦ: ").append(monthName).append(" ===\n")
        sb.append("Показатель;Сумма (руб)\n")
        sb.append("Общие доходы;").append(formatAmt(totalMonthIncome)).append("\n")
        sb.append("Общие расходы;").append(formatAmt(totalMonthExpenses)).append("\n")
        sb.append("Чистый итог (Сальдо);").append(formatAmt(totalMonthIncome - totalMonthExpenses)).append("\n")
        sb.append("Накопления / Инвестиции (за месяц);").append(formatAmt(totalMonthDeposits)).append("\n")
        if (expenseLimit > 0) {
            sb.append("Лимит расходов;").append(formatAmt(expenseLimit)).append("\n")
            sb.append("Расходы в рамках лимита;").append(formatAmt(limitTargetExpenses)).append("\n")
            sb.append("Расходы вне лимита;").append(formatAmt(excludedExpensesTotal)).append("\n")
            sb.append("Остаток лимита;").append(formatAmt(expenseLimit - limitTargetExpenses)).append("\n")
        }
        sb.append("\n")

        sb.append("=== СВОДКА ПО РАЗДЕЛАМ ЗА МЕСЯЦ ===\n")
        sb.append("Тип;Раздел;Сумма (руб);Доля в категории (%);Статус лимита\n")
        if (!hiddenSections.contains("inc")) {
            val t = incSecTotals["inc"] ?: 0.0
            val pct = if (totalMonthIncome > 0) String.format(Locale.US, "%.1f", (t / totalMonthIncome) * 100) else "0.0"
            sb.append("Доход;").append(esc(sectionNames["inc"] ?: "Доход")).append(";").append(formatAmt(t)).append(";").append(pct).append("%;Не применимо\n")
        }
        categories.filter { it.type == CatType.INCOME && !hiddenSections.contains(it.id) }.forEach { cat ->
            val t = incSecTotals[cat.id] ?: 0.0
            val pct = if (totalMonthIncome > 0) String.format(Locale.US, "%.1f", (t / totalMonthIncome) * 100) else "0.0"
            sb.append("Доход;").append(esc(cat.name)).append(";").append(formatAmt(t)).append(";").append(pct).append("%;Не применимо\n")
        }
        if (!hiddenSections.contains("exp")) {
            val t = expSecTotals["exp"] ?: 0.0
            val pct = if (totalMonthExpenses > 0) String.format(Locale.US, "%.1f", (t / totalMonthExpenses) * 100) else "0.0"
            val limStatus = if (excludedFromLimit.contains("exp")) "Вне лимита" else "В лимите"
            sb.append("Расход;").append(esc(sectionNames["exp"] ?: "Расход")).append(";").append(formatAmt(t)).append(";").append(pct).append("%;").append(limStatus).append("\n")
        }
        categories.filter { it.type == CatType.HISTORY && !hiddenSections.contains(it.id) }.forEach { cat ->
            val t = expSecTotals[cat.id] ?: 0.0
            val pct = if (totalMonthExpenses > 0) String.format(Locale.US, "%.1f", (t / totalMonthExpenses) * 100) else "0.0"
            val limStatus = if (excludedFromLimit.contains(cat.id)) "Вне лимита" else "В лимите"
            sb.append("Расход;").append(esc(cat.name)).append(";").append(formatAmt(t)).append(";").append(pct).append("%;").append(limStatus).append("\n")
        }
        if (!hiddenSections.contains("dep")) {
            val t = balSecTotals["dep"] ?: 0.0
            sb.append("Накопление / Баланс;").append(esc(sectionNames["dep"] ?: "Депозит")).append(";").append(formatAmt(t)).append(";-;Не применимо\n")
        }
        categories.filter { it.type == CatType.BALANCE && !hiddenSections.contains(it.id) }.forEach { cat ->
            val t = balSecTotals[cat.id] ?: 0.0
            sb.append("Накопление / Баланс;").append(esc(cat.name)).append(";").append(formatAmt(t)).append(";-;Не применимо\n")
        }
        sb.append("\n")

        sb.append("=== ДЕТАЛИЗАЦИЯ ВСЕХ ОПЕРАЦИЙ ПО ДНЯМ ЗА ").append(monthName.uppercase()).append(" ===\n")
        sb.append("Дата;Тип;Раздел;Сумма (руб);Примечание\n")

        data class ExportRow(val date: Long, val type: String, val category: String, val amount: Double, val note: String)
        val rows = mutableListOf<ExportRow>()

        mFinForExport.sortedBy { it.date }.forEach { fin ->
            if (!hiddenSections.contains("exp")) {
                val items = try { Gson().fromJson<List<FinanceItem>>(fin.expHistory ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                if (items.isNotEmpty()) {
                    items.forEach { rows.add(ExportRow(fin.date, "Расход", sectionNames["exp"] ?: "Расход", it.amount, it.note)) }
                } else if (fin.expense > 0) {
                    rows.add(ExportRow(fin.date, "Расход", sectionNames["exp"] ?: "Расход", fin.expense, "Итого за день"))
                }
            }
            if (!hiddenSections.contains("inc")) {
                val items = try { Gson().fromJson<List<FinanceItem>>(fin.incHistory ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                if (items.isNotEmpty()) {
                    items.forEach { rows.add(ExportRow(fin.date, "Доход", sectionNames["inc"] ?: "Доход", it.amount, it.note)) }
                } else if (fin.income > 0) {
                    rows.add(ExportRow(fin.date, "Доход", sectionNames["inc"] ?: "Доход", fin.income, "Итого за день"))
                }
            }
            if (!hiddenSections.contains("dep")) {
                val items = try { Gson().fromJson<List<FinanceItem>>(fin.depHistory ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                if (items.isNotEmpty()) {
                    items.forEach { rows.add(ExportRow(fin.date, "Накопление", sectionNames["dep"] ?: "Депозит", it.amount, it.note)) }
                } else if (fin.savings_deposit > 0) {
                    rows.add(ExportRow(fin.date, "Накопление", sectionNames["dep"] ?: "Депозит", fin.savings_deposit, "Итого за день"))
                }
            }
            val dataMap = try { Gson().fromJson<Map<String, String>>(fin.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch(e: Exception) { emptyMap() }
            categories.filter { it.type != CatType.BALANCE && !hiddenSections.contains(it.id) }.forEach { cat ->
                val items = try { Gson().fromJson<List<FinanceItem>>(dataMap[cat.id] ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                val tName = if (cat.type == CatType.INCOME) "Доход" else "Расход"
                items.forEach { rows.add(ExportRow(fin.date, tName, cat.name, it.amount, it.note)) }
            }
            val balMap = try { Gson().fromJson<Map<String, String>>(fin.dynamicBalances ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch(e: Exception) { emptyMap() }
            categories.filter { it.type == CatType.BALANCE && !hiddenSections.contains(it.id) }.forEach { cat ->
                val items = try { Gson().fromJson<List<FinanceItem>>(balMap[cat.id] ?: "[]", typeTokenFin) ?: emptyList() } catch(e: Exception) { emptyList() }
                items.forEach { rows.add(ExportRow(fin.date, "Баланс/Инвестиция", cat.name, it.amount, it.note)) }
            }
        }

        rows.sortBy { it.date }
        rows.forEach { r ->
            sb.append(dfDate.format(Date(r.date))).append(";")
            sb.append(r.type).append(";")
            sb.append(esc(r.category)).append(";")
            sb.append(formatAmt(r.amount)).append(";")
            sb.append(esc(r.note)).append("\n")
        }

        val csvContent = "\uFEFF" + sb.toString()
        csvDataToExport = csvContent
        val monthNum = String.format(Locale.US, "%02d", cal.get(Calendar.MONTH) + 1)
        val fileName = "finances_${cal.get(Calendar.YEAR)}_$monthNum.csv"

        if (isShare) {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                putExtra(Intent.EXTRA_TEXT, csvContent)
                type = "text/csv"
            }
            context.startActivity(Intent.createChooser(sendIntent, "Экспорт CSV за $monthName"))
        } else {
            try {
                exportCsvLauncher.launch(fileName)
            } catch (e: Exception) {
                val sendIntent = Intent(Intent.ACTION_SEND).apply {
                    putExtra(Intent.EXTRA_TEXT, csvContent)
                    type = "text/csv"
                }
                context.startActivity(Intent.createChooser(sendIntent, "Экспорт CSV за $monthName"))
            }
        }
    }

    Scaffold(topBar = { TopAppBar(title = { Text("Настройки") }, navigationIcon = { IconButton(onClick = { nav.popBackStack() }) { Icon(Icons.Default.ArrowBack, null) } }) }) { p ->
        Column(Modifier.padding(p).padding(16.dp).verticalScroll(rememberScrollState())) {
            Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = if(isPro) Color(0xFFE8F5E9) else Color(0xFFFFF3E0))) {
                Column(Modifier.padding(12.dp)) {
                    Text(if(isPro) "PRO Активна" else "Бесплатная версия", fontWeight = FontWeight.Bold)
                    Text(
                        if (isPro) "• Загрузка видео: без ограничений"
                        else "• Загрузка видео: ${VideoLimitManager.getVideoLoadCount(context)}/1 использовано (для последующих загрузок нужен PRO)",
                        fontSize = 11.sp,
                        color = if (isPro) Color(0xFF2E7D32) else Color(0xFFE65100),
                        modifier = Modifier.padding(top = 2.dp, bottom = 4.dp)
                    )
                    if(!isPro) {
                        Text("ID: ${ProManager.getDeviceId(context)}", fontSize = 10.sp)
                        OutlinedTextField(value = code, onValueChange = { code = it }, label = { Text("Код активации") }, modifier = Modifier.fillMaxWidth())
                        Button(onClick = { if(ProManager.activatePro(context, code)) isPro = true }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Активировать") }
                    }
                }
            }
            Spacer(Modifier.height(16.dp)); Text("ЗАЩИТА", fontWeight = FontWeight.Bold)
            Card(Modifier.fillMaxWidth().padding(top = 8.dp)){
                Column(Modifier.padding(8.dp)){
                    listOf("Нет", "ПИН-код", "Пароль", "Биометрия").forEach { t ->
                        Row(Modifier.fillMaxWidth().clickable { securityType = t; if(t=="Нет"||t=="Биометрия") SecurityManager.setSecurity(context, t, "") }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(securityType == t, null); Text(t, Modifier.padding(start = 8.dp))
                        }
                    }
                }
            }
            if(securityType == "ПИН-код" || securityType == "Пароль") {
                var v by remember { mutableStateOf("") }
                OutlinedTextField(value = v, onValueChange = { v = it; SecurityManager.setSecurity(context, securityType, it) }, label = { Text("Придумайте код") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
            }

            Spacer(Modifier.height(16.dp)); Text("ГРАФИК СМЕН", fontWeight = FontWeight.Bold)
            Card(Modifier.fillMaxWidth().padding(top = 8.dp)){
                val conf = shiftConfig ?: ShiftConfig(startDate = System.currentTimeMillis())
                Column(Modifier.padding(8.dp)){
                    Row(Modifier.horizontalScroll(rememberScrollState()), verticalAlignment = Alignment.CenterVertically) {
                        conf.pattern.forEachIndexed { i, c ->
                            Box(
                                Modifier.size(45.dp).clip(RoundedCornerShape(8.dp)).background(if(c=='W') Color(conf.shiftColor) else Color.LightGray)
                                    .clickable {
                                        val new = conf.pattern.toCharArray(); new[i] = if(c=='W') 'R' else 'W'
                                        scope.launch { dao.saveShiftConfig(conf.copy(pattern = new.concatToString(), isActive = true)) }
                                    }.border(1.dp, Color.White, RoundedCornerShape(8.dp)),
                                Alignment.Center
                            ) { Text(if(c=='W') "Раб" else "Вых", fontSize = 10.sp, color = if(c=='W') Color.White else Color.Black) }
                        }
                        IconButton(onClick = { if(conf.pattern.length < 14) scope.launch { dao.saveShiftConfig(conf.copy(pattern = conf.pattern + "R", isActive = true)) } }) { Icon(Icons.Default.AddCircleOutline, null) }
                        if(conf.pattern.length > 1) IconButton(onClick = { scope.launch { dao.saveShiftConfig(conf.copy(pattern = conf.pattern.dropLast(1), isActive = true)) } }) { Icon(Icons.Default.RemoveCircleOutline, null) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 8.dp)) {
                        Text("Уведомление о смене", Modifier.weight(1f))
                        Switch(conf.isAlarmEnabled, { scope.launch { dao.saveShiftConfig(conf.copy(isAlarmEnabled = it, isActive = true)) } })
                    }
                    if(conf.isAlarmEnabled) {
                        Row(Modifier.clickable {
                            TimePickerDialog(context, {_,h,m -> scope.launch { dao.saveShiftConfig(conf.copy(alarmHour = h, alarmMinute = m, isActive = true)) } }, conf.alarmHour, conf.alarmMinute, true).show()
                        }.padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("Время будильника: ")
                            Text(String.format(Locale.getDefault(), "%02d:%02d", conf.alarmHour, conf.alarmMinute), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        }
                    }
                    Button(onClick = { DatePickerDialog(context, {_,y,m,d -> val c = Calendar.getInstance().apply { set(y,m,d) }; scope.launch { dao.saveShiftConfig(conf.copy(startDate = c.timeInMillis, isActive = true)) } }, Calendar.getInstance().get(Calendar.YEAR), Calendar.getInstance().get(Calendar.MONTH), Calendar.getInstance().get(Calendar.DAY_OF_MONTH)).show() }, Modifier.fillMaxWidth()) { Text("Дата начала цикла") }
                    Text("Цвет смен:", fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
                    Row(Modifier.fillMaxWidth().padding(top = 4.dp), Arrangement.SpaceEvenly) {
                        listOf(0xFFEF9A9A, 0xFF81C784, 0xFF64B5F6, 0xFFFFD54F, 0xFFBA68C8).forEach { c ->
                            Box(Modifier.size(36.dp).clip(CircleShape).background(Color(c)).clickable { scope.launch { dao.saveShiftConfig(conf.copy(shiftColor = c.toInt(), isActive = true)) } }.border(if(conf.shiftColor == c.toInt()) 2.dp else 0.dp, Color.Black, CircleShape))
                        }
                    }
                }
            }
            var settingLimit by remember {
                val curL = getSafeExpenseLimit(context)
                mutableStateOf(if (curL > 0) String.format(Locale.US, "%.0f", curL) else "")
            }
            var settingExcluded by remember { mutableStateOf(getExcludedFromLimit(context)) }
            Spacer(Modifier.height(10.dp)); Text("ЛИМИТ РАСХОДОВ НА МЕСЯЦ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Card(Modifier.fillMaxWidth().padding(top = 4.dp)) {
                Column(Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
                    Text(
                        "При превышении лимита итоги расходов окрашиваются в красный цвет.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                    OutlinedTextField(
                        value = settingLimit,
                        onValueChange = {
                            settingLimit = it
                            val clean = it.replace(",", ".").replace(" ", "").trim()
                            val l = clean.toDoubleOrNull() ?: 0.0
                            saveSafeExpenseLimit(context, l)
                        },
                        label = { Text("Лимит расходов (0 — выключен)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    )

                    Spacer(Modifier.height(6.dp))
                    Text(
                        "Исключить категории из лимита:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        "Траты из отмеченных категорий не учитываются в лимите (например, оплата квартиры).",
                        fontSize = 10.sp,
                        color = Color.Gray,
                        modifier = Modifier.padding(bottom = 2.dp)
                    )

                    val expCats = mutableListOf<Pair<String, String>>()
                    val hiddenSet = namesPref.getStringSet("hidden", emptySet()) ?: emptySet()
                    if (!hiddenSet.contains("exp")) expCats.add("exp" to (namesPref.getString("exp", "Расход") ?: "Расход"))
                    val allCats = Gson().fromJson<List<CategoryConfig>>(prefs.getString("list", "[]"), object : TypeToken<List<CategoryConfig>>() {}.type) ?: emptyList()
                    allCats.filter { it.type == CatType.HISTORY && !hiddenSet.contains(it.id) }.forEach {
                        expCats.add(it.id to it.name)
                    }

                    expCats.forEach { (catId, catName) ->
                        val isEx = settingExcluded.contains(catId)
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(4.dp))
                                .clickable {
                                    val next = if (isEx) settingExcluded - catId else settingExcluded + catId
                                    settingExcluded = next
                                    saveExcludedFromLimit(context, next)
                                }
                                .padding(vertical = 1.dp, horizontal = 2.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = isEx,
                                onCheckedChange = {
                                    val next = if (it) settingExcluded + catId else settingExcluded - catId
                                    settingExcluded = next
                                    saveExcludedFromLimit(context, next)
                                },
                                modifier = Modifier.size(28.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(catName, fontSize = 11.sp, fontWeight = if (isEx) FontWeight.Bold else FontWeight.Normal)
                            if (isEx) {
                                Spacer(Modifier.width(4.dp))
                                Text("• вне лимита", fontSize = 10.sp, color = Color(0xFFE65100), fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(16.dp)); Text("ЦВЕТОВАЯ СХЕМА В ФИНАНСАХ", fontWeight = FontWeight.Bold)
            Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                val finPrefs = context.getSharedPreferences("fin_prefs", 0)
                var isColorFinanceState by remember { mutableStateOf(finPrefs.getBoolean("finance_color_scheme", false)) }
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Включить цветовую схему", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(
                                "Цветовые акценты для сумм (зеленый доход, красный расход, янтарный баланс). В выключенном состоянии все цифры по умолчанию отображаются черным цветом.",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = isColorFinanceState,
                            onCheckedChange = {
                                isColorFinanceState = it
                                finPrefs.edit().putBoolean("finance_color_scheme", it).apply()
                            }
                        )
                    }
                }
            }



            Spacer(Modifier.height(16.dp)); Text("АВТОМОБИЛЬ", fontWeight = FontWeight.Bold)
            Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                var hasCarState by remember { mutableStateOf(getCarEnabled(context)) }
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Раздел «Автомобиль»", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text(
                                "У меня есть автомобиль. Включает в разделе «Финансы» блок с автомобилями: учёт расходов, заправок, средней стоимости 1 км, динамику одометра и напоминания о ТО (по дате или пробегу).",
                                fontSize = 11.sp,
                                color = Color.Gray,
                                modifier = Modifier.padding(top = 2.dp)
                            )
                        }
                        Spacer(Modifier.width(8.dp))
                        Switch(
                            checked = hasCarState,
                            onCheckedChange = {
                                hasCarState = it
                                saveCarEnabled(context, it)
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(16.dp)); Text("ТЕМА ОФОРМЛЕНИЯ", fontWeight = FontWeight.Bold)
            Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Тёмная тема (ночной режим)", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Снижает нагрузку на глаза в темное время суток", fontSize = 11.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = isDarkMode,
                            onCheckedChange = { onDarkModeChange(it) }
                        )
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Цветовой акцент приложения:", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Row(Modifier.fillMaxWidth().padding(top = 8.dp), Arrangement.SpaceEvenly) {
                        ThemeManager.ThemeOption.entries.forEach { o ->
                            Box(
                                Modifier.size(40.dp).clip(CircleShape).background(o.color)
                                    .clickable { ThemeManager.setTheme(context, o); onTheme(o.color) }
                                    .border(if(ThemeManager.getThemeColor(context) == o.color) 2.dp else 0.dp, MaterialTheme.colorScheme.onSurface, CircleShape)
                            )
                        }
                    }
                }
            }
            Spacer(Modifier.height(16.dp))

            // РАЗДЕЛ: УВЕДОМЛЕНИЯ И НАПОМИНАНИЯ
            Text("УВЕДОМЛЕНИЯ И НАПОМИНАНИЯ", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Card(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                var remindExpected by remember { mutableStateOf(ReminderManager.isExpectedRemindersEnabled(context)) }
                var remindDebts by remember { mutableStateOf(ReminderManager.isDebtRemindersEnabled(context)) }
                var remindShifts by remember { mutableStateOf(ReminderManager.isShiftRemindersEnabled(context)) }

                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("План платежей до конца месяца", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Напоминание о платежах за сутки и в день платежа (напр. аренда, ЖКХ)", fontSize = 11.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = remindExpected,
                            onCheckedChange = {
                                remindExpected = it
                                ReminderManager.setExpectedRemindersEnabled(context, it)
                            }
                        )
                    }
                    Divider(Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Кредиты и долги", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Напоминание за сутки и в день платежа по кредиту", fontSize = 11.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = remindDebts,
                            onCheckedChange = {
                                remindDebts = it
                                ReminderManager.setDebtRemindersEnabled(context, it)
                            }
                        )
                    }
                    Divider(Modifier.padding(vertical = 8.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Напоминание о рабочей смене", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Text("Уведомление накануне смены (работает даже если будильник выключен)", fontSize = 11.sp, color = Color.Gray)
                        }
                        Switch(
                            checked = remindShifts,
                            onCheckedChange = {
                                remindShifts = it
                                ReminderManager.setShiftRemindersEnabled(context, it)
                            }
                        )
                    }
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = {
                            scope.launch(Dispatchers.Default) {
                                val count = ReminderManager.checkAndSendReminders(context, dao)
                                withContext(Dispatchers.Main) {
                                    if (count > 0) {
                                        Toast.makeText(context, "Отправлено напоминаний: $count", Toast.LENGTH_SHORT).show()
                                    } else {
                                        Toast.makeText(context, "Напоминания активны! На сегодня и завтра сроков нет.", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.NotificationsActive, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Проверить напоминания сейчас", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    TextButton(
                        onClick = {
                            ReminderManager.clearDismissedReminders(context)
                            Toast.makeText(context, "Скрытые напоминания снова активны!", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Restore, null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("Вернуть скрытые сегодня напоминания", fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(4.dp))
                    Text(
                        "💡 Если вы убрали напоминание крестиком (✕), оно скрывается только на текущий день/смену и автоматически появится снова при следующем сроке.",
                        fontSize = 11.sp,
                        color = Color.Gray,
                        lineHeight = 14.sp
                    )
                }
            }
            Spacer(Modifier.height(24.dp))

            // РАЗДЕЛ: ЭКСПОРТ И БЭКАП (PRO)
            Card(
                Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                border = BorderStroke(1.dp, if (isPro) Color(0xFF2E7D32).copy(alpha = 0.5f) else Color.Gray.copy(alpha = 0.3f))
            ) {
                Column(Modifier.padding(14.dp)) {
                    Row(
                        Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("ЭКСПОРТ И БЭКАП", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = if (isPro) Color(0xFF2E7D32) else Color(0xFFF57C00)
                        ) {
                            Text(
                                if (isPro) "PRO АКТИВЕН" else "PRO ФУНКЦИЯ",
                                color = Color.White,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                    Text(
                        "Резервное копирование и экспорт аналитических данных",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f),
                        modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                    )

                    // Опция 1: Полный бэкап в ZIP
                    Card(
                        Modifier.fillMaxWidth().padding(bottom = 10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text("1. Резервная копия (все данные)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(
                                "Архивирует все заметки, фото, задачи, смены, финансы и настройки в ZIP файл.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Row(Modifier.fillMaxWidth().padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(
                                    onClick = {
                                        val df = SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(Date())
                                        exportL.launch("zapisnyk_backup_$df.zip")
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Экспорт ZIP", fontSize = 12.sp)
                                }
                                OutlinedButton(
                                    onClick = {
                                        importL.launch(arrayOf("application/zip", "application/json", "*/*"))
                                    },
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text("Импорт ZIP", fontSize = 12.sp)
                                }
                            }
                        }
                    }

                    // Опция 2: Экспорт CSV (Итоги месяца)
                    Card(
                        Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Text("2. Финансовый отчёт (CSV итоги месяца)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(
                                "Формирует структурированную таблицу с общими итогами, сводкой по всем категориям и детализацией операций по дням для Excel / Google Таблиц.",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Button(
                                onClick = {
                                    selectedExportCal = Calendar.getInstance()
                                    showCsvMonthDialog = true
                                },
                                modifier = Modifier.fillMaxWidth().padding(top = 8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Экспорт CSV (итоги месяца)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // ДИАЛОГ ВЫБОРА МЕСЯЦА ДЛЯ CSV
            if (showCsvMonthDialog) {
                val dialogMonthName = SimpleDateFormat("LLLL yyyy", Locale("ru")).format(selectedExportCal.time).replaceFirstChar { it.uppercase() }
                val monthFinances = finances.filter {
                    val c = Calendar.getInstance().apply { timeInMillis = it.date }
                    c.get(Calendar.MONTH) == selectedExportCal.get(Calendar.MONTH) && c.get(Calendar.YEAR) == selectedExportCal.get(Calendar.YEAR)
                }
                var previewInc = 0.0
                var previewExp = 0.0
                monthFinances.forEach { fin ->
                    previewInc += fin.income
                    previewExp += fin.expense
                }

                AlertDialog(
                    onDismissRequest = { showCsvMonthDialog = false },
                    title = {
                        Text("Экспорт итогов месяца в CSV", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    },
                    text = {
                        Column {
                            Text("Выберите месяц для формирования отчёта:", fontSize = 13.sp)
                            Spacer(Modifier.height(12.dp))
                            // Переключатель месяца
                            Row(
                                Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(onClick = {
                                    selectedExportCal = (selectedExportCal.clone() as Calendar).apply {
                                        add(Calendar.MONTH, -1)
                                    }
                                }) {
                                    Icon(Icons.Default.ChevronLeft, "Предыдущий месяц")
                                }
                                Text(dialogMonthName, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                IconButton(onClick = {
                                    selectedExportCal = (selectedExportCal.clone() as Calendar).apply {
                                        add(Calendar.MONTH, 1)
                                    }
                                }) {
                                    Icon(Icons.Default.ChevronRight, "Следующий месяц")
                                }
                            }

                            Card(
                                Modifier.fillMaxWidth().padding(top = 8.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            ) {
                                Column(Modifier.padding(10.dp)) {
                                    Text("Данные за выбранный период:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text("Дней с операциями: ${monthFinances.size}", fontSize = 12.sp)
                                    Text("Доходы: ${String.format(Locale.US, "%.2f", previewInc)} ₽", fontSize = 12.sp, color = Color(0xFF2E7D32))
                                    Text("Расходы: ${String.format(Locale.US, "%.2f", previewExp)} ₽", fontSize = 12.sp, color = Color(0xFFC62828))
                                    Text("Сальдо: ${String.format(Locale.US, "%.2f", previewInc - previewExp)} ₽", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    },
                    confirmButton = {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            TextButton(onClick = {
                                generateAndExportCsv(selectedExportCal, isShare = true)
                                showCsvMonthDialog = false
                            }) {
                                Text("Поделиться")
                            }
                            Button(
                                onClick = {
                                    generateAndExportCsv(selectedExportCal, isShare = false)
                                    showCsvMonthDialog = false
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                            ) {
                                Text("Сохранить в файл")
                            }
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showCsvMonthDialog = false }) {
                            Text("Отмена")
                        }
                    }
                )
            }

            OutlinedButton(onClick = { nav.navigate("about") }, Modifier.fillMaxWidth().padding(top = 32.dp)) { Text("О приложении") }
        }
    }
}

@Composable
fun DayCell(day: Int, cellCal: Calendar, notes: List<DiaryNote>, finances: List<DiaryFinance>, config: ShiftConfig?, onClick: () -> Unit) {
    val context = LocalContext.current
    val midnight = cellCal.timeInMillis.toMidnight(); val note = notes.find { it.date == midnight }; val fin = finances.find { it.date == midnight }
    val isWork = isWorkDay(cellCal.timeInMillis, config); val isT = System.currentTimeMillis().toMidnight() == midnight
    val hasCarReminder = remember(midnight) {
        getCarReminders(context).any { !it.isCompleted && it.targetDate?.toMidnight() == midnight }
    }
    val paths = remember(note?.mediaPaths) { parseMediaPaths(note?.mediaPaths) }
    val mainMedia = note?.mainMediaPath ?: ""
    val path = remember(mainMedia, paths) {
        if (mainMedia.isNotBlank()) mainMedia else paths.firstOrNull() ?: ""
    }
    val hasMedia = path.isNotBlank()
    val color = config?.shiftColor?.let { Color(it) } ?: Color(0xFFEF9A9A)
    Box(Modifier.fillMaxSize().padding(1.dp).clip(RoundedCornerShape(4.dp)).background(if(isWork && !hasMedia) color else if(isT && !hasMedia) MaterialTheme.colorScheme.primary.copy(0.2f) else MaterialTheme.colorScheme.surfaceVariant).border(if(isWork && hasMedia) 3.dp else 0.dp, color, RoundedCornerShape(4.dp)).border(if(isT) 2.dp else 0.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(4.dp)).clickable { onClick() }, contentAlignment = Alignment.Center) {
        if (hasMedia) {
            SafeMediaThumbnail(path, isVideoPath(path), modifier = Modifier.fillMaxSize(), showVideoBadge = false)
            Box(Modifier.fillMaxSize().background(Color.Black.copy(0.25f)))
        }
        if (note != null && ((note.title ?: "").isNotEmpty() || (note.content ?: "").isNotEmpty() || (note.location ?: "").isNotEmpty())) Box(Modifier.align(Alignment.TopEnd).padding(3.dp).size(5.dp).background(Color(0xFFFFC107), CircleShape).border(1.dp, Color.White, CircleShape))
        if (fin != null && (fin.income > 0 || fin.expense > 0 || (fin.depHistory ?: "[]") != "[]")) Box(Modifier.align(Alignment.TopStart).padding(3.dp).size(5.dp).background(Color(0xFF4CAF50), CircleShape))
        if (hasCarReminder) Box(Modifier.align(Alignment.BottomEnd).padding(3.dp).size(5.dp).background(Color(0xFF0284C7), CircleShape).border(0.5.dp, Color.White, CircleShape))
        val moodText = note?.mood ?: ""
        if (moodText.isNotEmpty()) Text(moodText, Modifier.align(Alignment.BottomStart).padding(1.dp), fontSize = 9.sp)
        Text(day.toString(), fontSize = 14.sp, fontWeight = FontWeight.Bold, color = if(isWork || hasMedia) Color.White else MaterialTheme.colorScheme.onSurface, style = if(hasMedia) TextStyle(shadow = Shadow(Color.Black, blurRadius = 8f)) else TextStyle.Default)
    }
}

@Composable
fun MonthView(m: Calendar, notes: List<DiaryNote>, fins: List<DiaryFinance>, config: ShiftConfig?, onDateClick: (Long) -> Unit) {
    val first = (m.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1) }; var offset = first.get(Calendar.DAY_OF_WEEK) - 2; if (offset < 0) offset = 6
    Column(Modifier.padding(8.dp)) {
        Text(SimpleDateFormat("MMMM yyyy", Locale("ru")).format(m.time).uppercase(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        for (row in 0 until 6) {
            val start = row * 7 - offset + 1; if (start > m.getActualMaximum(Calendar.DAY_OF_MONTH)) break
            Row {
                for (col in 0 until 7) {
                    val d = row * 7 + col - offset + 1
                    Box(Modifier.weight(1f).aspectRatio(1f)) {
                        if (d in 1..m.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                            val c = (m.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, d) }
                            DayCell(d, c, notes, fins, config) { onDateClick(c.timeInMillis.toMidnight()) }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun DayOverviewDialog(
    date: Long,
    notes: List<DiaryNote>,
    finances: List<DiaryFinance>,
    tasks: List<DiaryTask>,
    config: ShiftConfig?,
    onDismiss: () -> Unit,
    onOpenNote: (Long) -> Unit,
    onOpenFinance: (Long) -> Unit,
    onToggleTask: (DiaryTask, Boolean) -> Unit,
    onAddTask: ((DiaryTask) -> Unit)? = null
) {
    val context = LocalContext.current
    val dateStrRu = SimpleDateFormat("dd.MM.yyyy", Locale("ru")).format(Date(date))
    val dateTitle = SimpleDateFormat("d MMMM yyyy, EEEE", Locale("ru")).format(Date(date))
        .replaceFirstChar { if (it.isLowerCase()) it.uppercase() else it.toString() }

    val isWork = isWorkDay(date, config)
    val isToday = System.currentTimeMillis().toMidnight() == date.toMidnight()

    val fin = finances.find { it.date == date.toMidnight() }
    val note = notes.find { it.date == date.toMidnight() }

    val income = fin?.income ?: 0.0
    val expense = fin?.expense ?: 0.0
    val savings = fin?.savings_deposit ?: 0.0
    val net = income - expense

    val doneTasks = tasks.filter { it.lastDoneDate == dateStrRu }
    var showAddReminderDialog by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Surface(
                        color = MaterialTheme.colorScheme.primaryContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text("Обзор дня", Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    if (isToday) {
                        Surface(
                            color = Color(0xFF2E7D32).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Сегодня", Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                        }
                    }
                    if (isWork) {
                        Surface(
                            color = Color(0xFFC2185B).copy(alpha = 0.2f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text("Смена", Modifier.padding(horizontal = 6.dp, vertical = 2.dp), fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFC2185B))
                        }
                    }
                    if (!note?.mood.isNullOrEmpty()) {
                        Text(note!!.mood, fontSize = 14.sp)
                    }
                }
                Spacer(Modifier.height(4.dp))
                Text(dateTitle, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                // 3 KPI cards
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9))) {
                        Column(Modifier.padding(8.dp)) {
                            Text("Доходы", fontSize = 10.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                            Text(if (income > 0) "+${income.toLong()} ₽" else "0 ₽", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFF1B5E20))
                        }
                    }
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE))) {
                        Column(Modifier.padding(8.dp)) {
                            Text("Траты", fontSize = 10.sp, color = Color(0xFFC62828), fontWeight = FontWeight.Bold)
                            Text(if (expense > 0) "-${expense.toLong()} ₽" else "0 ₽", fontSize = 13.sp, fontWeight = FontWeight.Black, color = Color(0xFFB71C1C))
                        }
                    }
                    Card(Modifier.weight(1f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                        Column(Modifier.padding(8.dp)) {
                            Text("Итог", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.Bold)
                            val netColor = if (net > 0) Color(0xFF2E7D32) else if (net < 0) Color(0xFFC62828) else MaterialTheme.colorScheme.onSurfaceVariant
                            Text("${if (net > 0) "+" else ""}${net.toLong()} ₽", fontSize = 13.sp, fontWeight = FontWeight.Black, color = netColor)
                        }
                    }
                }

                if (savings > 0) {
                    Surface(
                        color = Color(0xFFE3F2FD),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                            Text("Отложено в накопления:", fontSize = 11.sp, color = Color(0xFF1565C0))
                            Text("+${savings.toLong()} ₽", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0D47A1))
                        }
                    }
                }

                // Tasks section
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Задачи (выполнено ${doneTasks.size} из ${tasks.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        TextButton(
                            onClick = { showAddReminderDialog = true },
                            contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Icon(Icons.Default.Add, null, modifier = Modifier.size(14.dp))
                            Spacer(Modifier.width(2.dp))
                            Text("+ Напоминание", fontSize = 11.sp)
                        }
                    }
                    if (tasks.isEmpty()) {
                        Text("Нет задач", fontSize = 11.sp, color = Color.Gray)
                    } else {
                        tasks.forEach { t ->
                            val isDone = t.lastDoneDate == dateStrRu
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .clickable { onToggleTask(t, !isDone) }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Checkbox(checked = isDone, onCheckedChange = { onToggleTask(t, it) })
                                Text(
                                    t.title,
                                    fontSize = 12.sp,
                                    textDecoration = if (isDone) TextDecoration.LineThrough else null,
                                    color = if (isDone) Color.Gray else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                                if (!t.videoUrl.isNullOrBlank()) {
                                    val vidPath = t.videoUrl!!
                                    IconButton(
                                        onClick = { openVideo(context, vidPath) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.PlayCircleOutline,
                                            contentDescription = "Смотреть видео",
                                            tint = if (isYouTubeUrl(vidPath)) Color(0xFFCC0000) else if (isRutubeUrl(vidPath)) Color(0xFF00A0E3) else MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // Car reminders section
                val carRemindersThisDay = remember(date) {
                    val mid = date.toMidnight()
                    getCarReminders(context).filter { it.targetDate?.toMidnight() == mid }
                }
                val carsThisDay = remember { getCarList(context) }
                if (carRemindersThisDay.isNotEmpty()) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFE0F2FE)),
                        border = BorderStroke(1.dp, Color(0xFFBAE6FD))
                    ) {
                        Column(Modifier.padding(10.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DirectionsCar, null, tint = Color(0xFF0284C7), modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text("Напоминания по авто (${carRemindersThisDay.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0369A1))
                            }
                            Spacer(Modifier.height(4.dp))
                            carRemindersThisDay.forEach { r ->
                                val car = carsThisDay.find { it.id == r.carId }
                                val carName = if (car != null) "${car.brand} ${car.model}" else "Авто"
                                Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text("• $carName: ${r.title}", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                                    if (r.isCompleted) {
                                        Text("✓ Выполнено", fontSize = 10.sp, color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                TextButton(onClick = { onOpenFinance(date) }) {
                    Text("Финансы")
                }
                Button(onClick = { onOpenNote(date) }) {
                    Text(if (note != null) "Заметка" else "Создать запись")
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Закрыть")
            }
        }
    )

    if (showAddReminderDialog) {
        var reminderTitle by remember { mutableStateOf("") }
        var reminderTime by remember { mutableStateOf("09:00") }
        AlertDialog(
            onDismissRequest = { showAddReminderDialog = false },
            title = { Text("Напоминание на $dateStrRu", fontSize = 16.sp, fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = reminderTitle,
                        onValueChange = { reminderTitle = it },
                        label = { Text("Что напомнить?") },
                        placeholder = { Text("Например: Оплатить интернет") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = reminderTime,
                        onValueChange = { reminderTime = it },
                        label = { Text("Время (ЧЧ:ММ)") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (reminderTitle.isNotBlank()) {
                            onAddTask?.invoke(
                                DiaryTask(
                                    title = reminderTitle.trim(),
                                    frequency = "ONCE",
                                    targetDate = date,
                                    timeOfDay = reminderTime,
                                    priority = "HIGH"
                                )
                            )
                            showAddReminderDialog = false
                        }
                    },
                    enabled = reminderTitle.isNotBlank()
                ) { Text("Создать") }
            },
            dismissButton = {
                TextButton(onClick = { showAddReminderDialog = false }) { Text("Отмена") }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AboutScreen(onBack: () -> Unit) {
    val uri = LocalUriHandler.current
    Scaffold(topBar = { TopAppBar(title = { Text("О приложении") }, navigationIcon = { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) } }) }) { p ->
        Column(Modifier.padding(p).fillMaxSize().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.size(80.dp).background(MaterialTheme.colorScheme.primary, CircleShape), Alignment.Center) { Icon(Icons.Default.MenuBook, null, Modifier.size(40.dp), tint = Color.White) }
            Text("Zapisnyk", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary); Text("Версия 2.1", color = Color.Gray)
            Spacer(Modifier.height(24.dp)); Card(Modifier.fillMaxWidth()) { Text("Ваш личный дневник с задачами, планированием финансов и гибким графиком смен. Всё необходимое в одном месте.", Modifier.padding(16.dp), textAlign = TextAlign.Center) }
            Spacer(Modifier.height(24.dp)); Button(onClick = { uri.openUri("https://t.me/Zapisnyk1") }, Modifier.fillMaxWidth()) { Text("Telegram канал") }
            OutlinedButton(onClick = { uri.openUri("https://t.me/EugenG86") }, Modifier.fillMaxWidth().padding(top = 8.dp)) { Text("Связаться с автором") }
        }
    }
}

enum class TimelineSort(val label: String) { DATE("По дате"), MOOD("По настроению"), MEDIA("С медиа") }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TimelineView(
    notes: List<DiaryNote>,
    onDeleteDate: ((Long) -> Unit)? = null,
    onEdit: (Long) -> Unit
) {
    val context = LocalContext.current
    var q by remember { mutableStateOf("") }
    var selectedTag by remember { mutableStateOf<String?>(null) }
    var sortMode by remember { mutableStateOf(TimelineSort.DATE) }
    var dateToDelete by remember { mutableStateOf<Long?>(null) }

    val allTags = remember(notes) {
        notes.flatMap { note ->
            (note.tags ?: "")
                .split(",")
                .map { it.trim().removePrefix("#").trim() }
                .filter { it.isNotEmpty() }
        }.distinct().sorted()
    }

    fun moodScore(mood: String?): Int = when (mood?.trim()) {
        "🤩" -> 5
        "😊" -> 4
        "😐" -> 3
        "😔" -> 2
        "😡" -> 1
        else -> 0
    }

    fun getMediaCount(n: DiaryNote): Int {
        val paths = parseMediaPaths(n.mediaPaths)
        return paths.size + (if ((n.mainMediaPath ?: "").isNotBlank() && !paths.contains(n.mainMediaPath)) 1 else 0)
    }

    val filtered = notes.filter { n ->
        val matchesQuery = q.isEmpty() ||
            (n.title ?: "").contains(q, true) ||
            (n.content ?: "").contains(q, true) ||
            (n.tags ?: "").contains(q, true) ||
            (n.location ?: "").contains(q, true)

        val noteTags = (n.tags ?: "")
            .split(",")
            .map { it.trim().removePrefix("#").trim() }
            .filter { it.isNotEmpty() }

        val matchesTag = selectedTag == null || noteTags.any { it.equals(selectedTag, ignoreCase = true) }

        matchesQuery && matchesTag
    }

    val sorted = remember(filtered, sortMode) {
        when (sortMode) {
            TimelineSort.DATE -> filtered.sortedByDescending { it.date }
            TimelineSort.MOOD -> filtered.sortedWith(
                compareByDescending<DiaryNote> { moodScore(it.mood) }
                    .thenByDescending { it.date }
            )
            TimelineSort.MEDIA -> filtered.sortedWith(
                compareByDescending<DiaryNote> { getMediaCount(it) }
                    .thenByDescending { it.date }
            )
        }
    }

    Column(Modifier.fillMaxSize()) {
        OutlinedTextField(
            value = q,
            onValueChange = { q = it },
            placeholder = { Text("Поиск...") },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
            leadingIcon = { Icon(Icons.Default.Search, null) },
            shape = RoundedCornerShape(12.dp)
        )

        // Переключатели сортировки заметок (по дате, настроению, наличию медиа)
        LazyRow(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 2.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            item {
                Text("Сортировка:", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
            }
            items(listOf(TimelineSort.DATE, TimelineSort.MOOD, TimelineSort.MEDIA)) { mode ->
                val isSelected = sortMode == mode
                FilterChip(
                    selected = isSelected,
                    onClick = { sortMode = mode },
                    label = {
                        Text(
                            when (mode) {
                                TimelineSort.DATE -> "📅 По дате"
                                TimelineSort.MOOD -> "😊 По настроению"
                                TimelineSort.MEDIA -> "📷 С медиа"
                            },
                            fontSize = 11.sp
                        )
                    }
                )
            }
        }

        // Чипсы с тегами над списком заметок
        if (allTags.isNotEmpty()) {
            LazyRow(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                item {
                    Text("Теги:", fontSize = 11.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
                }
                item {
                    FilterChip(
                        selected = selectedTag == null,
                        onClick = { selectedTag = null },
                        label = { Text("Все") }
                    )
                }
                items(allTags) { tag ->
                    val isSelected = selectedTag.equals(tag, ignoreCase = true)
                    FilterChip(
                        selected = isSelected,
                        onClick = {
                            selectedTag = if (isSelected) null else tag
                        },
                        label = { Text("#$tag") }
                    )
                }
            }
        }

        LazyColumn(Modifier.padding(horizontal = 16.dp)) {
            if (sorted.isEmpty()) {
                item {
                    Box(Modifier.fillMaxWidth().padding(top = 32.dp), contentAlignment = Alignment.Center) {
                        Text("Заметок не найдено", color = Color.Gray, fontSize = 13.sp)
                    }
                }
            }
            items(sorted) { n ->
                val paths: List<String> = parseMediaPaths(n.mediaPaths)
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { onEdit(n.date) }) {
                    Column(Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(n.date)), fontSize = 10.sp, color = Color.Gray)
                            Spacer(Modifier.weight(1f))
                            if((n.mood?:"").isNotEmpty()) Text(n.mood!!)
                            if (onDeleteDate != null) {
                                Spacer(Modifier.width(6.dp))
                                IconButton(
                                    onClick = { dateToDelete = n.date },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Delete,
                                        contentDescription = "Удалить дату",
                                        modifier = Modifier.size(15.dp),
                                        tint = MaterialTheme.colorScheme.error.copy(alpha = 0.75f)
                                    )
                                }
                            }
                        }
                        if((n.title?:"").isNotEmpty()) Text(n.title!!, fontWeight = FontWeight.Bold)
                        if((n.location?:"").isNotEmpty()) {
                            Row(
                                Modifier.padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Place, null, modifier = Modifier.size(13.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(3.dp))
                                Text(n.location!!, fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Medium)
                            }
                        }
                        Text(n.content?:"", maxLines = 3, overflow = TextOverflow.Ellipsis, fontSize = 13.sp)
                        val noteTags = (n.tags ?: "").split(",").map { it.trim().removePrefix("#").trim() }.filter { it.isNotEmpty() }
                        if (noteTags.isNotEmpty()) {
                            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                noteTags.forEach { t ->
                                    val isSelected = selectedTag.equals(t, ignoreCase = true)
                                    Box(
                                        Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
                                            .clickable { selectedTag = if (isSelected) null else t }
                                            .padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            "#$t",
                                            fontSize = 10.sp,
                                            color = if (isSelected) Color.White else MaterialTheme.colorScheme.primary,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                }
                            }
                        }
                        if(paths.isNotEmpty()) {
                            LazyRow(Modifier.padding(top = 8.dp)) {
                                items(paths) { p ->
                                    SafeMediaThumbnail(
                                        path = p,
                                        isVideo = isVideoPath(p),
                                        modifier = Modifier
                                            .size(80.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable {
                                                if (isVideoPath(p)) openVideo(context, p) else onEdit(n.date)
                                            }
                                            .padding(end = 4.dp),
                                        contentScale = ContentScale.Crop
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        if (dateToDelete != null) {
            val targetDate = dateToDelete!!
            AlertDialog(
                onDismissRequest = { dateToDelete = null },
                title = { Text("Удалить дату полностью?") },
                text = {
                    Text("Вы действительно хотите удалить все записи и данные за ${SimpleDateFormat("dd.MM.yyyy", Locale.getDefault()).format(Date(targetDate))}?")
                },
                confirmButton = {
                    TextButton(
                        onClick = {
                            onDeleteDate?.invoke(targetDate)
                            dateToDelete = null
                        },
                        colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                    ) {
                        Text("Удалить", fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { dateToDelete = null }) {
                        Text("Отмена")
                    }
                }
            )
        }
    }
}

