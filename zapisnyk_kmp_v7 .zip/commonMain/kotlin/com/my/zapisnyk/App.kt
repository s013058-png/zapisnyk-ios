package com.my.zapisnyk

import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

// ==========================================
// 4. ГЛАВНЫЙ КОРНЕВОЙ КОМПОНЕНТ (KMP App + MainScreen)
// ==========================================

@Composable
fun App() {
    PlatformNative.ensureInitialized()?.BindContext()
    val context = LocalContext.current
    LaunchedEffect(Unit) {
        InMemoryDiaryDaoInstance.reloadFromStorage()
        ThemeManager.init(context)
    }
    val dao = remember { InMemoryDiaryDaoInstance }
    var currentThemeColor by remember { mutableStateOf(ThemeManager.getThemeColor(context)) }
    var isDarkMode by remember { mutableStateOf(ThemeManager.isDarkMode(context)) }

    val colorScheme = if (isDarkMode) {
        darkColorScheme(
            primary = currentThemeColor,
            background = Color(0xFF0B0F19),
            surface = Color(0xFF151D2E),
            surfaceVariant = Color(0xFF1E293B),
            onPrimary = Color.White,
            onBackground = Color(0xFFF8FAFC),
            onSurface = Color(0xFFF8FAFC),
            outline = Color(0xFF334155)
        )
    } else {
        lightColorScheme(primary = currentThemeColor)
    }

    CompositionLocalProvider(LocalIsModernFont provides ThemeManager.isModernFont) {
        MaterialTheme(colorScheme = colorScheme) {
            Box(Modifier.fillMaxSize()) {
                var isUnlocked by remember { mutableStateOf(SecurityManager.getSecurityType(context) == "Нет") }
                if (!isUnlocked) {
                    AuthScreen { isUnlocked = true }
                } else {
                    val nav = remember { NavController() }
                    val route = nav.currentRoute
                    when {
                        route == "main" -> {
                            MainScreen(
                                dao = dao,
                                nav = nav,
                                isDarkMode = isDarkMode,
                                onToggleDarkMode = {
                                    val next = !isDarkMode
                                    isDarkMode = next
                                    ThemeManager.setDarkMode(context, next)
                                }
                            )
                        }
                        route.startsWith("add/") -> {
                            val dateArg = route.removePrefix("add/").toLongOrNull() ?: System.currentTimeMillis().toMidnight()
                            AddNoteScreen(dao, dateArg) { nav.popBackStack() }
                        }
                        route == "settings" -> {
                            SettingsScreen(
                                dao = dao,
                                nav = nav,
                                isDarkMode = isDarkMode,
                                onTheme = { currentThemeColor = it },
                                onDarkModeChange = {
                                    isDarkMode = it
                                    ThemeManager.setDarkMode(context, it)
                                }
                            )
                        }
                        route == "about" -> {
                            AboutScreen { nav.popBackStack() }
                        }
                    }
                }
                PlatformDialogHost()
            }
        }
    }
}

@Composable
fun AuthScreen(onSuccess: () -> Unit) {
    val context = LocalContext.current
    val type = SecurityManager.getSecurityType(context)
    var input by remember { mutableStateOf("") }
    LaunchedEffect(Unit) {
        if (type == "Биометрия") {
            SecurityManager.authenticateBiometric(FragmentActivity()) { if (it) onSuccess() }
        }
    }
    Column(Modifier.fillMaxSize(), Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(Icons.Default.Lock, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.height(16.dp))
        if (type == "ПИН-код" || type == "Пароль") {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = if (type == "ПИН-код") KeyboardType.Number else KeyboardType.Password),
                label = { Text("Введите код") }
            )
            Button(
                onClick = { if (input == SecurityManager.getSecurityValue(context)) onSuccess() },
                Modifier.padding(top = 16.dp)
            ) {
                Text("Войти")
            }
        }
    }
}

// ==========================================
// 5. ГЛАВНЫЙ ЭКРАН
// ==========================================

enum class ViewMode(val label: String) {
    Calendar("Календарь"),
    Timeline("Лента"),
    Finance("Финансы"),
    Tasks("Задачи"),
    Analytics("Аналитика"),
    Attachments("Вложения")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    dao: DiaryDao,
    nav: NavController,
    isDarkMode: Boolean = false,
    onToggleDarkMode: () -> Unit = {}
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val notes by dao.getAllNotes().collectAsState(initial = emptyList())
    val tasks by dao.getAllTasks().collectAsState(initial = emptyList())
    val finances by dao.getAllFinances().collectAsState(initial = emptyList())
    val shiftConfig by dao.getShiftConfig().collectAsState(initial = null)
    val debts by dao.getAllDebts().collectAsState(initial = emptyList())
    val expected by dao.getAllExpectedFinances().collectAsState(initial = emptyList())

    var viewMode by remember { mutableStateOf(ViewMode.Calendar) }
    var globalDate by remember { mutableLongStateOf(System.currentTimeMillis().toMidnight()) }
    var showJumpDialog by remember { mutableStateOf(false) }
    var isIncognito by remember { mutableStateOf(false) }
    var dayOverviewDate by remember { mutableStateOf<Long?>(null) }

    val listState = rememberLazyListState(initialFirstVisibleItemIndex = 24)
    val months = remember { (0..48).map { Calendar.getInstance().apply { add(Calendar.MONTH, it - 24) } } }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = viewMode.label,
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold
                    )
                },
                actions = {
                    IconButton(onClick = onToggleDarkMode) {
                        Icon(
                            if (isDarkMode) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = if (isDarkMode) "Светлая тема" else "Тёмная тема (ночной режим)"
                        )
                    }
                    if (viewMode == ViewMode.Finance || viewMode == ViewMode.Analytics) {
                        IconButton(onClick = { isIncognito = !isIncognito }) {
                            Icon(if (isIncognito) Icons.Default.VisibilityOff else Icons.Default.Visibility, "Инкогнито")
                        }
                    }
                    if (viewMode == ViewMode.Calendar || viewMode == ViewMode.Finance || viewMode == ViewMode.Attachments) {
                        IconButton(onClick = { showJumpDialog = true }) {
                            Icon(Icons.Default.DateRange, "Выбор даты")
                        }
                    }
                    IconButton(onClick = { nav.navigate("settings") }) {
                        Icon(Icons.Default.Settings, "Настройки")
                    }
                }
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 8.dp
            ) {
                listOf(
                    ViewMode.Calendar to Icons.Default.CalendarMonth,
                    ViewMode.Finance to Icons.Default.AccountBalanceWallet,
                    ViewMode.Analytics to Icons.Default.TrendingUp,
                    ViewMode.Tasks to Icons.Default.Assignment,
                    ViewMode.Timeline to Icons.Default.MenuBook,
                    ViewMode.Attachments to Icons.Default.PhotoLibrary
                ).forEach { (mode, icon) ->
                    NavigationBarItem(
                        selected = viewMode == mode,
                        onClick = { viewMode = mode },
                        icon = { Icon(icon, contentDescription = mode.label) },
                        label = {
                            Text(
                                text = mode.label,
                                fontSize = 10.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        },
                        alwaysShowLabel = true
                    )
                }
            }
        },
        floatingActionButton = {
            if (viewMode != ViewMode.Finance && viewMode != ViewMode.Tasks && viewMode != ViewMode.Analytics && viewMode != ViewMode.Attachments) {
                FloatingActionButton(onClick = { nav.navigate("add/$globalDate") }) {
                    Icon(Icons.Default.Add, null)
                }
            }
        }
    ) { p ->
        Column(Modifier.padding(p)) {
            if (viewMode == ViewMode.Calendar) {
                val todayKey = remember { SimpleDateFormat("yyyyMMdd", Locale.US).format(Date()) }
                val nowCal = remember { Calendar.getInstance() }
                val todayDay = remember { nowCal.get(Calendar.DAY_OF_MONTH) }
                val tomCal = remember { (nowCal.clone() as Calendar).apply { add(Calendar.DAY_OF_MONTH, 1) } }
                val tomorrowDay = remember { tomCal.get(Calendar.DAY_OF_MONTH) }
                val todayMidnight = remember { System.currentTimeMillis().toMidnight() }
                val tomorrowMidnight = remember { todayMidnight + 86400000L }

                var dismissedKeys by remember {
                    mutableStateOf(ReminderManager.getDismissedKeys(context))
                }

                val dismissForNow = { key: String, msg: String ->
                    ReminderManager.dismissReminder(context, key)
                    dismissedKeys = dismissedKeys + key
                    Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                }

                // 1. График смен: Завтра рабочий день
                if (ReminderManager.isShiftRemindersEnabled(context)) {
                    shiftConfig?.let { config ->
                        val shiftKey = "shift_tomorrow_work_$todayKey"
                        if (config.isActive && isWorkDay(tomorrowMidnight, config) && !dismissedKeys.contains(shiftKey)) {
                            Card(
                                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp),
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                            ) {
                                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Alarm, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text("Завтра рабочий день по графику!", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                        Text(
                                            if (config.isAlarmEnabled) "Будильник: ${String.format(Locale.getDefault(), "%02d:%02d", config.alarmHour, config.alarmMinute)}"
                                            else "Будильник выключен",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                        )
                                    }
                                    TextButton(onClick = {
                                        val i = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                                            putExtra(AlarmClock.EXTRA_HOUR, config.alarmHour)
                                            putExtra(AlarmClock.EXTRA_MINUTES, config.alarmMinute)
                                            putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                                        }
                                        try { context.startActivity(i) } catch (_: Throwable) {}
                                    }) { Text(if (config.isAlarmEnabled) "Будильник" else "Поставить", fontSize = 11.sp) }
                                    IconButton(
                                        onClick = { dismissForNow(shiftKey, "Напоминание о смене убрано до следующего раза") },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "Убрать на сегодня",
                                            modifier = Modifier.size(16.dp),
                                            tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                // 2. План до конца месяца (Expected Finance)
                if (ReminderManager.isExpectedRemindersEnabled(context)) {
                    expected.forEach { item ->
                        val isToday = item.dayOfMonth == todayDay
                        val isTomorrow = item.dayOfMonth == tomorrowDay
                        if (isToday || isTomorrow) {
                            val key = if (isToday) "exp_today_${item.id}_${todayKey}" else "exp_tomorrow_${item.id}_${todayKey}"
                            if (!dismissedKeys.contains(key)) {
                                Card(
                                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isToday) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.85f)
                                        else MaterialTheme.colorScheme.secondaryContainer
                                    )
                                ) {
                                    Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            if (isToday) Icons.Default.PriorityHigh else Icons.Default.EventNote,
                                            null,
                                            tint = if (isToday) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.secondary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                if (isToday) (if (item.isIncome) "Ожидаемый доход сегодня!" else "Срок платежа сегодня!")
                                                else (if (item.isIncome) "Ожидаемый доход (завтра)" else "Напоминание о платеже (завтра)"),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (isToday) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer
                                            )
                                            Text(
                                                "${item.title} — ${String.format(Locale.getDefault(), "%.0f", item.amount)} ₽",
                                                fontSize = 11.sp,
                                                color = (if (isToday) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer).copy(alpha = 0.85f)
                                            )
                                        }
                                        TextButton(onClick = { viewMode = ViewMode.Finance }) {
                                            Text("План", fontSize = 11.sp)
                                        }
                                        IconButton(
                                            onClick = { dismissForNow(key, "Напоминание убрано на этот раз") },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Убрать",
                                                modifier = Modifier.size(16.dp),
                                                tint = (if (isToday) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onSecondaryContainer).copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 3. Кредиты и долги (DiaryDebt)
                if (ReminderManager.isDebtRemindersEnabled(context)) {
                    debts.filter { !it.isPaid }.forEach { debt ->
                        val dueMid = debt.dueDate.toMidnight()
                        val isOverdue = dueMid < todayMidnight
                        val isToday = dueMid == todayMidnight
                        val isTomorrow = dueMid == tomorrowMidnight
                        if (isOverdue || isToday || isTomorrow) {
                            val key = if (isOverdue) "debt_overdue_${debt.id}_${todayKey}"
                            else if (isToday) "debt_today_${debt.id}_${todayKey}"
                            else "debt_tomorrow_${debt.id}_${todayKey}"
                            if (!dismissedKeys.contains(key)) {
                                Card(
                                    Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp),
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (isOverdue) MaterialTheme.colorScheme.errorContainer
                                        else MaterialTheme.colorScheme.tertiaryContainer
                                    )
                                ) {
                                    Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            if (isOverdue) Icons.Default.Warning else Icons.Default.CreditCard,
                                            null,
                                            tint = if (isOverdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.tertiary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(Modifier.width(8.dp))
                                        Column(Modifier.weight(1f)) {
                                            Text(
                                                if (isOverdue) "Просрочен платеж по кредиту!"
                                                else if (isToday) "Срок платежа по кредиту сегодня!"
                                                else "Завтра срок платежа по кредиту",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                color = if (isOverdue) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onTertiaryContainer
                                            )
                                            Text(
                                                "${debt.creditor} — ${String.format(Locale.getDefault(), "%.0f", debt.amount)} ₽",
                                                fontSize = 11.sp,
                                                color = (if (isOverdue) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onTertiaryContainer).copy(alpha = 0.85f)
                                            )
                                        }
                                        TextButton(onClick = { viewMode = ViewMode.Finance }) {
                                            Text("Кредиты", fontSize = 11.sp)
                                        }
                                        IconButton(
                                            onClick = { dismissForNow(key, "Напоминание о кредите убрано на сегодня") },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                Icons.Default.Close,
                                                contentDescription = "Убрать",
                                                modifier = Modifier.size(16.dp),
                                                tint = (if (isOverdue) MaterialTheme.colorScheme.onErrorContainer else MaterialTheme.colorScheme.onTertiaryContainer).copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // 4. Активные задачи
                val activeTasksCount = tasks.count { !isTaskActuallyDone(it) }
                val tasksDismissKey = "tasks_summary_$todayKey"
                if (activeTasksCount > 0 && !dismissedKeys.contains(tasksDismissKey)) {
                    Card(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp)) {
                        Row(Modifier.padding(horizontal = 10.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            Row(
                                Modifier.weight(1f).clickable { viewMode = ViewMode.Tasks },
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Assignment, null, modifier = Modifier.size(18.dp))
                                Spacer(Modifier.width(8.dp))
                                Text("Активных задач: $activeTasksCount", fontSize = 12.sp, fontWeight = FontWeight.Medium)
                            }
                            IconButton(
                                onClick = { dismissForNow(tasksDismissKey, "Напоминание о задачах убрано на сегодня") },
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(Icons.Default.Close, "Убрать на сегодня", modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
                            }
                        }
                    }
                }

                // 5. Автомобильные напоминания по дате (ТО / страховка / замена расходников)
                val carRemindersList = remember(viewMode) { getCarReminders(context) }
                val carList = remember(viewMode) { getCarList(context) }
                carRemindersList.filter { !it.isCompleted && it.targetDate != null }.forEach { rem ->
                    val remDateMid = rem.targetDate!!.toMidnight()
                    val isDueOverdue = remDateMid < todayMidnight
                    val isDueToday = remDateMid == todayMidnight
                    val isDueTomorrow = remDateMid == tomorrowMidnight
                    val isDueSoon = remDateMid in (tomorrowMidnight + 1)..(todayMidnight + 4 * 86400000L)

                    if (isDueOverdue || isDueToday || isDueTomorrow || isDueSoon) {
                        val car = carList.find { it.id == rem.carId }
                        val carName = if (car != null) "${car.brand} ${car.model}" else "Авто"
                        val key = "car_rem_${rem.id}_${todayKey}"
                        if (!dismissedKeys.contains(key)) {
                            Card(
                                Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 3.dp),
                                colors = CardDefaults.cardColors(
                                    containerColor = if (isDueOverdue) MaterialTheme.colorScheme.errorContainer
                                    else if (isDueToday) Color(0xFFFFF3E0)
                                    else Color(0xFFE0F2FE)
                                )
                            ) {
                                Row(Modifier.padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.DirectionsCar,
                                        null,
                                        tint = if (isDueOverdue) MaterialTheme.colorScheme.error else Color(0xFF0284C7),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Column(Modifier.weight(1f)) {
                                        Text(
                                            if (isDueOverdue) "Просрочено ТО / напоминание по авто!"
                                            else if (isDueToday) "Сегодня напоминание по авто!"
                                            else if (isDueTomorrow) "Завтра напоминание по авто"
                                            else "Скоро по авто (${SimpleDateFormat("dd.MM", Locale("ru")).format(Date(rem.targetDate!!))})",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp,
                                            color = if (isDueOverdue) MaterialTheme.colorScheme.onErrorContainer else Color(0xFF0369A1)
                                        )
                                        Text(
                                            "$carName: ${rem.title}${if (rem.note.isNotBlank()) " (${rem.note})" else ""}",
                                            fontSize = 11.sp,
                                            color = if (isDueOverdue) MaterialTheme.colorScheme.onErrorContainer.copy(alpha = 0.85f) else Color.DarkGray
                                        )
                                    }
                                    TextButton(onClick = { viewMode = ViewMode.Finance }) {
                                        Text("Гараж", fontSize = 11.sp)
                                    }
                                    IconButton(
                                        onClick = { dismissForNow(key, "Напоминание по авто убрано на сегодня") },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.Close,
                                            contentDescription = "Убрать на сегодня",
                                            modifier = Modifier.size(16.dp),
                                            tint = (if (isDueOverdue) MaterialTheme.colorScheme.onErrorContainer else Color.Gray).copy(alpha = 0.7f)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            Box(Modifier.weight(1f)) {
                Crossfade(targetState = viewMode, label = "ScreenTransition") { targetMode ->
                    when (targetMode) {
                        ViewMode.Calendar -> LazyColumn(state = listState) {
                            items(months) { m ->
                                MonthView(m, notes, finances, shiftConfig) {
                                    globalDate = it
                                    dayOverviewDate = it
                                }
                            }
                        }
                        ViewMode.Finance -> FinanceScreen(dao, finances, debts, expected, globalDate, isIncognito, notes) { globalDate = it }
                        ViewMode.Tasks -> TasksScreen(dao, tasks, notes)
                        ViewMode.Analytics -> AnalyticsScreen(notes, finances, debts, globalDate, isIncognito)
                        ViewMode.Timeline -> TimelineView(
                            notes = notes,
                            onDeleteDate = { dateToDelete ->
                                scope.launch(Dispatchers.Default) {
                                    dao.deleteNoteByDate(dateToDelete)
                                    dao.deleteFinanceByDate(dateToDelete)
                                }
                            }
                        ) {
                            globalDate = it
                            nav.navigate("add/$it")
                        }
                        ViewMode.Attachments -> AttachmentsScreen(
                            dao = dao,
                            notes = notes,
                            nav = nav,
                            onOpenDateNote = { targetDate ->
                                globalDate = targetDate
                                nav.navigate("add/$targetDate")
                            }
                        )
                    }
                }
            }
        }
    }

    if (showJumpDialog) {
        val dpState = rememberDatePickerState(initialSelectedDateMillis = globalDate)
        androidx.compose.material3.DatePickerDialog(
            onDismissRequest = { showJumpDialog = false },
            confirmButton = {
                TextButton(onClick = {
                    dpState.selectedDateMillis?.let { ms ->
                        globalDate = ms.toMidnight()
                        val cal = Calendar.getInstance().apply { timeInMillis = ms }
                        val idx = months.indexOfFirst {
                            it.get(Calendar.MONTH) == cal.get(Calendar.MONTH) && it.get(Calendar.YEAR) == cal.get(Calendar.YEAR)
                        }
                        if (idx != -1) scope.launch { listState.scrollToItem(idx) }
                    }
                    showJumpDialog = false
                }) { Text("ОК") }
            }
        ) {
            DatePicker(state = dpState)
        }
    }

    dayOverviewDate?.let { dDate ->
        DayOverviewDialog(
            date = dDate,
            notes = notes,
            finances = finances,
            tasks = tasks,
            config = shiftConfig,
            onDismiss = { dayOverviewDate = null },
            onOpenNote = {
                nav.navigate("add/$it")
                dayOverviewDate = null
            },
            onOpenFinance = {
                globalDate = it
                viewMode = ViewMode.Finance
                dayOverviewDate = null
            },
            onToggleTask = { task, isDone ->
                val dateStr = SimpleDateFormat("dd.MM.yyyy", Locale("ru")).format(Date(dDate))
                scope.launch(Dispatchers.Default) {
                    dao.saveTask(task.copy(lastDoneDate = if (isDone) dateStr else ""))
                }
            },
            onAddTask = { task ->
                scope.launch(Dispatchers.Default) {
                    dao.saveTask(task)
                }
            }
        )
    }
}
