package com.my.zapisnyk


import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor


// ==========================================
// 2. УТИЛИТЫ
// ==========================================

fun getSafeExpenseLimit(context: Context): Double {
    val prefsNames = listOf("fin_prefs", "fin_cats", "prefs", "security")
    val keys = listOf("monthly_expense_limit", "expense_limit", "monthlyLimit", "limit")
    for (pName in prefsNames) {
        try {
            val sp = context.getSharedPreferences(pName, 0)
            for (key in keys) {
                if (sp.contains(key)) {
                    val raw = sp.all[key]
                    val num: Double? = when (raw) {
                        is Float -> raw.toDouble()
                        is Double -> raw
                        is Long -> raw.toDouble()
                        is Int -> raw.toDouble()
                        is String -> raw.replace(",", ".").replace(" ", "").trim().toDoubleOrNull()
                        else -> null
                    }
                    if (num != null && !num.isNaN() && !num.isInfinite() && num >= 0.0) {
                        return num
                    }
                }
            }
        } catch (_: Exception) {}
    }
    return 0.0
}

fun saveSafeExpenseLimit(context: Context, limit: Double) {
    val safe = if (limit.isNaN() || limit.isInfinite() || limit < 0.0) 0.0 else limit
    try {
        val finPrefs = context.getSharedPreferences("fin_prefs", 0)
        finPrefs.edit()
            .putFloat("monthly_expense_limit", safe.toFloat())
            .putString("expense_limit", safe.toString())
            .apply()
    } catch (_: Exception) {}
}

fun getExcludedFromLimit(context: Context): Set<String> {
    return try {
        val sp = context.getSharedPreferences("fin_prefs", 0)
        sp.getStringSet("excluded_from_limit", emptySet()) ?: emptySet()
    } catch (_: Exception) {
        emptySet()
    }
}

fun saveExcludedFromLimit(context: Context, excluded: Set<String>) {
    try {
        val finPrefs = context.getSharedPreferences("fin_prefs", 0)
        finPrefs.edit().putStringSet("excluded_from_limit", excluded).apply()
    } catch (_: Exception) {}
}


fun Long.toMidnight(): Long = Calendar.getInstance().apply {
    timeInMillis = this@toMidnight
    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
}.timeInMillis

fun formatMoney(amount: Double): String {
    val isNeg = amount < 0
    val absVal = kotlin.math.abs(amount)
    val hasDecimals = (absVal % 1.0) >= 0.05
    val formatted = if (hasDecimals) {
        String.format(Locale.US, "%,.1f", absVal).replace(",", " ")
    } else {
        String.format(Locale.US, "%,.0f", absVal).replace(",", " ")
    }
    return (if (isNeg) "-" else "") + formatted
}

fun mask(value: Any, isIncognito: Boolean): String {
    if (isIncognito) return "****"
    return when (value) {
        is Double -> formatMoney(value)
        is Float -> formatMoney(value.toDouble())
        is Int -> formatMoney(value.toDouble())
        is Long -> formatMoney(value.toDouble())
        is Number -> formatMoney(value.toDouble())
        else -> value.toString()
    }
}

fun extractYouTubeId(url: String): String? {
    if (url.isBlank()) return null
    if (url.startsWith("/") || url.startsWith("file:/")) return null
    val clean = url.trim()
    val patterns = listOf(
        "(?:v=|vi=)([a-zA-Z0-9_-]{11})".toRegex(),
        "(?:youtu\\.be/|shorts/|embed/|live/|videos/|yt:)([a-zA-Z0-9_-]{11})".toRegex(),
        "^([a-zA-Z0-9_-]{11})$".toRegex()
    )
    for (p in patterns) {
        val match = p.find(clean)
        if (match != null) {
            val res = match.groupValues.getOrNull(1) ?: match.value
            if (res.length == 11) return res
        }
    }
    return null
}

fun isYouTubeUrl(url: String): Boolean {
    if (url.isBlank()) return false
    if (url.startsWith("/") || url.startsWith("file:/")) return false
    return extractYouTubeId(url) != null
}

fun extractRutubeId(url: String): String? {
    if (url.isBlank()) return null
    if (url.startsWith("/") || url.startsWith("file:/")) return null
    val clean = url.trim()
    val patterns = listOf(
        "(?:rutube\\.ru/(?:video|play/embed|shorts)/)([a-zA-Z0-9]+)".toRegex(RegexOption.IGNORE_CASE),
        "(?:rutube:)([a-zA-Z0-9]+)".toRegex(RegexOption.IGNORE_CASE),
        "(?:rutube\\.ru/.*?[?&]v=)([a-zA-Z0-9]+)".toRegex(RegexOption.IGNORE_CASE),
        "^[a-fA-F0-9]{32}$".toRegex()
    )
    for (p in patterns) {
        val match = p.find(clean)
        if (match != null) {
            val res = match.groupValues.getOrNull(1) ?: match.value
            if (res.isNotBlank()) return res
        }
    }
    return null
}

fun isRutubeUrl(url: String): Boolean {
    if (url.isBlank()) return false
    if (url.startsWith("/") || url.startsWith("file:/")) return false
    val lower = url.lowercase().trim()
    if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") || lower.endsWith(".gif")) return false
    return extractRutubeId(url) != null || lower.contains("rutube.ru/video") || lower.contains("rutube.ru/play") || lower.contains("rutube.ru/shorts") || lower.startsWith("rutube:")
}

fun extractVkVideoId(url: String): String? {
    if (url.isBlank()) return null
    val clean = url.trim()
    if (clean.matches(Regex("^-?\\d+_\\d+$"))) return clean

    val extMatcher = Regex("(?:oid|owner_id)=(-?\\d+).*?(?:&|\\?|&amp;)id=(\\d+)").find(clean)
    if (extMatcher != null) {
        val oid = extMatcher.groupValues[1]
        val vid = extMatcher.groupValues[2]
        return "${oid}_${vid}"
    }
    val revExtMatcher = Regex("(?:&|\\?)id=(\\d+).*?(?:oid|owner_id)=(-?\\d+)").find(clean)
    if (revExtMatcher != null) {
        val vid = revExtMatcher.groupValues[1]
        val oid = revExtMatcher.groupValues[2]
        return "${oid}_${vid}"
    }

    val vidMatcher = Regex("(?:video|clip)[/_]?(-?\\d+_\\d+)").find(clean)
    if (vidMatcher != null) return vidMatcher.groupValues[1]

    if (clean.contains("vk.com") || clean.contains("vkvideo.ru") || clean.contains("vk.ru")) {
        val rawMatcher = Regex("(-?\\d+_\\d+)").find(clean)
        if (rawMatcher != null) return rawMatcher.groupValues[1]
    }
    return null
}

fun extractVkVideoHash(url: String): String? {
    if (url.isBlank()) return null
    val m = Regex("hash=([a-zA-Z0-9]+)").find(url)
    return m?.groupValues?.get(1)
}

fun isVkVideoUrl(url: String): Boolean {
    if (url.isBlank()) return false
    val lower = url.lowercase().trim()
    if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") || lower.endsWith(".webp") || lower.endsWith(".gif")) return false
    return lower.contains("vk.com/video") || lower.contains("vkvideo.ru") || lower.contains("vk.com/clip") || lower.contains("video_ext.php") || extractVkVideoId(url) != null
}

fun isVideoPath(p: String): Boolean {
    if (p.isBlank()) return false
    val lower = p.lowercase().trim()
    // Explicitly reject image extensions and common thumbnail patterns
    if (lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png") ||
        lower.endsWith(".webp") || lower.endsWith(".gif") || lower.endsWith(".bmp") ||
        lower.contains("/vi/") || lower.contains("/hqdefault") || lower.contains("/mqdefault") ||
        lower.contains("pic.rutube.ru")) return false
    return lower.endsWith(".mp4") || lower.endsWith(".mkv") || lower.endsWith(".mov") ||
           lower.endsWith(".avi") || lower.endsWith(".3gp") || lower.endsWith(".webm") ||
           lower.endsWith(".ts") ||
           isYouTubeUrl(p) || isRutubeUrl(p) || isVkVideoUrl(p) ||
           lower.contains("youtube.com/watch") || lower.contains("youtube.com/shorts") || lower.contains("youtube.com/embed") ||
           lower.contains("youtu.be/") ||
           lower.contains("vimeo.com") || lower.contains("dzen.ru/video") || lower.contains("tiktok.com") ||
           lower.startsWith("video_url:") || lower.startsWith("yt:") || lower.startsWith("rutube:")
}

object RutubeThumbnailCache {
    private val cache = ConcurrentHashMap<String, String>()
    fun getCached(id: String): String? = cache[id]
    suspend fun resolve(id: String): String? = cache[id]
}

fun parseMediaPaths(json: String?): List<String> {
    if (json.isNullOrBlank()) return emptyList()
    val trimmed = json.trim()
    if (!trimmed.startsWith("[")) {
        return listOf(trimmed).filter { it.isNotBlank() }
    }
    return try {
        val list: List<String>? = Gson().fromJson(trimmed, object : TypeToken<List<String>>() {}.type)
        list?.filter { it.isNotBlank() } ?: emptyList()
    } catch (_: Throwable) {
        if (trimmed.length > 2) listOf(trimmed) else emptyList()
    }
}

object SafeThumbnailManager {
    private val memoryCache = mutableMapOf<String, Bitmap>()
    fun getFromCache(key: String): Bitmap? = memoryCache[key]
    fun putInCache(key: String, bm: Bitmap) { memoryCache[key] = bm }
    suspend fun loadThumbnail(context: Context, path: String): Bitmap? {
        memoryCache[path]?.let { return it }
        val loaded = PlatformNative.ensureInitialized()?.loadThumbnail(path)
        if (loaded != null) {
            memoryCache[path] = loaded
        }
        return loaded
    }
}

suspend fun downloadYouTubeVideo(
    context: Context,
    ytId: String,
    onProgress: (String) -> Unit,
    onError: (String) -> Unit = {}
): File? {
    onError("Используйте кнопку «Прикрепить онлайн» для мгновенного добавления YouTube")
    return null
}

suspend fun downloadRutubeVideo(
    context: Context,
    rtId: String,
    onProgress: (String) -> Unit,
    onError: (String) -> Unit = {}
): File? {
    onError("Используйте кнопку «Прикрепить онлайн» для мгновенного добавления Rutube")
    return null
}

data class VkVideoDownloadResult(
    val file: File?,
    val title: String?
)

suspend fun downloadVkVideo(
    context: Context,
    vkUrl: String,
    onProgress: (String) -> Unit,
    onError: (String) -> Unit = {}
): VkVideoDownloadResult {
    onError("Используйте кнопку «Прикрепить онлайн» для мгновенного добавления VK Видео")
    return VkVideoDownloadResult(null, null)
}

fun openVideo(c: Context, p: String) {
    val opened = PlatformNative.ensureInitialized()?.openMedia(p) ?: false
    if (!opened) {
        Toast.makeText(c, "Открытие медиа: $p", Toast.LENGTH_SHORT).show()
    }
}

@Composable
fun SafeMediaThumbnail(
    path: String,
    isVideo: Boolean,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop,
    showVideoBadge: Boolean = true
) {
    val context = LocalContext.current
    val effectiveIsVideo = remember(path, isVideo) { isVideo || isVideoPath(path) }
    val isYt = remember(path) { isYouTubeUrl(path) }
    val ytId = remember(path) { extractYouTubeId(path) }
    val isRt = remember(path) { isRutubeUrl(path) }
    val rtId = remember(path) { extractRutubeId(path) }
    val isVk = remember(path) { isVkVideoUrl(path) }
    val vkId = remember(path) { extractVkVideoId(path) }

    var thumbBitmap by remember(path) {
        mutableStateOf(
            SafeThumbnailManager.getFromCache(path)
                ?: (ytId?.let { SafeThumbnailManager.getFromCache("yt_$it") })
                ?: (rtId?.let { SafeThumbnailManager.getFromCache("rt_$it") })
                ?: (vkId?.let { SafeThumbnailManager.getFromCache("vk_$it") })
        )
    }

    LaunchedEffect(path, ytId, rtId, vkId) {
        if (thumbBitmap == null) {
            val bm = SafeThumbnailManager.loadThumbnail(context, path)
            if (bm != null && !bm.isRecycled) {
                thumbBitmap = bm
            }
        }
    }

    val imgBitmap = remember(thumbBitmap) {
        val bm = thumbBitmap
        if (bm != null && !bm.isRecycled) {
            try { bm.asImageBitmap() } catch (_: Throwable) { null }
        } else null
    }

    Box(
        modifier = modifier.background(Color(0xFF1B1B22)),
        contentAlignment = Alignment.Center
    ) {
        if (imgBitmap != null) {
            Image(
                bitmap = imgBitmap,
                contentDescription = null,
                contentScale = contentScale,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            // Elegant, crash-proof placeholder when loading or offline
            if (isYt) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xFF2B0707), Color(0xFF140303)))),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(Color(0xFFCC0000), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.height(3.dp))
                        Text("YouTube", color = Color(0xFFCC0000), fontSize = 9.sp, fontWeight = FontWeight.Black)
                    }
                }
            } else if (isRt) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xFF0F172A), Color(0xFF001F3F)))),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text("RUTUBE", fontWeight = FontWeight.Black, fontSize = 9.sp, color = Color(0xFF00A0E3))
                        Spacer(Modifier.height(2.dp))
                        Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White.copy(alpha = 0.8f), modifier = Modifier.size(20.dp))
                    }
                }
            } else if (isVk) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xFF003D82), Color(0xFF001F44)))),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .background(Color(0xFF0077FF), RoundedCornerShape(8.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.height(3.dp))
                        Text("VK ВИДЕО", color = Color(0xFF4C9EFF), fontSize = 8.5.sp, fontWeight = FontWeight.Black)
                    }
                }
            } else if (effectiveIsVideo) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color(0xFF2C2D35), Color(0xFF16171D)))),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Videocam, contentDescription = null, tint = Color.White.copy(alpha = 0.6f), modifier = Modifier.size(26.dp))
                }
            } else {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Gray.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Photo, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(22.dp))
                }
            }
        }

        // Overlay video play button and badge if it is a video
        if (effectiveIsVideo) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.22f)),
                contentAlignment = Alignment.Center
            ) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .background(
                            if (isYt) Color(0xFFCC0000) else if (isRt) Color(0xFF00A0E3) else if (isVk) Color(0xFF0077FF) else Color.Black.copy(alpha = 0.65f),
                            CircleShape
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        Icons.Default.PlayArrow,
                        contentDescription = "Воспроизвести",
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            if (showVideoBadge) {
                Box(
                    modifier = Modifier
                        .align(Alignment.BottomStart)
                        .padding(4.dp)
                        .background(
                            if (isYt) Color(0xFFCC0000) else if (isRt) Color(0xFF00A0E3) else if (isVk) Color(0xFF0077FF) else Color.Black.copy(alpha = 0.7f),
                            RoundedCornerShape(4.dp)
                        )
                        .padding(horizontal = 4.dp, vertical = 2.dp)
                ) {
                    Text(
                        text = if (isYt) "YOUTUBE" else if (isRt) "RUTUBE" else if (isVk) "VK ВИДЕО" else "ВИДЕО",
                        color = Color.White,
                        fontSize = 8.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

fun isWorkDay(date: Long, config: ShiftConfig?): Boolean {
    if (config == null || !config.isActive) return false
    val t = date.toMidnight()
    val diff = floor((t - config.startDate.toMidnight()).toDouble() / (1000 * 60 * 60 * 24)).toInt()
    val pattern = config.pattern.ifEmpty { "WRRR" }
    val index = (diff % pattern.length + pattern.length) % pattern.length
    return pattern[index] == 'W'
}

fun isDateInCurrentPeriod(dateStr: String, frequency: String): Boolean {
    if (dateStr.isBlank()) return false
    val sdf = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())
    val lastDate = try { sdf.parse(dateStr) } catch(e: Exception) { null } ?: return false
    val lastCal = Calendar.getInstance().apply {
        firstDayOfWeek = Calendar.MONDAY
        time = lastDate
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    val now = Calendar.getInstance().apply {
        firstDayOfWeek = Calendar.MONDAY
        set(Calendar.HOUR_OF_DAY, 0)
        set(Calendar.MINUTE, 0)
        set(Calendar.SECOND, 0)
        set(Calendar.MILLISECOND, 0)
    }
    val diffMillis = now.timeInMillis - lastCal.timeInMillis
    if (diffMillis < 0) return true
    val diffDays = diffMillis / (1000 * 60 * 60 * 24)

    return when (frequency) {
        "Однажды" -> true
        "Ежедневно" -> diffDays == 0L
        "Еженедельно" -> diffDays < 7 && now.get(Calendar.WEEK_OF_YEAR) == lastCal.get(Calendar.WEEK_OF_YEAR) && now.get(Calendar.YEAR) == lastCal.get(Calendar.YEAR)
        "Ежемесячно" -> diffDays < 32 && now.get(Calendar.MONTH) == lastCal.get(Calendar.MONTH) && now.get(Calendar.YEAR) == lastCal.get(Calendar.YEAR)
        else -> false
    }
}

fun isTaskActuallyDone(task: DiaryTask): Boolean = isDateInCurrentPeriod(task.lastDoneDate, task.frequency)

// ==========================================
// КАТАЛОГ ИКОНОК И ОТОБРАЖЕНИЕ КАТЕГОРИЙ (v.2.1)
// ==========================================

data class CategoryPresetIcon(val id: String, val title: String, val icon: ImageVector)

val CATEGORY_PRESET_ICONS: List<CategoryPresetIcon> = listOf(
    CategoryPresetIcon("cart", "Продукты", Icons.Default.ShoppingCart),
    CategoryPresetIcon("restaurant", "Кафе / Ресторан", Icons.Default.Restaurant),
    CategoryPresetIcon("fastfood", "Фастфуд / Бургеры", Icons.Default.Fastfood),
    CategoryPresetIcon("cafe", "Кофе / Напитки", Icons.Default.LocalCafe),
    CategoryPresetIcon("bar", "Бар / Отдых", Icons.Default.LocalBar),
    CategoryPresetIcon("clothes", "Одежда / Майка", Icons.Default.Checkroom),
    CategoryPresetIcon("car", "Автомобиль", Icons.Default.DirectionsCar),
    CategoryPresetIcon("gas", "Заправка / Топливо", Icons.Default.LocalGasStation),
    CategoryPresetIcon("taxi", "Такси", Icons.Default.LocalTaxi),
    CategoryPresetIcon("bus", "Транспорт", Icons.Default.DirectionsBus),
    CategoryPresetIcon("flight", "Путешествия / Самолёт", Icons.Default.Flight),
    CategoryPresetIcon("repair", "Ремонт / Сервис / ТО", Icons.Default.Build),
    CategoryPresetIcon("home", "Дом / Аренда", Icons.Default.Home),
    CategoryPresetIcon("apartment", "ЖКХ / Квартира", Icons.Default.Apartment),
    CategoryPresetIcon("phone", "Связь / Телефон", Icons.Default.PhoneAndroid),
    CategoryPresetIcon("hospital", "Медицина / Врач", Icons.Default.LocalHospital),
    CategoryPresetIcon("fitness", "Спорт / Фитнес", Icons.Default.FitnessCenter),
    CategoryPresetIcon("game", "Игры / Гейминг", Icons.Default.SportsEsports),
    CategoryPresetIcon("movie", "Кинотеатр / Фильмы", Icons.Default.Movie),
    CategoryPresetIcon("music", "Музыка / Концерты", Icons.Default.MusicNote),
    CategoryPresetIcon("sub", "Подписки / Сервисы", Icons.Default.Subscriptions),
    CategoryPresetIcon("gift", "Подарки / Праздники", Icons.Default.CardGiftcard),
    CategoryPresetIcon("beauty", "Красота / Салон", Icons.Default.Face),
    CategoryPresetIcon("spa", "Уход / Спа", Icons.Default.Spa),
    CategoryPresetIcon("kids", "Дети / Садик", Icons.Default.ChildCare),
    CategoryPresetIcon("pets", "Питомцы / Животные", Icons.Default.Pets),
    CategoryPresetIcon("school", "Учеба / Курсы", Icons.Default.School),
    CategoryPresetIcon("books", "Книги / Хобби", Icons.Default.MenuBook),
    CategoryPresetIcon("credit", "Кредиты / Долги", Icons.Default.CreditCard),
    CategoryPresetIcon("bank", "Банк / Налоги", Icons.Default.AccountBalance),
    CategoryPresetIcon("savings", "Накопления / Вклад", Icons.Default.Savings),
    CategoryPresetIcon("income", "Зарплата / Доход", Icons.Default.TrendingUp),
    CategoryPresetIcon("work", "Работа / Бизнес", Icons.Default.Work),
    CategoryPresetIcon("tech", "Техника / Электроника", Icons.Default.Computer),
    CategoryPresetIcon("receipt", "Квитанции / Счета", Icons.Default.Receipt),
    CategoryPresetIcon("star", "Избранное", Icons.Default.Star),
    CategoryPresetIcon("favorite", "Важное", Icons.Default.Favorite),
    CategoryPresetIcon("other", "Разное", Icons.Default.Category)
)

fun getExpenseCategoryIcon(name: String?, id: String?): ImageVector {
    val n = (name ?: "").lowercase().trim()
    val cleanId = (id ?: "").lowercase().trim()
    return when {
        n.contains("продукт") || n.contains("супермаркет") || n.contains("еда") || n.contains("магнит") || n.contains("пятёрочк") || n.contains("пятерочк") || n.contains("ашан") || n.contains("вкусвилл") || n.contains("лента") || n.contains("корзин") -> Icons.Default.ShoppingCart
        n.contains("фаст") || n.contains("фуд") || n.contains("бургер") || n.contains("шаурм") || n.contains("мак") || n.contains("кфс") || n.contains("kfc") || n.contains("вкусно") -> Icons.Default.Fastfood
        n.contains("кафе") || n.contains("ресторан") || n.contains("пицц") || n.contains("доставк") || n.contains("столов") -> Icons.Default.Restaurant
        n.contains("кофе") || n.contains("чай") || n.contains("бар") -> Icons.Default.LocalCafe
        n.contains("одежд") || n.contains("майк") || n.contains("вещ") || n.contains("обув") || n.contains("куртк") || n.contains("штаны") || n.contains("плать") || n.contains("кроссов") -> Icons.Default.Checkroom
        n.contains("авто") || n.contains("машин") || n.contains("тачк") || n.contains("гараж") || n.contains("мойк") -> Icons.Default.DirectionsCar
        n.contains("сервис") || n.contains("ремонт") || n.contains("шиномонтаж") || n.contains("то") -> Icons.Default.Build
        n.contains("бензин") || n.contains("топлив") || n.contains("азс") || n.contains("заправк") || n.contains("газ") -> Icons.Default.LocalGasStation
        n.contains("такси") -> Icons.Default.LocalTaxi
        n.contains("дом") || n.contains("аренд") || n.contains("быт") -> Icons.Default.Home
        n.contains("жкх") || n.contains("квартир") || n.contains("коммунал") || n.contains("свет") || n.contains("вода") -> Icons.Default.Apartment
        n.contains("аптек") || n.contains("здоров") || n.contains("медицин") || n.contains("лекарств") || n.contains("врач") || n.contains("больниц") || n.contains("стоматолог") -> Icons.Default.LocalHospital
        n.contains("спорт") || n.contains("фитнес") || n.contains("зал") || n.contains("тренировк") || n.contains("бассейн") -> Icons.Default.FitnessCenter
        n.contains("развлечен") || n.contains("игр") || n.contains("гейм") -> Icons.Default.SportsEsports
        n.contains("кино") || n.contains("фильм") || n.contains("театр") -> Icons.Default.Movie
        n.contains("связь") || n.contains("интернет") || n.contains("телефон") || n.contains("мобильн") || n.contains("мтс") || n.contains("билайн") || n.contains("мегафон") || n.contains("теле2") -> Icons.Default.PhoneAndroid
        n.contains("подпис") || n.contains("онлайн") || n.contains("музык") -> Icons.Default.Subscriptions
        n.contains("подар") || n.contains("праздник") || n.contains("день рожден") || n.contains("цвет") -> Icons.Default.CardGiftcard
        n.contains("красот") || n.contains("салон") || n.contains("стрижк") || n.contains("парикмахер") || n.contains("косметик") -> Icons.Default.Face
        n.contains("дети") || n.contains("ребенок") || n.contains("сад") || n.contains("игрушк") -> Icons.Default.ChildCare
        n.contains("школ") || n.contains("учеб") || n.contains("курс") -> Icons.Default.School
        n.contains("путешеств") || n.contains("билет") || n.contains("поездк") || n.contains("отпуск") || n.contains("самолет") || n.contains("отель") -> Icons.Default.Flight
        n.contains("питомц") || n.contains("животн") || n.contains("кот") || n.contains("собак") || n.contains("корм") || n.contains("вет") -> Icons.Default.Pets
        n.contains("долг") || n.contains("кредит") || n.contains("ипотек") || n.contains("займ") -> Icons.Default.CreditCard
        n.contains("налог") || n.contains("госуслуг") || n.contains("штраф") -> Icons.Default.AccountBalance
        n.contains("зарплат") || n.contains("доход") || n.contains("аванс") || n.contains("преми") -> Icons.Default.TrendingUp
        cleanId == "exp" -> Icons.Default.ShoppingCart
        cleanId == "inc" -> Icons.Default.TrendingUp
        cleanId == "dep" -> Icons.Default.Savings
        else -> Icons.Default.Category
    }
}

@Composable
fun CategoryIconDisplay(
    iconKey: String? = "",
    customIconUri: String? = "",
    categoryName: String? = "",
    categoryId: String? = "",
    tint: Color = Color.White,
    modifier: Modifier = Modifier
) {
    val safeCustomUri = customIconUri ?: ""
    val safeIconKey = iconKey ?: ""
    val safeCategoryName = categoryName ?: ""
    val safeCategoryId = categoryId ?: ""
    val context = LocalContext.current

    val customBitmap: androidx.compose.ui.graphics.ImageBitmap? = remember(safeCustomUri) {
        if (safeCustomUri.isBlank()) {
            null
        } else {
            try {
                if (safeCustomUri.startsWith("content://")) {
                    context.contentResolver.openInputStream(Uri.parse(safeCustomUri))?.use { input ->
                        BitmapFactory.decodeStream(input)?.asImageBitmap()
                    }
                } else {
                    val cleanPath = when {
                        safeCustomUri.startsWith("file://") -> safeCustomUri.removePrefix("file://")
                        else -> safeCustomUri
                    }
                    val file = File(cleanPath)
                    if (file.exists() && file.isFile) {
                        BitmapFactory.decodeFile(file.absolutePath)?.asImageBitmap()
                    } else null
                }
            } catch (_: Throwable) {
                null
            }
        }
    }

    if (customBitmap != null) {
        Image(
            bitmap = customBitmap,
            contentDescription = safeCategoryName,
            modifier = modifier.clip(CircleShape),
            contentScale = ContentScale.Crop
        )
    } else {
        val preset = if (safeIconKey.isNotBlank()) CATEGORY_PRESET_ICONS.find { it.id == safeIconKey } else null
        val vector = preset?.icon ?: getExpenseCategoryIcon(safeCategoryName, safeCategoryId)

        Icon(
            imageVector = vector,
            contentDescription = safeCategoryName,
            tint = tint,
            modifier = modifier
        )
    }
}

@Composable
fun CategoryIconSelectorView(
    selectedIconKey: String,
    selectedCustomUri: String,
    accentColor: Color,
    onSelectPreset: (String) -> Unit,
    onSelectCustomUri: (String) -> Unit,
    onClearCustomUri: () -> Unit
) {
    val context = LocalContext.current
    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            try {
                val iconsDir = File(context.filesDir, "category_icons").apply { mkdirs() }
                val destFile = File(iconsDir, "cat_icon_${System.currentTimeMillis()}.png")
                context.contentResolver.openInputStream(uri)?.use { input ->
                    FileOutputStream(destFile).use { output ->
                        input.copyTo(output)
                    }
                }
                onSelectCustomUri(destFile.absolutePath)
            } catch (e: Exception) {
                Toast.makeText(context, "Ошибка загрузки: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Text(
            "ИКОНКА КАТЕГОРИИ:",
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(6.dp))

        // Строка с текущим превью и кнопкой загрузки своего фото
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(accentColor.copy(alpha = 0.2f))
                    .border(2.dp, accentColor, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                CategoryIconDisplay(
                    iconKey = selectedIconKey,
                    customIconUri = selectedCustomUri,
                    tint = accentColor,
                    modifier = Modifier.size(24.dp)
                )
            }
            Spacer(Modifier.width(10.dp))
            Column(modifier = Modifier.weight(1f)) {
                OutlinedButton(
                    onClick = { photoPickerLauncher.launch("image/*") },
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(6.dp))
                    Text(
                        if (selectedCustomUri.isNotBlank()) "Заменить своё фото" else "Загрузить своё фото / значок",
                        fontSize = 11.sp
                    )
                }
                if (selectedCustomUri.isNotBlank()) {
                    TextButton(
                        onClick = onClearCustomUri,
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("Вернуться к стандартным иконкам", fontSize = 10.sp, color = Color.Red)
                    }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Text(
            "Или выберите готовую иконку (${CATEGORY_PRESET_ICONS.size} вариантов):",
            fontSize = 10.sp,
            color = Color.Gray
        )
        Spacer(Modifier.height(4.dp))

        // Горизонтальный скролл с готовыми значками
        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            contentPadding = PaddingValues(vertical = 4.dp)
        ) {
            items(CATEGORY_PRESET_ICONS) { preset ->
                val isSelected = selectedCustomUri.isBlank() && selectedIconKey == preset.id
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = if (isSelected) accentColor.copy(alpha = 0.25f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    border = BorderStroke(
                        1.5.dp,
                        if (isSelected) accentColor else Color.Transparent
                    ),
                    modifier = Modifier
                        .size(42.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            onClearCustomUri()
                            onSelectPreset(preset.id)
                        }
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = preset.icon,
                            contentDescription = preset.title,
                            tint = if (isSelected) accentColor else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }
            }
        }
    }
}



