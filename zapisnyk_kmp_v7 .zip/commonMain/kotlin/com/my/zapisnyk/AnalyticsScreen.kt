package com.my.zapisnyk


import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.floor


// ==========================================
// 8. АНАЛИТИКА (v.2.1) — С КЛИКОМ НА РАЗДЕЛ, КОЛЬЦЕВОЙ ДИАГРАММОЙ И ИКОНКАМИ
// ==========================================

data class PieSegment(
    val id: String = "",
    val name: String = "",
    val value: Double = 0.0,
    val color: Color = Color.Gray,
    val iconKey: String = "",
    val customIconUri: String = ""
)

fun Color.safeAlpha(alpha: Float): Color {
    return try {
        this.copy(alpha = alpha)
    } catch (_: Throwable) {
        Color.Gray.copy(alpha = alpha)
    }
}
data class YearlyCapitalPoint(
    val monthIdx: Int,
    val shortName: String,
    val fullName: String,
    val assets: Double,
    val debts: Double,
    val netCapital: Double,
    val timestamp: Long,
    val isOverridden: Boolean = false,
    val rawNetCapital: Double = netCapital,
    val year: Int = 2026
)

fun getCapitalOverrides(): Map<String, Double> {
    return try {
        val sp = PlatformPreferences.get("capital_overrides")
        val json = sp.getString("map", "{}") ?: "{}"
        val type = object : TypeToken<Map<String, Double>>() {}.type
        Gson().fromJson<Map<String, Double>>(json, type) ?: emptyMap()
    } catch (_: Exception) {
        emptyMap()
    }
}

fun saveCapitalOverride(key: String, amount: Double?) {
    try {
        val sp = PlatformPreferences.get("capital_overrides")
        val current = getCapitalOverrides().toMutableMap()
        if (amount == null) {
            current.remove(key)
        } else {
            current[key] = amount
        }
        sp.edit().putString("map", Gson().toJson(current)).apply()
    } catch (_: Exception) {}
}

fun getCapitalOverrides(context: Any?): Map<String, Double> = getCapitalOverrides()
fun saveCapitalOverride(context: Any?, key: String, amount: Double?) { saveCapitalOverride(key, amount) }

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun AnalyticsScreen(
    notes: List<DiaryNote>,
    finances: List<DiaryFinance>,
    debts: List<DiaryDebt> = emptyList(),
    globalDate: Long,
    isIncognito: Boolean
) {
    val context = LocalContext.current
    val nowCal = remember { Calendar.getInstance() }
    val currentCalYear = nowCal.get(Calendar.YEAR)
    val currentCalMonth = nowCal.get(Calendar.MONTH)

    var selectedMonth by remember {
        val cal = Calendar.getInstance().apply { timeInMillis = globalDate }
        val isFuture = cal.get(Calendar.YEAR) > currentCalYear || (cal.get(Calendar.YEAR) == currentCalYear && cal.get(Calendar.MONTH) > currentCalMonth)
        mutableStateOf(if (isFuture) nowCal.clone() as Calendar else cal)
    }
    val prefs = PlatformPreferences.get("fin_cats")
    val categories = remember(prefs) {
        try {
            val list = Gson().fromJson<List<CategoryConfig>>(prefs.getString("list", "[]"), object : TypeToken<List<CategoryConfig>>() {}.type)
            list?.filterNotNull() ?: emptyList()
        } catch (_: Exception) {
            emptyList()
        }
    }
    val namesPref = PlatformPreferences.get("section_names")
    val expName = namesPref.getString("exp", "Расход") ?: "Расход"
    val incName = namesPref.getString("inc", "Доход") ?: "Доход"
    val hiddenPref = PlatformPreferences.get("hidden_sections")
    val hiddenSections = remember(hiddenPref) {
        try {
            hiddenPref.getStringSet("set", emptySet()) ?: emptySet<String>()
        } catch (_: Exception) {
            emptySet<String>()
        }
    }

    var capitalOverrides by remember { mutableStateOf<Map<String, Double>>(getCapitalOverrides()) }
    var showOverrideDialog by remember { mutableStateOf<Boolean>(false) }
    var monthToOverride by remember { mutableStateOf<YearlyCapitalPoint?>(null) }

    fun getFullBalanceForDate(catId: String, targetDate: Long): Double {
        val typeToken = object : TypeToken<List<FinanceItem>>() {}.type
        return finances.filter { it.date <= targetDate }.sumOf { f ->
            try {
                if (catId == "dep") Gson().fromJson<List<FinanceItem>>(f.depHistory ?: "[]", typeToken)?.sumOf { it.amount } ?: 0.0
                else {
                    val map = Gson().fromJson<Map<String, String>>(f.dynamicBalances ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                    Gson().fromJson<List<FinanceItem>>(map[catId] ?: "[]", typeToken)?.sumOf { it.amount } ?: 0.0
                }
            } catch (e: Exception) { 0.0 }
        }
    }

    val monthNamesShort = listOf("Янв", "Фев", "Мар", "Апр", "Май", "Июн", "Июл", "Авг", "Сен", "Окт", "Ноя", "Дек")
    val monthNamesFull = listOf("Январь", "Февраль", "Март", "Апрель", "Май", "Июнь", "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь")

    fun calculatePointForMonth(
        year: Int,
        monthIdx: Int,
        labelShort: String,
        labelFull: String
    ): YearlyCapitalPoint {
        val cal = Calendar.getInstance().apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, monthIdx)
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        val isCurrentMonth = (year == currentCalYear && monthIdx == currentCalMonth)
        val targetDate = if (isCurrentMonth) System.currentTimeMillis() else cal.timeInMillis

        var assets = if (!hiddenSections.contains("dep")) getFullBalanceForDate("dep", targetDate) else 0.0
        categories.filter { (it.type ?: CatType.HISTORY) == CatType.BALANCE && !hiddenSections.contains(it.id ?: "") }.forEach {
            assets += getFullBalanceForDate(it.id ?: "", targetDate)
        }

        val cumInc = finances.filter { it.date <= targetDate }.sumOf { it.income }
        val cumExp = finances.filter { it.date <= targetDate }.sumOf { it.expense }
        val cumCashflow = cumInc - cumExp

        val finalAssets = if (assets > 0) assets else (if (cumCashflow > 0) cumCashflow else 0.0)
        val activeDebts = debts.filter { debt ->
            val debtStart: Long = if (debt.createdAt > 0L) debt.createdAt else debt.dueDate
            if (debtStart > targetDate) {
                false
            } else {
                if (!debt.isPaid) {
                    true
                } else {
                    val paidTs: Long = if (debt.paidDate > 0L) debt.paidDate else debt.dueDate
                    paidTs > targetDate
                }
            }
        }.sumOf { it.amount }
        val calculatedNet = (if (assets > 0) assets else cumCashflow) - activeDebts
        val overrideKey = "${year}_$monthIdx"
        val overrideVal = capitalOverrides[overrideKey]
        val finalNet = overrideVal ?: calculatedNet

        return YearlyCapitalPoint(
            monthIdx = monthIdx,
            shortName = labelShort,
            fullName = labelFull,
            assets = finalAssets,
            debts = activeDebts,
            netCapital = finalNet,
            timestamp = targetDate,
            isOverridden = overrideVal != null,
            rawNetCapital = calculatedNet,
            year = year
        )
    }

    val earliestRecordedTimestamp = remember(finances, debts, capitalOverrides) {
        val typeToken = object : TypeToken<List<FinanceItem>>() {}.type
        val list = mutableListOf<Long>()
        finances.forEach { f ->
            var hasAmount = (f.income != 0.0 || f.expense != 0.0 || f.savings_deposit != 0.0 || f.debt != 0.0)
            if (!hasAmount) {
                try {
                    if (!f.incHistory.isNullOrBlank() && f.incHistory != "[]") {
                        if (Gson().fromJson<List<FinanceItem>>(f.incHistory, typeToken)?.any { it.amount != 0.0 } == true) hasAmount = true
                    }
                    if (!hasAmount && !f.expHistory.isNullOrBlank() && f.expHistory != "[]") {
                        if (Gson().fromJson<List<FinanceItem>>(f.expHistory, typeToken)?.any { it.amount != 0.0 } == true) hasAmount = true
                    }
                    if (!hasAmount && !f.depHistory.isNullOrBlank() && f.depHistory != "[]") {
                        if (Gson().fromJson<List<FinanceItem>>(f.depHistory, typeToken)?.any { it.amount != 0.0 } == true) hasAmount = true
                    }
                    if (!hasAmount && !f.dynamicBalances.isNullOrBlank() && f.dynamicBalances != "{}") {
                        val map = Gson().fromJson<Map<String, String>>(f.dynamicBalances, object : TypeToken<Map<String, String>>() {}.type)
                        if (map?.values?.any { j -> Gson().fromJson<List<FinanceItem>>(j, typeToken)?.any { it.amount != 0.0 } == true } == true) hasAmount = true
                    }
                    if (!hasAmount && !f.dynamicData.isNullOrBlank() && f.dynamicData != "{}") {
                        val map = Gson().fromJson<Map<String, String>>(f.dynamicData, object : TypeToken<Map<String, String>>() {}.type)
                        if (map?.values?.any { j -> Gson().fromJson<List<FinanceItem>>(j, typeToken)?.any { it.amount != 0.0 } == true } == true) hasAmount = true
                    }
                } catch (_: Exception) {}
            }
            if (hasAmount && f.date > 0L) {
                list.add(f.date)
            }
        }
        debts.forEach { d ->
            if (d.amount > 0.0) {
                val t = if (d.createdAt > 0L) d.createdAt else d.dueDate
                if (t > 0L) list.add(t)
            }
        }
        capitalOverrides.keys.forEach { k ->
            val p = k.split("_")
            if (p.size == 2) {
                val y = p[0].toIntOrNull()
                val m = p[1].toIntOrNull()
                if (y != null && m != null) {
                    val cal = Calendar.getInstance().apply {
                        set(Calendar.YEAR, y)
                        set(Calendar.MONTH, m)
                        set(Calendar.DAY_OF_MONTH, 1)
                        set(Calendar.HOUR_OF_DAY, 0)
                        set(Calendar.MINUTE, 0)
                        set(Calendar.SECOND, 0)
                        set(Calendar.MILLISECOND, 0)
                    }
                    list.add(cal.timeInMillis)
                }
            }
        }
        list.minOrNull()
    }

    val earliestCutoffCal = remember(earliestRecordedTimestamp, currentCalYear, currentCalMonth) {
        if (earliestRecordedTimestamp != null) {
            Calendar.getInstance().apply { timeInMillis = earliestRecordedTimestamp }
        } else {
            Calendar.getInstance().apply {
                set(Calendar.YEAR, currentCalYear)
                set(Calendar.MONTH, currentCalMonth)
            }
        }
    }
    val earliestCutoffYear = earliestCutoffCal.get(Calendar.YEAR).coerceAtMost(currentCalYear)
    val earliestCutoffMonth = earliestCutoffCal.get(Calendar.MONTH)
    val minYearInApp = earliestCutoffYear
    val maxYearInApp = currentCalYear

    val availableYears = remember(earliestCutoffYear, currentCalYear) {
        (earliestCutoffYear..currentCalYear).toList()
    }

    var capitalMode by remember { mutableStateOf("YEAR") } // "YEAR" or "RANGE"
    var chartYear by remember(earliestCutoffYear) { mutableIntStateOf(selectedMonth.get(Calendar.YEAR).coerceIn(earliestCutoffYear, currentCalYear)) }
    var rangeStartYear by remember(earliestCutoffYear) { mutableIntStateOf(earliestCutoffYear) }
    var rangeEndYear by remember { mutableIntStateOf(currentCalYear) }
    var rangeStep by remember { mutableStateOf("YEARLY") } // "YEARLY" or "MONTHLY"

    LaunchedEffect(selectedMonth, earliestCutoffYear) {
        if (capitalMode == "YEAR") {
            chartYear = selectedMonth.get(Calendar.YEAR).coerceIn(earliestCutoffYear, currentCalYear)
        }
    }

    val yearlyPoints = remember(
        capitalMode,
        chartYear,
        rangeStartYear,
        rangeEndYear,
        rangeStep,
        finances,
        debts,
        categories,
        hiddenSections,
        capitalOverrides,
        earliestCutoffYear,
        earliestCutoffMonth,
        earliestRecordedTimestamp
    ) {
        if (capitalMode == "YEAR") {
            val effectiveYear = chartYear.coerceIn(earliestCutoffYear, currentCalYear)
            // Исключаем месяцы до того, как пользователь начал вести учет:
            // Если выбран начальный год учета, начинаем только с месяца первой отсечки
            val minMonthIdx = if (effectiveYear == earliestCutoffYear && earliestRecordedTimestamp != null) earliestCutoffMonth else 0
            // Исключаем будущие месяцы: для текущего года отображаем только прошедшие и текущий
            val maxMonthIdx = if (effectiveYear == currentCalYear) currentCalMonth else 11
            val safeMin = minMonthIdx.coerceAtMost(maxMonthIdx)
            (safeMin..maxMonthIdx).map { mIdx ->
                calculatePointForMonth(
                    year = effectiveYear,
                    monthIdx = mIdx,
                    labelShort = monthNamesShort[mIdx],
                    labelFull = "${monthNamesFull[mIdx]} $effectiveYear"
                )
            }
        } else {
            val sYear = minOf(rangeStartYear, rangeEndYear).coerceIn(earliestCutoffYear, currentCalYear)
            val eYear = maxOf(rangeStartYear, rangeEndYear).coerceIn(earliestCutoffYear, currentCalYear)
            if (rangeStep == "YEARLY") {
                (sYear..eYear).map { y ->
                    val mIdx = if (y == currentCalYear) currentCalMonth else 11
                    val shortLbl = if (y == currentCalYear) "$y (тек.)" else "$y"
                    val fullLbl = if (y == currentCalYear) "${monthNamesFull[currentCalMonth]} $y" else "Конец $y г."
                    calculatePointForMonth(
                        year = y,
                        monthIdx = mIdx,
                        labelShort = shortLbl,
                        labelFull = fullLbl
                    )
                }
            } else {
                val list = mutableListOf<YearlyCapitalPoint>()
                for (y in sYear..eYear) {
                    val minM = if (y == earliestCutoffYear && earliestRecordedTimestamp != null) earliestCutoffMonth else 0
                    val maxM = if (y == currentCalYear) currentCalMonth else 11
                    val safeMinM = minM.coerceAtMost(maxM)
                    for (mIdx in safeMinM..maxM) {
                        list.add(
                            calculatePointForMonth(
                                year = y,
                                monthIdx = mIdx,
                                labelShort = "${monthNamesShort[mIdx]} '${y.toString().takeLast(2)}",
                                labelFull = "${monthNamesFull[mIdx]} $y"
                            )
                        )
                    }
                }
                list
            }
        }
    }

    var analyticsType by remember { mutableStateOf("EXPENSE") } // "EXPENSE" or "INCOME"

    val filteredNotes = notes.filter { val c = Calendar.getInstance().apply { timeInMillis = it.date }; c.get(Calendar.MONTH) == selectedMonth.get(Calendar.MONTH) && c.get(Calendar.YEAR) == selectedMonth.get(Calendar.YEAR) }
    val filteredFinances = finances.filter { val c = Calendar.getInstance().apply { timeInMillis = it.date }; c.get(Calendar.MONTH) == selectedMonth.get(Calendar.MONTH) && c.get(Calendar.YEAR) == selectedMonth.get(Calendar.YEAR) }

    val segments = remember(filteredFinances, categories, expName, incName, analyticsType) {
        val list = mutableListOf<PieSegment>()
        try {
            if (analyticsType == "EXPENSE") {
                val sysExp = filteredFinances.sumOf { it.expense }
                val expCat = categories.find { (it.id ?: "") == "exp" }
                if (sysExp > 0) {
                    list.add(
                        PieSegment(
                            id = "exp",
                            name = expName ?: "Расход",
                            value = sysExp,
                            color = Color(0xFFF44336),
                            iconKey = expCat?.iconKey ?: "cart",
                            customIconUri = expCat?.customIconUri ?: ""
                        )
                    )
                }
                categories.filter { (it.type ?: CatType.HISTORY) == CatType.HISTORY }.forEach { cat ->
                    val total = filteredFinances.sumOf { f ->
                        try {
                            val map = Gson().fromJson<Map<String, String>>(f.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                            Gson().fromJson<List<FinanceItem>>(map[cat.id ?: ""] ?: "[]", object : TypeToken<List<FinanceItem>>() {}.type)?.sumOf { it.amount } ?: 0.0
                        } catch (_: Exception) { 0.0 }
                    }
                    if (total > 0) {
                        val segColor = try { Color(cat.color) } catch (_: Exception) { Color(0xFFF44336) }
                        list.add(
                            PieSegment(
                                id = cat.id ?: "",
                                name = cat.name ?: "",
                                value = total,
                                color = segColor,
                                iconKey = cat.iconKey ?: "",
                                customIconUri = cat.customIconUri ?: ""
                            )
                        )
                    }
                }
            } else {
                val sysInc = filteredFinances.sumOf { it.income }
                val incCat = categories.find { (it.id ?: "") == "inc" }
                if (sysInc > 0) {
                    list.add(
                        PieSegment(
                            id = "inc",
                            name = incName ?: "Доход",
                            value = sysInc,
                            color = Color(0xFF2E7D32),
                            iconKey = incCat?.iconKey ?: "income",
                            customIconUri = incCat?.customIconUri ?: ""
                        )
                    )
                }
                categories.filter { (it.type ?: CatType.HISTORY) == CatType.INCOME }.forEach { cat ->
                    val total = filteredFinances.sumOf { f ->
                        try {
                            val map = Gson().fromJson<Map<String, String>>(f.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap()
                            Gson().fromJson<List<FinanceItem>>(map[cat.id ?: ""] ?: "[]", object : TypeToken<List<FinanceItem>>() {}.type)?.sumOf { it.amount } ?: 0.0
                        } catch (_: Exception) { 0.0 }
                    }
                    if (total > 0) {
                        val segColor = try { Color(cat.color) } catch (_: Exception) { Color(0xFF2E7D32) }
                        list.add(
                            PieSegment(
                                id = cat.id ?: "",
                                name = cat.name ?: "",
                                value = total,
                                color = segColor,
                                iconKey = cat.iconKey ?: "",
                                customIconUri = cat.customIconUri ?: ""
                            )
                        )
                    }
                }
            }
        } catch (_: Exception) {}
        list
    }

    // Состояние выбранного раздела для детального просмотра трат / доходов по числам
    var selectedCategoryForDetail by remember { mutableStateOf<PieSegment?>(null) }
    var activeSegment by remember { mutableStateOf<PieSegment?>(null) }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        val canGoForwardMonth = remember(selectedMonth, nowCal) {
            selectedMonth.get(Calendar.YEAR) < currentCalYear ||
            (selectedMonth.get(Calendar.YEAR) == currentCalYear && selectedMonth.get(Calendar.MONTH) < currentCalMonth)
        }

        // ЛИНЕЙНЫЙ ГРАФИК ЧИСТОГО КАПИТАЛА (NET CAPITAL) ПО МЕСЯЦАМ / ГОДАМ
        var inspectedPointIdx by remember(yearlyPoints) {
            val initialIdx = if (capitalMode == "YEAR" && selectedMonth.get(Calendar.YEAR) == chartYear) {
                val mIdx = selectedMonth.get(Calendar.MONTH)
                val found = yearlyPoints.indexOfFirst { it.monthIdx == mIdx }
                if (found != -1) found else (yearlyPoints.size - 1).coerceAtLeast(0)
            } else {
                (yearlyPoints.size - 1).coerceAtLeast(0)
            }
            mutableIntStateOf(initialIdx)
        }

        val safeIdx = inspectedPointIdx.coerceIn(0, (yearlyPoints.size - 1).coerceAtLeast(0))
        val inspectedPoint = yearlyPoints.getOrElse(safeIdx) {
            yearlyPoints.firstOrNull() ?: calculatePointForMonth(chartYear, 11, "Дек", "Декабрь $chartYear")
        }

        val startCap = yearlyPoints.firstOrNull()?.netCapital ?: 0.0
        val endCap = inspectedPoint.netCapital
        val annualDiff = endCap - startCap
        val annualPct = if (startCap != 0.0) ((annualDiff / Math.abs(startCap)) * 100).toInt() else 0

        val minNet = yearlyPoints.minOfOrNull { it.netCapital } ?: 0.0
        val maxNet = yearlyPoints.maxOfOrNull { it.netCapital } ?: 0.0

        Card(
            Modifier.fillMaxWidth().padding(bottom = 12.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(16.dp),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
        ) {
            Column(Modifier.padding(14.dp)) {
                // Заголовок и переключатель режима (1 год / Период)
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Box(Modifier.size(32.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFE8EAF6)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.TrendingUp, null, tint = Color(0xFF3F51B5), modifier = Modifier.size(18.dp))
                        }
                        Spacer(Modifier.width(8.dp))
                        Column {
                            Text("ЧИСТЫЙ КАПИТАЛ", fontSize = 11.sp, fontWeight = FontWeight.Normal)
                            Text(
                                if (capitalMode == "YEAR") {
                                    if (chartYear == currentCalYear) {
                                        if (earliestCutoffYear == currentCalYear && earliestRecordedTimestamp != null && earliestCutoffMonth > 0) {
                                            "Прогресс за $chartYear год (с ${monthNamesShort[earliestCutoffMonth]} по тек. месяц)"
                                        } else {
                                            "Прогресс за $chartYear год (по тек. месяц)"
                                        }
                                    } else {
                                        if (chartYear == earliestCutoffYear && earliestRecordedTimestamp != null && earliestCutoffMonth > 0) {
                                            "Прогресс за $chartYear год (с ${monthNamesShort[earliestCutoffMonth]})"
                                        } else {
                                            "Прогресс за $chartYear год"
                                        }
                                    }
                                } else {
                                    "Период: ${minOf(rangeStartYear, rangeEndYear)}–${maxOf(rangeStartYear, rangeEndYear)} гг. (${if (rangeStep == "YEARLY") "по годам" else "по месяцам"})"
                                },
                                fontSize = 10.sp,
                                color = Color.Gray
                            )
                        }
                    }

                    // Переключатель режима: 1 год / Период
                    Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .padding(2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (capitalMode == "YEAR") MaterialTheme.colorScheme.surface else Color.Transparent)
                                .clickable { capitalMode = "YEAR" }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("1 год", fontSize = 11.sp, fontWeight = if (capitalMode == "YEAR") FontWeight.Bold else FontWeight.Normal)
                        }
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(if (capitalMode == "RANGE") MaterialTheme.colorScheme.surface else Color.Transparent)
                                .clickable { capitalMode = "RANGE" }
                                .padding(horizontal = 8.dp, vertical = 4.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("Период", fontSize = 11.sp, fontWeight = if (capitalMode == "RANGE") FontWeight.Bold else FontWeight.Normal)
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Панель управления выбранным режимом
                if (capitalMode == "YEAR") {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        ) {
                            IconButton(
                                onClick = {
                                    if (chartYear > minYearInApp) chartYear -= 1
                                },
                                enabled = chartYear > minYearInApp,
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    Icons.Default.KeyboardArrowLeft,
                                    null,
                                    modifier = Modifier.size(18.dp),
                                    tint = if (chartYear > minYearInApp) MaterialTheme.colorScheme.onSurface else Color.Gray.copy(alpha = 0.3f)
                                )
                            }
                            Text("$chartYear", fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 4.dp))
                            IconButton(
                                onClick = {
                                    if (chartYear < currentCalYear) chartYear += 1
                                },
                                enabled = chartYear < currentCalYear,
                                modifier = Modifier.size(26.dp)
                            ) {
                                Icon(
                                    Icons.Default.KeyboardArrowRight,
                                    null,
                                    modifier = Modifier.size(18.dp),
                                    tint = if (chartYear < currentCalYear) MaterialTheme.colorScheme.onSurface else Color.Gray.copy(alpha = 0.3f)
                                )
                            }
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                            .padding(8.dp)
                    ) {
                        Row(
                            Modifier.fillMaxWidth(),
                            Arrangement.SpaceBetween,
                            Alignment.CenterVertically
                        ) {
                            // Выбор С ... По ...
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("С: ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .padding(horizontal = 2.dp, vertical = 1.dp)
                                ) {
                                    IconButton(
                                        onClick = {
                                            if (rangeStartYear > minYearInApp) rangeStartYear -= 1
                                            if (rangeStartYear > rangeEndYear) rangeEndYear = rangeStartYear
                                        },
                                        enabled = rangeStartYear > minYearInApp,
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.KeyboardArrowLeft,
                                            null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (rangeStartYear > minYearInApp) MaterialTheme.colorScheme.onSurface else Color.Gray.copy(alpha = 0.3f)
                                        )
                                    }
                                    Text("$rangeStartYear", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 2.dp))
                                    IconButton(
                                        onClick = {
                                            if (rangeStartYear < rangeEndYear && rangeStartYear < currentCalYear) rangeStartYear += 1
                                        },
                                        enabled = rangeStartYear < rangeEndYear && rangeStartYear < currentCalYear,
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.KeyboardArrowRight,
                                            null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (rangeStartYear < rangeEndYear && rangeStartYear < currentCalYear) MaterialTheme.colorScheme.onSurface else Color.Gray.copy(alpha = 0.3f)
                                        )
                                    }
                                }

                                Spacer(Modifier.width(8.dp))

                                Text("По: ", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(MaterialTheme.colorScheme.surface)
                                        .padding(horizontal = 2.dp, vertical = 1.dp)
                                ) {
                                    IconButton(
                                        onClick = {
                                            if (rangeEndYear > rangeStartYear && rangeEndYear > minYearInApp) rangeEndYear -= 1
                                        },
                                        enabled = rangeEndYear > rangeStartYear && rangeEndYear > minYearInApp,
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.KeyboardArrowLeft,
                                            null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (rangeEndYear > rangeStartYear && rangeEndYear > minYearInApp) MaterialTheme.colorScheme.onSurface else Color.Gray.copy(alpha = 0.3f)
                                        )
                                    }
                                    Text("$rangeEndYear", fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 2.dp))
                                    IconButton(
                                        onClick = {
                                            if (rangeEndYear < currentCalYear) rangeEndYear += 1
                                        },
                                        enabled = rangeEndYear < currentCalYear,
                                        modifier = Modifier.size(22.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.KeyboardArrowRight,
                                            null,
                                            modifier = Modifier.size(16.dp),
                                            tint = if (rangeEndYear < currentCalYear) MaterialTheme.colorScheme.onSurface else Color.Gray.copy(alpha = 0.3f)
                                        )
                                    }
                                }
                            }

                            // Шаг: по годам / по месяцам
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(MaterialTheme.colorScheme.surface)
                                    .padding(2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (rangeStep == "YEARLY") MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent)
                                        .clickable { rangeStep = "YEARLY" }
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text("Года", fontSize = 10.sp, fontWeight = if (rangeStep == "YEARLY") FontWeight.Bold else FontWeight.Normal, color = if (rangeStep == "YEARLY") MaterialTheme.colorScheme.primary else Color.Gray)
                                }
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(if (rangeStep == "MONTHLY") MaterialTheme.colorScheme.primary.copy(alpha = 0.15f) else Color.Transparent)
                                        .clickable { rangeStep = "MONTHLY" }
                                        .padding(horizontal = 6.dp, vertical = 3.dp)
                                ) {
                                    Text("Месяцы", fontSize = 10.sp, fontWeight = if (rangeStep == "MONTHLY") FontWeight.Bold else FontWeight.Normal, color = if (rangeStep == "MONTHLY") MaterialTheme.colorScheme.primary else Color.Gray)
                                }
                            }
                        }

                        Spacer(Modifier.height(6.dp))

                        // Быстрые пресеты
                        Row(
                            Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("Быстро:", fontSize = 10.sp, color = Color.Gray)
                            listOf(
                                "3 года" to (currentCalYear - 2).coerceAtLeast(minYearInApp),
                                "5 лет" to (currentCalYear - 4).coerceAtLeast(minYearInApp),
                                "Все годы" to minYearInApp
                            ).distinctBy { it.second }.forEach { (label, startY) ->
                                val isSelected = rangeStartYear == startY && rangeEndYear == currentCalYear
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                                        .clickable {
                                            rangeStartYear = startY
                                            rangeEndYear = currentCalYear
                                        }
                                        .padding(horizontal = 8.dp, vertical = 3.dp)
                                ) {
                                    Text(
                                        label,
                                        fontSize = 10.sp,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(Modifier.height(10.dp))

                // Карточки метрик выбранной точки
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Card(
                        Modifier
                            .weight(1.15f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                monthToOverride = inspectedPoint
                                showOverrideDialog = true
                            },
                        colors = CardDefaults.cardColors(
                            containerColor = if (inspectedPoint.isOverridden) Color(0xFFFFF8E1) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                        ),
                        border = if (inspectedPoint.isOverridden) BorderStroke(1.dp, Color(0xFFFFA000).copy(alpha = 0.6f)) else null
                    ) {
                        Column(Modifier.padding(8.dp)) {
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                                Text(
                                    inspectedPoint.fullName,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.Gray,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    if (inspectedPoint.isOverridden) {
                                        Text("Вручную ✎", fontSize = 8.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                    } else {
                                        Icon(Icons.Default.Edit, "Изменить", tint = Color(0xFF3F51B5).copy(alpha = 0.7f), modifier = Modifier.size(11.dp))
                                    }
                                }
                            }
                            Text(mask(inspectedPoint.netCapital, isIncognito), fontSize = 14.sp, fontWeight = FontWeight.Normal, color = if (inspectedPoint.isOverridden) Color(0xFFE65100) else Color(0xFF3F51B5))
                            Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                                Text("Акт: ${mask(inspectedPoint.assets, isIncognito)}", fontSize = 9.sp, color = Color(0xFF2E7D32))
                                if (inspectedPoint.isOverridden) {
                                    Text("Авто: ${mask(inspectedPoint.rawNetCapital, isIncognito)}", fontSize = 8.sp, color = Color.Gray)
                                } else {
                                    Text("изменить ✎", fontSize = 8.sp, color = Color(0xFF3F51B5).copy(alpha = 0.8f))
                                }
                            }
                        }
                    }
                    Card(Modifier.weight(0.85f), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))) {
                        Column(Modifier.padding(8.dp)) {
                            Text(
                                if (capitalMode == "YEAR") "Прирост за год (Δ)" else "Прирост за период (Δ)",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Gray
                            )
                            Text("${if(annualDiff >= 0) "+" else ""}${mask(annualDiff, isIncognito)}", fontSize = 14.sp, fontWeight = FontWeight.Normal, color = if(annualDiff >= 0) Color(0xFF2E7D32) else Color(0xFFD32F2F))
                            Text(
                                "${if(annualPct >= 0) "+" else ""}$annualPct% ${if (capitalMode == "YEAR") "с начала года" else "за период"}",
                                fontSize = 9.sp,
                                color = Color.Gray
                            )
                        }
                    }
                }

                Spacer(Modifier.height(14.dp))

                val primaryColor = Color(0xFF3F51B5)
                val gradientBrush = Brush.verticalGradient(
                    colors = listOf(primaryColor.copy(alpha = 0.28f), primaryColor.copy(alpha = 0.0f))
                )

                Box(Modifier.fillMaxWidth().height(160.dp)) {
                    val pointsCount = yearlyPoints.size
                    Canvas(
                        Modifier
                            .fillMaxSize()
                            .pointerInput(yearlyPoints) {
                                detectTapGestures { offset ->
                                    val w = size.width
                                    val padLeft = 32.dp.toPx()
                                    val padRight = 16.dp.toPx()
                                    val plotW = (w - padLeft - padRight).coerceAtLeast(1f)
                                    if (pointsCount > 0) {
                                        val ptsX = (0 until pointsCount).map { idx ->
                                            padLeft + (if (pointsCount > 1) (idx.toFloat() / (pointsCount - 1)) else 0.5f) * plotW
                                        }
                                        val closestIdx = ptsX.indices.minByOrNull { Math.abs(ptsX[it] - offset.x) } ?: 0
                                        inspectedPointIdx = closestIdx
                                    }
                                }
                            }
                    ) {
                        val w = size.width
                        val h = size.height
                        val padLeft = 32.dp.toPx()
                        val padRight = 16.dp.toPx()
                        val padTop = 15.dp.toPx()
                        val padBottom = 20.dp.toPx()
                        val plotW = w - padLeft - padRight
                        val plotH = h - padTop - padBottom

                        var yMin = minNet
                        var yMax = maxNet
                        if (yMin == yMax) {
                            yMin -= 10000.0
                            yMax += 10000.0
                        } else {
                            val margin = (yMax - yMin) * 0.15
                            yMin -= margin
                            yMax += margin
                        }
                        val yRange = (yMax - yMin).coerceAtLeast(1.0)

                        listOf(0f, 0.5f, 1f).forEach { r ->
                            val gy = padTop + plotH * (1f - r)
                            drawLine(
                                color = Color.LightGray.copy(alpha = 0.4f),
                                start = Offset(padLeft, gy),
                                end = Offset(padLeft + plotW, gy),
                                strokeWidth = 1.dp.toPx()
                            )
                        }

                        val pts = yearlyPoints.mapIndexed { idx, item ->
                            val x = padLeft + (if (pointsCount > 1) (idx.toFloat() / (pointsCount - 1)) else 0.5f) * plotW
                            val y = padTop + plotH - ((item.netCapital - yMin) / yRange * plotH).toFloat()
                            Offset(x, y)
                        }

                        if (pts.isNotEmpty()) {
                            if (pts.size == 1) {
                                val pt = pts[0]
                                drawCircle(color = primaryColor, radius = 5.dp.toPx(), center = pt)
                            } else {
                                val linePath = Path().apply {
                                    moveTo(pts[0].x, pts[0].y)
                                    for (i in 0 until pts.size - 1) {
                                        val p0 = if (i > 0) pts[i - 1] else pts[i]
                                        val p1 = pts[i]
                                        val p2 = pts[i + 1]
                                        val p3 = if (i < pts.size - 2) pts[i + 2] else p2

                                        val cp1x = p1.x + (p2.x - p0.x) / 6f
                                        val cp1y = p1.y + (p2.y - p0.y) / 6f
                                        val cp2x = p2.x - (p3.x - p1.x) / 6f
                                        val cp2y = p2.y - (p3.y - p1.y) / 6f

                                        cubicTo(cp1x, cp1y, cp2x, cp2y, p2.x, p2.y)
                                    }
                                }

                                val fillPath = Path().apply {
                                    addPath(linePath)
                                    lineTo(pts.last().x, padTop + plotH)
                                    lineTo(pts.first().x, padTop + plotH)
                                    close()
                                }

                                drawPath(fillPath, brush = gradientBrush)
                                drawPath(linePath, color = primaryColor, style = Stroke(width = 2.5.dp.toPx()))

                                pts.forEachIndexed { idx, pt ->
                                    val ptData = yearlyPoints[idx]
                                    val isSelected = idx == safeIdx
                                    val ptColor = if (ptData.isOverridden) Color(0xFFE65100) else primaryColor
                                    if (isSelected) {
                                        drawCircle(color = ptColor.copy(alpha = 0.25f), radius = 10.dp.toPx(), center = pt)
                                        drawCircle(color = ptColor, radius = 5.dp.toPx(), center = pt)
                                        drawCircle(color = Color.White, radius = 2.5.dp.toPx(), center = pt)
                                    } else {
                                        drawCircle(color = Color.White, radius = 3.5.dp.toPx(), center = pt)
                                        drawCircle(color = ptColor, radius = 3.5.dp.toPx(), center = pt, style = Stroke(width = 1.5.dp.toPx()))
                                    }
                                }
                            }
                        }
                    }
                }

                LazyRow(
                    Modifier.fillMaxWidth(),
                    horizontalArrangement = if (yearlyPoints.size <= 12) Arrangement.SpaceBetween else Arrangement.spacedBy(6.dp)
                ) {
                    items(count = yearlyPoints.size) { idx ->
                        val p = yearlyPoints[idx]
                        val isSelected = idx == safeIdx
                        val labelText = if (p.isOverridden) "${p.shortName}✎" else p.shortName
                        Text(
                            text = labelText,
                            fontSize = 11.sp,
                            fontWeight = if (isSelected) FontWeight.Normal else FontWeight.Normal,
                            color = if (isSelected) (if (p.isOverridden) Color(0xFFE65100) else Color(0xFF3F51B5)) else (if (p.isOverridden) Color(0xFFE65100).copy(alpha = 0.85f) else Color.Gray),
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(if (isSelected) (if (p.isOverridden) Color(0xFFFFF3E0) else Color(0xFFE8EAF6)) else Color.Transparent)
                                .clickable {
                                    inspectedPointIdx = idx
                                    selectedMonth = Calendar.getInstance().apply {
                                        timeInMillis = p.timestamp
                                    }
                                }
                                .padding(horizontal = 4.dp, vertical = 2.dp)
                        )
                    }
                }
            }
        }

        if (showOverrideDialog && monthToOverride != null) {
            val pt = monthToOverride!!
            val overrideKey = "${pt.year}_${pt.monthIdx}"
            var inputStr by remember(pt) {
                mutableStateOf<String>(if (pt.isOverridden) "${pt.netCapital.toLong()}" else "${pt.rawNetCapital.toLong()}")
            }
            AlertDialog(
                onDismissRequest = { showOverrideDialog = false; monthToOverride = null },
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Edit, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Капитал: ${pt.fullName}", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    }
                },
                text = {
                    Column {
                        Text(
                            "Вы можете вручную скорректировать точный чистый капитал за ${pt.fullName} для точного просмотра динамики.",
                            fontSize = 12.sp,
                            color = Color.DarkGray
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            "Корректировка фиксируется ТОЛЬКО за этим периодом и никак не влияет на расчеты текущих или будущих периодов.",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                        Spacer(Modifier.height(10.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                        ) {
                            Column(Modifier.padding(8.dp)) {
                                Text("Авторасчет по операциям: ${mask(pt.rawNetCapital, isIncognito)} ₽", fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF3F51B5))
                                if (pt.isOverridden) {
                                    Text("Текущее ручное значение: ${mask(pt.netCapital, isIncognito)} ₽", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color(0xFFE65100))
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        OutlinedTextField(
                            value = inputStr,
                            onValueChange = { inputStr = it },
                            label = { Text("Чистый капитал за ${pt.shortName} (₽)") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.fillMaxWidth(),
                            singleLine = true
                        )
                    }
                },
                confirmButton = {
                    Button(onClick = {
                        val clean = inputStr.replace(",", ".").replace(" ", "").trim()
                        val parsed = clean.toDoubleOrNull()
                        if (parsed != null) {
                            saveCapitalOverride(context, overrideKey, parsed)
                            capitalOverrides = getCapitalOverrides(context)
                        }
                        showOverrideDialog = false
                        monthToOverride = null
                    }) {
                        Text("Сохранить")
                    }
                },
                dismissButton = {
                    Row {
                        if (pt.isOverridden) {
                            TextButton(onClick = {
                                saveCapitalOverride(context, overrideKey, null)
                                capitalOverrides = getCapitalOverrides(context)
                                showOverrideDialog = false
                                monthToOverride = null
                            }) {
                                Text("Сбросить на авто", color = Color.Red)
                            }
                        }
                        TextButton(onClick = { showOverrideDialog = false; monthToOverride = null }) {
                            Text("Отмена")
                        }
                    }
                }
            )
        }

        // КАРТОЧКА: РАСПРЕДЕЛЕНИЕ ТРАТ / ДОХОДОВ В СТИЛЕ СОВРЕМЕННОГО БАНКА (DONUT CHART)
        Card(
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
        ) {
            Column(Modifier.padding(16.dp)) {
                // Переключатель месяца прямо над диаграммой распределения трат
                val monthTitle = remember(selectedMonth) {
                    SimpleDateFormat("LLLL yyyy", Locale("ru")).format(selectedMonth.time).replaceFirstChar { it.uppercase() }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { selectedMonth = (selectedMonth.clone() as Calendar).apply { add(Calendar.MONTH, -1) } }) {
                        Icon(Icons.Default.ChevronLeft, contentDescription = "Предыдущий месяц", tint = MaterialTheme.colorScheme.primary)
                    }
                    Text(
                        text = monthTitle,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    IconButton(
                        onClick = {
                            if (canGoForwardMonth) {
                                selectedMonth = (selectedMonth.clone() as Calendar).apply { add(Calendar.MONTH, 1) }
                            }
                        },
                        enabled = canGoForwardMonth
                    ) {
                        Icon(
                            Icons.Default.ChevronRight,
                            contentDescription = "Следующий месяц",
                            tint = if (canGoForwardMonth) MaterialTheme.colorScheme.primary else Color.Gray.copy(alpha = 0.3f)
                        )
                    }
                }

                Spacer(Modifier.height(8.dp))

                // Переключатель: Траты (Расходы) / Доходы
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = { analyticsType = "EXPENSE"; selectedCategoryForDetail = null },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (analyticsType == "EXPENSE") Color(0xFFD32F2F) else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (analyticsType == "EXPENSE") Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Траты (Расходы)", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { analyticsType = "INCOME"; selectedCategoryForDetail = null },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (analyticsType == "INCOME") Color(0xFF2E7D32) else MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = if (analyticsType == "INCOME") Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Доходы", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(Modifier.height(14.dp))

                val sortedSegments = remember(segments) {
                    try {
                        segments.filter { it.value.isFinite() && it.value > 0.0 }.sortedByDescending { it.value }
                    } catch (_: Throwable) {
                        emptyList()
                    }
                }
                val total = sortedSegments.sumOf { if (it.value.isFinite()) it.value else 0.0 }
                val safeTotal = if (total.isFinite() && total > 0.0001) total else 0.0

                if (sortedSegments.isEmpty() || safeTotal <= 0.0) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height(180.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(Icons.Default.Category, null, tint = Color.LightGray, modifier = Modifier.size(36.dp))
                            Spacer(Modifier.height(8.dp))
                            Text(
                                if (analyticsType == "EXPENSE") "Нет данных о тратах за этот месяц" else "Нет данных о доходах за этот месяц",
                                color = Color.Gray,
                                fontSize = 12.sp
                            )
                        }
                    }
                } else {
                    // Определение активного раздела для центра круга
                    val currentActive = if (activeSegment != null && sortedSegments.any { it.id == activeSegment?.id }) {
                        sortedSegments.firstOrNull { it.id == activeSegment?.id } ?: sortedSegments.firstOrNull()
                    } else {
                        sortedSegments.firstOrNull()
                    }

                    // КОЛЬЦЕВАЯ ДИАГРАММА С КЛИКОМ ПО СЕКТОРАМ, ПРОЦЕНТАМИ ВОКРУГ И АКТИВНЫМ РАЗДЕЛОМ В ЦЕНТРЕ
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(280.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        // 1. Отрисовка кольца и точная обработка тапов по секторам диаграммы
                        Canvas(
                            modifier = Modifier
                                .size(200.dp)
                                .pointerInput(sortedSegments, safeTotal) {
                                    detectTapGestures { offset ->
                                        if (safeTotal <= 0.0 || sortedSegments.isEmpty()) return@detectTapGestures
                                        val centerX = size.width / 2f
                                        val centerY = size.height / 2f
                                        val dx = offset.x - centerX
                                        val dy = offset.y - centerY
                                        val dist = kotlin.math.sqrt(dx * dx + dy * dy)
                                        val densityVal = if (density > 0f) density else 1f
                                        val distDp = dist / densityVal

                                        // Клик по кольцу диаграммы (от 40 dp до 115 dp)
                                        if (distDp in 40f..115f) {
                                            var deg = Math.toDegrees(kotlin.math.atan2(dy.toDouble(), dx.toDouble())).toFloat()
                                            var normAngle = (deg - (-90f)) % 360f
                                            if (normAngle < 0f) normAngle += 360f

                                            var running = 0f
                                            for (seg in sortedSegments) {
                                                val sweep = (seg.value / safeTotal * 360f).toFloat()
                                                if (normAngle >= running && normAngle <= running + sweep) {
                                                    activeSegment = seg
                                                    selectedCategoryForDetail = seg
                                                    break
                                                }
                                                running += sweep
                                            }
                                        }
                                    }
                                }
                        ) {
                            val strokePx = 36.dp.toPx()
                            val diameter = (size.minDimension - strokePx).coerceAtLeast(10f)
                            val topLeft = Offset(strokePx / 2f, strokePx / 2f)
                            val arcSize = androidx.compose.ui.geometry.Size(diameter, diameter)

                            var curAngle = -90f
                            sortedSegments.forEach { seg ->
                                val rawSweep = (seg.value / safeTotal * 360.0).toFloat()
                                val sweep = if (rawSweep.isFinite() && rawSweep > 0f) rawSweep else 0f
                                val gap = if (sortedSegments.size > 1) 2.2f else 0f
                                val drawSweep = (sweep - gap).coerceAtLeast(0.5f)

                                if (drawSweep.isFinite() && drawSweep > 0f) {
                                    drawArc(
                                        color = seg.color,
                                        startAngle = curAngle + gap / 2f,
                                        sweepAngle = drawSweep,
                                        useCenter = false,
                                        topLeft = topLeft,
                                        size = arcSize,
                                        style = Stroke(width = strokePx, cap = StrokeCap.Butt)
                                    )
                                }
                                curAngle += sweep
                            }
                        }

                        // 2. Иконки внутри секторов и проценты вокруг кольца
                        var runningAngle = -90f
                        sortedSegments.forEachIndexed { idx, seg ->
                            val rawSweep = (seg.value / safeTotal * 360.0).toFloat()
                            val sweep = if (rawSweep.isFinite() && rawSweep > 0f) rawSweep else 0f
                            val midAngle = runningAngle + sweep / 2f
                            val rad = Math.toRadians(midAngle.toDouble())

                            val cosVal = Math.cos(rad)
                            val sinVal = Math.sin(rad)
                            val safeCos = if (cosVal.isFinite()) cosVal.toFloat() else 0f
                            val safeSin = if (sinVal.isFinite()) sinVal.toFloat() else 0f

                            // Координаты для иконки внутри кольца (r = 72 dp)
                            val iconDx = (72f * safeCos).dp
                            val iconDy = (72f * safeSin).dp

                            // Координаты для процента снаружи кольца (r = 114 dp)
                            val labelDx = (114f * safeCos).dp
                            val labelDy = (114f * safeSin).dp

                            val pct = (seg.value / safeTotal * 100.0)
                            val safePct = if (pct.isFinite()) pct else 0.0
                            val pctText = if (safePct >= 1.0) "${safePct.toInt()}%" else String.format(Locale.US, "%.1f%%", safePct)

                            // Иконка категории внутри сектора (если сектор достаточно широк)
                            if (sweep >= 18f) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .offset(x = iconDx, y = iconDy)
                                        .size(20.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CategoryIconDisplay(
                                        iconKey = seg.iconKey,
                                        customIconUri = seg.customIconUri,
                                        categoryName = seg.name,
                                        categoryId = seg.id,
                                        tint = Color.White,
                                        modifier = Modifier.size(15.dp)
                                    )
                                }
                            } else if (sweep >= 8f) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .offset(x = iconDx, y = iconDy)
                                        .size(16.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    CategoryIconDisplay(
                                        iconKey = seg.iconKey,
                                        customIconUri = seg.customIconUri,
                                        categoryName = seg.name,
                                        categoryId = seg.id,
                                        tint = Color.White,
                                        modifier = Modifier.size(11.dp)
                                    )
                                }
                            } else if (sweep >= 3f) {
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .offset(x = iconDx, y = iconDy)
                                        .size(4.dp)
                                        .clip(CircleShape)
                                        .background(Color.White)
                                )
                            }

                            // Проценты снаружи кольца
                            if (safePct >= 0.4) {
                                Text(
                                    text = pctText,
                                    fontSize = if (safePct >= 10.0) 11.sp else 10.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                                    modifier = Modifier
                                        .align(Alignment.Center)
                                        .offset(x = labelDx, y = labelDy)
                                )
                            }

                            runningAngle += sweep
                        }

                        // 3. Центр кольца: активный раздел с иконкой, названием и процентами (кликабелен)
                        Surface(
                            modifier = Modifier
                                .size(96.dp)
                                .clip(CircleShape)
                                .clickable(enabled = currentActive != null) {
                                    currentActive?.let { selectedCategoryForDetail = it }
                                },
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                            border = BorderStroke(1.5.dp, currentActive?.color?.safeAlpha(0.6f) ?: Color.Transparent)
                        ) {
                            if (currentActive != null) {
                                val activePct = if (safeTotal > 0.0) ((currentActive.value / safeTotal) * 100.0) else 0.0
                                val safeActivePct = if (activePct.isFinite() && activePct >= 0.0) activePct else 0.0
                                val activePctText = if (safeActivePct >= 1.0) "${safeActivePct.toInt()}%" else String.format(Locale.US, "%.1f%%", safeActivePct)
                                Column(
                                    modifier = Modifier
                                        .fillMaxSize()
                                        .padding(6.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(28.dp)
                                            .clip(CircleShape)
                                            .background(currentActive.color.safeAlpha(0.2f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CategoryIconDisplay(
                                            iconKey = currentActive.iconKey,
                                            customIconUri = currentActive.customIconUri,
                                            categoryName = currentActive.name,
                                            categoryId = currentActive.id,
                                            tint = currentActive.color,
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                    Spacer(Modifier.height(2.dp))
                                    Text(
                                        text = currentActive.name,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        textAlign = TextAlign.Center,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = activePctText,
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif,
                                        color = currentActive.color
                                    )
                                }
                            } else {
                                Box(
                                    modifier = Modifier.fillMaxSize(),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = if (analyticsType == "EXPENSE") Icons.Default.ShoppingCart else Icons.Default.TrendingUp,
                                        contentDescription = null,
                                        tint = if (analyticsType == "EXPENSE") Color(0xFFD32F2F).copy(alpha = 0.7f) else Color(0xFF2E7D32).copy(alpha = 0.7f),
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    // Общая сумма трат за месяц под диаграммой
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "${mask(safeTotal, isIncognito)} ₽",
                            fontSize = 24.sp,
                            fontWeight = FontWeight.Light,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif,
                            letterSpacing = 0.8.sp,
                            color = if (analyticsType == "EXPENSE") Color(0xFFD32F2F) else Color(0xFF2E7D32)
                        )
                        Text(
                            text = if (analyticsType == "EXPENSE") "Всего расходов за $monthTitle" else "Всего доходов за $monthTitle",
                            fontSize = 11.sp,
                            color = Color.Gray
                        )
                    }

                    Spacer(Modifier.height(16.dp))

                    // Список категорий с суммами, иконками и процентами (по клику — выбор активного и открытие трат)
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        sortedSegments.forEach { s ->
                            val pct = if (safeTotal > 0.0) ((s.value / safeTotal) * 100.0).toInt() else 0
                            val isSelected = currentActive?.id == s.id
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable {
                                        activeSegment = s
                                        selectedCategoryForDetail = s
                                    },
                                color = if (isSelected) s.color.safeAlpha(0.12f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                border = if (isSelected) BorderStroke(1.dp, s.color.safeAlpha(0.6f)) else null,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(s.color.safeAlpha(0.18f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        CategoryIconDisplay(
                                            iconKey = s.iconKey,
                                            customIconUri = s.customIconUri,
                                            categoryName = s.name,
                                            categoryId = s.id,
                                            tint = s.color,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    Column(Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(s.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Spacer(Modifier.width(6.dp))
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = s.color.safeAlpha(0.15f)
                                            ) {
                                                Text(
                                                    "$pct%",
                                                    fontSize = 10.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    color = s.color,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                        Text(
                                            if (analyticsType == "EXPENSE") "Траты за месяц" else "Поступления",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                    Text(
                                        text = "${if (analyticsType == "EXPENSE") "-" else "+"}${mask(s.value, isIncognito)} ₽",
                                        fontWeight = FontWeight.Light,
                                        fontFamily = androidx.compose.ui.text.font.FontFamily.SansSerif,
                                        letterSpacing = 0.8.sp,
                                        fontSize = 13.sp,
                                        color = if (analyticsType == "EXPENSE") Color(0xFFD32F2F) else Color(0xFF2E7D32)
                                    )
                                    Spacer(Modifier.width(4.dp))
                                    Icon(
                                        Icons.Default.ChevronRight,
                                        contentDescription = null,
                                        tint = Color.Gray,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        val hasCarAnalytics = remember { try { false } catch (_: Exception) { false } }
        if (hasCarAnalytics) {
            val aCars = remember { try { emptyList<CarItem>() } catch (_: Exception) { emptyList<CarItem>() } }
            val aLogs = remember { try { emptyList<CarMileageItem>() } catch (_: Exception) { emptyList<CarMileageItem>() } }
            if (aCars.isNotEmpty()) {
                Spacer(Modifier.height(16.dp))
                CarMileageChartCard(cars = aCars, logs = aLogs, selectedMonth = selectedMonth)
            }
        }

        Divider(Modifier.padding(vertical = 24.dp))
        Text("НАСТРОЕНИЕ", fontWeight = FontWeight.Bold)
        val moodCounts = filteredNotes.filter { (it.mood ?: "").isNotEmpty() }.groupingBy { it.mood }.eachCount()
        val totalMood = moodCounts.values.sum().toFloat()
        if(totalMood == 0f) {
            Box(Modifier.fillMaxWidth().height(100.dp), Alignment.Center) { Text("Нет данных о настроении", color = Color.Gray) }
        } else {
            listOf("🤩", "😊", "😐", "😔", "😡").forEach { m ->
                val c = moodCounts[m] ?: 0
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                    Text(m, Modifier.width(32.dp), fontSize = 20.sp)
                    LinearProgressIndicator(progress = { if(totalMood > 0) c/totalMood else 0f }, modifier = Modifier.weight(1f).height(8.dp).clip(CircleShape))
                    Text(" $c", Modifier.width(32.dp), textAlign = TextAlign.End, fontSize = 12.sp)
                }
            }
        }
    }

    // МОДАЛЬНОЕ ОКНО СО СПИСКОМ ВСЕХ ТРАТ / ДОХОДОВ РАЗДЕЛА В ЭТОМ МЕСЯЦЕ И В КАКИХ ЧИСЛАХ
    if (selectedCategoryForDetail != null) {
        val cat = selectedCategoryForDetail!!
        val isIncomeCategory = cat.id == "inc" || categories.find { it.id == cat.id }?.type == CatType.INCOME
        val typeToken = object : TypeToken<List<FinanceItem>>() {}.type
        val expenseList = mutableListOf<CategoryExpenseDetail>()

        filteredFinances.forEach { fin ->
            if (cat.id == "exp") {
                val items = try { Gson().fromJson<List<FinanceItem>>(fin.expHistory ?: "[]", typeToken) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
                items.forEach { expenseList.add(CategoryExpenseDetail(fin.date, it.amount, it.note)) }
            } else if (cat.id == "inc") {
                val items = try { Gson().fromJson<List<FinanceItem>>(fin.incHistory ?: "[]", typeToken) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
                items.forEach { expenseList.add(CategoryExpenseDetail(fin.date, it.amount, it.note)) }
            } else {
                val map = try { Gson().fromJson<Map<String, String>>(fin.dynamicData ?: "{}", object : TypeToken<Map<String, String>>() {}.type) ?: emptyMap() } catch(e: Exception) { emptyMap() }
                val items = try { Gson().fromJson<List<FinanceItem>>(map[cat.id] ?: "[]", typeToken) ?: emptyList() } catch(e: Exception) { emptyList<FinanceItem>() }
                items.forEach { expenseList.add(CategoryExpenseDetail(fin.date, it.amount, it.note)) }
            }
        }
        // Сортировка по дате (от ранних к поздним)
        expenseList.sortBy { it.date }

        AlertDialog(
            onDismissRequest = { selectedCategoryForDetail = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(14.dp).clip(CircleShape).background(cat.color))
                    Spacer(Modifier.width(8.dp))
                    Text("${cat.name}: ${if (isIncomeCategory) "список поступлений" else "список трат"}")
                }
            },
            text = {
                Column(Modifier.fillMaxWidth().heightIn(max = 400.dp)) {
                    Text(
                        "Всего за месяц: ${if (isIncomeCategory) "+" else "-"}${mask(cat.value, isIncognito)}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 13.sp,
                        color = if (isIncomeCategory) Color(0xFF2E7D32) else cat.color,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                    Divider()
                    if (expenseList.isEmpty()) {
                        Text("Нет записей", modifier = Modifier.padding(16.dp), color = Color.Gray)
                    } else {
                        LazyColumn(Modifier.weight(1f, fill = false)) {
                            items(expenseList) { item ->
                                val dayStr = SimpleDateFormat("d MMMM (EE)", Locale("ru")).format(Date(item.date))
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(Modifier.weight(1f)) {
                                        Text(dayStr, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = MaterialTheme.colorScheme.primary)
                                        Text(if (item.note.isBlank()) "Без описания" else item.note, fontSize = 11.sp, color = Color.DarkGray)
                                    }
                                    Text(
                                        "${if (isIncomeCategory) "+" else "-"}${mask(item.amount, isIncognito)}",
                                        fontWeight = FontWeight.Normal,
                                        fontSize = 13.sp,
                                        color = if (isIncomeCategory) Color(0xFF2E7D32) else Color(0xFFD32F2F)
                                    )
                                }
                                Divider(color = Color.LightGray.copy(alpha = 0.4f))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(onClick = { selectedCategoryForDetail = null }) { Text("Закрыть") }
            }
        )
    }
}

