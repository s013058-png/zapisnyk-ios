package com.my.zapisnyk

import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.ImageBitmap
import platform.Foundation.NSDate
import platform.Foundation.NSDocumentDirectory
import platform.Foundation.NSSearchPathForDirectoriesInDomains
import platform.Foundation.NSUserDefaults
import platform.Foundation.NSUserDomainMask
import platform.Foundation.timeIntervalSince1970
import platform.UIKit.UIActivityViewController
import platform.UIKit.UIApplication
import platform.UIKit.UIDevice

class IOSPlatform : Platform {
    override val name: String = UIDevice.currentDevice.systemName() + " " + UIDevice.currentDevice.systemVersion
}

actual fun getPlatform(): Platform {
    PlatformNative.bridge = IosNativeBridge
    return IOSPlatform()
}

// =========================================================================
// iOS SHARED PREFERENCES (Backed by NSUserDefaults — Persistent on iPhone)
// =========================================================================
class IosSharedPreferences(private val suiteName: String) : SharedPreferences {
    private val defaults: NSUserDefaults = NSUserDefaults.standardUserDefaults

    private fun keyFor(key: String): String = "${suiteName}__$key"

    override fun getString(key: String, defValue: String?): String? {
        val k = keyFor(key)
        if (defaults.objectForKey(k) == null) return defValue
        return defaults.stringForKey(k) ?: defValue
    }

    override fun getFloat(key: String, defValue: Float): Float {
        val k = keyFor(key)
        if (defaults.objectForKey(k) == null) return defValue
        return defaults.floatForKey(k)
    }

    override fun getLong(key: String, defValue: Long): Long {
        val k = keyFor(key)
        if (defaults.objectForKey(k) == null) return defValue
        return defaults.integerForKey(k)
    }

    override fun getInt(key: String, defValue: Int): Int {
        val k = keyFor(key)
        if (defaults.objectForKey(k) == null) return defValue
        return defaults.integerForKey(k).toInt()
    }

    override fun getBoolean(key: String, defValue: Boolean): Boolean {
        val k = keyFor(key)
        if (defaults.objectForKey(k) == null) return defValue
        return defaults.boolForKey(k)
    }

    override fun getStringSet(key: String, defValues: Set<String>?): Set<String>? {
        val k = keyFor(key)
        val raw = defaults.stringForKey(k) ?: return defValues
        if (raw.isEmpty()) return emptySet()
        return raw.split("\u001F").toSet()
    }

    override fun contains(key: String): Boolean {
        return defaults.objectForKey(keyFor(key)) != null
    }

    override val all: Map<String, Any?>
        get() {
            val prefix = "${suiteName}__"
            val dict = defaults.dictionaryRepresentation()
            val result = mutableMapOf<String, Any?>()
            for ((rawKey, value) in dict) {
                val kStr = rawKey as? String ?: continue
                if (kStr.startsWith(prefix)) {
                    result[kStr.removePrefix(prefix)] = value
                }
            }
            return result
        }

    override fun edit(): SharedPreferences.Editor = object : SharedPreferences.Editor {
        private val staged = mutableMapOf<String, Any?>()
        private val removed = mutableSetOf<String>()
        private var clearRequested = false

        override fun putString(key: String, value: String?): SharedPreferences.Editor {
            staged[key] = value
            return this
        }

        override fun putFloat(key: String, value: Float): SharedPreferences.Editor {
            staged[key] = value
            return this
        }

        override fun putLong(key: String, value: Long): SharedPreferences.Editor {
            staged[key] = value
            return this
        }

        override fun putInt(key: String, value: Int): SharedPreferences.Editor {
            staged[key] = value
            return this
        }

        override fun putBoolean(key: String, value: Boolean): SharedPreferences.Editor {
            staged[key] = value
            return this
        }

        override fun putStringSet(key: String, values: Set<String>?): SharedPreferences.Editor {
            staged[key] = values?.joinToString("\u001F")
            return this
        }

        override fun remove(key: String): SharedPreferences.Editor {
            removed.add(key)
            return this
        }

        override fun clear(): SharedPreferences.Editor {
            clearRequested = true
            return this
        }

        override fun apply() {
            commit()
        }

        override fun commit(): Boolean {
            val prefix = "${suiteName}__"
            if (clearRequested) {
                val dict = defaults.dictionaryRepresentation()
                for (rawKey in dict.keys) {
                    val kStr = rawKey as? String ?: continue
                    if (kStr.startsWith(prefix)) {
                        defaults.removeObjectForKey(kStr)
                    }
                }
            }
            for (r in removed) {
                defaults.removeObjectForKey(keyFor(r))
            }
            for ((k, v) in staged) {
                val fullKey = keyFor(k)
                when (v) {
                    null -> defaults.removeObjectForKey(fullKey)
                    is String -> defaults.setObject(v, forKey = fullKey)
                    is Float -> defaults.setFloat(v, forKey = fullKey)
                    is Long -> defaults.setInteger(v, forKey = fullKey)
                    is Int -> defaults.setInteger(v.toLong(), forKey = fullKey)
                    is Boolean -> defaults.setBool(v, forKey = fullKey)
                    else -> defaults.setObject(v.toString(), forKey = fullKey)
                }
            }
            defaults.synchronize()
            return true
        }
    }
}

// =========================================================================
// iOS NATIVE BRIDGE IMPLEMENTATION
// =========================================================================
object IosNativeBridge : PlatformNativeBridge {
    private val prefsCache = mutableMapOf<String, IosSharedPreferences>()

    override fun currentTimeMillis(): Long {
        return (NSDate().timeIntervalSince1970 * 1000.0).toLong()
    }

    override fun getFilesDirPath(): String {
        val paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, true)
        return (paths.firstOrNull() as? String) ?: "/Documents"
    }

    override fun getSharedPreferences(name: String): SharedPreferences {
        return prefsCache.getOrPut(name) { IosSharedPreferences(name) }
    }

    override fun getUriMimeType(uriString: String): String? {
        return when {
            uriString.endsWith(".zip", ignoreCase = true) -> "application/zip"
            uriString.endsWith(".json", ignoreCase = true) -> "application/json"
            uriString.endsWith(".csv", ignoreCase = true) -> "text/csv"
            uriString.endsWith(".mp4", ignoreCase = true) || uriString.endsWith(".mov", ignoreCase = true) -> "video/mp4"
            else -> "image/jpeg"
        }
    }

    override fun openUriInputStream(uriString: String): InputStream? {
        val bytes = PlatformVirtualFs.getBytes(uriString) ?: return null
        return MemoryInputStream(bytes)
    }

    override fun openUriOutputStream(uriString: String): OutputStream? {
        return MemoryOutputStream(uriString)
    }

    override fun fileExists(path: String): Boolean = PlatformVirtualFs.exists(path)
    override fun fileCanRead(path: String): Boolean = PlatformVirtualFs.exists(path)
    override fun fileIsFile(path: String): Boolean = PlatformVirtualFs.exists(path)
    override fun fileIsDirectory(path: String): Boolean = false
    override fun fileMkdirs(path: String): Boolean = true
    override fun fileDelete(path: String): Boolean = PlatformVirtualFs.delete(path)
    override fun fileLength(path: String): Long = PlatformVirtualFs.getBytes(path)?.size?.toLong() ?: 0L
    override fun fileListFiles(path: String): Array<File>? = emptyArray()

    override fun openFileInputStream(path: String): InputStream? {
        val bytes = PlatformVirtualFs.getBytes(path) ?: return null
        return MemoryInputStream(bytes)
    }

    override fun openFileOutputStream(path: String): OutputStream? {
        return MemoryOutputStream(path)
    }

    override fun createZipInputStream(inner: InputStream): ZipInputStreamDelegate? = null
    override fun createZipOutputStream(inner: OutputStream): ZipOutputStreamDelegate? = null
    override fun decodeBitmapStream(stream: InputStream): ImageBitmap? = null
    override fun decodeBitmapFile(path: String): ImageBitmap? = null
    override suspend fun loadThumbnail(path: String): ImageBitmap? = null
    override fun openMedia(path: String): Boolean = false

    override fun showToast(text: String, longDuration: Boolean) {
        PlatformDialogController.activeToastMessage = text
        PlatformDialogController.activeToastSeq++
    }

    override fun startActivityIntent(intent: Intent): Boolean {
        val text = intent.getStringExtra(Intent.EXTRA_TEXT)
        if (!text.isNullOrBlank()) {
            try {
                val rootVc = UIApplication.sharedApplication.keyWindow?.rootViewController
                if (rootVc != null) {
                    val activityVc = UIActivityViewController(
                        activityItems = listOf(text),
                        applicationActivities = null
                    )
                    rootVc.presentViewController(activityVc, animated = true, completion = null)
                    return true
                }
            } catch (_: Throwable) {}
        }
        return false
    }

    override fun launchCreateDocument(mimeType: String, suggestedName: String, onResult: (Uri?) -> Unit): Boolean = false
    override fun launchOpenDocument(mimeTypes: Array<String>, onResult: (Uri?) -> Unit): Boolean = false
    override fun launchGetContent(mimeType: String, onResult: (Uri?) -> Unit): Boolean = false
    override fun launchPickMultipleMedia(onResult: (List<Uri>) -> Unit): Boolean = false
    override fun readLegacyRoomDatabase(): BackupData? = null

    @Composable
    override fun BindContext() {
        PlatformNative.bridge = this
    }
}
