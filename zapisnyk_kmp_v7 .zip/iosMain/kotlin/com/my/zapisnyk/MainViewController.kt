package com.my.zapisnyk

import androidx.compose.ui.window.ComposeUIViewController

fun MainViewController() = ComposeUIViewController {
    PlatformNative.bridge = IosNativeBridge
    App()
}
