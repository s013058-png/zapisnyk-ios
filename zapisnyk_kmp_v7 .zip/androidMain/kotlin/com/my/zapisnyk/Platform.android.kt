package com.my.zapisnyk

import android.app.Activity as AndroidActivity
import android.app.Application as AndroidApplication
import android.app.Fragment as AndroidFragment
import android.content.ClipData as AndroidClipData
import android.content.ClipboardManager as AndroidClipboardManager
import android.content.ContentUris as AndroidContentUris
import android.content.Context as AndroidContext
import android.content.ContextWrapper as AndroidContextWrapper
import android.content.Intent as AndroidIntent
import android.content.SharedPreferences as AndroidSharedPreferences
import android.database.Cursor as AndroidCursor
import android.database.sqlite.SQLiteDatabase as AndroidSQLiteDatabase
import android.graphics.BitmapFactory as AndroidBitmapFactory
import android.media.MediaMetadataRetriever as AndroidMediaMetadataRetriever
import android.media.ThumbnailUtils as AndroidThumbnailUtils
import android.net.Uri as AndroidUri
import android.os.Build as AndroidBuild
import android.os.Bundle as AndroidBundle
import android.os.Handler as AndroidHandler
import android.os.Looper as AndroidLooper
import android.provider.DocumentsContract as AndroidDocumentsContract
import android.provider.MediaStore as AndroidMediaStore
import android.util.Size as AndroidSize
import android.webkit.MimeTypeMap as AndroidMimeTypeMap
import android.widget.Toast as AndroidToast
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext as ComposeLocalContext
import java.io.ByteArrayOutputStream as JavaByteArrayOutputStream
import java.io.File as JavaFile
import java.io.FileInputStream as JavaFileInputStream
import java.io.FileOutputStream as JavaFileOutputStream
import java.io.InputStream as JavaInputStream
import java.io.OutputStream as JavaOutputStream
import java.util.zip.ZipEntry as JavaZipEntry
import java.util.zip.ZipInputStream as JavaZipInputStream
import java.util.zip.ZipOutputStream as JavaZipOutputStream

class AndroidPlatform : Platform {
    override val name: String = "Android ${AndroidBuild.VERSION.SDK_INT}"
}

actual fun getPlatform(): Platform {
    PlatformNative.bridge = AndroidNativeBridge
    return AndroidPlatform()
}

// =========================================================================
// HEADLESS FRAGMENT FOR SYSTEM FILE PICKER / ACTIVITY RESULTS
// Uses standard android.app.Activity + android.app.Fragment (zero extra Gradle dependencies)
// =========================================================================
@Suppress("DEPRECATION")
class ZapisnykResultFragment : AndroidFragment() {
    private val callbacks = mutableMapOf<Int, (Int, AndroidIntent?) -> Unit>()
    private val pendingQueue = mutableListOf<Triple<AndroidIntent, Int, (Int, AndroidIntent?) -> Unit>>()
    private var nextRequestCode = 42001

    override fun onCreate(savedInstanceState: AndroidBundle?) {
        super.onCreate(savedInstanceState)
        retainInstance = true
        flushPending()
    }

    override fun onAttach(context: AndroidContext?) {
        super.onAttach(context)
        flushPending()
    }

    @Deprecated("Deprecated in Java")
    override fun onAttach(activity: AndroidActivity?) {
        super.onAttach(activity)
        flushPending()
    }

    private fun flushPending() {
        if (activity == null || pendingQueue.isEmpty()) return
        val copy = ArrayList(pendingQueue)
        pendingQueue.clear()
        for ((intent, reqCode, cb) in copy) {
            try {
                callbacks[reqCode] = cb
                startActivityForResult(intent, reqCode)
            } catch (_: Throwable) {
                callbacks.remove(reqCode)
                cb(AndroidActivity.RESULT_CANCELED, null)
            }
        }
    }

    fun launch(intent: AndroidIntent, callback: (Int, AndroidIntent?) -> Unit) {
        val reqCode = nextRequestCode++
        if (nextRequestCode > 49999) nextRequestCode = 42001
        if (activity != null && isAdded) {
            try {
                callbacks[reqCode] = callback
                startActivityForResult(intent, reqCode)
            } catch (_: Throwable) {
                callbacks.remove(reqCode)
                callback(AndroidActivity.RESULT_CANCELED, null)
            }
        } else {
            pendingQueue.add(Triple(intent, reqCode, callback))
        }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: AndroidIntent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val cb = callbacks.remove(requestCode)
        cb?.invoke(resultCode, data)
    }
}

// =========================================================================
// ANDROID NATIVE BRIDGE (Implements PlatformNativeBridge from PlatformBridge.kt)
// =========================================================================
object AndroidNativeBridge : PlatformNativeBridge {
    init {
        PlatformNative.bridge = this
    }

    @Volatile
    var appContext: AndroidContext? = null

    @Volatile
    var currentActivity: AndroidActivity? = null

    private var lifecycleRegistered = false
    private var initialReloadTriggered = false

    fun updateContext(ctx: AndroidContext) {
        val wasNull = (appContext == null)
        val app = ctx.applicationContext ?: ctx
        if (appContext == null) {
            appContext = app
        }
        if (!lifecycleRegistered && app is AndroidApplication) {
            lifecycleRegistered = true
            app.registerActivityLifecycleCallbacks(object : AndroidApplication.ActivityLifecycleCallbacks {
                override fun onActivityCreated(activity: AndroidActivity, savedInstanceState: AndroidBundle?) {
                    currentActivity = activity
                    ensureResultFragment(activity)
                }
                override fun onActivityStarted(activity: AndroidActivity) {
                    currentActivity = activity
                }
                override fun onActivityResumed(activity: AndroidActivity) {
                    currentActivity = activity
                    ensureResultFragment(activity)
                }
                override fun onActivityPaused(activity: AndroidActivity) {}
                override fun onActivityStopped(activity: AndroidActivity) {}
                override fun onActivitySaveInstanceState(activity: AndroidActivity, outState: AndroidBundle) {}
                override fun onActivityDestroyed(activity: AndroidActivity) {
                    if (currentActivity === activity) {
                        currentActivity = null
                    }
                }
            })
        }
        val act = findActivity(ctx)
        if (act != null && currentActivity !== act) {
            currentActivity = act
            ensureResultFragment(act)
        }
        if (wasNull && !initialReloadTriggered) {
            initialReloadTriggered = true
            try {
                InMemoryDiaryDaoInstance.reloadFromStorage()
            } catch (_: Throwable) {}
        }
    }

    private fun findActivity(ctx: AndroidContext?): AndroidActivity? {
        var c = ctx
        while (c is AndroidContextWrapper) {
            if (c is AndroidActivity) return c
            c = c.baseContext
        }
        return null
    }

    @Suppress("DEPRECATION")
    private fun ensureResultFragment(act: AndroidActivity): ZapisnykResultFragment? {
        return try {
            val fm = act.fragmentManager
            var frag = fm.findFragmentByTag("ZapisnykResultFragment") as? ZapisnykResultFragment
            if (frag == null) {
                frag = ZapisnykResultFragment()
                fm.beginTransaction().add(frag, "ZapisnykResultFragment").commitAllowingStateLoss()
                fm.executePendingTransactions()
            }
            frag
        } catch (_: Throwable) {
            null
        }
    }

    @Composable
    override fun BindContext() {
        val ctx = ComposeLocalContext.current
        updateContext(ctx)
        if (PlatformNative.bridge !== this) {
            PlatformNative.bridge = this
        }
    }

    override fun currentTimeMillis(): Long = java.lang.System.currentTimeMillis()

    override fun getFilesDirPath(): String {
        val ctx = appContext ?: return "/data/user/0/com.my.zapisnyk/files"
        return ctx.filesDir.absolutePath
    }

    override fun getSharedPreferences(name: String): SharedPreferences? {
        val ctx = appContext ?: return null
        val sp: AndroidSharedPreferences = ctx.getSharedPreferences(name, AndroidContext.MODE_PRIVATE)
        return object : SharedPreferences {
            override fun getString(key: String, defValue: String?): String? =
                try { sp.getString(key, defValue) } catch (_: Throwable) { defValue }

            override fun getFloat(key: String, defValue: Float): Float =
                try { sp.getFloat(key, defValue) } catch (_: Throwable) { defValue }

            override fun getLong(key: String, defValue: Long): Long =
                try { sp.getLong(key, defValue) } catch (_: Throwable) { defValue }

            override fun getInt(key: String, defValue: Int): Int =
                try { sp.getInt(key, defValue) } catch (_: Throwable) { defValue }

            override fun getBoolean(key: String, defValue: Boolean): Boolean =
                try { sp.getBoolean(key, defValue) } catch (_: Throwable) { defValue }

            override fun getStringSet(key: String, defValues: Set<String>?): Set<String>? =
                try { sp.getStringSet(key, defValues)?.toSet() } catch (_: Throwable) { defValues }

            override fun contains(key: String): Boolean =
                try { sp.contains(key) } catch (_: Throwable) { false }

            override val all: Map<String, Any?>
                get() = try {
                    val raw = sp.all ?: emptyMap<String, Any?>()
                    val map = LinkedHashMap<String, Any?>()
                    for ((k, v) in raw) {
                        if (k != null) map[k] = v
                    }
                    map
                } catch (_: Throwable) {
                    emptyMap()
                }

            override fun edit(): SharedPreferences.Editor {
                val ed = sp.edit()
                return object : SharedPreferences.Editor {
                    override fun putString(key: String, value: String?): SharedPreferences.Editor {
                        ed.putString(key, value)
                        return this
                    }
                    override fun putFloat(key: String, value: Float): SharedPreferences.Editor {
                        ed.putFloat(key, value)
                        return this
                    }
                    override fun putLong(key: String, value: Long): SharedPreferences.Editor {
                        ed.putLong(key, value)
                        return this
                    }
                    override fun putInt(key: String, value: Int): SharedPreferences.Editor {
                        ed.putInt(key, value)
                        return this
                    }
                    override fun putBoolean(key: String, value: Boolean): SharedPreferences.Editor {
                        ed.putBoolean(key, value)
                        return this
                    }
                    override fun putStringSet(key: String, values: Set<String>?): SharedPreferences.Editor {
                        ed.putStringSet(key, values)
                        return this
                    }
                    override fun remove(key: String): SharedPreferences.Editor {
                        ed.remove(key)
                        return this
                    }
                    override fun clear(): SharedPreferences.Editor {
                        ed.clear()
                        return this
                    }
                    override fun apply() {
                        ed.apply()
                    }
                    override fun commit(): Boolean = ed.commit()
                }
            }
        }
    }

    // =========================================================================
    // STREAM WRAPPERS & URI / FILE I/O
    // =========================================================================
    private fun wrapJavaInputStream(javaIn: JavaInputStream): InputStream {
        return object : InputStream() {
            override fun read(): Int = javaIn.read()
            override fun read(b: ByteArray): Int = javaIn.read(b)
            override fun read(b: ByteArray, off: Int, len: Int): Int = javaIn.read(b, off, len)
            override fun readAllBytes(): ByteArray {
                val out = JavaByteArrayOutputStream()
                val buf = ByteArray(8192)
                var n: Int
                while (javaIn.read(buf).also { n = it } > 0) {
                    out.write(buf, 0, n)
                }
                return out.toByteArray()
            }
            override fun close() {
                try { javaIn.close() } catch (_: Throwable) {}
            }
        }
    }

    private fun wrapJavaOutputStream(javaOut: JavaOutputStream): OutputStream {
        return object : OutputStream() {
            override fun write(b: Int) = javaOut.write(b)
            override fun write(b: ByteArray) = javaOut.write(b)
            override fun write(b: ByteArray, off: Int, len: Int) = javaOut.write(b, off, len)
            override fun flush() {
                try { javaOut.flush() } catch (_: Throwable) {}
            }
            override fun close() {
                try { javaOut.flush() } catch (_: Throwable) {}
                try { javaOut.close() } catch (_: Throwable) {}
            }
        }
    }

    override fun getUriMimeType(uriString: String): String? {
        val ctx = appContext ?: return null
        return try {
            if (uriString.startsWith("content://")) {
                ctx.contentResolver.getType(AndroidUri.parse(uriString))
            } else {
                val ext = uriString.substringAfterLast('.', "").lowercase()
                if (ext.isNotBlank()) AndroidMimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) else null
            }
        } catch (_: Throwable) {
            null
        }
    }

    override fun openUriInputStream(uriString: String): InputStream? {
        val ctx = appContext
        return try {
            when {
                uriString.startsWith("content://") && ctx != null -> {
                    val s = ctx.contentResolver.openInputStream(AndroidUri.parse(uriString)) ?: return null
                    wrapJavaInputStream(s)
                }
                uriString.startsWith("file://") -> {
                    val f = JavaFile(uriString.removePrefix("file://"))
                    if (f.exists() && f.isFile) wrapJavaInputStream(JavaFileInputStream(f)) else null
                }
                else -> {
                    val f = JavaFile(uriString)
                    if (f.exists() && f.isFile) {
                        wrapJavaInputStream(JavaFileInputStream(f))
                    } else if (ctx != null) {
                        val s = ctx.contentResolver.openInputStream(AndroidUri.parse(uriString)) ?: return null
                        wrapJavaInputStream(s)
                    } else null
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    override fun openUriOutputStream(uriString: String): OutputStream? {
        val ctx = appContext
        return try {
            when {
                uriString.startsWith("content://") && ctx != null -> {
                    val uri = AndroidUri.parse(uriString)
                    val s = try {
                        ctx.contentResolver.openOutputStream(uri, "wt")
                    } catch (_: Throwable) {
                        null
                    } ?: ctx.contentResolver.openOutputStream(uri) ?: return null
                    wrapJavaOutputStream(s)
                }
                uriString.startsWith("file://") -> {
                    val f = JavaFile(uriString.removePrefix("file://"))
                    f.parentFile?.mkdirs()
                    wrapJavaOutputStream(JavaFileOutputStream(f))
                }
                else -> {
                    val f = JavaFile(uriString)
                    f.parentFile?.mkdirs()
                    wrapJavaOutputStream(JavaFileOutputStream(f))
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    override fun fileExists(path: String): Boolean = try { JavaFile(path).exists() } catch (_: Throwable) { false }
    override fun fileCanRead(path: String): Boolean = try { JavaFile(path).canRead() } catch (_: Throwable) { false }
    override fun fileIsFile(path: String): Boolean = try { JavaFile(path).isFile } catch (_: Throwable) { false }
    override fun fileIsDirectory(path: String): Boolean = try { JavaFile(path).isDirectory } catch (_: Throwable) { false }
    override fun fileMkdirs(path: String): Boolean = try { JavaFile(path).mkdirs() } catch (_: Throwable) { false }
    override fun fileDelete(path: String): Boolean = try { JavaFile(path).delete() } catch (_: Throwable) { false }
    override fun fileLength(path: String): Long = try { JavaFile(path).length() } catch (_: Throwable) { 0L }

    override fun fileListFiles(path: String): Array<File>? {
        return try {
            val arr = JavaFile(path).listFiles() ?: return emptyArray()
            Array(arr.size) { i -> File(arr[i].absolutePath) }
        } catch (_: Throwable) {
            emptyArray()
        }
    }

    override fun openFileInputStream(path: String): InputStream? {
        return try {
            val clean = path.removePrefix("file://")
            val f = JavaFile(clean)
            if (!f.exists() || !f.isFile) return null
            wrapJavaInputStream(JavaFileInputStream(f))
        } catch (_: Throwable) {
            null
        }
    }

    override fun openFileOutputStream(path: String): OutputStream? {
        return try {
            val clean = path.removePrefix("file://")
            val f = JavaFile(clean)
            f.parentFile?.mkdirs()
            wrapJavaOutputStream(JavaFileOutputStream(f))
        } catch (_: Throwable) {
            null
        }
    }

    // =========================================================================
    // REAL JAVA ZIP INPUT / OUTPUT STREAM DELEGATES
    // =========================================================================
    override fun createZipInputStream(inner: InputStream): ZipInputStreamDelegate? {
        return try {
            val javaIn = object : JavaInputStream() {
                override fun read(): Int = inner.read()
                override fun read(b: ByteArray, off: Int, len: Int): Int = inner.read(b, off, len)
                override fun close() = inner.close()
            }
            val zis = JavaZipInputStream(javaIn)
            object : ZipInputStreamDelegate {
                override fun nextEntryName(): String? {
                    return try {
                        zis.nextEntry?.name
                    } catch (_: Throwable) {
                        null
                    }
                }
                override fun read(b: ByteArray, off: Int, len: Int): Int {
                    return try {
                        zis.read(b, off, len)
                    } catch (_: Throwable) {
                        -1
                    }
                }
                override fun closeEntry() {
                    try { zis.closeEntry() } catch (_: Throwable) {}
                }
                override fun close() {
                    try { zis.close() } catch (_: Throwable) {}
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    override fun createZipOutputStream(inner: OutputStream): ZipOutputStreamDelegate? {
        return try {
            val buffer = JavaByteArrayOutputStream()
            val zos = JavaZipOutputStream(buffer)
            object : ZipOutputStreamDelegate {
                private var finished = false
                private var closed = false

                override fun putNextEntry(name: String) {
                    zos.putNextEntry(JavaZipEntry(name))
                }
                override fun write(b: ByteArray, off: Int, len: Int) {
                    if (len > 0) {
                        zos.write(b, off, len)
                    }
                }
                override fun closeEntry() {
                    try { zos.closeEntry() } catch (_: Throwable) {}
                }
                override fun finish() {
                    if (!finished) {
                        finished = true
                        try { zos.finish() } catch (_: Throwable) {}
                        try { zos.flush() } catch (_: Throwable) {}
                        val zipBytes = buffer.toByteArray()
                        if (zipBytes.isNotEmpty()) {
                            inner.write(zipBytes, 0, zipBytes.size)
                            inner.flush()
                        }
                    }
                }
                override fun flush() {
                    try { zos.flush() } catch (_: Throwable) {}
                    try { inner.flush() } catch (_: Throwable) {}
                }
                override fun close() {
                    if (!closed) {
                        closed = true
                        try { finish() } catch (_: Throwable) {}
                        try { zos.close() } catch (_: Throwable) {}
                        try { inner.close() } catch (_: Throwable) {}
                    }
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    // =========================================================================
    // BITMAP & THUMBNAIL DECODING
    // =========================================================================
    private fun decodeBytesSampled(bytes: ByteArray, maxDim: Int = 2048): ImageBitmap? {
        if (bytes.isEmpty()) return null
        return try {
            val boundsOpts = AndroidBitmapFactory.Options().apply { inJustDecodeBounds = true }
            AndroidBitmapFactory.decodeByteArray(bytes, 0, bytes.size, boundsOpts)
            var sampleSize = 1
            if (boundsOpts.outHeight > maxDim || boundsOpts.outWidth > maxDim) {
                val halfH = boundsOpts.outHeight / 2
                val halfW = boundsOpts.outWidth / 2
                while ((halfH / sampleSize) >= maxDim && (halfW / sampleSize) >= maxDim) {
                    sampleSize *= 2
                }
            }
            val decodeOpts = AndroidBitmapFactory.Options().apply { inSampleSize = sampleSize }
            AndroidBitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOpts)?.asImageBitmap()
        } catch (_: Throwable) {
            null
        }
    }

    override fun decodeBitmapStream(stream: InputStream): ImageBitmap? {
        return try {
            val bytes = stream.readAllBytes()
            decodeBytesSampled(bytes)
        } catch (_: Throwable) {
            null
        }
    }

    private fun readFileBytesFast(cleanPath: String): ByteArray? {
        val f = JavaFile(cleanPath)
        if (!f.exists() || !f.isFile) return null
        val fis = JavaFileInputStream(f)
        return try {
            val out = JavaByteArrayOutputStream()
            val buf = ByteArray(8192)
            var n: Int
            while (fis.read(buf).also { n = it } > 0) {
                out.write(buf, 0, n)
            }
            out.toByteArray()
        } catch (_: Throwable) {
            null
        } finally {
            try { fis.close() } catch (_: Throwable) {}
        }
    }

    override fun decodeBitmapFile(path: String): ImageBitmap? {
        return try {
            val clean = path.removePrefix("file://")
            val bytes = readFileBytesFast(clean) ?: return null
            decodeBytesSampled(bytes)
        } catch (_: Throwable) {
            null
        }
    }

    override suspend fun loadThumbnail(path: String): ImageBitmap? {
        val ctx = appContext
        return try {
            val isVid = isVideoPath(path)
            if (path.startsWith("content://") && ctx != null) {
                val uri = AndroidUri.parse(path)
                if (AndroidBuild.VERSION.SDK_INT >= AndroidBuild.VERSION_CODES.Q) {
                    ctx.contentResolver.loadThumbnail(uri, AndroidSize(512, 512), null).asImageBitmap()
                } else {
                    val retriever = AndroidMediaMetadataRetriever()
                    try {
                        retriever.setDataSource(ctx, uri)
                        (retriever.getFrameAtTime(1000000L, AndroidMediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?: retriever.frameAtTime)?.asImageBitmap()
                    } finally {
                        try { retriever.release() } catch (_: Throwable) {}
                    }
                }
            } else {
                val clean = path.removePrefix("file://")
                val f = JavaFile(clean)
                if (!f.exists()) return null
                if (isVid) {
                    val retriever = AndroidMediaMetadataRetriever()
                    try {
                        retriever.setDataSource(clean)
                        (retriever.getFrameAtTime(1000000L, AndroidMediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                            ?: retriever.frameAtTime)?.asImageBitmap()
                    } catch (_: Throwable) {
                        if (AndroidBuild.VERSION.SDK_INT >= AndroidBuild.VERSION_CODES.Q) {
                            AndroidThumbnailUtils.createVideoThumbnail(f, AndroidSize(512, 512), null).asImageBitmap()
                        } else null
                    } finally {
                        try { retriever.release() } catch (_: Throwable) {}
                    }
                } else {
                    val bytes = readFileBytesFast(clean) ?: return null
                    decodeBytesSampled(bytes, maxDim = 512)
                }
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun getFileProviderUri(ctx: AndroidContext, file: JavaFile): AndroidUri {
        return try {
            val clazz = Class.forName("androidx.core.content.FileProvider")
            val method = clazz.getMethod("getUriForFile", AndroidContext::class.java, String::class.java, JavaFile::class.java)
            method.invoke(null, ctx, "${ctx.packageName}.provider", file) as AndroidUri
        } catch (_: Throwable) {
            AndroidUri.fromFile(file)
        }
    }

    override fun openMedia(path: String): Boolean {
        val ctx = currentActivity ?: appContext ?: return false
        return try {
            val viewIntent = if (path.startsWith("http://") || path.startsWith("https://")) {
                AndroidIntent(AndroidIntent.ACTION_VIEW, AndroidUri.parse(path))
            } else if (path.startsWith("content://")) {
                AndroidIntent(AndroidIntent.ACTION_VIEW).apply {
                    val mime = if (isVideoPath(path)) "video/*" else "image/*"
                    setDataAndType(AndroidUri.parse(path), mime)
                    addFlags(AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            } else {
                val clean = path.removePrefix("file://")
                val f = JavaFile(clean)
                if (!f.exists()) return false
                val uri = getFileProviderUri(ctx, f)
                val mime = if (isVideoPath(clean)) "video/*" else "image/*"
                AndroidIntent(AndroidIntent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    addFlags(AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION)
                }
            }
            viewIntent.addFlags(AndroidIntent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(viewIntent)
            true
        } catch (_: Throwable) {
            false
        }
    }

    override fun showToast(text: String, longDuration: Boolean) {
        val ctx = appContext ?: return
        try {
            val dur = if (longDuration) AndroidToast.LENGTH_LONG else AndroidToast.LENGTH_SHORT
            AndroidHandler(AndroidLooper.getMainLooper()).post {
                try {
                    AndroidToast.makeText(ctx, text, dur).show()
                } catch (_: Throwable) {}
            }
        } catch (_: Throwable) {}
    }

    override fun startActivityIntent(intent: Intent): Boolean {
        val ctx = currentActivity ?: appContext ?: return false
        return try {
            val actStr = intent.action.ifBlank { AndroidIntent.ACTION_VIEW }
            val androidIntent = AndroidIntent(actStr)
            val dataStr = intent.dataUri?.toString()
            if (dataStr != null && intent.type != null) {
                val u = if (dataStr.startsWith("file://") || dataStr.startsWith("/")) {
                    getFileProviderUri(ctx, JavaFile(dataStr.removePrefix("file://")))
                } else AndroidUri.parse(dataStr)
                androidIntent.setDataAndType(u, intent.type)
            } else if (dataStr != null) {
                androidIntent.data = AndroidUri.parse(dataStr)
            } else if (intent.type != null) {
                androidIntent.type = intent.type
            }
            androidIntent.addFlags(AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION or AndroidIntent.FLAG_ACTIVITY_NEW_TASK)
            for ((k, v) in intent.extras) {
                when (v) {
                    is String -> androidIntent.putExtra(k, v)
                    is Int -> androidIntent.putExtra(k, v)
                    is Long -> androidIntent.putExtra(k, v)
                    is Boolean -> androidIntent.putExtra(k, v)
                    is Uri -> {
                        val uStr = v.toString()
                        val u = if (uStr.startsWith("file://") || uStr.startsWith("/")) {
                            getFileProviderUri(ctx, JavaFile(uStr.removePrefix("file://")))
                        } else AndroidUri.parse(uStr)
                        androidIntent.putExtra(k, u)
                    }
                }
            }
            val launcher = if (actStr == AndroidIntent.ACTION_SEND) {
                AndroidIntent.createChooser(androidIntent, "").apply {
                    addFlags(AndroidIntent.FLAG_ACTIVITY_NEW_TASK)
                }
            } else {
                androidIntent
            }
            ctx.startActivity(launcher)
            true
        } catch (_: Throwable) {
            false
        }
    }

    // =========================================================================
    // ANDROID SYSTEM FILE PICKER (DocumentsUI Opening at Root of Phone Storage)
    // =========================================================================
    private fun createRootDocumentUri(): AndroidUri? {
        return try {
            AndroidDocumentsContract.buildRootUri("com.android.externalstorage.documents", "primary")
        } catch (_: Throwable) {
            try {
                AndroidUri.parse("content://com.android.externalstorage.documents/root/primary")
            } catch (_: Throwable) {
                null
            }
        }
    }

    private fun launchIntentForResult(androidIntent: AndroidIntent, onResult: (Int, AndroidIntent?) -> Unit): Boolean {
        val act = currentActivity ?: return false
        return try {
            AndroidHandler(AndroidLooper.getMainLooper()).post {
                try {
                    val frag = ensureResultFragment(act)
                    if (frag != null) {
                        frag.launch(androidIntent, onResult)
                    } else {
                        onResult(AndroidActivity.RESULT_CANCELED, null)
                    }
                } catch (_: Throwable) {
                    onResult(AndroidActivity.RESULT_CANCELED, null)
                }
            }
            true
        } catch (_: Throwable) {
            false
        }
    }

    override fun launchCreateDocument(mimeType: String, suggestedName: String, onResult: (Uri?) -> Unit): Boolean {
        val intent = AndroidIntent(AndroidIntent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(AndroidIntent.CATEGORY_OPENABLE)
            type = if (mimeType.isNotBlank()) mimeType else "application/zip"
            putExtra(AndroidIntent.EXTRA_TITLE, suggestedName)
            addFlags(AndroidIntent.FLAG_GRANT_WRITE_URI_PERMISSION or AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION)
            if (AndroidBuild.VERSION.SDK_INT >= AndroidBuild.VERSION_CODES.O) {
                createRootDocumentUri()?.let {
                    putExtra(AndroidDocumentsContract.EXTRA_INITIAL_URI, it)
                }
            }
        }
        return launchIntentForResult(intent) { resultCode, resultIntent ->
            val u: AndroidUri? = if (resultCode == AndroidActivity.RESULT_OK) resultIntent?.data else null
            if (u != null) {
                try {
                    appContext?.contentResolver?.takePersistableUriPermission(
                        u,
                        AndroidIntent.FLAG_GRANT_WRITE_URI_PERMISSION or AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Throwable) {}
            }
            onResult(u?.let { Uri.parse(it.toString()) })
        }
    }

    override fun launchOpenDocument(mimeTypes: Array<String>, onResult: (Uri?) -> Unit): Boolean {
        val intent = AndroidIntent(AndroidIntent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(AndroidIntent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION or AndroidIntent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
            if (AndroidBuild.VERSION.SDK_INT >= AndroidBuild.VERSION_CODES.O) {
                createRootDocumentUri()?.let {
                    putExtra(AndroidDocumentsContract.EXTRA_INITIAL_URI, it)
                }
            }
        }
        return launchIntentForResult(intent) { resultCode, resultIntent ->
            val u: AndroidUri? = if (resultCode == AndroidActivity.RESULT_OK) resultIntent?.data else null
            if (u != null) {
                try {
                    appContext?.contentResolver?.takePersistableUriPermission(
                        u,
                        AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Throwable) {}
            }
            onResult(u?.let { Uri.parse(it.toString()) })
        }
    }

    override fun launchGetContent(mimeType: String, onResult: (Uri?) -> Unit): Boolean {
        val intent = AndroidIntent(AndroidIntent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(AndroidIntent.CATEGORY_OPENABLE)
            type = if (mimeType.isNotBlank()) mimeType else "*/*"
            addFlags(AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION or AndroidIntent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        return launchIntentForResult(intent) { resultCode, resultIntent ->
            val u: AndroidUri? = if (resultCode == AndroidActivity.RESULT_OK) resultIntent?.data else null
            if (u != null) {
                try {
                    appContext?.contentResolver?.takePersistableUriPermission(
                        u,
                        AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Throwable) {}
            }
            onResult(u?.let { Uri.parse(it.toString()) })
        }
    }

    override fun launchPickMultipleMedia(onResult: (List<Uri>) -> Unit): Boolean {
        val intent = AndroidIntent(AndroidIntent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(AndroidIntent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(AndroidIntent.EXTRA_MIME_TYPES, arrayOf("image/*", "video/*"))
            putExtra(AndroidIntent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION or AndroidIntent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        return launchIntentForResult(intent) { resultCode, resultIntent ->
            if (resultCode != AndroidActivity.RESULT_OK || resultIntent == null) {
                onResult(emptyList())
                return@launchIntentForResult
            }
            val list = mutableListOf<Uri>()
            val clip = resultIntent.clipData
            if (clip != null) {
                for (i in 0 until clip.itemCount) {
                    val u = clip.getItemAt(i)?.uri
                    if (u != null) {
                        try {
                            appContext?.contentResolver?.takePersistableUriPermission(
                                u,
                                AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        } catch (_: Throwable) {}
                        list.add(Uri.parse(u.toString()))
                    }
                }
            } else {
                val u = resultIntent.data
                if (u != null) {
                    try {
                        appContext?.contentResolver?.takePersistableUriPermission(
                            u,
                            AndroidIntent.FLAG_GRANT_READ_URI_PERMISSION
                        )
                    } catch (_: Throwable) {}
                    list.add(Uri.parse(u.toString()))
                }
            }
            onResult(list)
        }
    }

    // =========================================================================
    // AUTOMATIC MIGRATION FROM LEGACY ANDROID ROOM SQLITE ("zapisnyk-db")
    // =========================================================================
    override fun readLegacyRoomDatabase(): BackupData? {
        val ctx = appContext ?: return null
        try {
            val dbNames = listOf("zapisnyk-db", "diary-db", "zapisnyk.db")
            val dbFile = dbNames.mapNotNull { ctx.getDatabasePath(it) }.firstOrNull { it.exists() } ?: return null
            val db = AndroidSQLiteDatabase.openDatabase(dbFile.absolutePath, null, AndroidSQLiteDatabase.OPEN_READONLY)
            val notes = mutableListOf<DiaryNote>()
            val finances = mutableListOf<DiaryFinance>()
            val debts = mutableListOf<DiaryDebt>()
            val expected = mutableListOf<ExpectedFinance>()
            val tasks = mutableListOf<DiaryTask>()
            var shiftConfig: ShiftConfig? = null

            try {
                val c = db.rawQuery("SELECT * FROM notes", null)
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            notes.add(
                                DiaryNote(
                                    date = c.colLong("date", 0L),
                                    title = c.colString("title", ""),
                                    content = c.colString("content", ""),
                                    mediaPaths = c.colString("mediaPaths", "[]"),
                                    mainMediaPath = c.colString("mainMediaPath", ""),
                                    mood = c.colString("mood", ""),
                                    tags = c.colString("tags", ""),
                                    location = c.colString("location", "")
                                )
                            )
                        }
                    } finally {
                        try { c.close() } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}

            try {
                val c = db.rawQuery("SELECT * FROM finance", null)
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            finances.add(
                                DiaryFinance(
                                    date = c.colLong("date", 0L),
                                    income = c.colDouble("income", 0.0),
                                    expense = c.colDouble("expense", 0.0),
                                    savings_deposit = c.colDouble("savings_deposit", 0.0),
                                    debt = c.colDouble("debt", 0.0),
                                    incHistory = c.colString("incHistory", "[]"),
                                    expHistory = c.colString("expHistory", "[]"),
                                    depHistory = c.colString("depHistory", "[]"),
                                    dynamicData = c.colString("dynamicData", "{}"),
                                    dynamicBalances = c.colString("dynamicBalances", "{}")
                                )
                            )
                        }
                    } finally {
                        try { c.close() } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}

            try {
                val c = db.rawQuery("SELECT * FROM debts", null)
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            debts.add(
                                DiaryDebt(
                                    id = c.colInt("id", 0),
                                    creditor = c.colString("creditor", ""),
                                    amount = c.colDouble("amount", 0.0),
                                    dueDate = c.colLong("dueDate", 0L),
                                    isPaid = c.colInt("isPaid", 0) != 0,
                                    createdAt = c.colLong("createdAt", 0L),
                                    paidDate = c.colLong("paidDate", 0L)
                                )
                            )
                        }
                    } finally {
                        try { c.close() } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}

            try {
                val c = db.rawQuery("SELECT * FROM expected_finance", null)
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            expected.add(
                                ExpectedFinance(
                                    id = c.colInt("id", 0),
                                    title = c.colString("title", ""),
                                    amount = c.colDouble("amount", 0.0),
                                    dayOfMonth = c.colInt("dayOfMonth", 1),
                                    isIncome = c.colInt("isIncome", 0) != 0
                                )
                            )
                        }
                    } finally {
                        try { c.close() } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}

            try {
                val c = db.rawQuery("SELECT * FROM tasks", null)
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            tasks.add(
                                DiaryTask(
                                    id = c.colInt("id", 0),
                                    title = c.colString("title", ""),
                                    frequency = c.colString("frequency", "Ежедневно"),
                                    lastDoneDate = c.colString("lastDoneDate", ""),
                                    targetDate = c.colLong("targetDate", 0L),
                                    isHabit = c.colInt("isHabit", 0) != 0,
                                    streak = c.colInt("streak", 0),
                                    bestStreak = c.colInt("bestStreak", 0),
                                    historyDates = c.colString("historyDates", "[]"),
                                    subtasks = c.colString("subtasks", "[]"),
                                    timeOfDay = c.colString("timeOfDay", "ANY"),
                                    priority = c.colString("priority", "NORMAL"),
                                    category = c.colString("category", ""),
                                    videoUrl = c.colStringNull("videoUrl"),
                                    videoTitle = c.colStringNull("videoTitle")
                                )
                            )
                        }
                    } finally {
                        try { c.close() } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}

            try {
                val c = db.rawQuery("SELECT * FROM shift_config LIMIT 1", null)
                if (c != null) {
                    try {
                        if (c.moveToFirst()) {
                            shiftConfig = ShiftConfig(
                                id = c.colInt("id", 1),
                                startDate = c.colLong("startDate", 0L),
                                isActive = c.colInt("isActive", 0) != 0,
                                alarmHour = c.colInt("alarmHour", 7),
                                alarmMinute = c.colInt("alarmMinute", 0),
                                isAlarmEnabled = c.colInt("isAlarmEnabled", 0) != 0,
                                lastAlarmSetDate = c.colString("lastAlarmSetDate", ""),
                                shiftColor = c.colInt("shiftColor", 0xFFEF9A9A.toInt()),
                                pattern = c.colString("pattern", "WRRR")
                            )
                        }
                    } finally {
                        try { c.close() } catch (_: Throwable) {}
                    }
                }
            } catch (_: Throwable) {}

            try { db.close() } catch (_: Throwable) {}

            if (notes.isEmpty() && finances.isEmpty() && debts.isEmpty() && expected.isEmpty() && tasks.isEmpty() && shiftConfig == null) {
                return null
            }
            return BackupData(
                notes = notes,
                tasks = tasks,
                shiftConfig = shiftConfig,
                finances = finances,
                debts = debts,
                expectedFinances = expected,
                categoryList = null
            )
        } catch (_: Throwable) {
            return null
        }
    }

    private fun AndroidCursor.colInt(name: String, def: Int): Int {
        val idx = getColumnIndex(name)
        return if (idx >= 0 && !isNull(idx)) getInt(idx) else def
    }
    private fun AndroidCursor.colLong(name: String, def: Long): Long {
        val idx = getColumnIndex(name)
        return if (idx >= 0 && !isNull(idx)) getLong(idx) else def
    }
    private fun AndroidCursor.colDouble(name: String, def: Double): Double {
        val idx = getColumnIndex(name)
        return if (idx >= 0 && !isNull(idx)) getDouble(idx) else def
    }
    private fun AndroidCursor.colString(name: String, def: String): String {
        val idx = getColumnIndex(name)
        return if (idx >= 0 && !isNull(idx)) (getString(idx) ?: def) else def
    }
    private fun AndroidCursor.colStringNull(name: String): String? {
        val idx = getColumnIndex(name)
        return if (idx >= 0 && !isNull(idx)) getString(idx) else null
    }
}
